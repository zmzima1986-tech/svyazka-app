package app.svyazka.mobile;

/** Lightweight regression for the backwards-compatible local result envelope. */
public final class VisualProtocolChecks {
    public static void main(String[] args) {
        SandboxClient.Result old = new SandboxClient.Result("ok", "", "local", 0, "");
        if (!old.html.isEmpty() || !old.pngBase64.isEmpty() || !old.diagnostic().isEmpty()) {
            throw new AssertionError("Old console-only result changed");
        }
        SandboxClient.Result page = new SandboxClient.Result("", "", "local", 0, "",
                "<html><body>Preview</body></html>", "");
        if (!page.html.contains("Preview") || !page.pngBase64.isEmpty()) {
            throw new AssertionError("HTML output not carried separately");
        }
        SandboxClient.Result chart = new SandboxClient.Result("", "", "local", 0, "", "", "iVBORw0KGgo=");
        if (chart.pngBase64.isEmpty() || !chart.stdout.isEmpty()) {
            throw new AssertionError("Image should not be mixed into stdout");
        }
        System.out.println("3 visual protocol checks passed");
    }
}
