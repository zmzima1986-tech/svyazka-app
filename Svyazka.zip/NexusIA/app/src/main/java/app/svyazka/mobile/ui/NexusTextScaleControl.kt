package app.svyazka.mobile.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.R

/** Compact control inside the existing Appearance card in both themes. */
@Composable
internal fun NexusTextScaleControl(ui: NexusComposeUi, dark: Boolean) {
    val percent = ui.textScalePercent
    val ink = if (dark) Color.White else NexusLightDesign.ink
    val secondaryInk = if (dark) NexusDarkDesign.secondaryText else NexusLightDesign.secondary
    val outline = if (dark) NexusDarkDesign.chatBorder else NexusLightDesign.border
    val glass = if (dark) NexusDarkDesign.chatGlass else NexusLightDesign.glass

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(stringResource(R.string.settings_text_size),
            style = MaterialTheme.typography.bodyMedium,
            color = secondaryInk,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f))
        NexusScaleStepButton(
            enabled = percent > 80,
            onClick = { ui.activity.nexusTextScaleChanged(percent - 10) },
            description = stringResource(R.string.settings_text_smaller),
            ink = ink, glass = glass, outline = outline,
            increase = false)
        Text("$percent%", modifier = Modifier.widthIn(min = 48.dp),
            color = ink, style = MaterialTheme.typography.labelLarge,
            textAlign = TextAlign.Center, maxLines = 1)
        NexusScaleStepButton(
            enabled = percent < 150,
            onClick = { ui.activity.nexusTextScaleChanged(percent + 10) },
            description = stringResource(R.string.settings_text_larger),
            ink = ink, glass = glass, outline = outline,
            increase = true)
    }
}

@Composable
private fun NexusScaleStepButton(
    enabled: Boolean,
    onClick: () -> Unit,
    description: String,
    ink: Color,
    glass: Color,
    outline: Color,
    increase: Boolean
) {
    Surface(onClick = onClick, enabled = enabled,
        modifier = Modifier.size(48.dp), shape = RoundedCornerShape(12.dp),
        color = glass, border = BorderStroke(1.dp, outline),
        contentColor = ink) {
        Box(contentAlignment = Alignment.Center) {
            Icon(if (increase) Icons.Outlined.Add else Icons.Outlined.Remove,
                contentDescription = description,
                modifier = Modifier.size(20.dp),
                tint = if (enabled) ink else ink.copy(alpha = 0.35f))
        }
    }
}
