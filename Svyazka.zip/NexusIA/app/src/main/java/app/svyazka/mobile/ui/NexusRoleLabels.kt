package app.svyazka.mobile.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import app.svyazka.mobile.R

// Presentation aliases only. Stored names and the full model instructions are retained.
private val standardRoles = listOf(
    setOf("Архитектор", "Architect", "架构师", "المعماري", "設計者"),
    setOf("Ревьюер", "Критик", "Reviewer", "Critic", "评审员", "الناقد", "批評者"),
    setOf("Автор итога", "Редактор", "Final author", "Editor", "编辑", "المحرر", "編集者")
)

internal fun isStandardRole(role: String, index: Int): Boolean =
    index in standardRoles.indices && role in standardRoles[index]

@Composable
internal fun roleTitle(role: String, index: Int): String = if (isStandardRole(role, index)) {
    stringResource(listOf(R.string.role_architect, R.string.role_critic, R.string.role_editor)[index])
} else role

@Composable
internal fun roleSubtitle(role: String, index: Int): String? = if (isStandardRole(role, index)) {
    stringResource(listOf(R.string.role_architect_description, R.string.role_critic_description,
        R.string.role_editor_description)[index])
} else null
