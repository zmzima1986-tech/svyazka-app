package app.svyazka.mobile;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebMessage;
import android.webkit.WebMessagePort;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import org.json.JSONException;
import org.json.JSONObject;

final class LocalSandbox {
    private static final String HOST = "svyazka-python.invalid";
    private static final String ORIGIN = "https://" + HOST;
    private static final String PAGE = ORIGIN + "/index.html";
    private static final String CSP = "default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; "
            + "connect-src 'self'; worker-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Consumer<SandboxClient.Result> result;
    private final Consumer<String> problem;
    private Runnable deadline;
    private WebView view;
    private WebMessagePort port;

    LocalSandbox(Consumer<SandboxClient.Result> result, Consumer<String> problem) {
        this.result = result;
        this.problem = problem;
    }

    void execute(Context context, String code, String stdin) {
        execute(context, code, stdin, false);
    }

    void execute(Context context, String code, String stdin, boolean allowMatplotlib) {
        String message;
        try {
            message = new JSONObject().put("code", code).put("stdin", stdin)
                    .put("allow_matplotlib", allowMatplotlib).toString();
            view = new WebView(context);
        } catch (JSONException | RuntimeException e) {
            fail("Не удалось запустить Python. Проверь Android System WebView.");
            return;
        }

        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setDomStorageEnabled(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        view.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView page, WebResourceRequest request) {
                return bundledAsset(context, request, allowMatplotlib);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView page, WebResourceRequest request) {
                return true;
            }

            @Override public void onPageFinished(WebView page, String url) {
                if (view != page || port != null || !PAGE.equals(url)) return;
                WebMessagePort[] channel = page.createWebMessageChannel();
                port = channel[0];
                port.setWebMessageCallback(new WebMessagePort.WebMessageCallback() {
                    @Override public void onMessage(WebMessagePort sender, WebMessage output) {
                        if (port == sender) accept(output.getData());
                    }
                }, handler);
                page.postWebMessage(new WebMessage(message, new WebMessagePort[] {channel[1]}),
                        Uri.parse(ORIGIN));
            }

            @Override public void onReceivedError(WebView page, WebResourceRequest request,
                                                  WebResourceError error) {
                if (view == page && request.isForMainFrame()) fail("Не удалось открыть локальную песочницу.");
            }

            @Override public boolean onRenderProcessGone(WebView page, RenderProcessGoneDetail detail) {
                if (view == page) fail("Песочница завершилась. Проверь объём памяти, который использует код.");
                return true;
            }
        });
        deadline = () -> fail(allowMatplotlib
                ? "Загрузка пакетов и запуск Python не завершились за 180 секунд."
                : "Запуск Python на телефоне не завершился за 40 секунд.");
        handler.postDelayed(deadline, allowMatplotlib ? 180_000 : 40_000);
        view.loadUrl(PAGE);
    }

    private static WebResourceResponse bundledAsset(Context context,
                                                    WebResourceRequest request, boolean allowMatplotlib) {
        Uri url = request.getUrl();
        String path = url.getEncodedPath();
        if (allowMatplotlib && "https".equals(url.getScheme())
                && CDN_HOST.equals(url.getHost()) && path != null
                && path.startsWith(PACKAGE_PATH) && "GET".equals(request.getMethod())
                && !request.isForMainFrame()) {
            // Only explicit user opt-in enables pinned Pyodide wheel downloads.
            // Never forward keys or application data to this origin.
            return null;
        }
        if (!"GET".equals(request.getMethod()) || !"https".equals(url.getScheme())
                || !HOST.equals(url.getEncodedAuthority()) || path == null) {
            return denied();
        }
        String type;
        switch (path) {
            case "/index.html": type = "text/html"; break;
            case "/runner.js":
            case "/worker.mjs":
            case "/pyodide/pyodide.mjs":
            case "/pyodide/pyodide.asm.mjs": type = "application/javascript"; break;
            case "/pyodide/pyodide.asm.wasm": type = "application/wasm"; break;
            case "/pyodide/pyodide-lock.json": type = "application/json"; break;
            case "/pyodide/python_stdlib.zip": type = "application/zip"; break;
            default: return denied();
        }
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put("Content-Security-Policy", allowMatplotlib ? CDN_CSP : CSP);
            headers.put("X-Content-Type-Options", "nosniff");
            headers.put("Cache-Control", "no-store");
            return new WebResourceResponse(type, null, 200, "OK", headers,
                    context.getAssets().open("sandbox" + path));
        } catch (IOException e) {
            return denied();
        }
    }

    private static WebResourceResponse denied() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden",
                java.util.Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    private void accept(String message) {
        SandboxClient.Result output;
        try {
            JSONObject json = new JSONObject(message);
            if (json.has("error")) {
                fail(json.getString("error"));
                return;
            }
            Integer code = json.isNull("code") ? null : json.getInt("code");
            String html = json.optString("html", "");
            String png = json.optString("image_png", "");
            if (html.length() > 100_000 || png.length() > 700_000) {
                fail("Визуальный результат превышает безопасный лимит размера.");
                return;
            }
            output = new SandboxClient.Result(json.getString("stdout"),
                    json.getString("stderr"), json.getString("engine"), code,
                    json.optString("status"), html, png);
        } catch (JSONException | RuntimeException e) {
            fail("Не удалось прочитать вывод локальной песочницы.");
            return;
        }
        close();
        result.accept(output);
    }

    private void fail(String message) {
        close();
        problem.accept(message);
    }

    void close() {
        if (deadline != null) handler.removeCallbacks(deadline);
        deadline = null;
        if (port != null) {
            port.close();
            port = null;
        }
        if (view != null) {
            WebView previous = view;
            view = null;
            previous.destroy();
        }
    }
}
