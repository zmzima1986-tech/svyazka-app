package app.svyazka.mobile;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

/** Serve the Android automatic mode's exact Wasm binary in integration tests. */
public final class CappedWasm {
    public static void main(String[] args) throws Exception {
        try (InputStream in = VerificationMemory.limit(Files.newInputStream(Paths.get(args[0])))) {
            Files.copy(in, Paths.get(args[1]));
        }
    }
}
