package app.svyazka.mobile;

import java.util.regex.Pattern;

/** Shared path and file-size limits, independent of Android storage. */
final class PythonProjectPaths {
    static final int MAX_FILE_BYTES = 420_000;
    private static final Pattern PATH = Pattern.compile("[a-zA-Z0-9_][a-zA-Z0-9_.-]{0,63}(?:/[a-zA-Z0-9_][a-zA-Z0-9_.-]{0,63}){0,3}");
    private PythonProjectPaths() { }

    static boolean validPath(String path) {
        if (path == null || !PATH.matcher(path).matches() || path.length() > 180) return false;
        for (String part : path.split("/")) if (part.equals(".") || part.equals("..") || part.startsWith(".")) return false;
        return !path.endsWith("/");
    }
}
