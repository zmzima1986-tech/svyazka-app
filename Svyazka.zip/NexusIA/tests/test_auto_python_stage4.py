"""Safety wiring for autonomous Python repairs; does not simulate Android execution."""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java/app/svyazka/mobile'

class PythonAutoRepairWiring(unittest.TestCase):
    def test_only_checked_repairs_are_applied(self):
        main = (SRC / 'MainActivity.java').read_text()
        self.assertIn('run.verification.status == PythonVerification.Status.RAN', main)
        self.assertIn('run.verification.status == PythonVerification.Status.PASSED', main)
        self.assertIn('run.verification.matchesCheckedSource(selected.code, "")', main)
        self.assertIn('repair.alreadyTried(selected.code)', main)
        self.assertIn('repair.unchangedProject(previousCode)', main)
        self.assertIn('repair.path.equals(selected.path)', main)

    def test_failed_execution_rolls_back_before_ai_retry(self):
        main = (SRC / 'MainActivity.java').read_text()
        begin = main.index('if (output.exitCode != null && output.exitCode != 0\n')
        feedback = main.index('forwardAutoPythonFailure(source, resultProject', begin)
        self.assertIn('rollbackFailedAutoPython(', main[begin:feedback])
        self.assertIn('samePythonSnapshot(launchedFiles, projects.snapshot(projectId))', main)
        self.assertIn('projects.restorePrevious(projectId)', main)
        self.assertIn('source != run || active || clearing', main)

    def test_bounded_without_fallback(self):
        state = (SRC / 'PythonAutoRepair.java').read_text()
        main = (SRC / 'MainActivity.java').read_text()
        self.assertIn('MAX_ATTEMPTS = 3', state)
        self.assertIn('state.errors.contains(errorSignature(diagnostic))', state)
        self.assertIn('state.alreadyTried(failedCode)', state)
        self.assertIn('!state.unchangedProject(savedCode)', state)
        self.assertIn('PythonAutoRepair.next(previous, prompt', main)
        self.assertIn('PythonAutoRepair.first(prompt', main)
        self.assertIn('.withFallbackPolicy(false)', main)

    def test_translations(self):
        names = {'python_auto_repair_stopped', 'python_auto_repair_project_changed',
                 'python_auto_repair_rollback_failed'}
        for folder in ('values', 'values-en', 'values-ja', 'values-zh-rCN', 'values-ar'):
            path = ROOT / 'app/src/main/res' / folder / 'strings.xml'
            found = {item.attrib.get('name') for item in ET.parse(path).getroot()}
            self.assertTrue(names.issubset(found), folder)

if __name__ == '__main__':
    unittest.main()
