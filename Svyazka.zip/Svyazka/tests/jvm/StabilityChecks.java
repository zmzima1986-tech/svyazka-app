package app.svyazka.mobile;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONObject;

/** Deterministic 0.4.2 checks; run alongside the existing JVM suite. */
public final class StabilityChecks {
    private static int passed;

    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        passed++;
    }

    private static ModelClient.Reply stop(String text) {
        return new ModelClient.Reply(text, ModelClient.Finish.STOP, "");
    }

    public static void main(String[] args) throws Exception {
        String oldText = "header\n" + "a repeated sentence from the first provider\n";
        String overlap = "a repeated sentence from the first provider\n";
        ContinuationIntegrity.Merge dedup = ContinuationIntegrity.merge(oldText, overlap + "continuation");
        check(dedup.text.equals(oldText + "continuation") && !dedup.warnings.isEmpty(),
                "long exact overlap is deduplicated and disclosed");
        ContinuationIntegrity.Merge full = ContinuationIntegrity.merge(oldText, oldText + "new ending");
        check(full.text.equals(oldText + "new ending") && !full.warnings.isEmpty(),
                "whole repeated response is not doubled");
        check(ContinuationIntegrity.merge("Partial ", "answer").text.equals("Partial answer"),
                "short ordinary continuation remains unchanged");
        check(ContinuationIntegrity.merge("word", "again").warnings.contains(ContinuationIntegrity.WARNING_JOIN),
                "unknown word join requests manual review");
        check(ContinuationIntegrity.merge("```python\nprint(1)\n", "```\nFinished").warnings.isEmpty(),
                "legitimate closing code fence is not flagged");
        check(ContinuationIntegrity.merge("```python\nprint(1)\n", "```javascript\nalert(1)\n")
                        .warnings.contains(ContinuationIntegrity.WARNING_FENCE),
                "reopened fence inside incomplete code warns user");

        Workflow.Run base = Workflow.Run.quick("Create code", ModelCatalog.NORTH,
                Workflow.defaultStages().get(1));
        Workflow.Run interrupted = base.receive(ModelClient.Reply.error("```python\nprint(1)\n", "Network", 408));
        Workflow.Run recovered = Workflow.Run.fromJson(interrupted.toJson());
        check(recovered.draft.text.equals(interrupted.draft.text)
                        && recovered.draftMode == Workflow.DraftMode.CONTINUE,
                "network error preserves resumable draft through restart");
        Workflow.Run completed = recovered.receive(stop("```python\nprint(2)\n```"));
        check(completed.complete() && completed.answerAt(0).warnings.contains(ContinuationIntegrity.WARNING_FENCE),
                "suspicious recovered fence is visible after completion");
        check(Workflow.Run.fromJson(completed.toJson()).answerAt(0).warnings.equals(completed.answerAt(0).warnings),
                "integrity warnings survive JSON persistence");
        String repeated = "Some sufficiently long draft repeated by the next model in its entirety.";
        Workflow.Run savedDraft = base.receive(ModelClient.Reply.error(repeated, "Network", 408));
        Workflow.Run repeatedOnly = savedDraft.receive(stop(repeated));
        check(!repeatedOnly.complete() && repeatedOnly.draft.warnings.contains(ContinuationIntegrity.WARNING_OVERLAP)
                        && repeatedOnly.draft.text.equals(repeated),
                "identical repeated completion stays a visible resumable warning");
        Workflow.Run unclosed = base.receive(stop("```python\nprint(1)"));
        check(unclosed.answerAt(0).warnings.contains(ContinuationIntegrity.WARNING_UNCLOSED),
                "unclosed code block is not silently considered safe");
        Workflow.Run restoredOld = Workflow.Run.fromJson(base.receive(stop("text only")).toJson());
        check(restoredOld.answerAt(0).warnings.isEmpty(), "old JSON without warnings still loads");

        check("COMPLETED".equals(AttemptJournal.status(stop("text"), "")),
                "text on successful finish is COMPLETED, not partial");
        check("INCOMPLETE".equals(AttemptJournal.status(new ModelClient.Reply("text",
                ModelClient.Finish.LENGTH, ""), "")), "length finish remains incomplete");
        check("TIMED_OUT".equals(AttemptJournal.status(ModelClient.Reply.error("", "", 408), "TIMEOUT")),
                "timeout status is explicit");
        check("CANCELLED".equals(AttemptJournal.status(null, "CANCELLED")),
                "manual cancellation does not imply failure or fallback");
        JSONArray legacy = new JSONArray().put(new JSONObject().put("outcome", "STOP")
                .put("partial", true).put("model", "example"));
        JSONObject normalized = AttemptJournal.normalizeAll(legacy).getJSONObject(0);
        check("COMPLETED".equals(normalized.getString("status")) && normalized.getBoolean("has_text")
                        && !normalized.has("partial") && !normalized.has("outcome"),
                "old journal entries display unambiguous status while keeping metadata");
        check(legacy.getJSONObject(0).has("outcome"), "display normalization does not rewrite saved history");

        // No credentials ever pass through the PythonExecutor contract.
        CredentialStore credentials = new CredentialStore() {
            @Override public String read(Workflow.Provider provider)
                    throws GeneralSecurityException, IOException { return "secret"; }
            @Override public String readPiston() { return "piston"; }
            @Override public void save(String router, String gemini, String groq, String piston) { }
        };
        check("secret".equals(credentials.read(Workflow.Provider.GROQ)),
                "credential interface supports fake platform storage");
        List<String> executed = new ArrayList<>();
        PythonExecutor executor = new PythonExecutor() {
            @Override public void execute(String code, String stdin) { executed.add(code + ":" + stdin); }
            @Override public void cancel() { executed.clear(); }
        };
        executor.execute("print(1)", "");
        check(executed.size() == 1, "Python executor accepts code without a platform Context");
        executor.cancel();
        check(executed.isEmpty(), "Python executor supports cancellation");

        ExecutorService independent = RequestExecutor.create();
        CountDownLatch occupied = new CountDownLatch(1);
        CountDownLatch oldRelease = new CountDownLatch(1);
        Future<?> previous = independent.submit(() -> {
            occupied.countDown();
            try { oldRelease.await(); }
            catch (InterruptedException cancelled) { Thread.currentThread().interrupt(); }
        });
        try {
            check(occupied.await(3, TimeUnit.SECONDS), "old request occupies network worker");
            check("fallback".equals(independent.submit(() -> "fallback").get(3, TimeUnit.SECONDS)),
                    "reserve can run while old request still occupies a worker");
        } finally {
            previous.cancel(true);
            oldRelease.countDown();
            independent.shutdownNow();
            check(independent.awaitTermination(3, TimeUnit.SECONDS), "cancellation frees cooperative old request");
        }

        ExecutorService network = RequestExecutor.create();
        CountDownLatch started = new CountDownLatch(RequestExecutor.MAX_PARALLEL);
        CountDownLatch release = new CountDownLatch(1);
        List<Future<?>> work = new ArrayList<>();
        try {
            for (int i = 0; i < RequestExecutor.MAX_PARALLEL; i++) {
                work.add(network.submit(() -> {
                    started.countDown();
                    try { release.await(); }
                    catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                }));
            }
            check(started.await(3, TimeUnit.SECONDS), "all bounded calls can execute concurrently");
            boolean rejected = false;
            try { network.submit(() -> { }); }
            catch (RejectedExecutionException expected) { rejected = true; }
            check(rejected, "no unbounded queue can build behind stuck calls");
        } finally {
            release.countDown();
            for (Future<?> future : work) future.cancel(true);
            network.shutdownNow();
            check(network.awaitTermination(3, TimeUnit.SECONDS), "cooperative cancellations free pool workers");
        }
        System.out.println(passed + " stability checks passed");
    }
}
