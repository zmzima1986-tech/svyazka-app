Nexus AI Python Tools Drawer patch
Changed files:
- NexusIA/app/src/main/java/app/svyazka/mobile/ui/NexusPythonWorkspace.kt
- NexusIA/app/src/main/java/app/svyazka/mobile/ui/NexusPythonProjectFiles.kt
- NexusIA/app/src/main/res/values/workbench.xml
- NexusIA/app/src/main/res/values-en/workbench.xml
- NexusIA/app/src/main/res/values-ar/workbench.xml
- NexusIA/app/src/main/res/values-ja/workbench.xml
- NexusIA/app/src/main/res/values-zh-rCN/workbench.xml
