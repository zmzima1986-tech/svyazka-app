package app.svyazka.mobile;

/** Offline checks: no network, billing API or Android runtime required. */
public final class AutonomyQuotaGuardChecks {
    public static void main(String[] args) {
        long now = 1_800_000_000_000L;
        long recent = now - 5_000L;
        assert AutonomyQuotaGuard.groqExhausted(0, 999, recent, now);
        assert AutonomyQuotaGuard.groqExhausted(7000, 0, recent, now);
        assert AutonomyQuotaGuard.openRouterExhausted(0, recent, now);
        assert !AutonomyQuotaGuard.groqExhausted(-1, -1, recent, now);
        assert !AutonomyQuotaGuard.openRouterExhausted(-1, recent, now);
        assert !AutonomyQuotaGuard.groqExhausted(0, 0, now - 60_000, now);
        assert !AutonomyQuotaGuard.openRouterExhausted(0, now + 1000, now);
        assert !AutonomyQuotaGuard.openRouterExhausted(4, recent, now);
        assert !AutonomyQuotaGuard.groqExhausted(0, 0, 0, now);
        System.out.println("AutonomyQuotaGuard: 9 checks passed");
    }
}
