package app.svyazka.mobile;

import static org.junit.Assert.*;
import org.junit.Test;

/** Offline regression tests: console filtering cannot discard unique user requirements. */
public class ConsoleInstructionBudgetTest {
    private Workflow.Run run(String task) {
        return Workflow.Run.quick(task, ModelCatalog.GROQ_120B,
                Workflow.defaultStages().get(Workflow.Step.REVIEW.ordinal()));
    }

    @Test public void explicitConsolePythonSavesOnlyWebWidgetInstructions() {
        Workflow.Run request = run("Напиши программу на Python для сложения 15 и 25. В консоли [console].");
        String rules = request.instructions();
        assertFalse(rules.contains("data-nexus"));
        assertFalse(rules.contains("Для виджета без указанной платформы"));
        assertTrue(rules.contains("Не выдумывай данные."));
        assertTrue(rules.contains("Не заменяй GUI консолью без запроса."));
        assertTrue(rules.contains("Сохрани все ранее запрошенные функции"));
        assertTrue(request.consoleInstructionBytesSaved() > 600);
        assertTrue(request.estimatedConsoleInstructionTokensSaved() > 0);
    }

    @Test public void webWidgetStillReceivesEveryWidgetRule() {
        Workflow.Run request = run("Создай HTML-виджет часов с погодой.");
        assertTrue(request.instructions().contains("data-nexus"));
        assertTrue(request.instructions().contains("покажи источник, город и ошибку сети"));
        assertEquals(0, request.consoleInstructionBytesSaved());
    }

    @Test public void consoleWeatherPythonKeepsWeatherSafetyRules() {
        Workflow.Run request = run("Напиши Python программу погоды в консоли [console].");
        assertTrue(request.instructions().contains("покажи источник, город и ошибку сети"));
        assertTrue(request.instructions().contains("data-nexus"));
        assertEquals(0, request.consoleInstructionBytesSaved());
    }

    @Test public void explicitWidgetAndConsoleMustNotLoseWebRequirements() {
        Workflow.Run request = run("Напиши Python виджет календаря для консоли [console].");
        assertTrue(request.instructions().contains("data-nexus"));
        assertEquals(0, request.consoleInstructionBytesSaved());
    }

    @Test public void androidMentionWithConsoleIsAmbiguousSoKeepFullRules() {
        Workflow.Run request = run("Напиши Python-код для Android. В консоли [console].");
        assertTrue(request.instructions().contains("data-nexus"));
        assertEquals(0, request.consoleInstructionBytesSaved());
    }

    @Test public void noExplicitPythonOrConsoleMustNotBeFiltered() {
        Workflow.Run request = run("Объясни, что такое рекурсия.");
        assertTrue(request.instructions().contains("data-nexus"));
        assertEquals(0, request.consoleInstructionBytesSaved());
        assertEquals(0, request.estimatedConsoleInstructionTokensSaved());
    }

    @Test public void plainConsoleRequestWithoutPythonIsNotAssumedPython() {
        Workflow.Run request = run("Напиши руководство для консоли [console].");
        assertTrue(request.instructions().contains("data-nexus"));
        assertEquals(0, request.consoleInstructionBytesSaved());
    }

    @Test public void desktopPythonIsNotConsolePython() {
        Workflow.Run request = run("Напиши Python-приложение для компьютера с графическим интерфейсом [desktop].");
        assertTrue(request.instructions().contains("data-nexus"));
        assertEquals(0, request.consoleInstructionBytesSaved());
    }

    @Test public void serializedPromptAndTaskRemainUntouched() throws Exception {
        Workflow.Run request = run("Напиши Python-программу в консоли [console], выведи 40.");
        String taskBefore = request.task;
        String promptBefore = request.prompt();
        assertTrue(request.consoleInstructionBytesSaved() > 0);
        assertEquals(taskBefore, request.task);
        assertEquals(promptBefore, request.prompt());
    }
}
