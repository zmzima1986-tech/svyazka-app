"""Source regression checks for the attachment glass and nested-panel close fix.

These checks cannot establish rendered frame timing without an Android device.
"""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/svyazka/mobile/ui'


class GlassCloseV21(unittest.TestCase):
    def test_nested_tool_sheet_exits_without_full_screen_fade_or_dim_patch(self):
        source = (UI / 'NexusPythonWorkspace.kt').read_text(encoding='utf-8')
        self.assertIn('exit = ExitTransition.None', source)
        self.assertIn('enter = fadeIn(tween(130))', source)
        self.assertNotIn('.background(Color.Black.copy(alpha = .52f))', source)
        self.assertIn('toolDrag * dismissDirection >= dismissThreshold', source)
        self.assertIn('BackHandler(enabled = toolPanel != null)', source)
        self.assertIn('PythonToolPanel.FILES -> PythonProjectFileManager(ui)', source)

    def test_chat_plus_and_composer_corners(self):
        source = (UI / 'NexusChat.kt').read_text(encoding='utf-8')
        self.assertIn('val composerShape = RoundedCornerShape(32.dp)', source)
        self.assertIn('modifier = Modifier.size(50.dp)', source)
        self.assertIn('modifier = Modifier.size(38.dp)', source)
        self.assertIn('Icons.Filled.Add, stringResource(R.string.chat_options)', source)
        self.assertEqual(source.count('DropdownMenuItem('), 4)

    def test_attachment_sheet_uses_matching_rounded_matte_glass(self):
        source = (UI / 'NexusAttachments.kt').read_text(encoding='utf-8')
        self.assertIn('RoundedCornerShape(30.dp)', source)
        self.assertIn('Dialog(', source)
        self.assertIn('DialogProperties(usePlatformDefaultWidth = false)', source)
        self.assertIn('RoundedCornerShape(30.dp)', source)
        self.assertIn('Modifier.widthIn(max = 460.dp).fillMaxWidth()', source)
        self.assertIn('BorderStroke(1.dp, menuBorder)', source)
        self.assertIn('Color(0xFF14243A).copy(alpha = .88f)', source)
        self.assertIn('Color(0xFFF5F9FF).copy(alpha = .90f)', source)
        self.assertIn('.heightIn(min = 52.dp)', source)
        self.assertNotIn('ModalBottomSheet(', source)
        self.assertNotIn('modifier = Modifier.border(', source)
        self.assertIn('AttachmentAction(Icons.Outlined.PhotoCamera', source)
        self.assertIn('AttachmentAction(Icons.Outlined.PhotoLibrary', source)
        self.assertIn('AttachmentAction(Icons.Outlined.AttachFile', source)


if __name__ == '__main__':
    unittest.main()
