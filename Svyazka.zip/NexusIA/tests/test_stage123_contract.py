"""Static contracts for changes in reliability stages 1-3.

These checks do not replace Android, JVM or provider integration tests.
"""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'
UI = JAVA / 'ui'


class ReliabilityContract(unittest.TestCase):
    def test_completion_and_verification_are_separate(self):
        chat = (UI / 'NexusChat.kt').read_text()
        screen = (UI / 'NexusScreens.kt').read_text()
        self.assertIn('verificationOutcomeLabel(check, state.resultHasPython)', chat)
        self.assertIn('ui_python_not_verified', screen)
        self.assertIn('ui_verification_unconfirmed', screen)
        self.assertIn('!state.resultHasPython && !checkedPython', screen)

    def test_uncertain_python_not_silently_marked_valid(self):
        inputs = (JAVA / 'PythonInputs.java').read_text()
        integrity = (JAVA / 'ContinuationIntegrity.java').read_text()
        workflow = (JAVA / 'Workflow.java').read_text()
        self.assertIn('Внутри блока кода повторена метка python.', inputs)
        self.assertIn('Не закрыт блок Python.', inputs)
        self.assertIn('WARNING_REPLACED', integrity)
        self.assertIn('DraftMode.CONTINUE', workflow)
        self.assertIn('python_artifact', workflow)

    def test_unverified_python_export_not_disguised_as_source(self):
        save = (UI / 'NexusFileActions.kt').read_text()
        self.assertIn('PythonInputs.candidate(answer)', save)
        self.assertIn('python.ambiguous || python.issue.isNotEmpty()', save)
        self.assertIn('SavePayload("result.md", answer)', save)

    def test_provider_tpm_and_context_distinction(self):
        failures = (JAVA / 'RequestFailure.java').read_text()
        client = (JAVA / 'ModelClient.java').read_text()
        models = (JAVA / 'ModelPool.java').read_text()
        self.assertIn('tokens per minute', failures)
        self.assertIn('CONTEXT_LIMIT', failures)
        self.assertIn('TOKEN_RATE_LIMIT', failures)
        self.assertIn('Это не размер контекстного окна', client)
        self.assertIn('reply.status == 413 && reply.failure.reason == RequestFailure.Reason.TOKEN_RATE_LIMIT', models)

    def test_history_keeps_code_not_generated_explanations(self):
        history = (JAVA / 'TaskHistory.java').read_text()
        workflow = (JAVA / 'Workflow.java').read_text()
        self.assertIn('previousSource(answer)', history)
        self.assertIn('TaskHistory.forRepair(task)', workflow)
        self.assertIn('Исходная задача пользователя', history)

    def test_verification_strings_present_in_all_locales(self):
        resources = ROOT / 'app/src/main/res'
        names = {
            'ui_ai_answer_completed', 'ui_python_not_verified',
            'ui_verification_failed', 'ui_verification_unconfirmed'
        }
        for locale in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            tree = ET.parse(resources / locale / 'strings.xml')
            actual = {node.attrib['name'] for node in tree.getroot().findall('string')}
            self.assertTrue(names.issubset(actual), locale)


if __name__ == '__main__':
    unittest.main()
