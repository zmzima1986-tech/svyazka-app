package app.svyazka.mobile.ui

import android.os.SystemClock
import android.graphics.Color
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.MainActivity
import app.svyazka.mobile.NexusState
import app.svyazka.mobile.NexusPythonReport
import app.svyazka.mobile.R

/** UI boundary; no request execution or SQLite/Keystore access happens here. */
class NexusComposeUi(val activity: MainActivity) {
    enum class Page { TASK, RESULT, MODELS, HISTORY, SETTINGS }

    var snapshot by mutableStateOf(activity.nexusSnapshot())
        private set
    var draft by mutableStateOf(snapshot.task)
        private set
    fun draftChanged(value: String) { draft = value; activity.nexusDraftChanged(value) }
    var page by mutableStateOf(Page.TASK)
        private set
    var theme by mutableStateOf(activity.nexusThemeChoice())
        private set
    var streaming by mutableStateOf("")
        private set
    var visualPng by mutableStateOf("")
        private set
    var visualHtml by mutableStateOf("")
        private set
    var visualOpen by mutableStateOf(false)
        private set
    private var lastStreamAt = 0L
    var pythonCodeBlocks by mutableStateOf(emptyList<String>())
        private set
    var pythonStep by mutableIntStateOf(0)
        private set
    var pythonHasPiston by mutableStateOf(false)
        private set
    var pythonBusy by mutableStateOf(false)
        private set
    var pythonReport by mutableStateOf<NexusPythonReport?>(null)
        private set
    var pythonError by mutableStateOf<String?>(null)
        private set
    fun requestPython(step: Int, codes: Array<String>, hasPiston: Boolean) {
        pythonStep = step
        pythonCodeBlocks = codes.toList()
        pythonHasPiston = hasPiston
    }
    fun dismissPythonInput() { pythonCodeBlocks = emptyList() }
    fun pythonStarted() { pythonCodeBlocks = emptyList(); pythonBusy = true; pythonReport = null; pythonError = null }
    fun pythonFinished(report: NexusPythonReport) { pythonBusy = false; pythonReport = report }
    fun pythonFailed(error: String) { pythonBusy = false; pythonError = error }
    fun pythonCancelled() { pythonBusy = false; pythonError = null; pythonReport = null }
    fun dismissPythonResult() { pythonReport = null; pythonError = null }

    var versionsRequested by mutableStateOf(false)
        private set
    fun requestVersions() { versionsRequested = true }
    fun dismissVersions() { versionsRequested = false }
    var keysRequested by mutableStateOf(false)
        private set
    fun requestKeys() { keysRequested = true }
    fun dismissKeys() { keysRequested = false }

    var newTaskConfirm by mutableIntStateOf(0)
        private set
    fun requestNewTask() { if (!snapshot.active && !snapshot.clearing) newTaskConfirm = 1 }
    fun nextNewTaskConfirm() { if (newTaskConfirm == 1) newTaskConfirm = 2 }
    fun dismissNewTask() { newTaskConfirm = 0 }
    fun closeVisual() { visualOpen = false }

    fun mount() {
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        val compose = ComposeView(activity)
        compose.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
        activity.setContentView(compose)
        compose.setContent { NexusApp(this) }
    }

    fun render(updated: NexusState, newPage: Page?) {
        snapshot = updated
        if (updated.task != draft) draft = updated.task
        if (newPage != null) page = newPage
        if (!updated.active) streaming = ""
    }

    fun open(newPage: Page) { page = newPage }

    fun onStreaming(text: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastStreamAt < 110) return
        lastStreamAt = now
        streaming = if (text.length > 5000) text.takeLast(5000) else text
    }

    fun onThemeChanged(value: String) { theme = value }
    fun onVisualAvailable(available: Boolean) {
        if (!available) { visualPng = ""; visualHtml = "" }
        snapshot = activity.nexusSnapshot()
    }
    fun cacheVisual(png: String, html: String) { visualPng = png; visualHtml = html }
    fun showVisual(png: String, html: String) {
        cacheVisual(png, html)
        visualOpen = true
    }
    fun openVisual() {
        if (visualPng.isNotBlank() || visualHtml.isNotBlank()) visualOpen = true
    }

    fun navigateBack(): Boolean {
        if (visualOpen) { visualOpen = false; return true }
        if (page == Page.MODELS || page == Page.SETTINGS || page == Page.HISTORY) {
            page = if (snapshot.hasRun) Page.RESULT else Page.TASK
            return true
        }
        if (page == Page.RESULT) {
            activity.nexusOpenTaskEditor()
            return true
        }
        return false
    }
}

@Composable
private fun NexusApp(ui: NexusComposeUi) {
    val state = ui.snapshot
    val activity = ui.activity
    val darkMode = ui.theme == "dark" || (ui.theme == "system" && androidx.compose.foundation.isSystemInDarkTheme())

    SideEffect {
        @Suppress("DEPRECATION")
        activity.window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        activity.window.navigationBarColor = Color.TRANSPARENT
        val controller = WindowInsetsControllerCompat(activity.window, activity.window.decorView)
        controller.isAppearanceLightStatusBars = !darkMode
        controller.isAppearanceLightNavigationBars = !darkMode
    }

    NexusTheme(ui.theme) {
        val rtl = androidx.compose.ui.platform.LocalConfiguration.current.layoutDirection == android.view.View.LAYOUT_DIRECTION_RTL
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.ui.platform.LocalLayoutDirection provides
                if (rtl) androidx.compose.ui.unit.LayoutDirection.Rtl else androidx.compose.ui.unit.LayoutDirection.Ltr
        ) {
            BackHandler(enabled = true) {
                if (!ui.navigateBack()) activity.finish()
            }
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = { NexusTopBar(ui) },
                bottomBar = { NexusBottomBar(ui) }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (ui.page) {
                        NexusComposeUi.Page.TASK -> TaskScreen(ui)
                        NexusComposeUi.Page.RESULT -> ResultScreen(ui)
                        NexusComposeUi.Page.HISTORY -> HistoryScreen(ui)
                        NexusComposeUi.Page.MODELS -> ModelsScreen(ui)
                        NexusComposeUi.Page.SETTINGS -> SettingsScreen(ui)
                    }
                }
            }
            if (ui.newTaskConfirm > 0) {
                AlertDialog(onDismissRequest = { ui.dismissNewTask() },
                    title = { Text(stringResource(if (ui.newTaskConfirm == 1)
                        R.string.confirm_new_first else R.string.confirm_new_second)) },
                    text = { Text(stringResource(if (ui.newTaskConfirm == 1)
                        R.string.confirm_new_first_message else R.string.confirm_new_second_message)) },
                    confirmButton = { TextButton(onClick = {
                        if (ui.newTaskConfirm == 1) ui.nextNewTaskConfirm()
                        else { ui.dismissNewTask(); ui.activity.nexusCreateTask() }
                    }) { Text(stringResource(if (ui.newTaskConfirm == 1)
                        R.string.action_continue else R.string.action_create)) } },
                    dismissButton = { TextButton(onClick = { ui.dismissNewTask() }) {
                        Text(stringResource(R.string.action_cancel))
                    } })
            }
            if (ui.keysRequested) KeysDialog(ui) { ui.dismissKeys() }
            if (ui.versionsRequested) VersionsDialog(ui)
            PythonDialogs(ui)
            VisualResultOverlay(ui)
        }
    }
}

@Composable
private fun NexusBottomBar(ui: NexusComposeUi) {
    val page = ui.page
    Box {
        NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
            NavigationBarItem(selected = page == NexusComposeUi.Page.TASK || page == NexusComposeUi.Page.RESULT,
                onClick = { ui.activity.nexusOpenTaskEditor() },
                icon = { Icon(Icons.Outlined.Home, null) }, label = { Text(stringResource(R.string.nav_home)) })
            NavigationBarItem(selected = page == NexusComposeUi.Page.MODELS,
                onClick = { ui.open(NexusComposeUi.Page.MODELS) },
                icon = { Icon(Icons.Outlined.SmartToy, null) }, label = { Text(stringResource(R.string.nav_models)) })
            Spacer(Modifier.weight(1f))
            NavigationBarItem(selected = page == NexusComposeUi.Page.HISTORY,
                onClick = { ui.activity.nexusOpenHistory() },
                icon = { Icon(Icons.Outlined.History, null) }, label = { Text(stringResource(R.string.nav_history)) })
            NavigationBarItem(selected = page == NexusComposeUi.Page.SETTINGS,
                onClick = { ui.open(NexusComposeUi.Page.SETTINGS) },
                icon = { Icon(Icons.Outlined.Settings, null) }, label = { Text(stringResource(R.string.nav_profile)) })
        }
        FloatingActionButton(onClick = { ui.open(NexusComposeUi.Page.TASK); ui.requestNewTask() },
            modifier = Modifier.align(Alignment.TopCenter).offset(y = (-10).dp).size(56.dp),
            containerColor = NexusCyan, contentColor = NexusNavy) {
            Icon(Icons.Default.Add, stringResource(R.string.action_new_task))
        }
    }
}
