package app.svyazka.mobile.ui

import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Use identical wrapping in both themes, accounting for the selected text scale. */
internal fun nexusThemeChoicesInOneRow(availableWidth: Dp, fontScale: Float): Boolean {
    val buttonWidth = (availableWidth - 16.dp) / 3 // Two 8.dp gaps.
    return buttonWidth >= 86.dp * fontScale
}
