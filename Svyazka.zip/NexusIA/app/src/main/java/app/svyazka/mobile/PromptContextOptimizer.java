package app.svyazka.mobile;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Lossless cross-reference of large, byte-identical content within a SINGLE model request.
 * Never assumes the model can access SQLite, another request, or an external cache.
 * Never shortens unique source files, unfinished code, test expectations or diagnostics.
 */
final class PromptContextOptimizer {
    private static final int MIN_DUPLICATE_BYTES = 256;
    private static final String LINK_START = "\n\n<linked_python_project>\n";
    private static final String LINK_END = "</linked_python_project>";

    private PromptContextOptimizer() { }

    static JSONObject compact(JSONObject outgoing) throws JSONException {
        JSONObject inputs = outgoing.optJSONObject("inputs");
        if (inputs == null) return outgoing;
        compactIdenticalRepairFile(inputs);
        compactLinkedProject(outgoing, inputs);
        return outgoing;
    }

    /** A repair may otherwise send one file twice: as python_code AND complete_project[path]. */
    private static void compactIdenticalRepairFile(JSONObject inputs) throws JSONException {
        JSONObject diagnostic = inputs.optJSONObject("sandbox_result");
        if (diagnostic == null) return;
        JSONObject project = diagnostic.optJSONObject("complete_project");
        if (project == null) return;
        String source = diagnostic.optString("python_code", "");
        if (utf8Length(source) < MIN_DUPLICATE_BYTES) return;
        Iterator<String> names = project.keys();
        while (names.hasNext()) {
            String name = names.next();
            Object value = project.opt(name);
            if (value instanceof String && source.equals(value)) {
                project.put(name, "[Exact copy of sandbox_result.python_code; "
                        + "same bytes, SHA-256=" + sha256(source) + "]");
            }
        }
    }

    /**
     * Elide only a second, byte-identical copy of a complete linked file when the
     * SAME request already carries that source in a prior answer, repair diagnostic,
     * or the earlier part of its task. A file is never removed from every location.
     * Partial, truncated, modified and unverified file sections remain untouched.
     */
    private static void compactLinkedProject(JSONObject outgoing, JSONObject inputs)
            throws JSONException {
        String task = outgoing.optString("task", "");
        int begin = task.indexOf(LINK_START);
        if (begin < 0) return;
        int end = task.indexOf(LINK_END, begin + LINK_START.length());
        if (end < 0) return;
        // Only source text BEFORE this snapshot can prove a duplicate.
        // Searching the entire task would falsely match the snapshot against itself.
        String earlierTask = task.substring(0, begin);

        StringBuilder reduced = new StringBuilder(task.length());
        int lastCopied = 0;
        int search = begin + LINK_START.length();
        boolean changed = false;
        while (search < end) {
            // ChatProjectContext emits a header before each included file.
            int header = task.indexOf("\n--- ", search);
            if (header < 0 || header >= end) break;
            int close = task.indexOf(" bytes) ---\n", header + 6);
            if (close < 0 || close >= end) break;
            String declared = task.substring(header + 5, close);
            int separator = declared.lastIndexOf(" (");
            if (separator < 1) {
                search = close + " bytes) ---\n".length();
                continue;
            }
            String byteCount = declared.substring(separator + 2);
            // Strictly validate metadata. Malformed or hand-crafted text is left alone.
            if (!byteCount.matches("[0-9]{1,7}")) {
                search = close + " bytes) ---\n".length();
                continue;
            }
            int fileBytes;
            try { fileBytes = Integer.parseInt(byteCount); }
            catch (NumberFormatException invalid) { search = close + " bytes) ---\n".length(); continue; }
            int sourceStart = close + " bytes) ---\n".length();
            if (sourceStart >= end) break;
            int sourceEnd = utf8Advance(task, sourceStart, fileBytes, end);
            // A truncated, malformed or manipulated section cannot be parsed safely.
            if (sourceEnd < sourceStart) break;
            if (fileBytes >= MIN_DUPLICATE_BYTES && sourceEnd > sourceStart
                    && sourceEnd < end && task.charAt(sourceEnd) == '\n') {
                String contents = task.substring(sourceStart, sourceEnd);
                // The source must be followed by the exact separator ChatProjectContext emits.
                int after = sourceEnd + 1;
                boolean safeBoundary = task.startsWith("\n--- ", after)
                        || task.startsWith(LINK_END, after)
                        || task.startsWith("\n[Additional files omitted due to request size:", after);
                String reference = safeBoundary ? existingSourceReference(contents, earlierTask, inputs) : null;
                if (reference != null) {
                    reduced.append(task, lastCopied, sourceStart);
                    reduced.append("[Exact copy of ").append(reference)
                            .append("; SHA-256=").append(sha256(contents)).append(']');
                    lastCopied = sourceEnd;
                    changed = true;
                }
            }
            search = sourceEnd > sourceStart ? sourceEnd + 1 : sourceStart;
        }
        if (changed) {
            reduced.append(task, lastCopied, task.length());
            String rewritten = reduced.toString();
            // An actual reduction is required; never make short files more expensive.
            if (utf8Length(rewritten) < utf8Length(task)) outgoing.put("task", rewritten);
        }
    }

    /** Reference locations all belong to this outgoing request; no cross-request cache. */
    private static String existingSourceReference(String source, String earlierTask, JSONObject inputs) {
        JSONObject solution = inputs.optJSONObject("solution");
        if (solution != null && solution.optString("text", "").contains(source))
            return "inputs.solution.text";

        JSONObject diagnostic = inputs.optJSONObject("sandbox_result");
        if (diagnostic != null) {
            if (diagnostic.optString("python_code", "").equals(source))
                return "inputs.sandbox_result.python_code";
            JSONObject project = diagnostic.optJSONObject("complete_project");
            if (project != null) {
                Iterator<String> names = project.keys();
                while (names.hasNext()) {
                    String name = names.next();
                    Object value = project.opt(name);
                    if (value instanceof String && source.equals(value))
                        return "inputs.sandbox_result.complete_project[" + name + "]";
                }
            }
        }
        if (earlierTask.contains(source)) return "earlier task text";
        return null;
    }

    private static int utf8Advance(String text, int start, int desiredBytes, int limit) {
        int consumed = 0;
        int index = start;
        while (index < limit && consumed < desiredBytes) {
            char first = text.charAt(index);
            if (Character.isSurrogate(first)
                    && !(Character.isHighSurrogate(first) && index + 1 < limit
                    && Character.isLowSurrogate(text.charAt(index + 1)))) return -1;
            int cp = text.codePointAt(index);
            int bytes = cp <= 0x7f ? 1 : cp <= 0x7ff ? 2 : cp <= 0xffff ? 3 : 4;
            if (consumed + bytes > desiredBytes) return -1;
            consumed += bytes;
            index += Character.charCount(cp);
        }
        return consumed == desiredBytes ? index : -1;
    }

    private static int utf8Length(String text) {
        return text.getBytes(StandardCharsets.UTF_8).length;
    }

    private static String sha256(String value) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder(hash.length * 2);
            for (byte item : hash) hex.append(Character.forDigit((item >>> 4) & 15, 16))
                    .append(Character.forDigit(item & 15, 16));
            return hex.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 unavailable", impossible);
        }
    }
}
