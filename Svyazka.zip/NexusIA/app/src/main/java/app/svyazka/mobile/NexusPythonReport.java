package app.svyazka.mobile;

/** UI-only report from a completed Python attempt; no tokens or private credentials. */
public final class NexusPythonReport {
    public final String engine;
    public final String stdout;
    public final String stderr;
    public final String status;
    public final String diagnostic;
    public final Integer exitCode;
    public final boolean hasVisual;

    public NexusPythonReport(String engine, String stdout, String stderr, String status,
                             String diagnostic, Integer exitCode, boolean hasVisual) {
        this.engine = engine;
        this.stdout = stdout;
        this.stderr = stderr;
        this.status = status;
        this.diagnostic = diagnostic;
        this.exitCode = exitCode;
        this.hasVisual = hasVisual;
    }
}
