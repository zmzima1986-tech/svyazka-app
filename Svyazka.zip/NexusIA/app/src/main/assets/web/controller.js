"use strict";
// Only this shell is the Android page. The user document is never inserted into its DOM.
function inspectSource(source, kind) {
    const result = { checked: 0, external: 0, issues: [] };
    function parseScript(body, mode, name, handler) {
        try {
            acorn.parse(handler ? "function eventHandler(event){\n" + body + "\n}" : body,
                { ecmaVersion: "latest", sourceType: mode, allowHashBang: true });
            result.checked++;
        } catch (error) { result.issues.push(name + ": " + error.message); }
    }
    if (kind === "javascript") {
        try { acorn.parse(source, { ecmaVersion: "latest", sourceType: "script" }); result.checked++; }
        catch (_) { parseScript(source, "module", "JavaScript", false); }
    } else if (kind === "html") {
        const doc = new DOMParser().parseFromString(source, "text/html");
        for (const [index, script] of [...doc.querySelectorAll("script")].entries()) {
            const type = (script.type || "").trim().toLowerCase().split(";")[0];
            if (type && type !== "module" && !/^(?:text|application)\/(?:javascript|ecmascript)$/.test(type)) continue;
            if (script.hasAttribute("src")) { result.external++; continue; }
            parseScript(script.textContent, type === "module" ? "module" : "script", "script " + (index + 1), false);
        }
        for (const el of doc.querySelectorAll("*")) {
            for (const attr of el.attributes) {
                if (/^on[a-z]+$/i.test(attr.name)) parseScript(attr.value, "script", attr.name, true);
            }
        }
    }
    const resources = new Set();
    if (kind === "html") {
        const doc = new DOMParser().parseFromString(source, "text/html");
        for (const node of doc.querySelectorAll("[src],link[href],video[poster],object[data]")) {
            const value = node.getAttribute("src") || node.getAttribute("href") || node.getAttribute("poster") || node.getAttribute("data") || "";
            if (value && !/^(?:data:|#)/i.test(value)) resources.add(value.split(/[?#]/)[0]);
        }
        for (const match of source.matchAll(/(?:url\(\s*|@import\s+)["']?([^\s"')<>]+)/gi))
            if (!/^(?:data:|#)/i.test(match[1])) resources.add(match[1].split(/[?#]/)[0]);
    }
    if (resources.size) result.resources = [...resources];
    if (/\bfetch\s*\(|XMLHttpRequest|WebSocket\s*\(|https?:\/\//i.test(source)) result.network = true;
    if (/navigator\s*\.\s*bluetooth|requestDevice\s*\(/i.test(source)) result.bluetooth = true;
    return JSON.stringify(result);
}
function sandboxFrame(source, bootstrap = "") {
    const frame = document.createElement("iframe");
    frame.setAttribute("sandbox", "allow-scripts");
    frame.referrerPolicy = "no-referrer";
    frame.setAttribute("allow", "camera 'none'; microphone 'none'; geolocation 'none'; bluetooth 'none'; payment 'none'; usb 'none'");
    const policy = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; frame-src 'none'; child-src 'none'; worker-src 'none'; form-action 'none'; base-uri 'none'; object-src 'none'";
    // Prefix the policy even for fragments. A later, untrusted policy can only restrict it.
    frame.srcdoc = "<!doctype html><meta charset=utf-8><meta http-equiv=Content-Security-Policy content=\"" + policy + "\">" + bootstrap + source;
    return frame;
}
function renderSource(source, kind) {
    if (kind !== "html") return false;
    const frame = sandboxFrame(source);
    window.previewLoaded = false;
    frame.onload = () => { window.previewLoaded = true; };
    document.body.replaceChildren(frame);
    return true;
}

// Serialized into the opaque frame before the submitted document begins to execute.
function widgetProbe(options, token) {
    const send = parent.postMessage.bind(parent);
    const later = setTimeout.bind(window);
    const NativeDate = Date, realNow = NativeDate.now.bind(NativeDate);
    const started = realNow();
    const base = options.date ? new NativeDate(...options.date, 12, 0, 5).getTime() : started;
    function SimDate(...args) {
        if (!new.target) return new NativeDate(SimDate.now()).toString();
        return new NativeDate(...(args.length ? args : [SimDate.now()]));
    }
    Object.setPrototypeOf(SimDate, NativeDate);
    SimDate.prototype = NativeDate.prototype;
    SimDate.now = () => base + realNow() - started;
    if (options.date) window.Date = SimDate;
    let requests = 0;
    const sample = options.temperature;
    window.fetch = async function(input) {
        const url = new URL(typeof input === "string" ? input : input.url || input.href, location.href);
        if (url.origin !== "https://api.open-meteo.com" || url.pathname !== "/v1/forecast" ||
            !["latitude","longitude"].every(k => url.searchParams.has(k) && Number.isFinite(Number(url.searchParams.get(k))))) throw TypeError("Unsupported offline fixture");
        requests++;
        if (options.offline) throw TypeError("Failed to fetch");
        const data = {current_weather:{temperature:sample,weathercode:0,windspeed:3},
            current:{temperature_2m:sample,weather_code:0,wind_speed_10m:3},current_units:{temperature_2m:"°C"}};
        return new Response(JSON.stringify(data), {headers:{"Content-Type":"application/json"}});
    };
    const query = s => document.querySelector(s);
    const shown = n => n && n.getClientRects().length && getComputedStyle(n).visibility !== "hidden";
    const read = n => shown(n) ? n.innerText.trim() : "";
    const clock = () => {
        const el = query('[data-nexus="clock"],#clock,#clockTime,time');
        const m = (el ? read(el) : read(document.body)).match(/(?:^|\D)(\d{1,2}):(\d{2}):(\d{2})(?!\d)/);
        return m && Number(m[1])<24 && Number(m[2])<60 && Number(m[3])<60 ?
            Number(m[1])*3600+Number(m[2])*60+Number(m[3]) : null;
    };
    const result = [];
    function record(id, status, detail) { result.push({id,status,detail}); }
    function calendarState(date) {
        const grid = query('[data-nexus="calendar"],#calendarTable,#calendarGrid,#calendar,.calendar');
        const year = date.getFullYear(), month = date.getMonth();
        const last = new NativeDate(year,month+1,0).getDate();
        const cells = grid ? [...grid.querySelectorAll('td,[role="gridcell"],button,div,span')].filter(el=>shown(el) && el.childElementCount===0).map(read)
            .filter(v=>/^\d{1,2}$/.test(v)).map(Number) : [];
        const header = read(query('[data-nexus="month"],#date,#monthYear,#monthLabel')) || read(grid && grid.parentElement);
        const monthNames = [...new Set([document.documentElement.lang || "en","en","ru","ja","ar","zh","de","fr","es"])]
            .flatMap(lang=>{try{return ["long","short"].map(format=>date.toLocaleString(lang,{month:format}).toLowerCase());}catch(_){return [];}});
        const matchesMonth = monthNames.some(name=>name && header.toLowerCase().includes(name)) ||
            header.includes(year+"-"+String(month+1).padStart(2,"0"));
        const days = Array.from({length:last},(_,i)=>i+1);
        const exact = cells.some((_,i)=>days.every((v,j)=>cells[i+j]===v) && cells[i+last]!==last+1);
        return {status:!cells.length || !header ? "unverified" :
            exact && header.includes(String(year)) && matchesMonth ? "pass" : "fail",
            detail:{year,month:month+1,last}};
    }
    document.currentScript.remove();
    document.addEventListener("DOMContentLoaded", () => later(() => {
        const t0 = clock(), start = realNow();
        const ticks=[];
        let previous=t0, lastChange=start, sampledAt=start, gap=0;
        const timer = options.clock ? setInterval(() => {
            const value=clock(), time=realNow();
            gap=Math.max(gap,time-sampledAt);
            sampledAt=time;
            if (value!==null && previous!==null && value!==previous) {
                ticks.push({step:(value-previous+86400)%86400,ms:time-lastChange});
                lastChange=time;
            }
            previous=value;
        },95) : null;
        later(() => {
            if (timer!==null) clearInterval(timer);
            if (options.clock) {
                const t1 = clock(), elapsed = (realNow()-start)/1000;
                const actual = t0 == null || t1 == null ? null : (t1-t0+86400)%86400;
                const now = new NativeDate(base + realNow()-started);
                const expected = now.getHours()*3600+now.getMinutes()*60+now.getSeconds();
                const offset = t1 == null ? 0 : (t1-expected+86400)%86400;
                record("clock.tick", actual == null || elapsed > 4 || gap>650 ? "unverified" :
                    ticks.length>=2 && ticks.every((t,i)=>t.step===1 && (i===0 || t.ms<=1400)) && Math.abs(actual-elapsed)<=1 && Math.min(offset,86400-offset)<=1 ? "pass":"fail",
                    {seconds:actual, observed_ticks:ticks.length, elapsed_ms:Math.round(elapsed*1000)});
            }
            if (options.calendar) {
                const state=calendarState(new NativeDate(base));
                record("calendar."+options.name,state.status,state.detail);
            }
            if (options.weather) {
                const el = query('[data-nexus="weather"],#weather,#weatherInfo,#weatherResult');
                const t = read(el);
                const error = /ошиб|недоступ|не удал|нет (сети|связи|подключения)|проверьте подключение|error|failed|unavailable|offline|network|失败|エラー|خطأ/i.test(t);
                const temp = new RegExp("(^|[^0-9-])"+sample+"\\s*(?:°|℃)").test(t.replace(/−/g,"-"));
                record("weather."+options.name,!requests || !t ? "unverified" : (options.offline ? error && !temp : temp) ? "pass":"fail",
                    {mock:true,requests});
            }
            if (options.name==="december") {
                const next=query('[data-nexus="next"],#nextMonth,#next-month,button[aria-label="Next month"]');
                if (shown(next)) {
                    next.click();
                    later(()=>{
                        const state=calendarState(new NativeDate(2024,0,1));
                        record("calendar.nextyear",state.status,state.detail);
                        send({token,result},"*");
                    },250);
                    return;
                }
            }
            send({token, result},"*");
        },options.clock ? 2650 : 170);
    },80),{once:true});
}
function startWidgetChecks(source, required) {
    const clock=required.includes("часы"), calendar=required.includes("календарь"), weather=required.includes("погода");
    const results=[], plans=[];
    if(required.includes("Bluetooth")) results.push({id:"bluetooth.device",status:"unverified",detail:{hardware:false}});
    if(clock || calendar || weather) plans.push({name:"current",clock,calendar,weather,temperature:-17});
    if(calendar) plans.push({name:"december",calendar,date:[2023,11,31]},{name:"january",calendar,date:[2024,0,1]});
    if(calendar || weather) plans.push({name:"leap",calendar,weather,date:[2024,1,29],temperature:28});
    if(weather) plans.push({name:"offline",weather,offline:true,temperature:-17});
    window.nexusTestResult=null;
    if(!plans.length){window.nexusTestResult=results;return;}
    const pending=new Map();
    function close() {
        window.removeEventListener("message",receive);
        for(const [token,{frame,plan}] of pending) {
            results.push({id:"probe."+plan.name,status:"unverified",detail:{timeout:true}});
            frame.remove();
        }
        pending.clear();
        window.nexusTestResult=results;
    }
    function receive(event) {
        const data=event.data;
        if(!data || typeof data.token!=="string" || !pending.has(data.token)) return;
        const entry=pending.get(data.token);
        if(event.source!==entry.frame.contentWindow || !Array.isArray(data.result)) return;
        results.push(...data.result);
        pending.delete(data.token);
        entry.frame.remove();
        if(!pending.size){clearTimeout(deadline);close();}
    }
    window.addEventListener("message",receive);
    const deadline=setTimeout(close,8500);
    for(const plan of plans) {
        const token=Array.from(crypto.getRandomValues(new Uint32Array(4))).join("-");
        const bootstrap="<script>("+widgetProbe.toString()+")("+JSON.stringify(plan)+","+JSON.stringify(token)+")<"+"/script>";
        const frame=sandboxFrame(source,bootstrap);
        // Overlap frames so every clock remains visible to browser timer scheduling.
        frame.style.cssText="position:fixed;inset:0;width:100%;height:100%";
        pending.set(token,{frame,plan});
        document.body.appendChild(frame);
    }
}
