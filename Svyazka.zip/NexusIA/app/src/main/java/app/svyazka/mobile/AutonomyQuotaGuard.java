package app.svyazka.mobile;

/** A conservative, local stop for unattended AI retries.
 * Only a recent, provider-reported zero is authoritative; missing or stale
 * quota information must never be presented as exhaustion.
 */
final class AutonomyQuotaGuard {
    static final long SNAPSHOT_VALID_MS = 60_000L;

    private AutonomyQuotaGuard() { }

    static boolean recentZero(long remaining, long recordedAt, long now) {
        return remaining == 0 && recordedAt > 0 && now >= recordedAt
                && now - recordedAt < SNAPSHOT_VALID_MS;
    }

    static boolean groqExhausted(long tokensThisMinute, long requestsToday,
                                 long recordedAt, long now) {
        return recentZero(tokensThisMinute, recordedAt, now)
                || recentZero(requestsToday, recordedAt, now);
    }

    static boolean openRouterExhausted(long freeRequestsToday, long recordedAt, long now) {
        return recentZero(freeRequestsToday, recordedAt, now);
    }
}
