package app.svyazka.mobile.ui

import android.content.Context
import app.svyazka.mobile.AttachmentProblem.Code
import app.svyazka.mobile.R

object AttachmentMessages {
    @JvmStatic fun format(context: Context, code: Code, detail: String): String {
        val id = when (code) {
            Code.FILE_COUNT -> R.string.attachment_err_file_count
            Code.FILE_SIZE -> R.string.attachment_err_file_size
            Code.TOTAL_SIZE -> R.string.attachment_err_total_size
            Code.TEXT_SIZE -> R.string.attachment_err_text_size
            Code.REQUEST_TEXT_SIZE -> R.string.attachment_err_request_text_size
            Code.IMAGE_PIXELS -> R.string.attachment_err_image_pixels
            Code.PACKAGE_SIZE -> R.string.attachment_err_package_size
            Code.ZIP_COUNT -> R.string.attachment_err_zip_count
            Code.ZIP_PATH -> R.string.attachment_err_zip_path
            Code.ZIP_RATIO -> R.string.attachment_err_zip_ratio
            Code.UNSUPPORTED -> R.string.attachment_err_unsupported
            Code.ENCODING -> R.string.attachment_err_encoding
            Code.NOT_TEXT -> R.string.attachment_err_not_text
            Code.CORRUPT -> R.string.attachment_err_corrupt
            Code.DOCX_STRUCTURE -> R.string.attachment_err_docx_structure
            Code.DOCX_SCOPE -> R.string.attachment_err_docx_scope
            Code.PDF_SCOPE -> R.string.attachment_err_pdf_scope
            Code.PDF_NO_TEXT -> R.string.attachment_err_pdf_no_text
            Code.PDF_LOCKED -> R.string.attachment_err_pdf_locked
            Code.PDF_PAGES -> R.string.attachment_err_pdf_pages
            Code.PDF_PAGE_EMPTY -> R.string.attachment_err_pdf_page_empty
            Code.NESTED_ARCHIVE -> R.string.attachment_err_nested_archive
            Code.BINARY_ENTRY -> R.string.attachment_err_binary_entry
            Code.IO -> R.string.attachment_err_io
            Code.INTERRUPTED -> R.string.attachment_err_interrupted
            Code.NOT_READY -> R.string.attachment_err_not_ready
            Code.MODEL_IMAGES -> R.string.attachment_err_model_images
            Code.MODEL_CONTEXT -> R.string.attachment_err_model_context
            Code.UNKNOWN_CONTEXT -> R.string.attachment_err_unknown_context
            Code.HTTP_SIZE -> R.string.attachment_err_http_size
            Code.IMAGE_SIZE -> R.string.attachment_err_image_size
            Code.IMAGE_INVALID -> R.string.attachment_err_image_invalid
            Code.MISSING -> R.string.attachment_err_missing
            Code.INTEGRITY -> R.string.attachment_err_integrity
            Code.LOADING -> R.string.attachment_err_loading
        }
        val text = context.getString(id)
        return if (detail.isBlank()) text else "$text\n$detail"
    }
}
