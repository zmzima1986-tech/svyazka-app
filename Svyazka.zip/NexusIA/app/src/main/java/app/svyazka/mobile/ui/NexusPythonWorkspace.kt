package app.svyazka.mobile.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.R
import org.json.JSONArray

/** A manual mini-project belongs to one chat. Automated verification has another engine. */
@Composable
fun NexusPythonWorkspace(ui: NexusComposeUi) {
    val state = ui.snapshot
    val clipboard = LocalClipboardManager.current
    val save = rememberSaveResultAction(ui.pythonEditingCode, ui.pythonFileName)
    val blocks = ui.pythonCodeBlocks
    var selected by remember(blocks, ui.pythonStep) { mutableIntStateOf(0) }
    var section by remember { mutableIntStateOf(1) }
    var allowedPackage by remember { mutableStateOf("") }
    var extended by remember { mutableStateOf(false) }
    var confirmExtended by remember { mutableStateOf(false) }
    var showAdvancedWorkspace by remember { mutableStateOf(false) }
    var showArtifacts by remember { mutableStateOf(false) }
    val tabs = listOf(stringResource(R.string.ws_files), stringResource(R.string.ws_code), stringResource(R.string.ws_output), stringResource(R.string.ws_tests), stringResource(R.string.ws_artifacts))

    fun launch() {
        if (ui.pythonFileName.endsWith(".py")) {
            val accepted = if (ui.pythonRemote && ui.pythonFileList.size <= 1) {
                ui.activity.nexusExecutePython(ui.pythonStep, ui.pythonEditingCode,
                    ui.pythonStdin, true, false)
            } else ui.activity.nexusExecutePythonProject(ui.pythonFileName,
                ui.pythonEditingCode, ui.pythonStdin, allowedPackage, extended)
            if (accepted) section = 2
        }
    }

    Column(Modifier.fillMaxSize().padding(vertical = 8.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(stringResource(R.string.python_run_title), style = MaterialTheme.typography.titleMedium)
        PythonProjectFiles(ui)
        NexusPrimaryButton(text = stringResource(R.string.ws_easy_run),
            enabled = !state.active && !state.clearing && !ui.pythonBusy &&
                ui.pythonEditingCode.isNotBlank() && ui.pythonFileName.endsWith(".py"),
            onClick = { launch() }, modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Outlined.PlayArrow, null) }, glow = false)
        if (ui.pythonBusy) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(21.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(9.dp))
                Text(stringResource(R.string.status_processing), modifier = Modifier.weight(1f))
                IconButton(onClick = { ui.activity.nexusCancelPython() }) {
                    Icon(Icons.Outlined.Stop, stringResource(R.string.action_stop))
                }
            }
        }
        ui.pythonReport?.let { report ->
            val success = report.exitCode == 0
            Text(stringResource(if (success) R.string.ws_easy_run_ok else R.string.ws_easy_run_error),
                style = MaterialTheme.typography.titleMedium,
                color = if (success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            if (report.stdout.isNotBlank()) {
                SelectionContainer { Text(report.stdout, maxLines = 8) }
            }
            if (report.stderr.isNotBlank()) {
                SelectionContainer {
                    Text(report.stderr, maxLines = 6, color = MaterialTheme.colorScheme.error)
                }
            }
            val tests = remember(report.testsJson) {
                runCatching { JSONArray(report.testsJson) }.getOrNull()
            }
            if (tests != null && tests.length() > 0) {
                val passed = (0 until tests.length()).count {
                    tests.optJSONObject(it)?.optBoolean("passed") == true
                }
                Text(stringResource(R.string.ws_easy_tests_summary, passed, tests.length()),
                    color = if (passed == tests.length()) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error)
            }
            val artifacts = remember(report.artifactsJson) {
                runCatching { JSONArray(report.artifactsJson).length() }.getOrDefault(0)
            }
            if (artifacts > 0) {
                TextButton(onClick = { showArtifacts = !showArtifacts }) {
                    Text(stringResource(R.string.ws_easy_artifacts, artifacts))
                }
                if (showArtifacts) PythonRunArtifacts(ui)
            }
            if (report.hasVisual) TextButton(onClick = { ui.openVisual() }) {
                Text(stringResource(R.string.action_show_result))
            }
        }
        ui.pythonError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        TextButton(onClick = { showAdvancedWorkspace = !showAdvancedWorkspace }) {
            Text(stringResource(if (showAdvancedWorkspace) R.string.ws_easy_hide_advanced
                else R.string.ws_easy_edit_settings))
        }
        if (showAdvancedWorkspace) {
        NexusLabel(stringResource(R.string.python_scope))
        if (state.resultHasPython && state.complete && !ui.pythonBusy) {
            TextButton(onClick = { ui.activity.nexusRunPython(ui.activity.nexusFinalStep()) }) {
                Text(stringResource(R.string.load_answer))
            }
        }
        if (blocks.size > 1 && !ui.pythonBusy) {
            Column {
                blocks.forEachIndexed { index, code ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = index == selected, onClick = {
                            selected = index
                            ui.loadPython(ui.activity.nexusFinalStep(), code)
                        })
                        Text(stringResource(R.string.python_block, index + 1),
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        ScrollableTabRow(selectedTabIndex = section, edgePadding = 0.dp) {
            tabs.forEachIndexed { index, name ->
                Tab(selected = section == index, onClick = { section = index }, text = { Text(name) })
            }
        }
        Column(Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (section) {
                0 -> Text(stringResource(R.string.ws_easy_files_above))
                1 -> {
                    PythonProjectEditor(ui)
                    if (!ui.pythonBusy) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { clipboard.getText()?.text?.let {
                                if (it.length <= 75_000) ui.loadPython(-1, it)
                            } }) { Text(stringResource(R.string.editor_paste)) }
                            TextButton(enabled = ui.pythonEditingCode.isNotBlank(),
                                onClick = { clipboard.setText(AnnotatedString(ui.pythonEditingCode)) }) {
                                Text(stringResource(R.string.action_copy))
                            }
                            TextButton(enabled = ui.pythonEditingCode.isNotBlank(), onClick = save) {
                                Text(stringResource(R.string.action_save_file))
                            }
                            TextButton(enabled = ui.pythonEditingCode.isNotEmpty(),
                                onClick = { ui.editPython("") }) { Text(stringResource(R.string.editor_clear)) }
                        }
                        OutlinedTextField(value = ui.pythonStdin,
                            onValueChange = { if (it.length <= 16_000) ui.pythonStdin = it },
                            modifier = Modifier.fillMaxWidth(), maxLines = 4,
                            label = { Text(stringResource(R.string.python_input_hint)) })
                        if (ui.pythonHasPiston) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = ui.pythonRemote, onCheckedChange = {
                                    ui.pythonRemote = it
                                    if (it) { allowedPackage = ""; extended = false }
                                }, enabled = ui.pythonFileList.size <= 1)
                                Text(stringResource(R.string.python_use_piston),
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            if (ui.pythonRemote && ui.pythonFileList.size <= 1) NexusLabel(stringResource(R.string.python_warning_remote))
                            if (ui.pythonFileList.size > 1)
                                NexusLabel(stringResource(R.string.ws_remote_single))
                        }
                        if (!ui.pythonRemote || ui.pythonFileList.size > 1) {
                        Text(stringResource(R.string.ws_package),
                            style = MaterialTheme.typography.labelMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = allowedPackage.isEmpty(), onClick = { allowedPackage = "" })
                            Text(stringResource(R.string.ws_no_package), style = MaterialTheme.typography.bodySmall)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = allowedPackage == "matplotlib", onClick = { allowedPackage = "matplotlib" })
                            Text(stringResource(R.string.ws_matplotlib), style = MaterialTheme.typography.bodySmall)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = allowedPackage == "numpy", onClick = { allowedPackage = "numpy" })
                            Text("NumPy 2.4.6", style = MaterialTheme.typography.bodySmall)
                        }
                        NexusLabel(stringResource(R.string.ws_package_note))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = extended, onCheckedChange = { extended = it })
                            Text(stringResource(R.string.ws_extended),
                                style = MaterialTheme.typography.bodySmall)
                        }
                        }
                        NexusPrimaryButton(text = stringResource(R.string.action_start),
                            enabled = !state.active && !state.clearing && ui.pythonEditingCode.isNotBlank()
                                && ui.pythonFileName.endsWith(".py"),
                            onClick = { if (extended && (!ui.pythonRemote || ui.pythonFileList.size > 1)) confirmExtended = true else launch() },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = { Icon(Icons.Outlined.PlayArrow, null) }, glow = false)
                        NexusLabel(stringResource(R.string.ws_test_hint))
                    }
                }
                2 -> PythonRunOutput(ui)
                3 -> PythonRunTests(ui)
                4 -> PythonRunArtifacts(ui)
            }
            if (ui.pendingPython != null) AlertDialog(onDismissRequest = { ui.pendingPython = null },
                title = { Text(stringResource(R.string.editor_replace)) },
                confirmButton = { TextButton(onClick = { ui.confirmPythonLoad() }) {
                    Text(stringResource(R.string.action_continue))
                } },
                dismissButton = { TextButton(onClick = { ui.pendingPython = null }) {
                    Text(stringResource(R.string.action_cancel))
                } })
            if (confirmExtended) AlertDialog(onDismissRequest = { confirmExtended = false },
                title = { Text(stringResource(R.string.ws_extended_title)) },
                text = { Text(stringResource(R.string.ws_extended_body)) },
                confirmButton = { TextButton(onClick = { confirmExtended = false; launch() }) {
                    Text(stringResource(R.string.ws_allow))
                } },
                dismissButton = { TextButton(onClick = { confirmExtended = false }) {
                    Text(stringResource(R.string.action_cancel))
                } })
        }
        }
    }
}

@Composable
private fun PythonProjectEditor(ui: NexusComposeUi) {
    val code = ui.pythonEditingCode
    var editor by remember(ui.pythonFileName) { mutableStateOf(TextFieldValue(code)) }
    val undo = remember(ui.pythonFileName) { mutableStateListOf<String>() }
    val redo = remember(ui.pythonFileName) { mutableStateListOf<String>() }
    var find by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf("") }
    var targetLine by remember { mutableStateOf("") }
    LaunchedEffect(code) {
        if (editor.text != code) editor = editor.copy(text = code, selection = TextRange(0))
    }
    fun edit(next: TextFieldValue) {
        if (next.text != editor.text) {
            undo.add(editor.text)
            if (undo.size > 16) undo.removeAt(0)
            redo.clear()
        }
        editor = next
        ui.editPython(next.text)
    }
    val cursor = editor.selection.start.coerceIn(0, editor.text.length)
    Text((if (ui.pythonFileDirty) "● " else "") +
        stringResource(R.string.ws_editor_stats, ui.pythonFileName, code.count { it == '\n' } + 1,
            code.take(cursor).count { it == '\n' } + 1),
        style = MaterialTheme.typography.labelMedium)
    OutlinedTextField(value = editor, onValueChange = { if (it.text.length <= 75_000) edit(it) },
        modifier = Modifier.fillMaxWidth(), enabled = !ui.pythonBusy && !ui.snapshot.active,
        minLines = 8, maxLines = 14,
        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
        label = { Text(stringResource(R.string.ui_code)) })
    Row {
        TextButton(onClick = {
            if (undo.isNotEmpty()) {
                redo.add(editor.text)
                val text = undo.removeAt(undo.lastIndex)
                editor = TextFieldValue(text, selection = TextRange(text.length))
                ui.editPython(text)
            }
        }, enabled = undo.isNotEmpty()) { Text(stringResource(R.string.ws_undo)) }
        TextButton(onClick = {
            if (redo.isNotEmpty()) {
                undo.add(editor.text)
                val text = redo.removeAt(redo.lastIndex)
                editor = TextFieldValue(text, selection = TextRange(text.length))
                ui.editPython(text)
            }
        }, enabled = redo.isNotEmpty()) { Text(stringResource(R.string.ws_redo)) }
    }
    OutlinedTextField(value = find, onValueChange = { find = it.take(200) },
        modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.ws_find)) })
    OutlinedTextField(value = replace, onValueChange = { replace = it.take(200) },
        modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.ws_replace_with)) })
    Row {
        TextButton(enabled = find.isNotEmpty(), onClick = {
            val offset = code.indexOf(find, startIndex = cursor).takeIf { it >= 0 }
                ?: code.indexOf(find)
            if (offset >= 0) editor = editor.copy(selection = TextRange(offset,offset + find.length))
        }) { Text(stringResource(R.string.ws_find_next)) }
        TextButton(enabled = find.isNotEmpty(), onClick = {
            if (code.contains(find)) edit(editor.copy(text = code.replace(find, replace)))
        }) { Text(stringResource(R.string.ws_replace_all)) }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = targetLine, onValueChange = { targetLine = it.take(7) },
            modifier = Modifier.width(118.dp), singleLine = true,
            label = { Text(stringResource(R.string.ws_line)) })
        TextButton(onClick = {
            val line = targetLine.toIntOrNull()?.coerceAtLeast(1) ?: 1
            val offset = if (line == 1) 0 else {
                var index = -1
                repeat(line - 1) { index = code.indexOf('\n', index + 1).takeIf { it >= 0 } ?: code.length }
                (index + 1).coerceAtMost(code.length)
            }
            editor = editor.copy(selection = TextRange(offset))
        }) { Text(stringResource(R.string.ws_go)) }
    }
}

@Composable
private fun PythonRunOutput(ui: NexusComposeUi) {
    val report = ui.pythonReport
    if (report == null) { NexusLabel(stringResource(R.string.ws_output_empty)); return }
    HorizontalDivider()
    Text(stringResource(R.string.ui_result), style = MaterialTheme.typography.titleMedium)
    NexusLabel(report.engine + (report.exitCode?.let { stringResource(R.string.ws_exit_code, it) } ?:
        stringResource(R.string.ws_stopped)))
    NexusLabel(stringResource(R.string.ws_level) + when {
        report.exitCode == null -> stringResource(R.string.ws_not_finished)
        report.exitCode == 0 -> stringResource(R.string.ws_executed)
        else -> stringResource(R.string.ws_error)
    })
    if (report.snapshotSha256.isNotBlank()) NexusLabel(stringResource(R.string.ws_sha, report.snapshotSha256))
    if (report.status.isNotBlank()) Text(report.status, style = MaterialTheme.typography.bodySmall)
    Text(stringResource(R.string.python_stdout), style = MaterialTheme.typography.labelLarge)
    SelectionContainer { Text(report.stdout.ifBlank { stringResource(R.string.python_no_output) }) }
    if (report.stderr.isNotBlank()) {
        Text(stringResource(R.string.python_stderr), style = MaterialTheme.typography.labelLarge)
        SelectionContainer { Text(report.stderr, color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)) }
        val location = Regex("""File "([^"]+)", line (\d+)""").find(report.stderr)
        if (location != null) TextButton(onClick = {
            val name = location.groupValues[1].substringAfterLast("/workspace/")
            if (ui.pythonFileList.contains(name)) ui.openPythonFile(name)
            // The editor provides an explicit line-number navigation field.
        }) { Text(stringResource(R.string.ws_goto_error)) }
    }
    if (report.hasVisual) TextButton(onClick = { ui.openVisual() }) {
        Text(stringResource(R.string.action_show_result))
    }
    if (report.stderr.isNotBlank()) TextButton(onClick = {
        ui.chatTextChanged("Проверь ошибку Python и предложи конкретное исправление. " +
            "Исходный код и секреты не отправляй автоматически. Диагностика:\n" +
            report.stderr.take(1600))
        ui.selectPage(NexusComposeUi.Page.TASK)
    }) { Text(stringResource(R.string.ws_ask_ai)) }
    if (report.diagnostic.isNotBlank()) TextButton(onClick = {
        ui.activity.nexusSendPythonError(); ui.dismissPythonResult()
    }) { Text(stringResource(R.string.python_error_to_review)) }
    OutlinedButton(onClick = { ui.dismissPythonResult() }) { Text(stringResource(R.string.action_close)) }
}
