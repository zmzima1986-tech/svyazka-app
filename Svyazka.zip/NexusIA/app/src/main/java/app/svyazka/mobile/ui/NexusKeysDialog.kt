package app.svyazka.mobile.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.svyazka.mobile.R

@Composable
fun KeysDialog(ui: NexusComposeUi, dismiss: () -> Unit) {
    val keys = remember { ui.activity.nexusKeysForEditing() }
    // Keep all four fields outside the selected section: changing tabs must retain edits.
    var openRouter by remember { mutableStateOf(keys[0]) }
    var groq by remember { mutableStateOf(keys[1]) }
    var gemini by remember { mutableStateOf(keys[2]) }
    var piston by remember { mutableStateOf(keys[3]) }
    var reserve by remember { mutableStateOf(ui.snapshot.groqReserve) }
    var selected by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val labels = listOf(R.string.keys_openrouter, R.string.keys_groq,
        R.string.keys_gemini, R.string.keys_piston)
    val links = listOf("https://openrouter.ai/settings/keys", "https://console.groq.com/keys",
        "https://aistudio.google.com/api-keys")
    val linkLabels = listOf(R.string.keys_get_openrouter, R.string.keys_get_groq, R.string.keys_get_gemini)
    val dark = MaterialTheme.colorScheme.background == NexusNavy
    Dialog(onDismissRequest = dismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        BoxWithConstraints(Modifier.fillMaxWidth().systemBarsPadding().imePadding()
            .padding(horizontal = 16.dp, vertical = 12.dp), contentAlignment = Alignment.Center) {
            Surface(modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth().heightIn(max = maxHeight),
                shape = RoundedCornerShape(24.dp),
                color = if (dark) Color(0xFF111D2C) else MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                border = BorderStroke(1.dp, if (dark) Color.White.copy(alpha = .1f)
                    else Color(0xFFE1E5EB)), tonalElevation = 0.dp) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        NexusGlyph(R.drawable.ic_nia_key, null, Modifier.size(30.dp))
                        Text(stringResource(R.string.models_settings), style = MaterialTheme.typography.titleLarge)
                    }
                    Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("OpenRouter", "Groq", "Gemini", "Piston").forEachIndexed { index, name ->
                                FilterChip(selected = selected == index, onClick = {
                                    focus.clearFocus()
                                    keyboard?.hide()
                                    selected = index
                                }, label = { Text(name) })
                            }
                        }
                        key(selected) {
                            OutlinedTextField(value = when (selected) {
                                0 -> openRouter; 1 -> groq; 2 -> gemini; else -> piston
                            }, onValueChange = { value ->
                                when (selected) {
                                    0 -> openRouter = value; 1 -> groq = value
                                    2 -> gemini = value; else -> piston = value
                                }
                            }, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(labels[selected])) },
                                singleLine = true, shape = RoundedCornerShape(16.dp),
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password,
                                    imeAction = ImeAction.Done, autoCorrectEnabled = false),
                                keyboardActions = KeyboardActions(onDone = { keyboard?.hide(); focus.clearFocus() }))
                        }
                        if (selected < links.size) {
                            TextButton(onClick = { runCatching { uriHandler.openUri(links[selected]) } }) {
                                Text(stringResource(linkLabels[selected]), style = MaterialTheme.typography.labelLarge)
                            }
                        }
                        if (selected == 1) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = reserve, onCheckedChange = { reserve = it })
                                Text(stringResource(R.string.keys_reserve), style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        Text(stringResource(R.string.keys_hint), style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(stringResource(R.string.keys_warning), style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = dismiss) { Text(stringResource(R.string.action_cancel)) }
                        TextButton(onClick = {
                            if (ui.activity.nexusSaveKeys(openRouter, groq, gemini, piston, reserve)) {
                                dismiss()
                                Toast.makeText(context, R.string.keys_saved, Toast.LENGTH_SHORT).show()
                            } else Toast.makeText(context, R.string.keys_error, Toast.LENGTH_LONG).show()
                        }) { Text(stringResource(R.string.action_save)) }
                    }
                }
            }
        }
    }
}
