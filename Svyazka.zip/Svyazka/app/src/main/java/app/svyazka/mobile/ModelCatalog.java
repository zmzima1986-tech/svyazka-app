package app.svyazka.mobile;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class ModelCatalog {
    private static final Pattern FREE_ID =
            Pattern.compile("[a-zA-Z0-9._-]+/[a-zA-Z0-9._-]+:free");

    static final Model LING = router("inclusionai/ling-3.2-flash:free", "Ling 3.2 Flash",
            1_048_576, 262_144, true);
    static final Model NEMOTRON = router("nvidia/nemotron-3-ultra-550b-a55b:free",
            "Nemotron 3 Ultra", 1_000_000, 65_536, true);
    static final Model NORTH = router("cohere/north-mini-code:free", "North Mini Code",
            256_000, 64_000, true);
    static final Model PARTICLE = router("particle-ai/particle-1:free", "Particle-1",
            1_048_576, 131_072, true);
    static final Model GEMMA = router("google/gemma-4-31b-it:free", "Gemma 4 31B",
            262_144, 32_768, true);
    static final Model FLINT = router("recursive/flint-v1.0:free", "Flint",
            262_144, 235_929, true);
    static final Model GEMINI = new Model("gemini-3.8-flash", "Gemini 3.8 Flash",
            Workflow.Provider.GEMINI, 1_048_576, 65_536, false);
    static final Model GROQ_120B = new Model("openai/gpt-oss-120b", "GPT-OSS 120B",
            Workflow.Provider.GROQ, 131_072, 65_536, true);
    static final Model GROQ_20B = new Model("openai/gpt-oss-20b", "GPT-OSS 20B",
            Workflow.Provider.GROQ, 131_072, 65_536, true);
    private static final List<Model> STARTER = Collections.unmodifiableList(Arrays.asList(
            LING, NEMOTRON, NORTH, PARTICLE, GEMMA, FLINT));

    static final class Model {
        final String id;
        final String label;
        final Workflow.Provider provider;
        final int context;
        final int maxOutput;
        final boolean reasoning;

        private Model(String id, String label, Workflow.Provider provider, int context,
                      int maxOutput, boolean reasoning) {
            this.id = id;
            this.label = label;
            this.provider = provider;
            this.context = Math.max(0, context);
            this.maxOutput = Math.max(0, maxOutput);
            this.reasoning = reasoning;
        }
    }

    private final Map<String, Model> entries;
    final boolean refreshed;

    private ModelCatalog(List<Model> entries, boolean refreshed) {
        this.entries = new LinkedHashMap<>();
        for (Model model : entries) this.entries.put(model.id, model);
        this.refreshed = refreshed;
    }

    static ModelCatalog starter() {
        return new ModelCatalog(STARTER, false);
    }

    static boolean isFreeId(String id) {
        return FREE_ID.matcher(id).matches();
    }

    static Model storedModel(String id, String savedLabel) throws JSONException {
        if (GEMINI.id.equals(id)) return GEMINI;
        if (GROQ_120B.id.equals(id)) return GROQ_120B;
        if (GROQ_20B.id.equals(id)) return GROQ_20B;
        for (Model model : STARTER) {
            if (model.id.equals(id)) return model;
        }
        if (!isFreeId(id)) throw new JSONException("Некорректная модель OpenRouter");
        return router(id, savedLabel.isEmpty() ? id : savedLabel, 0, 0, false);
    }

    private static Model router(String id, String label, int context, int maxOutput, boolean reasoning) {
        return new Model(id, label, Workflow.Provider.OPENROUTER, context, maxOutput, reasoning);
    }

    Model details(Model chosen) {
        Model updated = entries.get(chosen.id);
        return updated == null ? chosen : updated;
    }

    boolean available(Model chosen) {
        return !refreshed || chosen.provider != Workflow.Provider.OPENROUTER
                || entries.containsKey(chosen.id);
    }

    List<Model> choices() {
        List<Model> models = new ArrayList<>(entries.values());
        models.sort(Comparator.comparing(model -> model.label, String.CASE_INSENSITIVE_ORDER));
        models.add(GEMINI);
        models.add(GROQ_120B);
        models.add(GROQ_20B);
        return models;
    }

    int routerCount() {
        return entries.size();
    }

    static ModelCatalog fromOpenRouter(JSONObject response) throws JSONException {
        List<Model> results = new ArrayList<>();
        JSONArray data = response.getJSONArray("data");
        for (int i = 0; i < data.length(); i++) {
            JSONObject item = data.getJSONObject(i);
            String id = item.optString("id", "");
            JSONObject architecture = item.optJSONObject("architecture");
            if (!isFreeId(id) || !zeroPricing(item.optJSONObject("pricing")) || architecture == null
                    || !contains(architecture.optJSONArray("input_modalities"), "text")
                    || !contains(architecture.optJSONArray("output_modalities"), "text")) continue;
            JSONArray endpoints = item.optJSONArray("endpoints");
            if (endpoints != null && !contains(endpoints, "/api/v1/chat/completions")) continue;
            JSONObject top = item.optJSONObject("top_provider");
            int maxOutput = top == null ? 0 : top.optInt("max_completion_tokens");
            int context = item.optInt("context_length");
            if (top != null && top.optInt("context_length") > 0) {
                context = context > 0 ? Math.min(context, top.optInt("context_length"))
                        : top.optInt("context_length");
            }
            String label = item.optString("name", id).replaceFirst(" \\(free\\)$", "");
            for (Model starter : STARTER) {
                if (starter.id.equals(id)) label = starter.label;
            }
            results.add(router(id, label, context, maxOutput,
                    contains(item.optJSONArray("supported_parameters"), "reasoning")));
        }
        return new ModelCatalog(results, true);
    }

    JSONArray cacheData() throws JSONException {
        JSONArray array = new JSONArray();
        for (Model model : entries.values()) {
            array.put(new JSONObject().put("id", model.id).put("label", model.label)
                    .put("context", model.context).put("max_output", model.maxOutput)
                    .put("reasoning", model.reasoning));
        }
        return array;
    }

    static ModelCatalog fromCache(JSONArray array) throws JSONException {
        List<Model> results = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject item = array.getJSONObject(i);
            String id = item.getString("id");
            if (isFreeId(id)) {
                results.add(router(id, item.getString("label"), item.optInt("context"),
                        item.optInt("max_output"), item.optBoolean("reasoning")));
            }
        }
        return new ModelCatalog(results, true);
    }

    private static boolean zeroPricing(JSONObject price) {
        if (price == null || !price.has("prompt") || !price.has("completion")) return false;
        try {
            for (java.util.Iterator<String> keys = price.keys(); keys.hasNext();) {
                if (new BigDecimal(price.getString(keys.next())).signum() != 0) return false;
            }
            return true;
        } catch (JSONException | NumberFormatException ex) {
            return false;
        }
    }

    private static boolean contains(JSONArray values, String target) {
        if (values == null) return false;
        for (int i = 0; i < values.length(); i++) {
            if (target.equals(values.optString(i))) return true;
        }
        return false;
    }
}
