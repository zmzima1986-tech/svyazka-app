package app.svyazka.mobile.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path

/** Reconstructed dark-only design tokens from nexus_ai_dark_theme_spec.zip. */
internal object NexusDarkDesign {
    val background = Color(0xFF020E20)
    val chatBackground = Color(0xFF020D1D)
    val surface = Color(0xFF111F33)
    val raised = Color(0xFF16283E)
    val console = Color(0xFF0B1829)
    val editor = Color(0xFF05111F)
    val border = Color(0xFF405C7B)
    val subtleBorder = Color(0xFF2B3B53)
    val focusBorder = Color(0xFF35D8F0)
    val text = Color(0xFFF4F7FF)
    val secondaryText = Color(0xFFBFCBDB)
    val mutedText = Color(0xFF91A3B8)
    val cyan = Color(0xFF34D8EA)
    val blue = Color(0xFF3184FE)
    val purple = Color(0xFF8719EF)
    val success = Color(0xFF2FE2A3)
    val error = Color(0xFFFF7282)
    val disabled = Color(0xFF26354B)
    val disabledText = Color(0xFF8895A7)
    val primaryGradient = Brush.horizontalGradient(
        0f to Color(0xFF3082FF), .25f to Color(0xFF405CFD),
        .50f to Color(0xFF5B3EFA), .75f to Color(0xFF782BF7),
        1f to Color(0xFF8619F0))
    val runGradient = Brush.horizontalGradient(
        0f to Color(0xFF157DFF), .25f to Color(0xFF3C5CFD),
        .50f to Color(0xFF5642F9), .75f to Color(0xFF6F2FF8),
        1f to Color(0xFF7D1FEF))
    val selectedGradient = Brush.horizontalGradient(
        listOf(Color(0xFF136BD7), Color(0xFF1C7FFF)))
    val sendGradient = Brush.linearGradient(listOf(
        Color(0xFF00BDF2), Color(0xFF147BFF), Color(0xFF7A21E8)))
}

/** Behind interactive content only. No image resources, blur layers or touch interceptors. */
@Composable
internal fun NexusDarkBackdrop(modifier: Modifier = Modifier) {
    Box(modifier.background(Brush.verticalGradient(listOf(
        NexusDarkDesign.chatBackground, Color(0xFF031229), Color(0xFF0A1231))))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val blueWave = Path().apply {
                moveTo(0f, h * .79f)
                cubicTo(w * .25f, h * .84f, w * .30f, h * .95f, w * .61f, h * .90f)
                cubicTo(w * .85f, h * .88f, w * .91f, h * .79f, w, h * .78f)
                lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(blueWave, Brush.verticalGradient(listOf(
                Color(0xFF09152D).copy(alpha = .15f),
                Color(0xFF1154B5).copy(alpha = .35f), Color(0xFF071C41).copy(alpha = .65f)),
                startY = h * .78f, endY = h))
            val purpleWave = Path().apply {
                moveTo(0f, h * .96f)
                cubicTo(w * .32f, h * .94f, w * .62f, h * .80f, w, h * .78f)
                lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(purpleWave, Brush.verticalGradient(listOf(
                Color(0xFF5527B3).copy(alpha = .16f),
                Color(0xFF361A89).copy(alpha = .30f),
                Color(0xFF11184E).copy(alpha = .43f)),
                startY = h * .78f, endY = h))
        }
    }
}
