package app.svyazka.fixture;

import android.app.Instrumentation;
import android.content.Context;
import android.system.Os;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import org.json.JSONObject;

/** Real LocalSandbox checks with synthetic data only; no external requests. */
final class PythonSecurityProbe {
    private static final String ENV = "NEXUS_TEST_HOST_MARKER";
    private PythonSecurityProbe() { }
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    private static Object field(Object owner, String name) throws Exception {
        Field f = owner.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(owner);
    }
    private static final class Outcome {
        Object result;
        String error;
    }
    private static Outcome execute(Instrumentation test, String code, JSONObject files) throws Exception {
        return execute(test, code, files, "");
    }
    private static Outcome execute(Instrumentation test, String code, JSONObject files, String input) throws Exception {
        Context context = test.getTargetContext();
        Class<?> cls = context.getClassLoader().loadClass("app.svyazka.mobile.LocalSandbox");
        Constructor<?> constructor = cls.getDeclaredConstructor(Consumer.class, Consumer.class);
        constructor.setAccessible(true);
        Method execute = cls.getDeclaredMethod("executeProject", Context.class, String.class,
                String.class, JSONObject.class, String.class, String.class, boolean.class);
        execute.setAccessible(true);
        Method close = cls.getDeclaredMethod("close");
        close.setAccessible(true);
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Object> sandbox = new AtomicReference<>();
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Outcome out = new Outcome();
        test.runOnMainSync(() -> {
            try {
                Object runner = constructor.newInstance((Consumer<Object>) value -> {
                    out.result = value; done.countDown();
                }, (Consumer<String>) problem -> {
                    out.error = problem; done.countDown();
                });
                sandbox.set(runner);
                execute.invoke(runner, context, code, input, files, "main.py", "", false);
            } catch (Throwable problem) { failure.set(problem); done.countDown(); }
        });
        try {
            check(done.await(60, TimeUnit.SECONDS), "Sandbox timed out");
            if (failure.get() != null) throw new AssertionError("Sandbox fixture failed", failure.get());
            return out;
        } finally {
            test.runOnMainSync(() -> {
                try { if (sandbox.get() != null) close.invoke(sandbox.get()); }
                catch (Exception problem) { throw new AssertionError("Sandbox cleanup failed", problem); }
            });
        }
    }
    private static String b64(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }
    private static void success(Outcome out) throws Exception {
        check(out.error == null && out.result != null && Integer.valueOf(0).equals(field(out.result, "exitCode")),
                "Sandbox fixture did not complete successfully");
    }
    static void runtime(Instrumentation test, String step) throws Exception {
        if (step.equals("runtime_cancel")) {
            cancelAndRestart(test);
            return;
        }
        JSONObject files = new JSONObject();
        String code, expected, input = "";
        switch (step) {
            case "runtime_typing":
                code = "from typing import List\nx: List[int] = [3, 4]\nprint(sum(x))";
                expected = "7\n"; break;
            case "runtime_stdin":
                code = "print(int(input()) + int(input()))"; input = "7\n9\n"; expected = "16\n"; break;
            case "runtime_assert_fail":
                Outcome rejected = execute(test, "assert 2 + 2 == 5, 'fixture-failure'", files);
                check(rejected.result != null && rejected.error == null, "No execution result");
                Object exit = field(rejected.result, "exitCode");
                check(exit instanceof Integer && ((Integer)exit) != 0
                        && String.valueOf(field(rejected.result, "stderr")).contains("AssertionError"), "Expected a failing assertion");
                return;
            case "runtime_import":
                files.put("support.py", b64("value = 27\n"));
                code = "from support import value\nprint(value)"; expected = "27\n"; break;
            case "runtime_output":
                code = "print('Привет')\nprint(0, False, sep='|')"; expected = "Привет\n0|False\n"; break;
            default: throw new IllegalArgumentException(step);
        }
        Outcome out = execute(test, code, files, input);
        success(out);
        check(expected.equals(field(out.result, "stdout")), "Unexpected stdout: " + step);
    }

    private static void cancelAndRestart(Instrumentation test) throws Exception {
        Context ctx = test.getTargetContext();
        Class<?> cls = ctx.getClassLoader().loadClass("app.svyazka.mobile.LocalSandbox");
        Constructor<?> ctor = cls.getDeclaredConstructor(Consumer.class, Consumer.class);
        ctor.setAccessible(true);
        Method verify = cls.getDeclaredMethod("verify", Context.class, JSONObject.class, Consumer.class, Consumer.class);
        Method close = cls.getDeclaredMethod("close");
        verify.setAccessible(true);
        close.setAccessible(true);
        CountDownLatch reachedSyntax = new CountDownLatch(1);
        CountDownLatch terminal = new CountDownLatch(1);
        Object sandbox = ctor.newInstance((Consumer<Object>) x -> terminal.countDown(), (Consumer<String>) x -> terminal.countDown());
        JSONObject request = new JSONObject().put("mode", "verify").put("code", "while True:\n    pass")
                .put("entry", "main.py").put("files", new JSONObject());
        try {
            test.runOnMainSync(() -> {
                try {
                    verify.invoke(sandbox, ctx, request,
                            (Consumer<JSONObject>) stage -> {
                                if ("syntax".equals(stage.optString("stage"))) reachedSyntax.countDown();
                            }, (Consumer<JSONObject>) value -> terminal.countDown());
                } catch (Exception error) { throw new AssertionError(error); }
            });
            check(reachedSyntax.await(60, TimeUnit.SECONDS), "Sandbox did not reach syntax stage");
            check(!terminal.await(200, TimeUnit.MILLISECONDS), "Run already finished before cancellation");
            long start = android.os.SystemClock.elapsedRealtime();
            test.runOnMainSync(() -> {
                try { close.invoke(sandbox); } catch (Exception error) { throw new AssertionError(error); }
            });
            check(android.os.SystemClock.elapsedRealtime() - start <= 2000, "Cancellation exceeded two seconds");
            check(!terminal.await(6, TimeUnit.SECONDS), "Late result after cancellation");
            Outcome fresh = execute(test, "print('fresh')", new JSONObject());
            success(fresh);
            check("fresh\n".equals(field(fresh.result, "stdout")), "Fresh worker failed");
        } finally {
            test.runOnMainSync(() -> {
                try { close.invoke(sandbox); } catch (Exception error) { throw new AssertionError(error); }
            });
        }
    }
    static void run(Instrumentation test) throws Exception {
        Context context = test.getTargetContext();
        File marker = File.createTempFile("nexus-security-fixture-", ".txt", context.getCacheDir());
        String old = Os.getenv(ENV);
        try {
            try (FileOutputStream output = new FileOutputStream(marker)) {
                output.write("synthetic-only".getBytes(StandardCharsets.UTF_8));
            }
            check(marker.isFile() && marker.length() > 0, "Missing native canary");
            Os.setenv(ENV, "synthetic-only", true);
            check("synthetic-only".equals(Os.getenv(ENV)), "Missing environment canary");
            String source;
            try (Scanner scan = new Scanner(test.getContext().getAssets().open("security-runtime.py"), "UTF-8")) {
                source = scan.useDelimiter("\\A").next();
            }
            source += "\ntry:\n    with Path(" + JSONObject.quote(marker.getAbsolutePath()) + ").open('rb') as stream:\n"
                    + "        stream.read(1)\nexcept (FileNotFoundError, PermissionError):\n    pass\n"
                    + "else:\n    raise AssertionError('Native canary readable')\nprint('NATIVE_CANARY_ABSENT: PASS')\n";
            Outcome clean = execute(test, source, new JSONObject().put("probe.txt", b64("nexus-public-fixture\n")));
            success(clean);
            check("WORKSPACE: PASS\nENV_CANARY_ABSENT: PASS\nJS_NAMESPACE: PASS\nNATIVE_CANARY_ABSENT: PASS\n"
                    .equals(field(clean.result, "stdout")), "Runtime probe results differ");
            check(marker.isFile() && marker.length() > 0, "Native fixture was changed");
            Outcome blocked = execute(test, "print('MUST_NOT_RUN')", new JSONObject().put("helper.py", b64("import socket\n")));
            check(blocked.result == null && blocked.error != null && blocked.error.contains("helper.py: socket"),
                    "Network helper not blocked before execution");
            success(execute(test, "from pathlib import Path\nPath('/tmp/nexus-run-marker').write_text('synthetic')\n", new JSONObject()));
            success(execute(test, "from pathlib import Path\nassert not Path('/tmp/nexus-run-marker').exists()\n", new JSONObject()));
        } finally {
            try { if (old == null) Os.unsetenv(ENV); else Os.setenv(ENV, old, true); }
            finally { if (!marker.delete()) throw new AssertionError("Synthetic marker cleanup failed"); }
        }
    }
}
