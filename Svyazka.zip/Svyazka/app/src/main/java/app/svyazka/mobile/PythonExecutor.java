package app.svyazka.mobile;

/** One user-authorized Python invocation; callbacks are supplied by the platform adapter. */
interface PythonExecutor {
    void execute(String code, String stdin);
    void cancel();
}
