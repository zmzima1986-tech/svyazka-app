package app.svyazka.mobile;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class PythonChatFileTest {
    @Test public void exampleFromChatResolvesToOnlySavedMain() {
        String generated = "# src/main.py\ndef main():\n    print(\"Nexus AI работает\")\n";
        assertEquals("main.py", PythonChatFile.target(generated, new String[]{"main.py"}));
    }

    @Test public void screenshotStyleReplyKeepsOnlyPythonAndIgnoresFakeRunOutput() {
        String reply = "Файл: src/main.py\n\n```python\n# src/main.py\n"
                + "def main():\n    print(\"Nexus AI работает\")\n```\n"
                + "Запуск\n```bash\npython src/main.py\n```\n"
                + "Результат выполнения\n```text\nNexus AI работает\n```";
        java.util.List<String> blocks = PythonInputs.manualBlocks(reply);
        assertEquals(1, blocks.size());
        assertEquals("main.py", PythonChatFile.target(blocks.get(0), new String[]{"main.py"}));
    }

    @Test public void exactExistingPathIsUsedWhenSeveralFilesExist() {
        String generated = "# src/main.py\nprint(123)\n";
        assertEquals("src/main.py", PythonChatFile.target(generated,
                new String[]{"main.py", "src/main.py", "lib/helper.py"}));
    }

    @Test public void ambiguousFileIsNeverGuessed() {
        assertEquals("", PythonChatFile.target("print(123)",
                new String[]{"main.py", "other.py"}));
        assertEquals("", PythonChatFile.target("# missing.py\nprint(123)",
                new String[]{"main.py"}));
    }

    @Test public void dangerousOrMissingPathIsRejected() {
        assertEquals("", PythonChatFile.target("# ../main.py\nprint(123)",
                new String[]{"main.py"}));
        assertEquals("", PythonChatFile.target("print(123)", new String[]{}));
        assertEquals("", PythonChatFile.target("", new String[]{"main.py"}));
    }

    @Test public void modelMayTargetUniqueScriptWithoutMain() {
        assertEquals("checks.py", PythonChatFile.target("print('ok')",
                new String[]{"docs/readme.txt", "checks.py"}));
    }
}
