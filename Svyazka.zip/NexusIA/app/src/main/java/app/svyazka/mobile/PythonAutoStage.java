package app.svyazka.mobile;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** Conservatively selects one complete Python source from a completed AI reply.
 * Nothing is written here: all file operations belong to PythonProjectStore.
 */
final class PythonAutoStage {
    private static final Pattern RU_EDIT = Pattern.compile(
            "(?iu)(?<![\\p{L}])(?:создай|напиши|измени|замени|исправь|добавь|обнови|перепиши|доработай|реализуй|сделай|внеси)(?![\\p{L}])");
    private static final Pattern EN_EDIT = Pattern.compile(
            "(?i)\\b(?:create|write|modify|edit|replace|fix|add|update|rewrite|implement|build|change)\\b");
    private static final Pattern NO_EDIT = Pattern.compile(
            "(?iu)(?:\\bне\\s+(?:изменяй|меняй|исправляй|переписывай|добавляй|создавай|трогай|обновляй)\\b|"
                    + "\\b(?:do\\s+not|don't)\\s+(?:modify|edit|change|write|replace|update|touch)\\b)");

    private static final Pattern NO_RUN_RU = Pattern.compile(
            "(?iu)(?<![\\p{L}])(?:не\\s+(?:запускай|выполняй|исполняй|тестируй|проверяй)|без\\s+(?:запуска|выполнения|тестирования))(?![\\p{L}])");
    private static final Pattern NO_RUN_EN = Pattern.compile(
            "(?i)\\b(?:do\\s+not|don.t|without)\\s+(?:run|execute|test|launch|running|executing|testing)\\b");

    /** An explicit request to only save the edit disables automatic execution. */
    static boolean runAllowed(String message) {
        if (message == null || message.trim().isEmpty()) return false;
        return !NO_RUN_RU.matcher(message).find() && !NO_RUN_EN.matcher(message).find()
                && !message.contains("実行しない") && !message.contains("実行せず")
                && !message.contains("不要运行") && !message.contains("别运行")
                && !message.contains("لا تشغل") && !message.contains("لا تنفذ");
    }

    /** Run the saved entry point, not an arbitrary edited helper module. */
    static String launchEntry(String editedPath, String[] savedPaths) {
        if (savedPaths == null || editedPath == null) return "";
        int count = 0;
        boolean containsEdited = false, root = false, src = false;
        for (String path : savedPaths) {
            if (!PythonProjectPaths.validPath(path) || !path.endsWith(".py")) continue;
            count++;
            if (editedPath.equals(path)) containsEdited = true;
            if ("main.py".equals(path)) root = true;
            if ("src/main.py".equals(path)) src = true;
        }
        if (!containsEdited) return "";
        if ("main.py".equals(editedPath) || "src/main.py".equals(editedPath)) return editedPath;
        if (root != src) return root ? "main.py" : "src/main.py";
        return count == 1 ? editedPath : "";
    }

    private PythonAutoStage() { }

    static final class Selection {
        final String path;
        final String code;

        Selection(String path, String code) {
            this.path = path;
            this.code = code;
        }
    }

    static boolean requested(String userMessage) {
        if (userMessage == null || userMessage.trim().isEmpty()
                || userMessage.contains(PythonAutoFeedback.MARKER)) return false;
        String value = userMessage.trim();
        if (NO_EDIT.matcher(value).find()) return false;
        return RU_EDIT.matcher(value).find() || EN_EDIT.matcher(value).find()
                || value.contains("作成して") || value.contains("書いて")
                || value.contains("変更して") || value.contains("修正して")
                || value.contains("追加して") || value.contains("実装して")
                || value.contains("编写") || value.contains("创建")
                || value.contains("修改") || value.contains("修复")
                || value.contains("添加") || value.contains("实现")
                || value.contains("更新") || value.contains("اكتب")
                || value.contains("أنشئ") || value.contains("عدل")
                || value.contains("عدّل") || value.contains("أصلح");
    }

    /** A whole generated project may be executed only on an explicit request
     * to create/edit AND run/test it, inside the existing offline workspace. */
    static boolean projectRunAllowed(String message, Map<String,String> files) {
        if (!requested(message) || !runAllowed(message) || projectEntry(files).isEmpty()
                || files.size() > 48) return false;
        String value = message.toLowerCase(Locale.ROOT);
        if (!value.matches("(?s).*(?:проверь|протестируй|запусти|выполни|\\bverify\\b|\\brun\\b|\\bexecute\\b).*")) return false;
        return validProjectBytes(files);
    }

    static boolean singleSuiteRunAllowed(String message, String code) {
        if (code == null || code.trim().isEmpty() || code.getBytes(StandardCharsets.UTF_8).length > 64_000
                || !requested(message) || !runAllowed(message)) return false;
        return message.toLowerCase(Locale.ROOT).matches("(?s).*(?:проверь|протестируй|запусти|выполни|\\bverify\\b|\\brun\\b|\\bexecute\\b).*");
    }

    /** Keep the saved workspace installation contract (root main.py) separate
     * from an isolated execution of a delivered package. */
    static boolean validGeneratedProject(Map<String,String> files) {
        return files.containsKey("main.py") && validProjectBytes(files);
    }

    static String projectEntry(Map<String,String> files) {
        if (files.containsKey("main.py")) return "main.py";
        // A single root non-test Python module with an explicit main guard is
        // an unambiguous alternative to main.py. Never launch a test/helper
        // merely because it is first in the model output.
        String entry = "";
        for (Map.Entry<String,String> file : files.entrySet()) {
            String name = file.getKey();
            if (!PythonProjectPaths.validPath(name) || name.contains("/")
                    || !name.endsWith(".py") || name.startsWith("test") || name.endsWith("_test.py")) continue;
            if (!entry.isEmpty()) return "";
            entry = name;
        }
        if (entry.isEmpty() || files.get(entry) == null) return "";
        return Pattern.compile("(?m)^if[ \t]+__name__[ \t]*==[ \t]*[\"']__main__[\"'][ \t]*:")
                .matcher(files.get(entry)).find() ? entry : "";
    }

    private static boolean validProjectBytes(Map<String,String> files) {
        if (files.size() < 2 || files.size() > 48) return false;
        long total = 0;
        for (Map.Entry<String,String> file : files.entrySet()) {
            if (!PythonProjectPaths.validPath(file.getKey()) || file.getValue() == null) return false;
            int size = file.getValue().getBytes(StandardCharsets.UTF_8).length;
            if (size == 0 || size > 64_000) return false;
            total += size;
        }
        return total <= 64_000;
    }

    static Selection select(String userMessage, String answer, String[] savedPaths) {
        if (!requested(userMessage) || answer == null || answer.trim().isEmpty()
                || savedPaths == null || savedPaths.length == 0
                || ContinuationIntegrity.unclosedFence(answer)) return null;

        List<String> sources = PythonInputs.manualBlocks(answer);
        // Multiple examples/partial scripts must never automatically replace a saved file.
        if (sources.size() != 1) return null;
        String code = sources.get(0);
        if (code.trim().isEmpty()
                || code.getBytes(StandardCharsets.UTF_8).length > PythonProjectPaths.MAX_FILE_BYTES) return null;

        Map<String, String> named = PythonInputs.namedFiles(answer);
        if (PythonInputs.hasNamedFiles(answer) && named.size() != 1) return null;
        String path;
        if (named.isEmpty()) {
            path = PythonChatFile.target(code, savedPaths);
        } else {
            String declared = named.keySet().iterator().next();
            if (!declared.toLowerCase(Locale.ROOT).endsWith(".py")) return null;
            if (!code.equals(named.get(declared))) return null;
            // Resolve the explicit file= path against the project, including the
            // established src/main.py -> main.py single-file compatibility case.
            path = PythonChatFile.target("# " + declared + "\n" + code, savedPaths);
            String headerPath = PythonChatFile.target(code, savedPaths);
            if (!headerPath.isEmpty() && !headerPath.equals(path)) return null;
        }
        return path.isEmpty() ? null : new Selection(path, code);
    }
}
