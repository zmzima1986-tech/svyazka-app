package app.svyazka.mobile.ui

import android.graphics.Color
import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.res.stringResource
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import app.svyazka.mobile.MainActivity
import app.svyazka.mobile.NexusState
import app.svyazka.mobile.NexusPythonReport
import app.svyazka.mobile.R
import app.svyazka.mobile.attachments.AttachmentStore

/** Only state and UI navigation. Requests, Python execution and persistence remain in Java. */
class NexusComposeUi(val activity: MainActivity) {
    enum class Page { TASK, RESULT, MODELS, HISTORY, SETTINGS }
    enum class Panel { NONE, LEFT, RIGHT }
    enum class WorkspaceTab { PYTHON, CODE, LOGS, FILES }

    var snapshot by mutableStateOf(activity.nexusSnapshot())
        private set
    var verification by mutableStateOf(activity.nexusVerification())
        private set
    fun updateVerification() { verification = activity.nexusVerification() }
    var taskId by mutableLongStateOf(activity.nexusTaskId())
        private set
    init { AttachmentStore.get(activity).ensure(taskId) }
    var draft by mutableStateOf(snapshot.task)
        private set
    fun draftChanged(value: String) { draft = value; activity.nexusDraftChanged(value) }
    var chatText by mutableStateOf(if (snapshot.hasRun) "" else snapshot.task)
        private set
    fun chatTextChanged(value: String) {
        chatText = value
        if (!snapshot.hasRun) draftChanged(value)
    }
    fun submitChat() {
        if (snapshot.active || snapshot.clearing) return
        val message = chatText.trim()
        if (message.isBlank()) return
        if (!snapshot.hasRun) {
            draftChanged(message)
            activity.nexusStart()
        } else if (snapshot.complete) {
            activity.nexusFollowUp(message)
        }
        // Clear only after the Java workflow actually enters the running state.
    }
    var page by mutableStateOf(Page.TASK)
        private set
    var panel by mutableStateOf(Panel.NONE)
        private set
    var workspaceTab by mutableStateOf(WorkspaceTab.PYTHON)
    var teamSettingsRequested by mutableStateOf(false)
    var streaming by mutableStateOf("")
        private set
    private var lastStreamAt = 0L

    var visualPng by mutableStateOf("")
        private set
    var visualHtml by mutableStateOf("")
        private set
    var visualOpen by mutableStateOf(false)
        private set
    var pythonCodeBlocks by mutableStateOf(emptyList<String>())
        private set
    var pythonEditingCode by mutableStateOf("")
    var pythonStdin by mutableStateOf("")
    var pythonMatplotlib by mutableStateOf(false)
    var pythonRemote by mutableStateOf(false)
    var pythonStep by mutableIntStateOf(0)
        private set
    var pythonHasPiston by mutableStateOf(false)
        private set
    var pythonBusy by mutableStateOf(false)
        private set
    var pythonReport by mutableStateOf<NexusPythonReport?>(null)
        private set
    var pythonError by mutableStateOf<String?>(null)
        private set

    fun requestPython(step: Int, codes: Array<String>, hasPiston: Boolean) {
        pythonStep = step
        pythonCodeBlocks = codes.toList()
        pythonEditingCode = codes.firstOrNull().orEmpty()
        pythonHasPiston = hasPiston
        workspaceTab = WorkspaceTab.PYTHON
        openRight()
    }
    fun dismissPythonInput() { pythonCodeBlocks = emptyList() }
    fun pythonStarted() { pythonCodeBlocks = emptyList(); pythonBusy = true; pythonReport = null; pythonError = null }
    fun pythonFinished(report: NexusPythonReport) { pythonBusy = false; pythonReport = report }
    fun pythonFailed(error: String) { pythonBusy = false; pythonError = error }
    fun pythonCancelled() { pythonBusy = false; pythonError = null; pythonReport = null }
    fun dismissPythonResult() { pythonReport = null; pythonError = null }

    var versionsRequested by mutableStateOf(false)
        private set
    fun requestVersions() { versionsRequested = true }
    fun dismissVersions() { versionsRequested = false }
    var keysRequested by mutableStateOf(false)
        private set
    fun requestKeys() { keysRequested = true }
    fun dismissKeys() { keysRequested = false }
    var newTaskConfirm by mutableIntStateOf(0)
        private set
    fun requestNewTask() { if (!snapshot.active && !snapshot.clearing) newTaskConfirm = 1 }
    fun nextNewTaskConfirm() { if (newTaskConfirm == 1) newTaskConfirm = 2 }
    fun dismissNewTask() { newTaskConfirm = 0 }
    fun closeVisual() { visualOpen = false }

    fun openLeft() { panel = Panel.LEFT }
    fun openRight() { panel = Panel.RIGHT }
    fun closePanel() { panel = Panel.NONE }
    fun selectPage(newPage: Page) { page = newPage; panel = Panel.NONE }

    fun mount() {
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        val compose = ComposeView(activity)
        compose.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
        activity.setContentView(compose)
        compose.setContent { NexusApp(this) }
    }

    fun render(updated: NexusState, newPage: Page?) {
        val changedTask = taskId != activity.nexusTaskId()
        snapshot = updated
        updateVerification()
        taskId = activity.nexusTaskId()
        AttachmentStore.get(activity).ensure(taskId)
        if (updated.task != draft) draft = updated.task
        if (changedTask) {
            chatText = if (updated.hasRun) "" else updated.task
            pythonReport = null
            pythonError = null
            pythonCodeBlocks = emptyList()
            pythonEditingCode = ""
            pythonStdin = ""
        } else if (updated.active) {
            chatText = ""
        } else if (!updated.hasRun && updated.task != chatText) {
            chatText = updated.task
        }
        if (newPage != null) {
            // TASK and RESULT are one physical chat; Java keeps its persistence flags.
            page = if (newPage == Page.RESULT) Page.TASK else newPage
        }
        if (!updated.active) streaming = ""
    }

    fun open(newPage: Page) { selectPage(newPage) }
    fun onStreaming(text: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastStreamAt < 110) return
        lastStreamAt = now
        streaming = if (text.length > 5000) text.takeLast(5000) else text
    }
    var theme by mutableStateOf(activity.nexusThemeChoice())
        private set
    fun onThemeChanged(value: String) { theme = value }
    fun onVisualAvailable(available: Boolean) {
        if (!available) { visualPng = ""; visualHtml = "" }
        snapshot = activity.nexusSnapshot()
    }
    fun cacheVisual(png: String, html: String) { visualPng = png; visualHtml = html }
    fun showVisual(png: String, html: String) { cacheVisual(png, html); visualOpen = true }
    fun openVisual() { if (visualPng.isNotBlank() || visualHtml.isNotBlank()) visualOpen = true }

    fun navigateBack(): Boolean {
        if (visualOpen) { visualOpen = false; return true }
        if (panel != Panel.NONE) { closePanel(); return true }
        if (teamSettingsRequested) { teamSettingsRequested = false; return true }
        if (page == Page.MODELS || page == Page.SETTINGS || page == Page.HISTORY) {
            page = Page.TASK
            return true
        }
        return false
    }
}

@Composable
private fun NexusApp(ui: NexusComposeUi) {
    val activity = ui.activity
    val darkMode = ui.theme == "dark" ||
        (ui.theme == "system" && NexusSystemIsDark())
    SideEffect {
        @Suppress("DEPRECATION")
        activity.window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        activity.window.navigationBarColor = Color.TRANSPARENT
        val controller = WindowInsetsControllerCompat(activity.window, activity.window.decorView)
        controller.isAppearanceLightStatusBars = !darkMode
        controller.isAppearanceLightNavigationBars = !darkMode
    }
    NexusTheme(ui.theme) {
        // Android 12+ already presents a native splash until the first app frame.
        // Do not draw another Compose splash over it: that caused two successive
        // logos, a visible scale jump, and a flicker on modern devices.
        val useLegacySplash = android.os.Build.VERSION.SDK_INT < 31
        var showLegacySplash by rememberSaveable { mutableStateOf(useLegacySplash) }
        if (useLegacySplash) {
            LaunchedEffect(Unit) {
                // Older Android versions have no platform splash-screen icon.
                // Only show our branded surface until the initial UI can draw.
                withFrameNanos { }
                showLegacySplash = false
            }
        }
        BackHandler(enabled = true) {
            if (!ui.navigateBack()) activity.finish()
        }
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            Scaffold(
                modifier = Modifier.fillMaxSize().imePadding(),
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground,
                topBar = { NexusTopBar(ui) }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (ui.page) {
                        NexusComposeUi.Page.TASK, NexusComposeUi.Page.RESULT -> NexusChatScreen(ui)
                        NexusComposeUi.Page.HISTORY -> HistoryScreen(ui)
                        NexusComposeUi.Page.MODELS -> ModelsScreen(ui)
                        NexusComposeUi.Page.SETTINGS -> SettingsScreen(ui)
                    }
                }
            }
            NexusSidePanels(ui)
            if (ui.newTaskConfirm > 0) {
                AlertDialog(onDismissRequest = { ui.dismissNewTask() },
                    title = { Text(stringResource(if (ui.newTaskConfirm == 1)
                        R.string.confirm_new_first else R.string.confirm_new_second)) },
                    text = { Text(stringResource(if (ui.newTaskConfirm == 1)
                        R.string.confirm_new_first_message else R.string.confirm_new_second_message)) },
                    confirmButton = { TextButton(onClick = {
                        if (ui.newTaskConfirm == 1) ui.nextNewTaskConfirm()
                        else { ui.dismissNewTask(); ui.activity.nexusCreateTask() }
                    }) { Text(stringResource(if (ui.newTaskConfirm == 1)
                        R.string.action_continue else R.string.action_create)) } },
                    dismissButton = { TextButton(onClick = { ui.dismissNewTask() }) {
                        Text(stringResource(R.string.action_cancel))
                    } })
            }
            if (ui.keysRequested) KeysDialog(ui) { ui.dismissKeys() }
            if (ui.versionsRequested) VersionsDialog(ui)
            if (ui.teamSettingsRequested) NexusTeamSettings(ui)
            // Python runs and results are nonmodal: only the right panel renders them.
            VisualResultOverlay(ui)
            if (useLegacySplash) {
                AnimatedVisibility(visible = showLegacySplash,
                    enter = androidx.compose.animation.EnterTransition.None,
                    exit = fadeOut(animationSpec = tween(160)),
                    modifier = Modifier.fillMaxSize()) {
                    NexusSplashScreen()
                }
            }
        }
    }
}
