package app.svyazka.mobile.attachments

import android.content.Context
import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.AtomicFile
import app.svyazka.mobile.AttachmentParser
import app.svyazka.mobile.AttachmentProblem
import app.svyazka.mobile.AttachmentProblem.Code
import app.svyazka.mobile.InputMaterial
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import android.media.ExifInterface
import android.graphics.Matrix
import android.content.Intent
import java.security.MessageDigest
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Application-scoped draft materials, independent of screens, Activity rotation and SQLite. */
class AttachmentStore private constructor(private val context: Application) {
    enum class Status { ADDING, PROCESSING, READY, UNSUPPORTED, ERROR, LIMIT }
    data class Item(val id: String, val name: String, val mime: String, val size: Long,
        val kind: AttachmentParser.Kind, val status: Status, val reserved: Long = 0,
        val sha256: String = "", val width: Int = 0, val height: Int = 0,
        val content: String = "", val partial: Boolean = false, val processed: Int = 0,
        val total: Int = 0, val notes: List<AttachmentParser.Note> = emptyList(),
        val problem: Code? = null)
    data class Task(val loaded: Boolean = false, val items: List<Item> = emptyList(),
        val notice: Code? = null, val busy: Boolean = false)
    data class Prepared(val task: String, val refs: List<InputMaterial.Ref>)
    private val root = File(context.filesDir, "input-materials").apply { mkdirs() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val processing = Semaphore(2)
    private val operationCounts = ConcurrentHashMap<Long, AtomicInteger>()
    private val pending = MutableStateFlow<Map<Long, Int>>(emptyMap())
    val operations: StateFlow<Map<Long, Int>> = pending.asStateFlow()
    private val loading = HashSet<Long>()
    private val deleted = HashSet<Long>()
    private val epochs = ConcurrentHashMap<Long, AtomicInteger>()
    private val clearBarriers = ConcurrentHashMap<Long, CompletableDeferred<Unit>>()
    private val mutable = MutableStateFlow<Map<Long, Task>>(emptyMap())
    val states: StateFlow<Map<Long, Task>> = mutable.asStateFlow()
    init {
        scope.launch {
            listOf(File(context.cacheDir, "attachment-camera"), File(context.cacheDir, "pdf-text")).forEach { folder ->
                folder.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 24L * 60 * 60 * 1000 }?.forEach { it.deleteRecursively() }
            }
        }
    }
    private fun epoch(taskId: Long) = epochs.getOrPut(taskId) { AtomicInteger() }
    private fun operation(taskId: Long, delta: Int) {
        val counter = operationCounts.getOrPut(taskId) { AtomicInteger() }
        counter.addAndGet(delta)
        pending.update { it + (taskId to counter.get()) }
    }

    companion object {
        @Volatile private var instance: AttachmentStore? = null
        @JvmStatic fun get(context: Context): AttachmentStore = instance ?: synchronized(this) {
            instance ?: AttachmentStore(context.applicationContext as Application).also { instance = it }
        }
    }
    private fun directory(taskId: Long): File {
        require(taskId > 0)
        return File(root, "task-$taskId")
    }
    private fun file(taskId: Long, id: String, suffix: String): File {
        require(id.matches(Regex("[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}")))
        return File(directory(taskId), "$id.$suffix")
    }
    fun preview(taskId: Long, id: String): File = file(taskId, id, "preview.png")
    fun ensure(taskId: Long) {
        if (taskId <= 0 || mutable.value[taskId]?.loaded == true) return
        synchronized(loading) { if (!loading.add(taskId)) return }
        scope.launch { try { load(taskId) } finally { synchronized(loading) { loading.remove(taskId) } } }
    }
    private suspend fun load(taskId: Long) = mutex.withLock {
        if (mutable.value[taskId]?.loaded == true || deleted.contains(taskId)) return@withLock
        val folder = directory(taskId).apply { mkdirs() }
        folder.listFiles()?.filter { it.name.endsWith(".part") }?.forEach { it.delete() }
        val items = ArrayList<Item>()
        var notice: Code? = null
        val manifest = AtomicFile(File(folder, "manifest.json"))
        try {
            if (manifest.baseFile.exists() || File(folder, "manifest.json.bak").exists()) {
                val json = manifest.openRead().use { JSONObject(String(AttachmentParser.readBounded(it, 5L * 1024 * 1024), Charsets.UTF_8)) }
                require(json.getInt("version") == 1)
                val entries = json.getJSONArray("items")
                require(entries.length() <= InputMaterial.MAX_FILES)
                for (i in 0 until entries.length()) {
                    val entry = entries.getJSONObject(i)
                    val id = entry.getString("id")
                    val saved = Status.valueOf(entry.getString("status"))
                    val kind = AttachmentParser.Kind.valueOf(entry.getString("kind"))
                    var status = saved
                    var problem = entry.optString("problem").takeIf { it.isNotEmpty() }?.let { Code.valueOf(it) }
                    var content = ""
                    file(taskId, id, "source") // Validate opaque IDs before filesystem access.
                    if (saved == Status.ADDING || saved == Status.PROCESSING) {
                        status = Status.ERROR; problem = Code.INTERRUPTED
                        cleanItem(taskId, id)
                    } else if (saved == Status.READY) {
                        val data = file(taskId, id, if (kind == AttachmentParser.Kind.IMAGE) "source" else "text")
                        if (!data.isFile) { status = Status.ERROR; problem = Code.MISSING }
                        else if (kind != AttachmentParser.Kind.IMAGE) {
                            content = data.inputStream().use { String(AttachmentParser.readBounded(it, 2L * 1024 * 1024), Charsets.UTF_8) }
                        }
                    }
                    if (status == Status.READY) {
                        try { InputMaterial.Ref(taskId, id, entry.getString("name"), entry.getString("mime").ifEmpty { "text/plain" },
                            entry.getString("sha256"), entry.getLong("size"), entry.optInt("width"), entry.optInt("height")) }
                        catch (_: Exception) { status = Status.ERROR; problem = Code.INTEGRITY }
                    }
                    val notes = entry.optJSONArray("notes") ?: JSONArray()
                    items.add(Item(id, entry.getString("name"), entry.getString("mime"), entry.getLong("size"), kind, status,
                        sha256 = entry.optString("sha256"), width = entry.optInt("width"), height = entry.optInt("height"),
                        content = content, partial = entry.optBoolean("partial"), processed = entry.optInt("processed"),
                        total = entry.optInt("total"), problem = problem,
                        notes = (0 until notes.length()).map { index -> notes.getJSONObject(index).let { value ->
                            AttachmentParser.Note(value.getString("name"), value.optString("code").takeIf { it.isNotEmpty() }?.let { Code.valueOf(it) }) } }))
                }
            }
        } catch (_: Exception) { notice = Code.IO }
        publish(taskId, Task(true, items, notice))
    }
    private fun publish(taskId: Long, task: Task) {
        if (deleted.contains(taskId)) return
        val next = LinkedHashMap(mutable.value); next[taskId] = task
        if (next.size > 4) {
            next.entries.firstOrNull { it.key != taskId && it.value.items.none { item -> pending(item) } }?.let { next.remove(it.key) }
        }
        mutable.value = next
    }
    private fun pending(item: Item) = item.status == Status.ADDING || item.status == Status.PROCESSING
    private fun save(taskId: Long, task: Task) {
        val folder = directory(taskId).apply { mkdirs() }
        val items = JSONArray()
        task.items.forEach { item ->
            val notes = JSONArray()
            item.notes.forEach { note -> notes.put(JSONObject().put("name", note.name).put("code", note.code?.name ?: "")) }
            items.put(JSONObject().put("id", item.id).put("name", item.name).put("mime", item.mime).put("size", item.size)
                .put("kind", item.kind.name).put("status", item.status.name).put("sha256", item.sha256)
                .put("width", item.width).put("height", item.height).put("partial", item.partial)
                .put("processed", item.processed).put("total", item.total).put("problem", item.problem?.name ?: "").put("notes", notes))
        }
        val atomic = AtomicFile(File(folder, "manifest.json")); val output = atomic.startWrite()
        try { output.write(JSONObject().put("version", 1).put("items", items).toString().toByteArray(Charsets.UTF_8)); atomic.finishWrite(output) }
        catch (e: Exception) { atomic.failWrite(output); throw e }
    }
    private suspend fun update(taskId: Long, transform: (Task) -> Task) = mutex.withLock {
        if (deleted.contains(taskId)) return@withLock
        val current = mutable.value[taskId] ?: Task(true)
        val next = transform(current)
        try { save(taskId, next); publish(taskId, next) }
        catch (_: Exception) { publish(taskId, next.copy(notice = Code.IO)) }
    }
    private suspend fun replace(taskId: Long, item: Item) = update(taskId) { task ->
        if (task.items.none { it.id == item.id }) task else task.copy(items = task.items.map { if (it.id == item.id) item else it })
    }
    fun add(taskId: Long, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val counter = epoch(taskId)
        val (generation, clearing) = synchronized(counter) { counter.get() to clearBarriers[taskId] }
        operation(taskId, 1)
        scope.launch {
            try {
            clearing?.await()
            load(taskId)
            for (uri in uris.distinct()) {
                val persisted = runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); true }.getOrDefault(false)
                try { if (epoch(taskId).get() == generation) importOne(taskId, uri, generation) }
                finally {
                    if (persisted) runCatching { context.contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    if (uri.authority == context.packageName + ".attachments") runCatching { context.contentResolver.delete(uri, null, null) }
                }
            }
            } finally { operation(taskId, -1) }
        }
    }
    private suspend fun importOne(taskId: Long, uri: Uri, generation: Int) {
        val resolver = context.contentResolver
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "attachment"
        var declared = -1L
        try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val n = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val s = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (n >= 0 && !cursor.isNull(n)) name = cursor.getString(n)
                    if (s >= 0 && !cursor.isNull(s)) declared = cursor.getLong(s)
                }
            }
        } catch (_: Exception) { declared = -1 }
        name = name.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[\\p{Cc}]"), "_").ifBlank { "attachment" }
        val mime = runCatching { resolver.getType(uri) }.getOrNull().orEmpty()
        val kind = AttachmentParser.kind(name, mime)
        val id = UUID.randomUUID().toString()
        var item = Item(id, name.take(1024), mime, declared, kind, Status.ADDING)
        var accepted = false
        var cap = InputMaterial.MAX_FILE_BYTES
        update(taskId) { task ->
            if (epoch(taskId).get() != generation) task
            else if (task.items.size >= InputMaterial.MAX_FILES) task.copy(notice = Code.FILE_COUNT)
            else {
                val used = task.items.sumOf { if (pending(it)) it.reserved else if (it.status == Status.READY) it.size.coerceAtLeast(0) else 0 }
                cap = minOf(InputMaterial.MAX_FILE_BYTES, (InputMaterial.MAX_TOTAL_BYTES - used).coerceAtLeast(0))
                val error = when {
                    name.length > 1024 -> Code.UNSUPPORTED
                    declared > InputMaterial.MAX_FILE_BYTES -> Code.FILE_SIZE
                    cap == 0L || declared > cap -> Code.TOTAL_SIZE
                    kind == AttachmentParser.Kind.UNKNOWN -> Code.UNSUPPORTED
                    else -> null
                }
                item = item.copy(reserved = if (declared >= 0) declared.coerceAtMost(cap) else cap,
                    status = when (error) { null -> Status.ADDING; Code.UNSUPPORTED -> Status.UNSUPPORTED; else -> Status.LIMIT }, problem = error)
                accepted = error == null
                task.copy(items = task.items + item, notice = null)
            }
        }
        if (!accepted) return
        val folder = directory(taskId).apply { mkdirs() }
        val partial = file(taskId, id, "part"); val source = file(taskId, id, "source")
        try {
            resolver.openInputStream(uri)?.use { input ->
                partial.outputStream().use { output ->
                    val buffer = ByteArray(8192); var count: Int; var size = 0L
                    while (input.read(buffer).also { count = it } != -1) {
                        if (epoch(taskId).get() != generation || mutable.value[taskId]?.items?.none { it.id == id } != false) throw AttachmentProblem(Code.INTERRUPTED)
                        size += count
                        if (size > InputMaterial.MAX_FILE_BYTES) throw AttachmentProblem(Code.FILE_SIZE, name)
                        if (size > cap) throw AttachmentProblem(Code.TOTAL_SIZE, name)
                        output.write(buffer, 0, count)
                    }
                }
            } ?: throw AttachmentProblem(Code.IO, name)
            if (!partial.renameTo(source)) throw IOException("Cannot commit input file")
            processing.withPermit {
            val digest = MessageDigest.getInstance("SHA-256")
            source.inputStream().use { stream -> val buffer = ByteArray(8192); var count: Int
                while (stream.read(buffer).also { count = it } != -1) digest.update(buffer, 0, count)
            }
            val hash = digest.digest().joinToString("") { "%02x".format(java.util.Locale.ROOT, it.toInt() and 255) }
            // Provider metadata is only a reservation: enforce the aggregate against actual bytes
            // atomically, including other concurrent imports, before publishing processing/ready.
            update(taskId) { task ->
                if (epoch(taskId).get() != generation || task.items.none { it.id == id })
                    throw AttachmentProblem(Code.INTERRUPTED)
                val used = task.items.filter { it.id != id }.sumOf {
                    if (pending(it)) it.reserved else if (it.status == Status.READY) it.size.coerceAtLeast(0) else 0
                }
                val actual = source.length()
                if (actual + used > InputMaterial.MAX_TOTAL_BYTES) throw AttachmentProblem(Code.TOTAL_SIZE, name)
                item = item.copy(size = actual, reserved = actual, sha256 = hash, status = Status.PROCESSING)
                task.copy(items = task.items.map { if (it.id == id) item else it })
            }
            val result: AttachmentParser.Result
            if (kind == AttachmentParser.Kind.IMAGE) {
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(source.absolutePath, options)
                if (options.outWidth <= 0 || options.outHeight <= 0) throw AttachmentProblem(Code.IMAGE_INVALID, name)
                if (!InputMaterial.imageMime(options.outMimeType.orEmpty())) throw AttachmentProblem(Code.UNSUPPORTED, name)
                if (options.outWidth.toLong() * options.outHeight > 40_000_000L) throw AttachmentProblem(Code.IMAGE_PIXELS, name)
                val decoded = BitmapFactory.Options().apply {
                    inSampleSize = 1
                    while (options.outWidth / inSampleSize > 256 || options.outHeight / inSampleSize > 256) inSampleSize *= 2
                }
                val bitmap = BitmapFactory.decodeFile(source.absolutePath, decoded) ?: throw AttachmentProblem(Code.IMAGE_INVALID, name)
                var oriented = bitmap
                try {
                    if (options.outMimeType == "image/jpeg") {
                        val orientation = runCatching { ExifInterface(source.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
                        val matrix = Matrix()
                        when (orientation) {
                            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
                            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
                            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
                            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
                            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
                            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(270f); matrix.postScale(-1f, 1f) }
                            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(270f)
                        }
                        if (!matrix.isIdentity) oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                    }
                    preview(taskId, id).outputStream().use { if (!oriented.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IOException("Preview failed") }
                } finally { if (oriented !== bitmap) oriented.recycle(); bitmap.recycle() }
                item = item.copy(mime = options.outMimeType.orEmpty(), width = options.outWidth, height = options.outHeight)
                result = AttachmentParser.Result("", listOf(AttachmentParser.Note(name, null)), false, 1, 1)
            } else {
                result = if (kind == AttachmentParser.Kind.PDF) PdfTextExtractor.read(context, source, name)
                    else AttachmentParser.read(source, name, mime)
                val textFile = file(taskId, id, "text")
                val textPart = file(taskId, id, "text.part")
                textPart.writeText(result.text, Charsets.UTF_8)
                if (!textPart.renameTo(textFile)) throw IOException("Cannot commit extracted text")
                source.delete()
            }
            if (mutable.value[taskId]?.items?.none { it.id == id } != false) { cleanItem(taskId, id); return@withPermit }
            val unreadable = if (kind != AttachmentParser.Kind.IMAGE && result.processed == 0)
                if (kind == AttachmentParser.Kind.PDF) Code.PDF_NO_TEXT else Code.NOT_TEXT else null
            replace(taskId, item.copy(status = if (unreadable == null) Status.READY else Status.UNSUPPORTED,
                reserved = 0, content = result.text, partial = result.partial, problem = unreadable,
                processed = result.processed, total = result.total, notes = result.notes))
            if (unreadable != null) cleanItem(taskId, id)
            }
        } catch (e: Exception) {
            cleanItem(taskId, id)
            val code = (e as? AttachmentProblem)?.code ?: Code.IO
            val status = when (code) {
                Code.FILE_SIZE, Code.TOTAL_SIZE, Code.TEXT_SIZE, Code.PACKAGE_SIZE, Code.ZIP_COUNT, Code.ZIP_RATIO, Code.PDF_PAGES, Code.IMAGE_SIZE, Code.IMAGE_PIXELS -> Status.LIMIT
                Code.UNSUPPORTED, Code.NOT_TEXT, Code.PDF_NO_TEXT, Code.PDF_LOCKED -> Status.UNSUPPORTED
                else -> Status.ERROR
            }
            replace(taskId, item.copy(status = status, reserved = 0, problem = code))
        } finally {
            partial.delete()
            if (uri.authority == context.packageName + ".attachments") runCatching { resolver.delete(uri, null, null) }
        }
    }
    private fun cleanItem(taskId: Long, id: String) {
        val keep = file(taskId, id, "keep").exists()
        directory(taskId).listFiles()?.filter { it.name.startsWith("$id.") }?.forEach {
            if (!keep || it.name != "$id.source" && it.name != "$id.keep") it.delete()
        }
    }
    fun remove(taskId: Long, id: String) {
        operation(taskId, 1)
        scope.launch {
            try {
                load(taskId)
                update(taskId) { it.copy(items = it.items.filterNot { item -> item.id == id }, notice = null) }
                cleanItem(taskId, id)
            } finally { operation(taskId, -1) }
        }
    }
    fun clearDraft(taskId: Long) {
        val counter = epoch(taskId)
        val finished = CompletableDeferred<Unit>()
        val previous = synchronized(counter) {
            counter.incrementAndGet()
            clearBarriers.put(taskId, finished)
        }
        operation(taskId, 1)
        scope.launch {
            try {
                previous?.await()
                load(taskId)
                update(taskId) { Task(true) }
                directory(taskId).listFiles()?.map { it.name.substringBefore('.') }
                    ?.filter { it.matches(Regex("[a-f0-9-]{36}")) }?.distinct()?.forEach { cleanItem(taskId, it) }
            } finally {
                clearBarriers.remove(taskId, finished)
                operation(taskId, -1)
                finished.complete(Unit)
            }
        }
    }
    fun deleteTask(taskId: Long) {
        epoch(taskId).incrementAndGet()
        scope.launch { mutex.withLock {
            deleted.add(taskId); directory(taskId).deleteRecursively(); mutable.value = mutable.value - taskId
        } }
    }
    @Throws(AttachmentProblem::class)
    fun prepare(taskId: Long, draft: String): Prepared {
        if ((operationCounts[taskId]?.get() ?: 0) > 0) throw AttachmentProblem(Code.NOT_READY)
        val task = mutable.value[taskId] ?: throw AttachmentProblem(Code.LOADING)
        if (!task.loaded) throw AttachmentProblem(Code.LOADING)
        if (task.notice == Code.IO) throw AttachmentProblem(Code.IO)
        if (task.items.isEmpty()) return Prepared(draft, emptyList())
        task.items.firstOrNull { it.status != Status.READY }?.let { throw AttachmentProblem(it.problem ?: Code.NOT_READY, it.name) }
        val materials = JSONArray()
        val refs = task.items.map { item ->
            val report = JSONArray()
            item.notes.forEach { note ->
                report.put(JSONObject().put("name", note.name)
                    .put("status", if (note.code == null) "READ" else if (note.code == Code.DOCX_SCOPE || note.code == Code.PDF_SCOPE) "SCOPE" else "SKIPPED")
                    .put("reason", note.code?.name ?: ""))
            }
            materials.put(JSONObject().put("name", item.name).put("type", item.kind.name)
                .put("scope", if (item.partial) "PARTIAL EXTRACTION: consult processing report" else if (item.kind == AttachmentParser.Kind.DOCX) "Main document text only; no layout or images" else "Processed locally")
                .put("processed", item.processed).put("total", item.total).put("processing_report", report)
                .put("text", if (item.kind == AttachmentParser.Kind.IMAGE) "Image supplied as a separate image input" else item.content))
            InputMaterial.Ref(taskId, item.id, item.name, if (item.kind == AttachmentParser.Kind.IMAGE) item.mime else item.mime.ifEmpty { "text/plain" },
                item.sha256, item.size, item.width, item.height)
        }
        if (refs.filter { it.isImage }.sumOf { it.size } > InputMaterial.MAX_IMAGE_BYTES) throw AttachmentProblem(Code.IMAGE_SIZE)
        val combined = draft + "\n\n<attached_materials>\n" + materials + "\n</attached_materials>"
        if (InputMaterial.utf8(combined) > InputMaterial.MAX_REQUEST_TEXT_BYTES) throw AttachmentProblem(Code.REQUEST_TEXT_SIZE)
        return Prepared(combined, refs)
    }
    /** Empty keep markers pin immutable image bytes before a run can reference them durably. */
    @Throws(IOException::class)
    fun retain(taskId: Long, refs: List<InputMaterial.Ref>) {
        val created = ArrayList<File>()
        try {
            refs.filter { it.isImage }.forEach { ref ->
                if (ref.taskId != taskId || !file(taskId, ref.id, "source").isFile) throw AttachmentProblem(Code.MISSING, ref.name)
                val marker = file(taskId, ref.id, "keep")
                if (!marker.exists()) { if (!marker.createNewFile()) throw IOException("Cannot retain image"); created.add(marker) }
            }
        } catch (e: IOException) { created.forEach { it.delete() }; throw e }
    }
    @Throws(IOException::class)
    fun images(taskId: Long, refs: List<InputMaterial.Ref>): List<InputMaterial.Image> {
        var bytes = 0L
        return refs.filter { it.isImage }.map { ref ->
            if (ref.taskId != taskId) throw AttachmentProblem(Code.INTEGRITY, ref.name)
            bytes += ref.size
            if (bytes > InputMaterial.MAX_IMAGE_BYTES) throw AttachmentProblem(Code.IMAGE_SIZE)
            val data = file(taskId, ref.id, "source")
            if (!data.isFile) throw AttachmentProblem(Code.MISSING, ref.name)
            val content = FileInputStream(data).use { AttachmentParser.readBounded(it, InputMaterial.MAX_IMAGE_BYTES.toLong()) }
            InputMaterial.Image(ref, content)
        }
    }
}
