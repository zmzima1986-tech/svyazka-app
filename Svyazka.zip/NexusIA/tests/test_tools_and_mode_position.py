"""Source contracts only. Installable APK behavior requires Android build/device testing."""
from pathlib import Path
import unittest

UI = Path(__file__).resolve().parents[1] / 'app/src/main/java/app/svyazka/mobile/ui'


def source(name):
    return (UI / name).read_text(encoding='utf-8')


class ThreeRequestedUiFixes(unittest.TestCase):
    def test_tools_is_a_compact_clickable_button(self):
        s = source('NexusPythonWorkspace.kt')
        section = s[s.index('OutlinedButton(\n                onClick = { toolPanel = PythonToolPanel.MENU }'):s.index('NexusPrimaryButton(text = stringResource(R.string.ws_easy_run)')]
        self.assertIn('Icon(Icons.Outlined.Handyman, stringResource(R.string.ws_easy_tools)', section)
        self.assertIn('modifier = Modifier.size(44.dp)', section)
        self.assertIn('contentPadding = PaddingValues(0.dp)', section)
        self.assertNotIn('Modifier.fillMaxWidth()', section)
        self.assertIn('PythonToolPanel.MENU -> Column(', s)

    def test_composer_icons_centered_without_size_change(self):
        s = source('NexusChat.kt')
        composer = s.split('Surface(modifier = Modifier.fillMaxWidth().navigationBarsPadding()', 1)[1].split('\n@Composable', 1)[0]
        self.assertIn('verticalAlignment = Alignment.CenterVertically', composer)
        self.assertIn('Box(Modifier.align(Alignment.CenterVertically))', composer)
        self.assertIn('modifier = Modifier.size(42.dp)', composer)
        self.assertIn('Box(Modifier.size(43.dp).align(Alignment.CenterVertically)', composer)
        self.assertIn('maxLines = 5', composer)

    def test_drawer_history_and_artifacts_retain_return_path(self):
        ui = source('NexusComposeUi.kt')
        drawer = source('NexusDrawers.kt')
        self.assertIn('if (panel == Panel.LEFT && page != newPage) drawerReturnPage = page', ui)
        self.assertIn('if (panel == Panel.LEFT) selectPage(destination)', ui)
        self.assertIn('page = origin\n            panel = Panel.LEFT', ui)
        self.assertIn('state.putString("nexus.drawerReturnPage", it.name)', ui)
        self.assertIn('ui.activity.nexusOpenHistory()', drawer)
        self.assertIn('ui.activity.nexusOpenArtifacts()', drawer)
        self.assertNotIn('ui.closePanel(); ui.activity.nexusOpenHistory()', drawer)
        self.assertNotIn('ui.closePanel(); ui.activity.nexusOpenArtifacts()', drawer)

    def test_tools_from_drawer_go_back_to_drawer_on_all_close_paths(self):
        ui = source('NexusComposeUi.kt')
        self.assertIn('rightOpenedFromLeft = panel == Panel.LEFT', ui)
        self.assertIn('panel = if (panel == Panel.RIGHT && rightOpenedFromLeft) Panel.LEFT else Panel.NONE', ui)
        self.assertIn('if (panel != Panel.NONE) { closePanel(); return true }', ui)

    def test_team_settings_close_returns_to_drawer(self):
        ui = source('NexusComposeUi.kt')
        drawer = source('NexusDrawers.kt')
        self.assertIn('fun openTeamSettingsFromDrawer()', ui)
        self.assertIn('fun dismissTeamSettings()', ui)
        self.assertIn('if (teamSettingsFromLeft) panel = Panel.LEFT', ui)
        self.assertIn('ui.openTeamSettingsFromDrawer()', drawer)
        self.assertEqual(drawer.count('ui.dismissTeamSettings()'), 2)

    def test_chat_actions_moved_into_plus_without_changing_callbacks(self):
        chat = source('NexusChat.kt')
        self.assertNotIn('Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)', chat)
        self.assertIn('DropdownMenu(\n                            expanded = chatActionsExpanded,', chat)
        for callback in ('attachAction()', 'nexusSaveChat()', 'nexusOpenArtifact(ui.projectId)',
                         'nexusOpenArtifacts()', 'ui.workspaceTab = NexusComposeUi.WorkspaceTab.FILES'):
            self.assertIn(callback, chat)
        self.assertIn('fontSize = 12.sp', chat)
        components = source('NexusComponents.kt')
        self.assertIn('modifier = modifier.heightIn(min = 44.dp)', components)

    def test_python_project_and_results_collapsible_preserving_actions(self):
        workspace = source('NexusPythonWorkspace.kt')
        self.assertIn('projectActionsExpanded by rememberSaveable(ui.projectId)', workspace)
        self.assertIn('if (projectActionsExpanded) {\n                PythonProjectFiles(ui)', workspace)
        self.assertIn('ui.activity.nexusSaveArtifact(ui.pythonFileName, ui.pythonEditingCode)', workspace)
        self.assertIn('resultExpanded by rememberSaveable(ui.pythonReport)', workspace)
        self.assertIn('if (resultExpanded) {', workspace)
        self.assertIn('NexusLightPythonReport(ui, report, showArtifacts)', workspace)
        self.assertIn('if (showArtifacts) PythonRunArtifacts(ui)', workspace)
        self.assertIn('ui.activity.nexusAttachArtifactToChat()', workspace)
        self.assertIn('ui.activity.nexusDetachArtifactFromChat()', workspace)
        self.assertIn('onClick = { launch() }', workspace)


if __name__ == '__main__':
    unittest.main()
