**Solution Overview**

The project consists of three files:

| File | Purpose |
|------|---------|
| `expenses.py` | Core library – `ExpenseTracker` class with methods to add expenses, compute total, and group by category. |
| `main.py` | Simple console UI that uses `ExpenseTracker`. It gracefully handles `EOFError` so the program can be executed in non‑interactive environments. |
| `test_expenses.py` | Unit‑test suite (10 tests) that validates all behaviours of `ExpenseTracker`. |

All files are pure‑Python, use only the standard library, and are ready to run on the target **console** platform.

---

## expenses.py
```python
# file=expenses.py
"""
expenses.py – core logic of the expense‑tracking application.

Provides:
    - ExpenseTracker: class handling expense storage, total calculation,
      and grouping by categories.
"""

from __future__ import annotations
from collections import defaultdict
from typing import List, Dict


class ExpenseTracker:
    """
    Simple in‑memory expense tracker.
    """

    def __init__(self) -> None:
        # Each expense is stored as a dict: {"amount": float, "category": str}
        self._expenses: List[Dict[str, object]] = []

    # --------------------------------------------------------------------- #
    # Public API
    # --------------------------------------------------------------------- #
    def add_expense(self, amount: float, category: str) -> None:
        """
        Register a new expense.

        Parameters
        ----------
        amount : float
            Positive numeric amount of the expense.
        category : str
            Category name (case‑sensitive, empty string is allowed).

        Raises
        ------
        TypeError
            If ``amount`` is not a number.
        ValueError
            If ``amount`` is negative.
        """
        if not isinstance(amount, (int, float)):
            raise TypeError("Amount must be a number.")
        if amount < 0:
            raise ValueError("Amount cannot be negative.")
        self._expenses.append({"amount": float(amount), "category": str(category)})

    def total(self) -> float:
        """Return the sum of all recorded expenses."""
        return sum(exp["amount"] for exp in self._expenses)

    def by_category(self) -> Dict[str, float]:
        """
        Return a dictionary ``{category: total_amount}`` aggregating expenses
        per category.
        """
        result: Dict[str, float] = defaultdict(float)
        for exp in self._expenses:
            result[exp["category"]] += exp["amount"]
        return dict(result)

    def list_expenses(self) -> List[Dict[str, object]]:
        """Return a shallow copy of the internal expense list (read‑only)."""
        return list(self._expenses)

    # --------------------------------------------------------------------- #
    # Helper for debugging / representation
    # --------------------------------------------------------------------- #
    def __repr__(self) -> str:
        return f"<ExpenseTracker expenses={len(self._expenses)}>"
```

---

## main.py
```python
# file=main.py
"""
Console front‑end for the expense tracker.

Supported commands (case‑insensitive):

    add <amount> <category>   – add a new expense
    total                     – show total amount of all expenses
    categories                – show totals per category
    list                      – display all recorded expenses
    help                      – print this help message
    quit / exit               – terminate the program
"""

from __future__ import annotations
import sys
from expenses import ExpenseTracker


def _print_help() -> None:
    help_text = """
Commands:
  add <amount> <category>   Add a new expense.
  total                     Show total of all expenses.
  categories                Show totals grouped by category.
  list                      List all recorded expenses.
  help                      Show this help message.
  quit / exit               Exit the program.
"""
    print(help_text.strip())


def _cmd_add(tracker: ExpenseTracker, args: List[str]) -> None:
    if len(args) < 2:
        print("Usage: add <amount> <category>")
        return
    try:
        amount = float(args[0])
    except ValueError:
        print("Error: amount must be a number.")
        return
    category = " ".join(args[1:])
    try:
        tracker.add_expense(amount, category)
    except (TypeError, ValueError) as exc:
        print(f"Error: {exc}")
    else:
        print(f"Added expense: {amount:.2f} in category '{category}'.")


def _cmd_total(tracker: ExpenseTracker) -> None:
    print(f"Total expenses: {tracker.total():.2f}")


def _cmd_categories(tracker: ExpenseTracker) -> None:
    grouped = tracker.by_category()
    if not grouped:
        print("No expenses recorded yet.")
        return
    print("Expenses by category:")
    for cat, amt in sorted(grouped.items()):
        print(f"  {cat}: {amt:.2f}")


def _cmd_list(tracker: ExpenseTracker) -> None:
    expenses = tracker.list_expenses()
    if not expenses:
        print("No expenses recorded yet.")
        return
    print("All expenses:")
    for i, exp in enumerate(expenses, start=1):
        print(f"  {i}. {exp['amount']:.2f} – {exp['category']}")


def main() -> None:
    tracker = ExpenseTracker()
    _print_help()
    while True:
        try:
            raw = input("\n> ").strip()
        except EOFError:
            # End‑of‑file (e.g., when piped) → exit gracefully
            print("\nEOF received – exiting.")
            break

        if not raw:
            continue
        parts = raw.split()
        command = parts[0].lower()
        args = parts[1:]

        if command in ("quit", "exit"):
            print("Good bye!")
            break
        elif command == "help":
            _print_help()
        elif command == "add":
            _cmd_add(tracker, args)
        elif command == "total":
            _cmd_total(tracker)
        elif command == "categories":
            _cmd_categories(tracker)
        elif command == "list":
            _cmd_list(tracker)
        else:
            print(f"Unknown command: '{command}'. Type 'help' for list of commands.")


if __name__ == "__main__":
    # When executed directly, start the interactive console UI.
    main()
```

---

## test_expenses.py
```python
# file=test_expenses.py
"""
Unit‑test suite for the ExpenseTracker class.

Contains 10 automated tests covering:
  - basic addition
  - total calculation (empty / multiple)
  - grouping by category
  - error handling (type, negative values)
  - case sensitivity
  - floating‑point precision
"""

import unittest
from expenses import ExpenseTracker


class TestExpenseTracker(unittest.TestCase):
    def setUp(self) -> None:
        self.tracker = ExpenseTracker()

    # 1. Adding a single expense should be stored correctly
    def test_add_single(self):
        self.tracker.add_expense(12.5, "Food")
        self.assertEqual(len(self.tracker.list_expenses()), 1)
        self.assertAlmostEqual(self.tracker.total(), 12.5)

    # 2. Total of an empty tracker is zero
    def test_total_empty(self):
        self.assertEqual(self.tracker.total(), 0.0)

    # 3. Total with several expenses
    def test_total_multiple(self):
        self.tracker.add_expense(10, "Transport")
        self.tracker.add_expense(20.75, "Food")
        self.tracker.add_expense(5, "Entertainment")
        self.assertAlmostEqual(self.tracker.total(), 35.75)

    # 4. Grouping by category with a single entry
    def test_by_category_single(self):
        self.tracker.add_expense(7, "Books")
        self.assertDictEqual(self.tracker.by_category(), {"Books": 7.0})

    # 5. Grouping by category with multiple entries, same category
    def test_by_category_aggregate(self):
        self.tracker.add_expense(5, "Food")
        self.tracker.add_expense(15, "Food")
        self.tracker.add_expense(8, "Travel")
        expected = {"Food": 20.0, "Travel": 8.0}
        self.assertDictEqual(self.tracker.by_category(), expected)

    # 6. Adding expense with non‑numeric amount raises TypeError
    def test_add_invalid_amount_type(self):
        with self.assertRaises(TypeError):
            self.tracker.add_expense("ten", "Misc")

    # 7. Adding expense with negative amount raises ValueError
    def test_add_negative_amount(self):
        with self.assertRaises(ValueError):
            self.tracker.add_expense(-5, "Misc")

    # 8. Category names are case‑sensitive
    def test_category_case_sensitivity(self):
        self.tracker.add_expense(10, "food")
        self.tracker.add_expense(20, "Food")
        expected = {"food": 10.0, "Food": 20.0}
        self.assertDictEqual(self.tracker.by_category(), expected)

    # 9. Floating‑point precision is preserved (within tolerance)
    def test_total_precision(self):
        self.tracker.add_expense(0.1, "Misc")
        self.tracker.add_expense(0.2, "Misc")
        self.assertAlmostEqual(self.tracker.total(), 0.3, places=7)

    # 10. Grouping when there are no expenses returns empty dict
    def test_by_category_no_expenses(self):
        self.assertDictEqual(self.tracker.by_category(), {})


if __name__ == "__main__":
    # Running the test suite directly from the command line.
    unittest.main(verbosity=2)
```

---

### How to Run the Project

1. **Interactive console program**

```bash
python main.py
```

   - Use the commands described in the help output (`add`, `total`, `categories`, `list`, `quit`, …).

2. **Run the automated tests**

```bash
python test_expenses.py
```

   - The test runner will execute all 10 tests and report success/failure.

Both commands work on a plain Python installation (≥3.8) and require no external dependencies. The program also handles `EOFError` in `main.py`, making it safe for automated execution environments.