#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Простой консольный калькулятор с четырьмя арифметическими операциями.
* Защита от деления на ноль (генерирует ValueError с понятным сообщением).
* Автоматические тесты, выполненные через assert при запуске скрипта.
* Корректная обработка EOFError – позволяет запускать скрипт в средах,
  где stdin может быть закрыт (например, при автоматических проверках).
"""

def add(a: float, b: float) -> float:
    """Сложение."""
    return a + b


def sub(a: float, b: float) -> float:
    """Вычитание."""
    return a - b


def mul(a: float, b: float) -> float:
    """Умножение."""
    return a * b


def div(a: float, b: float) -> float:
    """Деление с проверкой деления на ноль."""
    if b == 0:
        raise ValueError("Деление на ноль недопустимо")
    return a / b


def calculate(a: float, b: float, op: str) -> float:
    """Выполняет требуемую арифметическую операцию."""
    ops = {
        '+': add,
        '-': sub,
        '*': mul,
        '/': div,
    }
    if op not in ops:
        raise ValueError(f"Неизвестный оператор: {op!r}. Допустимые: + - * /")
    return ops[op](a, b)


def run_tests() -> None:
    """Набор простых тестов, проверяющих корректность функций."""
    # Тесты на обычные операции
    assert add(2, 3) == 5
    assert sub(5, 2) == 3
    assert mul(4, 2.5) == 10.0
    assert div(9, 3) == 3.0

    # Тесты с отрицательными и дробными числами
    assert add(-1, -1) == -2
    assert sub(-5, 2) == -7
    assert mul(-3, 0.5) == -1.5
    assert div(-8, -2) == 4.0

    # Тест защиты от деления на ноль
    try:
        div(5, 0)
        assert False, "Ожидалось исключение ValueError при делении на ноль"
    except ValueError as e:
        assert str(e) == "Деление на ноль недопустимо"

    # Тест неизвестного оператора
    try:
        calculate(1, 2, '^')
        assert False, "Ожидалось исключение ValueError при неизвестном операторе"
    except ValueError as e:
        assert "Неизвестный оператор" in str(e)

    # Если дошли сюда – все тесты прошли
    print("✅ Все автоматические тесты пройдены успешно.")


def interactive_mode() -> None:
    """Запускает простой REPL‑цикл калькулятора."""
    print("Простой калькулятор. Введите выражение в виде: <число> <оператор> <число>")
    print("Поддерживаемые операторы: + - * /")
    print("Для выхода нажмите Ctrl+D (EOF).")
    while True:
        try:
            line = input("> ").strip()
        except EOFError:
            # Пользователь завершил ввод (Ctrl+D) – выходим из программы
            print("\nЗавершение работы.")
            break

        if not line:
            # Пустая строка – просто спросим ввод ещё раз
            continue

        parts = line.split()
        if len(parts) != 3:
            print("Ошибка: ожидается ровно три элемента: число оператор число")
            continue

        a_str, op, b_str = parts
        try:
            a = float(a_str)
            b = float(b_str)
        except ValueError:
            print("Ошибка: оба операнда должны быть числами.")
            continue

        try:
            result = calculate(a, b, op)
        except ValueError as exc:
            print(f"Ошибка: {exc}")
            continue

        # Выводим результат, убирая лишний .0 у целых значений
        if result.is_integer():
            result = int(result)
        print(f"= {result}")


if __name__ == "__main__":
    # Сначала запускаем тесты – если они падают, скрипт завершится с исключением.
    run_tests()
    # Затем переходим в интерактивный режим.
    interactive_mode()
