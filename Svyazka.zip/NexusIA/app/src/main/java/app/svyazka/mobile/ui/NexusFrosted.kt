package app.svyazka.mobile.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/** One lightweight, translucent surface for drawers and dialogs in both themes.
 *  It intentionally avoids expensive full-screen blur on older Android devices.
 */
@Composable
internal fun nexusFrostedColor(): Color =
    if (MaterialTheme.colorScheme.background.luminance() < .5f)
        Color(0xFF10121C).copy(alpha = .94f)
    else Color.White.copy(alpha = .94f)

@Composable
internal fun NexusFrostedPanel(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(0.dp),
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier,
        shape = shape,
        color = nexusFrostedColor(),
        contentColor = MaterialTheme.colorScheme.onSurface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f)),
        tonalElevation = 0.dp,
        content = content
    )
}

/** Keep the existing dialog actions while using the same surface as the side menu. */
@Composable
internal fun NexusFrostedAlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: @Composable (() -> Unit)? = null,
    icon: @Composable (() -> Unit)? = null,
    title: @Composable (() -> Unit)? = null,
    text: @Composable (() -> Unit)? = null
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = confirmButton,
        modifier = modifier,
        dismissButton = dismissButton,
        icon = icon,
        title = title,
        text = text,
        shape = RoundedCornerShape(24.dp),
        containerColor = nexusFrostedColor(),
        tonalElevation = 0.dp
    )
}
