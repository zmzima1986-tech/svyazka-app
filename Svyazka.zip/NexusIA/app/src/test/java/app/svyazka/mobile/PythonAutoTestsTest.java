package app.svyazka.mobile;

import static org.junit.Assert.*;

import org.json.JSONArray;
import org.junit.Test;

/** Offline tests: only the user's expectation is an oracle, never the AI reply. */
public class PythonAutoTestsTest {
    private SandboxClient.Result success(String stdout) {
        return new SandboxClient.Result(stdout, "", "Pyodide", 0, "");
    }

    @Test public void matchingOutputIsAnActualPassedTest() {
        PythonAutoTests.Assessment check = PythonAutoTests.evaluate(
                "Измени main.py.\nОжидаемый вывод: «ШАГ 5 РАБОТАЕТ»", success("ШАГ 5 РАБОТАЕТ\n"));
        assertTrue(check.checked);
        assertTrue(check.passed);
        SandboxClient.Result report = check.report("1/1");
        assertEquals(0, report.exitCode.intValue());
        assertEquals(1, report.tests.length());
        assertTrue(report.tests.optJSONObject(0).optBoolean("passed", false));
        assertFalse(PythonAutoTests.failed(report));
    }

    @Test public void wrongOutputFailsEvenWithExitCodeZero() {
        PythonAutoTests.Assessment check = PythonAutoTests.evaluate(
                "Ожидаемый вывод: «5»", success("4\n"));
        assertTrue(check.checked);
        assertFalse(check.passed);
        SandboxClient.Result report = check.report("Wrong output");
        assertEquals(0, report.exitCode.intValue()); // Actual process status is never falsified.
        assertTrue(PythonAutoTests.failed(report));
        assertEquals("4", report.tests.optJSONObject(0).optString("actual"));
        assertEquals("5", report.tests.optJSONObject(0).optString("expected"));
        assertEquals("Wrong output", report.status);
        assertTrue(PythonAutoTests.failureDiagnostic(report).contains("expected 5"));
    }

    @Test public void quotedRussianOutputWithInstructionPeriodPasses() {
        String request = "Измени подключённый main.py, чтобы программа выводила текст «ШАГ 5 ПРОВЕРЕНО».\n"
                + "Ожидаемый вывод: «ШАГ 5 ПРОВЕРЕНО».\nНапиши полный код файла.";
        PythonAutoTests.Assessment check = PythonAutoTests.evaluate(
                request, success("ШАГ 5 ПРОВЕРЕНО\n"));
        assertTrue(check.checked);
        assertTrue(check.passed);
        assertEquals("ШАГ 5 ПРОВЕРЕНО", check.expected);
        assertFalse(PythonAutoTests.failed(check.report("1/1")));
        assertTrue(check.report("1/1").tests.optJSONObject(0).optBoolean("passed"));
    }

    @Test public void punctuationInsideQuotesStillMustMatchExactly() {
        assertTrue(PythonAutoTests.evaluate(
                "Ожидаемый вывод: «Готово.»", success("Готово.\n")).passed);
        PythonAutoTests.Assessment wrong = PythonAutoTests.evaluate(
                "Ожидаемый вывод: «Готово.»", success("Готово\n"));
        assertTrue(wrong.checked);
        assertFalse(wrong.passed);
        assertTrue(PythonAutoTests.failed(wrong.report("mismatch")));
    }

    @Test public void unquotedPeriodIsPartOfExpectedOutput() {
        assertTrue(PythonAutoTests.evaluate(
                "Ожидаемый вывод: Готово.", success("Готово.\n")).passed);
        assertFalse(PythonAutoTests.evaluate(
                "Ожидаемый вывод: Готово.", success("Готово\n")).passed);
    }

    @Test public void quotePairsWorkAcrossLanguageLabelsAndSentenceStops() {
        assertTrue(PythonAutoTests.evaluate(
                "Expected output: \"done\".", success("done\n")).passed);
        assertTrue(PythonAutoTests.evaluate(
                "预期输出：「完成」。", success("完成\n")).passed);
        assertTrue(PythonAutoTests.evaluate(
                "期待する出力：「完了」。", success("完了\n")).passed);
        assertTrue(PythonAutoTests.evaluate(
                "الناتج المتوقع: 'تم'.", success("تم\n")).passed);
    }

    @Test public void malformedQuotationIsNotGuessedAsCorrectOutput() {
        PythonAutoTests.Assessment check = PythonAutoTests.evaluate(
                "Ожидаемый вывод: «Готово.", success("Готово.\n"));
        assertTrue(check.checked);
        assertFalse(check.passed);
    }

    @Test public void withoutUserExpectationNoTestIsInvented() {
        PythonAutoTests.Assessment check = PythonAutoTests.evaluate(
                "Создай калькулятор", success("42\n"));
        assertFalse(check.checked);
        assertEquals(0, check.report("unused").tests.length());
    }

    @Test public void runtimeFailureIsNotOverwrittenByOutputTest() {
        SandboxClient.Result error = new SandboxClient.Result("", "ZeroDivisionError", "Pyodide", 1, "");
        PythonAutoTests.Assessment check = PythonAutoTests.evaluate("Ожидаемый вывод: ok", error);
        assertFalse(check.checked);
        assertSame(error, check.report("unused"));
    }

    @Test public void conflictingUserExpectationsAreNotSilentlySelected() {
        PythonAutoTests.Assessment check = PythonAutoTests.evaluate(
                "Ожидаемый вывод: one\nОжидаемый вывод: two", success("two\n"));
        assertFalse(check.checked);
    }

    @Test public void englishJapaneseChineseArabicAreRecognized() {
        assertTrue(PythonAutoTests.evaluate("Expected output: done", success("done\n")).passed);
        assertTrue(PythonAutoTests.evaluate("期待する出力：完了", success("完了\n")).passed);
        assertTrue(PythonAutoTests.evaluate("预期输出：完成", success("完成\n")).passed);
        assertTrue(PythonAutoTests.evaluate("الناتج المتوقع: اكتمل", success("اكتمل\n")).passed);
    }

    @Test public void multiLineUnexpectedOutputIsFailure() {
        PythonAutoTests.Assessment check = PythonAutoTests.evaluate(
                "Ожидаемый вывод: ok", success("ok\nextra\n"));
        assertTrue(check.checked);
        assertFalse(check.passed);
    }

    @Test public void otherSandboxTestsArePreserved() throws Exception {
        SandboxClient.Result base = new SandboxClient.Result("42\n", "", "Pyodide", 0, "",
                "", "", new JSONArray(), new JSONArray().put(
                        new org.json.JSONObject().put("name", "Existing sandbox test")
                                .put("passed", true)), "digest");
        SandboxClient.Result report = PythonAutoTests.evaluate("Ожидаемый вывод: 42", base).report("ok");
        assertEquals(2, report.tests.length());
        assertEquals("Existing sandbox test", report.tests.optJSONObject(0).optString("name"));
        assertEquals("digest", report.snapshotSha256);
    }

    @Test public void latestChatClarificationControlsStdoutNotOldHistory() {
        String initial = "Измени main.py.\nОжидаемый вывод: «ШАГ 4 РАБОТАЕТ»";
        String followUp = TaskHistory.followUp(initial, "```python\nprint('ШАГ 4 РАБОТАЕТ')\n```",
                "Измени main.py.\nОжидаемый вывод: «ШАГ 5 РАБОТАЕТ»");
        String latest = TaskHistory.currentUserTestRequest(followUp);
        assertFalse(latest.contains("ШАГ 4 РАБОТАЕТ"));
        assertTrue(PythonAutoTests.evaluate(latest, success("ШАГ 5 РАБОТАЕТ\n")).passed);
        assertFalse(PythonAutoTests.evaluate(latest, success("ШАГ 4 РАБОТАЕТ\n")).passed);
    }

    @Test public void feedbackRepairKeepsLatestUserStdoutNotModelInstructions() {
        String initial = "Создай main.py.\nОжидаемый вывод: «ПРЕЖНИЙ»";
        String followUp = TaskHistory.followUp(initial, "```python\nprint('ПРЕЖНИЙ')\n```",
                "Обнови main.py.\nОжидаемый вывод: «ШАГ 5 РАБОТАЕТ»");
        String feedback = PythonAutoFeedback.functionalTestPrompt(TaskHistory.forRepair(followUp),
                "main.py", "print('неверно')", "Failed user-provided Python tests");
        assertFalse(feedback.isEmpty());
        String latest = TaskHistory.currentUserTestRequest(feedback);
        assertTrue(PythonAutoTests.evaluate(latest, success("ШАГ 5 РАБОТАЕТ\n")).passed);
        assertFalse(PythonAutoTests.evaluate(latest, success("ПРЕЖНИЙ\n")).passed);
    }

    @Test public void olderExpectationDoesNotApplyWhenNewRequestHasNone() {
        String followUp = TaskHistory.followUp("Ожидаемый вывод: «СТАРЫЙ»",
                "```python\nprint('СТАРЫЙ')\n```", "Измени main.py, добавь обработку ошибок");
        String latest = TaskHistory.currentUserTestRequest(followUp);
        assertFalse(PythonAutoTests.evaluate(latest, success("что-то другое\n")).checked);
    }

    @Test public void currentPlainRequestStillUsesExactOutput() {
        String current = TaskHistory.currentUserTestRequest(
                "Измени main.py.\nОжидаемый вывод: «ШАГ 5 РАБОТАЕТ»");
        assertTrue(PythonAutoTests.evaluate(current, success("ШАГ 5 РАБОТАЕТ\n")).checked);
    }

    @Test public void existingProjectTestFailureTriggersRepairEvenWhenProcessExitedZero() throws Exception {
        JSONArray cases = new JSONArray().put(new org.json.JSONObject()
                .put("name", "case one").put("passed", false)
                .put("stdin", "3\n").put("expected", "9\n").put("actual", "6\n"));
        SandboxClient.Result result = new SandboxClient.Result("ready\n", "", "Pyodide", 0, "Tests: 0/1",
                "", "", new JSONArray(), cases, "snapshot");
        assertTrue(PythonAutoTests.failed(result));
        String diagnostic = PythonAutoTests.failureDiagnostic(result);
        assertTrue(diagnostic.contains("case one"));
        assertTrue(diagnostic.contains("expected 9"));
        assertTrue(diagnostic.contains("actual 6"));
    }
}
