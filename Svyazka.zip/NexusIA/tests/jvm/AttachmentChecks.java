package app.svyazka.mobile;

import java.io.File;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLStreamHandler;
import java.net.URLConnection;
import java.security.cert.Certificate;
import java.util.ArrayList;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;

/** Real ZIP/OOXML fixtures, encoding failures and end-to-end immutable request contracts. No network. */
public final class AttachmentChecks {
    private static int checked;
    private static final Path DIRECTORY;
    static { try { DIRECTORY = Files.createTempDirectory("nexus-materials-"); } catch (Exception e) { throw new ExceptionInInitializerError(e); } }
    private interface Checked { void run() throws Exception; }
    private static void expect(AttachmentProblem.Code code, Checked action) throws Exception {
        try { action.run(); throw new AssertionError("Expected " + code); }
        catch (AttachmentProblem actual) { assert actual.code == code : actual; checked++; }
    }
    private static void check(boolean valid) { assert valid; checked++; }
    private static File data(String name, byte[] bytes) throws Exception { Path path = DIRECTORY.resolve(name); Files.write(path, bytes); return path.toFile(); }
    private static File zip(String name, String... pathsAndContents) throws Exception {
        File file = DIRECTORY.resolve(name).toFile();
        try (ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(file.toPath()))) {
            for (int i = 0; i < pathsAndContents.length; i += 2) {
                out.putNextEntry(new ZipEntry(pathsAndContents[i])); out.write(pathsAndContents[i + 1].getBytes(StandardCharsets.UTF_8)); out.closeEntry();
            }
        }
        return file;
    }
    private static ModelCatalog.Model vision(int context) throws Exception {
        JSONObject entry = new JSONObject().put("id", "fixture/vision:free").put("name", "Fixture vision")
                .put("pricing", new JSONObject().put("prompt", "0").put("completion", "0"))
                .put("context_length", context).put("top_provider", new JSONObject().put("max_completion_tokens", 32768))
                .put("architecture", new JSONObject().put("input_modalities", new JSONArray(Arrays.asList("text", "image")))
                        .put("output_modalities", new JSONArray(Collections.singletonList("text"))));
        return ModelCatalog.fromOpenRouter(new JSONObject().put("data", new JSONArray().put(entry))).choices().get(0);
    }
    private static final List<JSONObject> sent = new ArrayList<>();
    private static final class OfflineHttps extends HttpsURLConnection {
        private final ByteArrayOutputStream output = new ByteArrayOutputStream();
        OfflineHttps(URL url) { super(url); }
        @Override public void connect() {}
        @Override public void disconnect() {}
        @Override public boolean usingProxy() { return false; }
        @Override public String getCipherSuite() { return "offline-fixture"; }
        @Override public Certificate[] getLocalCertificates() { return new Certificate[0]; }
        @Override public Certificate[] getServerCertificates() { return new Certificate[0]; }
        @Override public OutputStream getOutputStream() { return output; }
        @Override public int getResponseCode() { return 200; }
        @Override public String getContentType() { return "text/event-stream"; }
        @Override public InputStream getInputStream() {
            try {
                check("Bearer fixture-only".equals(getRequestProperty("Authorization")));
                sent.add(new JSONObject(new String(output.toByteArray(), StandardCharsets.UTF_8)));
                String answer = sent.size() == 2 ? "Checked.\n[[REVIEW: PASS]]" : sent.size() == 1 ? "Solution" : "Edited final";
                String event = new JSONObject().put("choices", new JSONArray().put(new JSONObject()
                        .put("delta", new JSONObject().put("content", answer)).put("finish_reason", "stop"))).toString();
                return new ByteArrayInputStream(("data: " + event + "\n\ndata: [DONE]\n\n").getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) { throw new AssertionError(e); }
        }
    }
    private static void transport(ModelCatalog.Model model, InputMaterial.Ref ref, InputMaterial.Image image) throws Exception {
        URL.setURLStreamHandlerFactory(protocol -> !protocol.equals("https") ? null : new URLStreamHandler() {
            @Override protected URLConnection openConnection(URL url) {
                check(url.getHost().equals("openrouter.ai"));
                return new OfflineHttps(url);
            }
        });
        List<Workflow.Stage> stages = new ArrayList<>();
        for (Workflow.Stage original : Workflow.defaultStages()) stages.add(new Workflow.Stage(original.role, original.instruction, model));
        Workflow.Run run = new Workflow.Run("Review the attached document: original document text", stages).withMaterials(Collections.singletonList(ref));
        ModelClient client = new ModelClient();
        while (!run.complete()) {
            ModelClient.Reply reply = client.complete(run, model, "fixture-only", new ModelClient.Cancellation(), text -> {}, Collections.singletonList(image));
            check(reply.finish == ModelClient.Finish.STOP);
            run = run.receive(reply);
        }
        check(run.answers.size() == 3 && !run.revisionSkipped());
        check(sent.size() == 3);
        for (JSONObject body : sent) {
            JSONArray content = body.getJSONArray("messages").getJSONObject(1).getJSONArray("content");
            check(content.getJSONObject(0).getString("text").contains("original document text"));
            check(content.getJSONObject(2).getJSONObject("image_url").getString("url").endsWith(image.base64));
        }
    }

    public static void main(String[] args) throws Exception {
        try {
            File txt = data("test.txt", "Привет\nsecond line".getBytes(StandardCharsets.UTF_8));
            check(AttachmentParser.read(txt, "test.txt", "text/plain").text.equals("Привет\nsecond line"));
            check(AttachmentParser.read(txt, "test.md", "").processed == 1);
            byte[] utf16 = "\ufeffЯпонский 日本語".getBytes(StandardCharsets.UTF_16LE);
            check(AttachmentParser.decode(utf16).equals("Японский 日本語"));
            expect(AttachmentProblem.Code.ENCODING, () -> AttachmentParser.decode(new byte[] {(byte) 0xc3, 0x28}));
            expect(AttachmentProblem.Code.NOT_TEXT, () -> AttachmentParser.decode(new byte[] {65, 0, 66}));
            expect(AttachmentProblem.Code.TEXT_SIZE, () -> AttachmentParser.decode(new byte[InputMaterial.MAX_TEXT_CHARS + 1]));
            check(!AttachmentParser.safePath("../outside.txt")); check(!AttachmentParser.safePath("C:\\secrets.txt"));
            check(!AttachmentParser.safePath("/etc/passwd")); check(!AttachmentParser.safePath("a/../../b"));
            File safe = zip("safe.zip", "src/main.py", "print('safe, not executed')", "README.md", "# Notes", "nested.zip", "not unpacked", "image.png", "binary skipped");
            AttachmentParser.Result result = AttachmentParser.read(safe, "safe.zip", "application/zip");
            check(result.partial && result.processed == 2 && result.total == 4);
            check(new JSONObject(result.text).getJSONArray("processed_files").getJSONObject(0).getString("text").contains("not executed"));
            check(result.notes.get(2).code == AttachmentProblem.Code.NESTED_ARCHIVE);
            check(result.notes.get(3).code == AttachmentProblem.Code.BINARY_ENTRY);
            AttachmentParser.Result skipped = AttachmentParser.read(zip("binary-only.zip", "image.png", "binary", "child.zip", "nested"), "binary-only.zip", "");
            check(skipped.processed == 0 && skipped.total == 2 && skipped.partial && skipped.text.isEmpty());
            check(skipped.notes.size() == 2 && skipped.notes.get(0).code == AttachmentProblem.Code.BINARY_ENTRY);
            expect(AttachmentProblem.Code.ZIP_PATH, () -> AttachmentParser.read(zip("slip.zip", "../out.txt", "unsafe"), "slip.zip", ""));
            expect(AttachmentProblem.Code.CORRUPT, () -> AttachmentParser.read(data("broken.zip", new byte[] {80, 75, 3, 4, 1}), "broken.zip", ""));
            File many = DIRECTORY.resolve("many.zip").toFile();
            try (ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(many.toPath()))) {
                for (int i = 0; i <= AttachmentParser.MAX_ENTRIES; i++) { out.putNextEntry(new ZipEntry(i + ".txt")); out.write(65); out.closeEntry(); }
            }
            expect(AttachmentProblem.Code.ZIP_COUNT, () -> AttachmentParser.read(many, "many.zip", ""));
            File bomb = zip("bomb.zip", "large.txt", String.join("", Collections.nCopies(2_000_000, "A")));
            expect(AttachmentProblem.Code.ZIP_RATIO, () -> AttachmentParser.read(bomb, "bomb.zip", ""));
            String rels = "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"r1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>";
            String types = "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>";
            String document = "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body><w:p><w:r><w:t>First Я</w:t></w:r></w:p><w:p><w:r><w:t>Second</w:t></w:r></w:p><w:tbl><w:tr><w:tc><w:p><w:r><w:t>Cell 1</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Cell 2</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>";
            File docx = zip("sample.docx", "_rels/.rels", rels, "[Content_Types].xml", types, "word/document.xml", document, "word/header1.xml", "<empty/>");
            AttachmentParser.Result word = AttachmentParser.read(docx, "sample.docx", "");
            check(word.text.indexOf("First Я") < word.text.indexOf("Second"));
            check(word.text.indexOf("Cell 1") < word.text.indexOf("Cell 2")); check(word.partial);
            File xxe = zip("xxe.docx", "_rels/.rels", rels, "[Content_Types].xml", types, "word/document.xml", "<!DOCTYPE x [<!ENTITY leak SYSTEM 'file:///etc/passwd'>]>" + document);
            expect(AttachmentProblem.Code.DOCX_STRUCTURE, () -> AttachmentParser.read(xxe, "xxe.docx", ""));
            expect(AttachmentProblem.Code.DOCX_STRUCTURE, () -> AttachmentParser.read(zip("wrong.docx", "some.txt", "text"), "wrong.docx", ""));
            byte[] png = Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a4x8AAAAASUVORK5CYII=");
            InputMaterial.Ref ref = new InputMaterial.Ref(7, "12345678-1234-1234-1234-123456789abc", "test.png", "image/png", InputMaterial.sha256(png), png.length, 1, 1);
            InputMaterial.Image image = new InputMaterial.Image(ref, png);
            ModelCatalog.Model model = vision(262144);
            check(model.imageInput);
            ModelCatalog restoredCatalog = ModelCatalog.fromCache(ModelCatalog.fromOpenRouter(new JSONObject().put("data", new JSONArray())).cacheData());
            check(restoredCatalog.choices().stream().noneMatch(it -> it.imageInput));
            List<Workflow.Stage> stages = Workflow.defaultStages();
            Workflow.Run run = Workflow.Run.quick("Describe the supplied image", model, stages.get(1)).withMaterials(Collections.singletonList(ref));
            JSONObject request = ModelClient.materialBody(run, model, Collections.singletonList(image));
            JSONArray parts = request.getJSONArray("messages").getJSONObject(1).getJSONArray("content");
            check(parts.getJSONObject(0).getString("type").equals("text"));
            check(parts.getJSONObject(1).getString("text").contains("test.png"));
            check(parts.getJSONObject(2).getJSONObject("image_url").getString("url").equals("data:image/png;base64," + image.base64));
            check(request.getJSONObject("provider").getJSONObject("max_price").getInt("prompt") == 0);
            expect(AttachmentProblem.Code.MODEL_IMAGES, () -> ModelClient.materialBody(run, ModelCatalog.GROQ_120B, Collections.singletonList(image)));
            expect(AttachmentProblem.Code.MISSING, () -> ModelClient.materialBody(run, model, Collections.emptyList()));
            expect(AttachmentProblem.Code.MODEL_CONTEXT, () -> ModelClient.materialBody(run, vision(16000), Collections.singletonList(image)));
            byte[] changed = png.clone(); changed[0] = 0;
            expect(AttachmentProblem.Code.INTEGRITY, () -> new InputMaterial.Image(ref, changed));
            Workflow.Run restored = Workflow.Run.fromJson(run.toJson());
            check(restored.materials.get(0).sha256.equals(ref.sha256));
            check(restored.withNote("note").materials.size() == 1);
            check(restored.withModel(model).materials.size() == 1);
            restored = restored.receive(new ModelClient.Reply("answer", ModelClient.Finish.STOP, ""));
            check(restored.complete() && restored.materials.size() == 1);
            check(restored.addRepair(new Workflow.RepairInput(0, "print(1)", "", "error")).materials.size() == 1);
            Workflow.Run team = new Workflow.Run("Analyze input", stages).withMaterials(Collections.singletonList(ref));
            team = team.receive(new ModelClient.Reply("Solution", ModelClient.Finish.STOP, ""));
            team = team.receive(new ModelClient.Reply("No issues.\n[[REVIEW: PASS]]", ModelClient.Finish.STOP, ""));
            check(!team.complete() && team.nextIndex() == 2 && team.materials.size() == 1);
            team = team.receive(new ModelClient.Reply("Final", ModelClient.Finish.STOP, ""));
            check(team.complete() && team.answers.size() == 3 && team.materials.size() == 1);
            check(Workflow.Run.fromJson(team.toJson()).materials.size() == 1);
            transport(model, ref, image);
            System.out.println(checked + " attachment checks passed");
        } finally {
            try (java.util.stream.Stream<Path> paths = Files.walk(DIRECTORY)) {
                paths.sorted(java.util.Comparator.reverseOrder()).forEach(path -> { try { Files.delete(path); } catch (Exception ignored) {} });
            }
        }
    }
}
