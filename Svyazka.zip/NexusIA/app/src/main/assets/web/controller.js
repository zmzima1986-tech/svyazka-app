"use strict";
// Only this shell is the Android page. The user document is never inserted into its DOM.
function inspectSource(source, kind) {
    if (kind === "web-project") {
        try { return JSON.stringify(inspectWebProject(source)); }
        catch (_) { return JSON.stringify({status:"UNAVAILABLE",checked:0,external:0,issues:[]}); }
    }
    const result = { checked: 0, external: 0, issues: [] };
    function parseScript(body, mode, name, handler) {
        try {
            acorn.parse(handler ? "function eventHandler(event){\n" + body + "\n}" : body,
                { ecmaVersion: "latest", sourceType: mode, allowHashBang: true });
            result.checked++;
        } catch (error) { result.issues.push(name + ": " + error.message); }
    }
    if (kind === "javascript") {
        try { acorn.parse(source, { ecmaVersion: "latest", sourceType: "script" }); result.checked++; }
        catch (_) { parseScript(source, "module", "JavaScript", false); }
    } else if (kind === "html") {
        const doc = new DOMParser().parseFromString(source, "text/html");
        for (const [index, script] of [...doc.querySelectorAll("script")].entries()) {
            const type = (script.type || "").trim().toLowerCase().split(";")[0];
            if (type && type !== "module" && !/^(?:text|application)\/(?:javascript|ecmascript)$/.test(type)) continue;
            if (script.hasAttribute("src")) { result.external++; continue; }
            parseScript(script.textContent, type === "module" ? "module" : "script", "script " + (index + 1), false);
        }
        for (const el of doc.querySelectorAll("*")) {
            for (const attr of el.attributes) {
                if (/^on[a-z]+$/i.test(attr.name)) parseScript(attr.value, "script", attr.name, true);
            }
        }
    }
    const resources = new Set();
    if (kind === "html") {
        const doc = new DOMParser().parseFromString(source, "text/html");
        for (const node of doc.querySelectorAll("[src],link[href],video[poster],object[data]")) {
            const value = node.getAttribute("src") || node.getAttribute("href") || node.getAttribute("poster") || node.getAttribute("data") || "";
            if (value && !/^(?:data:|#)/i.test(value)) resources.add(value.split(/[?#]/)[0]);
        }
        for (const match of source.matchAll(/(?:url\(\s*|@import\s+)["']?([^\s"')<>]+)/gi))
            if (!/^(?:data:|#)/i.test(match[1])) resources.add(match[1].split(/[?#]/)[0]);
    }
    if (resources.size) result.resources = [...resources];
    if (/\bfetch\s*\(|XMLHttpRequest|WebSocket\s*\(|https?:\/\//i.test(source)) result.network = true;
    if (/navigator\s*\.\s*bluetooth|requestDevice\s*\(/i.test(source)) result.bluetooth = true;
    return JSON.stringify(result);
}
// Only resolve literal paths in the supplied snapshot; never read disk or fetch.
function inspectWebProject(source, forPreview = false) {
    const files = JSON.parse(source), paths = Object.keys(files);
    const htmlPaths = paths.filter(p => /\.html?$/i.test(p));
    const entry = htmlPaths.includes("index.html") ? "index.html" : htmlPaths.length === 1 ? htmlPaths[0] : "";
    const result = {checked:0, external:0, issues:[], project_entry:entry, preview_supported:!!entry};
    const resources = new Set(), parsed = new Set();
    let preview = "";
    function resolve(page, ref) {
        if (!ref || !/^[A-Za-z0-9_./-]+$/.test(ref) || ref.startsWith("//")) return "";
        const parts = ref.startsWith("/") ? [] : page.split("/").slice(0,-1);
        for (const part of ref.split("/")) {
            if (!part || part === ".") continue;
            if (part === "..") { if (!parts.length) return ""; parts.pop(); }
            else parts.push(part);
        }
        const path = parts.join("/");
        return Object.prototype.hasOwnProperty.call(files, path) ? path : "";
    }
    function parse(path, mode) {
        const key = path + ":" + mode;
        if (parsed.has(key)) return;
        parsed.add(key);
        try {
            acorn.parse(files[path], {ecmaVersion:"latest", sourceType:mode, allowHashBang:true});
            result.checked++;
        } catch (error) { result.issues.push(path + ": " + error.message); }
    }
    for (const page of htmlPaths) {
        const check = JSON.parse(inspectSource(files[page], "html"));
        result.checked += check.checked;
        result.issues.push(...check.issues.map(issue => page + ": " + issue));
        if (check.network) result.network = true;
        if (check.bluetooth) result.bluetooth = true;
        const doc = new DOMParser().parseFromString(files[page], "text/html");
        let supported = !doc.querySelector("base");
        const resolved = new Set();
        for (const script of doc.querySelectorAll("script")) {
            const type = (script.type || "").trim().toLowerCase().split(";")[0];
            if (type && type !== "module" && !/^(?:text|application)\/(?:javascript|ecmascript)$/.test(type)) continue;
            if (type === "module") supported = false;
            if (!script.hasAttribute("src")) continue;
            const ref = script.getAttribute("src"), path = resolve(page, ref);
            if (!path || !/\.m?js$/i.test(path)) {
                result.external++; resources.add(ref); supported = false; continue;
            }
            resolved.add(ref);
            parse(path, type === "module" ? "module" : "script");
            // Only classic script loading semantics can be preserved in this isolated preview.
            if (type === "module" || [...script.attributes].some(a => !["src","type","id"].includes(a.name))
                    || script.textContent.trim() || /<\/script/i.test(files[path]) || /^\s*#!/.test(files[path])) {
                supported = false; continue;
            }
            script.removeAttribute("src");
            script.textContent = files[path];
        }
        for (const link of doc.querySelectorAll("link[rel~='stylesheet'][href]")) {
            const ref = link.getAttribute("href"), path = resolve(page, ref);
            if (!path || !/\.css$/i.test(path)) { resources.add(ref); supported = false; continue; }
            resolved.add(ref);
            const css = files[path];
            if ([...link.attributes].some(a => !["href","rel","media","type","id"].includes(a.name))
                    || /<\/style|@import|url\s*\(/i.test(css)) { supported = false; continue; }
            const style = doc.createElement("style");
            for (const name of ["media","type","id"]) if (link.hasAttribute(name)) style.setAttribute(name,link.getAttribute(name));
            style.textContent = css;
            link.replaceWith(style);
        }
        for (const ref of check.resources || []) if (!resolved.has(ref)) {resources.add(ref); supported = false;}
        if (page === entry) {
            result.preview_supported = supported;
            if (supported) preview = "<!doctype html>" + doc.documentElement.outerHTML;
        }
    }
    // Unreferenced JS is parsed, not executed. Parse .mjs as a module.
    for (const path of paths.filter(p => /\.m?js$/i.test(p))) {
        if (!parsed.has(path + ":script") && !parsed.has(path + ":module")) {
            if (/\.mjs$/i.test(path)) parse(path,"module");
            else {
                const check = JSON.parse(inspectSource(files[path], "javascript"));
                result.checked += check.checked;
                result.issues.push(...check.issues.map(issue => path + ": " + issue));
            }
        }
        if (/\bfetch\s*\(|XMLHttpRequest|WebSocket\s*\(|https?:\/\//i.test(files[path])) result.network = true;
        if (/navigator\s*\.\s*bluetooth|requestDevice\s*\(/i.test(files[path])) result.bluetooth = true;
    }
    if (resources.size) result.resources = [...resources];
    return forPreview ? (result.preview_supported && !result.issues.length ? preview : "") : result;
}

function sandboxFrame(source, bootstrap = "") {
    const frame = document.createElement("iframe");
    // Permit local submit events; form-action none still blocks all actual form navigation.
    frame.setAttribute("sandbox", "allow-scripts allow-forms");
    frame.referrerPolicy = "no-referrer";
    frame.setAttribute("allow", "camera 'none'; microphone 'none'; geolocation 'none'; bluetooth 'none'; payment 'none'; usb 'none'");
    const policy = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; frame-src 'none'; child-src 'none'; worker-src 'none'; form-action 'none'; base-uri 'none'; object-src 'none'";
    // Prefix the policy even for fragments. A later, untrusted policy can only restrict it.
    frame.srcdoc = "<!doctype html><meta charset=utf-8><meta http-equiv=Content-Security-Policy content=\"" + policy + "\">" + bootstrap + source;
    return frame;
}
function renderSource(source, kind) {
    if (kind === "web-project") {
        try { source = inspectWebProject(source, true); }
        catch (_) { return false; }
        if (!source) return false;
    } else if (kind !== "html") return false;
    const frame = sandboxFrame(source);
    window.previewLoaded = false;
    frame.onload = () => { window.previewLoaded = true; };
    // Use the same full-size frame layout and append path as the widget checks.
    frame.style.cssText = "display:block;position:fixed;inset:0;width:100%;height:100%;border:0";
    while (document.body.firstChild) document.body.removeChild(document.body.firstChild);
    document.body.appendChild(frame);
    return true;
}

// Runs in a disposable frame using the same CSP as the visible preview.
function applicationProbe(options, token) {
    const send = parent.postMessage.bind(parent), later = setTimeout.bind(window);
    const on = window.addEventListener.bind(window);
    const problems = [];
    function issue(message) {
        if (problems.length < 5) problems.push(String(message).slice(0, 240));
    }
    on("error", e => { if (e.message) issue(e.message); });
    on("unhandledrejection", e => issue(e.reason && e.reason.message || "Unhandled promise rejection"));
    on("securitypolicyviolation", e => {
        if (e.effectiveDirective.startsWith("script-src")) issue(e.effectiveDirective + " blocked " + e.blockedURI);
    });
    const results = [];
    const add = (id, status, detail = {}) => results.push({id, status, detail});
    const visible = el => el && el.getClientRects().length && getComputedStyle(el).visibility !== "hidden";
    const normalize = key => String(key || "").trim().toLowerCase().replace(/×|✕|^x$/, "*").replace(/÷/, "/").replace(/−/, "-");
    document.currentScript.remove();
    on("load", () => later(async () => {
        if (options.scenario) {
            const {actions, expected} = options.scenario;
            const id = "scenario." + options.number;
            const matches = selector => Array.from(document.querySelectorAll(selector)).filter(visible);
            try {
                for (const action of actions) {
                    const controls = matches(action.click || action.fill);
                    if (controls.length !== 1 || controls[0].disabled) throw Error("Expected one enabled visible control");
                    const el = controls[0];
                    if (action.click) el.click();
                    else {
                        if (!el.matches("textarea,select,input:not([type=file])") || el.readOnly) throw Error("Control cannot accept text");
                        el.value = action.value;
                        el.dispatchEvent(new Event("input", {bubbles:true}));
                        el.dispatchEvent(new Event("change", {bubbles:true}));
                    }
                    await new Promise(done => later(done, 40));
                }
                const byValue = Object.prototype.hasOwnProperty.call(expected, "value");
                const wanted = byValue ? expected.value : expected.text;
                let actual = null;
                for (let attempt=0; attempt<12; attempt++) {
                    const found = matches(expected.selector);
                    actual = found.length === 1 ? (byValue ? found[0].value : found[0].textContent.trim()) : null;
                    if (actual === wanted) break;
                    await new Promise(done => later(done, 75));
                }
                add(id, actual === wanted ? "pass" : "fail", {expected:wanted.slice(0,100), actual:actual == null ? null : String(actual).slice(0,100)});
            } catch (err) { add(id,"fail",{error:String(err.message || err).slice(0,240)}); }
            send({token,result:results}, "*");
            return;
        }
        try {
            const buttons = new Map();
            for (const el of document.querySelectorAll('button,[role=button],input[type=button],input[type=submit]')) {
                if (!visible(el) || el.disabled) continue;
                for (const label of [el.innerText, el.value, el.dataset.key, el.getAttribute("aria-label")]) {
                    const key = normalize(label);
                    if (key && !buttons.has(key)) buttons.set(key, el);
                }
            }
            const equals = buttons.get("=") || buttons.get("equals");
            const clear = ["c","ac","clear","очистить","с"].map(k => buttons.get(k)).find(Boolean);
            const digits = Array.from("0123456789").every(k => buttons.has(k));
            const calculator = options.calculator || (equals && clear && digits);
            if (calculator) {
                const display = Array.from(document.querySelectorAll(
                    '[data-nexus="display"],output,[role=status],#display,.display,#result,.result,input[readonly],input[type=text],input:not([type])'
                )).find(visible);
                const value = () => String("value" in display ? display.value : display.textContent).trim().replace(",", ".");
                const pause = () => new Promise(done => later(done, 45));
                for (const [id, keys, expected] of [
                    ["add","8+5",13], ["subtract","8-5",3], ["multiply","58*5",290], ["divide","8/2",4]
                ]) {
                    if (!display || !clear || !equals || !Array.from(keys).every(k => buttons.has(k))) {
                        add("arithmetic."+id, "unverified", {reason:"controls unavailable"});
                        continue;
                    }
                    clear.click();
                    for (const key of keys) { buttons.get(key).click(); await pause(); }
                    equals.click(); await pause();
                    const actual = value();
                    add("arithmetic."+id, actual !== "" && Number(actual) === expected ? "pass" : "fail",
                        {input:keys, expected, actual:actual.slice(0,80)});
                }
            } else if (buttons.size && !options.widgets && !options.scenarios) {
                add("interaction.coverage", "unverified", {reason:"no independent action and expected outcome"});
            }
        } catch (err) { issue(err.message || err); }
        later(() => {
            add("page.startup", problems.length ? "fail" : "pass", {errors:problems});
            send({token, result:results}, "*");
        }, 80);
    }, 50), {once:true});
}

// Serialized into the opaque frame before the submitted document begins to execute.
function widgetProbe(options, token) {
    const send = parent.postMessage.bind(parent);
    const later = setTimeout.bind(window);
    const NativeDate = Date, realNow = NativeDate.now.bind(NativeDate);
    const started = realNow();
    const base = options.date ? new NativeDate(...options.date, 12, 0, 5).getTime() : started;
    function SimDate(...args) {
        if (!new.target) return new NativeDate(SimDate.now()).toString();
        return new NativeDate(...(args.length ? args : [SimDate.now()]));
    }
    Object.setPrototypeOf(SimDate, NativeDate);
    SimDate.prototype = NativeDate.prototype;
    SimDate.now = () => base + realNow() - started;
    if (options.date) window.Date = SimDate;
    let requests = 0;
    const sample = options.temperature;
    window.fetch = async function(input) {
        const url = new URL(typeof input === "string" ? input : input.url || input.href, location.href);
        if (url.origin !== "https://api.open-meteo.com" || url.pathname !== "/v1/forecast" ||
            !["latitude","longitude"].every(k => url.searchParams.has(k) && Number.isFinite(Number(url.searchParams.get(k))))) throw TypeError("Unsupported offline fixture");
        requests++;
        if (options.offline) throw TypeError("Failed to fetch");
        const data = {current_weather:{temperature:sample,weathercode:0,windspeed:3},
            current:{temperature_2m:sample,weather_code:0,wind_speed_10m:3},current_units:{temperature_2m:"°C"}};
        return new Response(JSON.stringify(data), {headers:{"Content-Type":"application/json"}});
    };
    const query = s => document.querySelector(s);
    const shown = n => n && n.getClientRects().length && getComputedStyle(n).visibility !== "hidden";
    const read = n => shown(n) ? n.innerText.trim() : "";
    const clock = () => {
        const el = query('[data-nexus="clock"],#clock,#clockTime,time');
        const m = (el ? read(el) : read(document.body)).match(/(?:^|\D)(\d{1,2}):(\d{2}):(\d{2})(?!\d)/);
        return m && Number(m[1])<24 && Number(m[2])<60 && Number(m[3])<60 ?
            Number(m[1])*3600+Number(m[2])*60+Number(m[3]) : null;
    };
    const result = [];
    function record(id, status, detail) { result.push({id,status,detail}); }
    function calendarState(date) {
        const grid = query('[data-nexus="calendar"],#calendarTable,#calendarGrid,#calendar,.calendar');
        const year = date.getFullYear(), month = date.getMonth();
        const last = new NativeDate(year,month+1,0).getDate();
        const cells = grid ? [...grid.querySelectorAll('td,[role="gridcell"],button,div,span')].filter(el=>shown(el) && el.childElementCount===0).map(read)
            .filter(v=>/^\d{1,2}$/.test(v)).map(Number) : [];
        const header = read(query('[data-nexus="month"],#date,#monthYear,#monthLabel')) || read(grid && grid.parentElement);
        const monthNames = [...new Set([document.documentElement.lang || "en","en","ru","ja","ar","zh","de","fr","es"])]
            .flatMap(lang=>{try{return ["long","short"].map(format=>date.toLocaleString(lang,{month:format}).toLowerCase());}catch(_){return [];}});
        const matchesMonth = monthNames.some(name=>name && header.toLowerCase().includes(name)) ||
            header.includes(year+"-"+String(month+1).padStart(2,"0"));
        const days = Array.from({length:last},(_,i)=>i+1);
        const exact = cells.some((_,i)=>days.every((v,j)=>cells[i+j]===v) && cells[i+last]!==last+1);
        return {status:!cells.length || !header ? "unverified" :
            exact && header.includes(String(year)) && matchesMonth ? "pass" : "fail",
            detail:{year,month:month+1,last}};
    }
    document.currentScript.remove();
    document.addEventListener("DOMContentLoaded", () => later(() => {
        const t0 = clock(), start = realNow();
        const ticks=[];
        let previous=t0, lastChange=start, sampledAt=start, gap=0;
        const timer = options.clock ? setInterval(() => {
            const value=clock(), time=realNow();
            gap=Math.max(gap,time-sampledAt);
            sampledAt=time;
            if (value!==null && previous!==null && value!==previous) {
                ticks.push({step:(value-previous+86400)%86400,ms:time-lastChange});
                lastChange=time;
            }
            previous=value;
        },95) : null;
        later(() => {
            if (timer!==null) clearInterval(timer);
            if (options.clock) {
                const t1 = clock(), elapsed = (realNow()-start)/1000;
                const actual = t0 == null || t1 == null ? null : (t1-t0+86400)%86400;
                const now = new NativeDate(base + realNow()-started);
                const expected = now.getHours()*3600+now.getMinutes()*60+now.getSeconds();
                const offset = t1 == null ? 0 : (t1-expected+86400)%86400;
                record("clock.tick", actual == null || elapsed > 4 || gap>650 ? "unverified" :
                    ticks.length>=2 && ticks.every((t,i)=>t.step===1 && (i===0 || t.ms<=1400)) && Math.abs(actual-elapsed)<=1 && Math.min(offset,86400-offset)<=1 ? "pass":"fail",
                    {seconds:actual, observed_ticks:ticks.length, elapsed_ms:Math.round(elapsed*1000)});
            }
            if (options.calendar) {
                const state=calendarState(new NativeDate(base));
                record("calendar."+options.name,state.status,state.detail);
            }
            if (options.weather) {
                const el = query('[data-nexus="weather"],#weather,#weatherInfo,#weatherResult');
                const t = read(el);
                const error = /ошиб|недоступ|не удал|нет (сети|связи|подключения)|проверьте подключение|error|failed|unavailable|offline|network|失败|エラー|خطأ/i.test(t);
                const temp = new RegExp("(^|[^0-9-])"+sample+"\\s*(?:°|℃)").test(t.replace(/−/g,"-"));
                record("weather."+options.name,!requests || !t ? "unverified" : (options.offline ? error && !temp : temp) ? "pass":"fail",
                    {mock:true,requests});
            }
            if (options.name==="december") {
                const next=query('[data-nexus="next"],#nextMonth,#next-month,button[aria-label="Next month"]');
                if (shown(next)) {
                    next.click();
                    later(()=>{
                        const state=calendarState(new NativeDate(2024,0,1));
                        record("calendar.nextyear",state.status,state.detail);
                        send({token,result},"*");
                    },250);
                    return;
                }
            }
            send({token, result},"*");
        },options.clock ? 2650 : 170);
    },80),{once:true});
}
function startWidgetChecks(source, required, kind = "html") {
    if (kind === "web-project") {
        try { source = inspectWebProject(source, true); } catch (_) { source = ""; }
        if (!source) { window.nexusTestResult = [{id:"page.startup",status:"unverified",detail:{unsupported:true}}]; return; }
    }
    const clock=required.includes("часы"), calendar=required.includes("календарь"), weather=required.includes("погода");
    const results=[], plans=[{name:"application", calculator:required.includes("calculator"), widgets:clock || calendar || weather}];
    const text = (value, limit) => typeof value === "string" && value.length <= limit;
    const selector = s => {
        if (!text(s,160) || !s.trim()) return false;
        try { document.createDocumentFragment().querySelector(s); return true; }
        catch (_) { return false; }
    };
    if (required.includes("invalid_web_cases")) results.push({id:"scenario.input",status:"unverified",detail:{invalid:true}});
    for (const [i,item] of required.filter(value => value && typeof value === "object").slice(0,6).entries()) {
        const s = item.scenario, e = s && s.expected;
        const valid = s && Array.isArray(s.actions) && s.actions.length <= 12
            && s.actions.every(a => a && (selector(a.click) && a.fill === undefined
                || selector(a.fill) && a.click === undefined && text(a.value,512)))
            && e && selector(e.selector) && (text(e.text,512) && e.value === undefined
                || text(e.value,512) && e.text === undefined);
        if (valid) plans.push({name:"scenario",number:i+1,scenario:s});
        else results.push({id:"scenario."+(i+1),status:"unverified",detail:{invalid:true}});
    }
    plans[0].scenarios = plans.some(plan => plan.name === "scenario");
    if(required.includes("Bluetooth")) results.push({id:"bluetooth.device",status:"unverified",detail:{hardware:false}});
    if(clock || calendar || weather) plans.push({name:"current",clock,calendar,weather,temperature:-17});
    if(calendar) plans.push({name:"december",calendar,date:[2023,11,31]},{name:"january",calendar,date:[2024,0,1]});
    if(calendar || weather) plans.push({name:"leap",calendar,weather,date:[2024,1,29],temperature:28});
    if(weather) plans.push({name:"offline",weather,offline:true,temperature:-17});
    window.nexusTestResult=null;
    if(!plans.length){window.nexusTestResult=results;return;}
    const pending=new Map();
    function close() {
        window.removeEventListener("message",receive);
        for(const [token,{frame,plan}] of pending) {
            results.push({id:"probe."+plan.name,status:"unverified",detail:{timeout:true}});
            frame.remove();
        }
        pending.clear();
        window.nexusTestResult=results;
    }
    function receive(event) {
        const data=event.data;
        if(!data || typeof data.token!=="string" || !pending.has(data.token)) return;
        const entry=pending.get(data.token);
        if(event.source!==entry.frame.contentWindow || !Array.isArray(data.result)) return;
        results.push(...data.result);
        pending.delete(data.token);
        entry.frame.remove();
        if(!pending.size){clearTimeout(deadline);close();}
    }
    window.addEventListener("message",receive);
    const deadline=setTimeout(close,8500);
    for(const plan of plans) {
        const token=Array.from(crypto.getRandomValues(new Uint32Array(4))).join("-");
        const probe=plan.name === "application" || plan.name === "scenario" ? applicationProbe : widgetProbe;
        const bootstrap="<script>("+probe.toString()+")("+JSON.stringify(plan).replace(/</g,"\\u003c")+","+JSON.stringify(token)+")<"+"/script>";
        const frame=sandboxFrame(source,bootstrap);
        // Overlap frames so every clock remains visible to browser timer scheduling.
        frame.style.cssText="position:fixed;inset:0;width:100%;height:100%";
        pending.set(token,{frame,plan});
        document.body.appendChild(frame);
    }
}
