"""Source-level safeguards for the final Nexus AI interface polish; not a device test."""
from pathlib import Path
import re
import unittest
import xml.etree.ElementTree as ET

PROJECT = Path(__file__).resolve().parents[1]
MAIN = PROJECT / 'app/src/main'
UI = MAIN / 'java/app/svyazka/mobile/ui'


class FinalPolishContract(unittest.TestCase):
    def test_visible_brand_all_locales(self):
        for folder in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            resources = ET.parse(MAIN / f'res/{folder}/strings.xml').getroot()
            name = next(item.text for item in resources.findall('string') if item.attrib['name'] == 'app_name')
            self.assertEqual(name, 'Nexus AI')
        for source in (MAIN / 'java').rglob('*'):
            if source.suffix in ('.kt', '.java'):
                self.assertNotIn('Nexus IA', source.read_text())

    def test_collapsible_chat_attachments(self):
        chat = (UI / 'NexusChat.kt').read_text()
        self.assertIn('var attachmentsExpanded by rememberSaveable(ui.taskId)', chat)
        self.assertIn('if (attachmentsExpanded)', chat)
        self.assertIn('attachment_expand', chat)
        self.assertIn('attachment_collapse', chat)
        for folder in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            names = {e.attrib['name'] for e in ET.parse(MAIN / f'res/{folder}/strings.xml').getroot()}
            self.assertTrue({'attachment_expand', 'attachment_collapse'} <= names)

    def test_key_indicator_reflects_saved_keys(self):
        keys = (UI / 'NexusKeysDialog.kt').read_text()
        self.assertIn('val isSaved = keys[index].isNotBlank()', keys)
        self.assertIn('status_key_configured', keys)
        self.assertIn('status_key_missing', keys)
        self.assertNotIn('isSaved = listOf(openRouter', keys)  # edits are not persisted yet

    def test_splash_follows_actual_readiness_not_artificial_timer(self):
        ui = (UI / 'NexusComposeUi.kt').read_text()
        activity = (MAIN / 'java/app/svyazka/mobile/MainActivity.java').read_text()
        splash = (UI / 'NexusSplash.kt').read_text()
        self.assertIn('NexusTheme(ui.theme)', ui)
        self.assertIn('withFrameNanos', ui)
        self.assertNotIn('nexusSplashRemainingMillis()', ui)
        self.assertNotIn('2760L', activity)
        self.assertIn('LinearProgressIndicator(', splash)
        self.assertIn('drawPath(rear', splash)
        self.assertIn('drawPath(front', splash)
        self.assertIn('NexusBrandMark(Modifier.size(140.dp))', splash)
        self.assertIn('useLegacySplash = android.os.Build.VERSION.SDK_INT < 31', ui)
        self.assertIn('if (useLegacySplash)', ui)
        self.assertNotIn('visible = showLaunch', ui)
        self.assertNotIn('R.string.ui_brand_subtitle', splash)
        self.assertIn('isUserDarkTheme', activity)
        self.assertIn('configuration.uiMode =', activity)
        self.assertIn('NexusSystemIsDark()', (UI / 'NexusTheme.kt').read_text())
        for folder in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            names = {e.attrib['name'] for e in ET.parse(MAIN / f'res/{folder}/strings.xml').getroot()}
            self.assertIn('ui_loading', names)
        for folder, color in (('values-v31', '#FFFFFF'), ('values-night-v31', '#000000')):
            root = ET.parse(MAIN / f'res/{folder}/styles.xml').getroot()
            attrs = {e.attrib['name']: e.text for e in root.iter('item')}
            self.assertEqual(attrs['android:windowSplashScreenBackground'], color)
            self.assertEqual(attrs['android:windowSplashScreenAnimatedIcon'], '@drawable/ic_nia_splash_brand')
        # Android 12+ masks the icon into a circle. Use a purpose-built asset
        # with the entire symbol and label inside the center safe area.
        for folder in ('drawable-nodpi', 'drawable-night-nodpi'):
            image = MAIN / f'res/{folder}/ic_nia_splash_brand.png'
            self.assertTrue(image.is_file(), image)
            data = image.read_bytes()
            self.assertEqual(data[:8], b'\x89PNG\r\n\x1a\n')
            import struct
            self.assertEqual(struct.unpack('>II', data[16:24]), (576, 576))


if __name__ == '__main__':
    unittest.main()
