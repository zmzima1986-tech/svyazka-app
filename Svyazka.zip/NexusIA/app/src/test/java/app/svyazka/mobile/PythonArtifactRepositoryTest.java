package app.svyazka.mobile;

import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class PythonArtifactRepositoryTest {
    private static boolean contains(List<NexusArtifact> artifacts, long id) {
        for (NexusArtifact item : artifacts) if (item.id == id) return true;
        return false;
    }

    @Test public void offlineFileCreatesArtifactNotChatHistory() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long chat = chats.create("");
            long project = artifacts.createUnlinked();
            assertEquals(0L, artifacts.forChat(chat));
            files.putText(project, "main.py", "print(1)");
            assertTrue(artifacts.touch(project, "main.py"));
            assertTrue(contains(artifacts.list(files), project));
            assertEquals("print(1)", files.text(project, "main.py"));
            assertFalse(chats.list().stream().anyMatch(item -> item.id == chat));
            long otherChat = chats.create("");
            assertEquals(0L, artifacts.forChat(otherChat));
            long otherProject = artifacts.createUnlinked();
            assertEquals(0L, artifacts.forChat(otherChat));
            assertNotEquals(project, otherProject);
            files.putText(otherProject, "main.py", "print(2)");
            assertTrue(artifacts.touch(otherProject, "main.py"));
            assertEquals("print(1)", files.text(project, "main.py"));
            assertEquals("print(2)", files.text(otherProject, "main.py"));
        }
    }

    @Test public void projectAndTitleSurviveReopeningBothDatabases() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        long project;
        long chat;
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            chat = chats.create("");
            project = artifacts.ensureForChat(chat);
            files.putText(project, "check.py", "assert 5 + 5 == 10");
            assertTrue(artifacts.touch(project, "check.py"));
            assertTrue(artifacts.rename(project, "Тестовый проект"));
        }
        try (PythonArtifactRepository reopened = new PythonArtifactRepository(context)) {
            assertEquals(project, reopened.forChat(chat));
            NexusArtifact saved = reopened.list(files).stream()
                    .filter(item -> item.id == project).findFirst().orElse(null);
            assertNotNull(saved);
            assertEquals("Тестовый проект", saved.title);
            assertEquals("assert 5 + 5 == 10", files.text(project, "check.py"));
        }
    }

    @Test public void chatDeletionDoesNotDeleteSeparateProject() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long chat = chats.create("");
            long project = artifacts.ensureForChat(chat);
            files.putText(project, "main.py", "print('safe')");
            assertTrue(artifacts.touch(project, "main.py"));
            assertTrue(chats.delete(chat));
            artifacts.unlinkChat(chat);
            assertEquals(0L, artifacts.forChat(chat));
            assertTrue(contains(artifacts.list(files), project));
            assertEquals("print('safe')", files.text(project, "main.py"));
        }
    }

    @Test public void twoChatsGetPrivateCopiesAndChangesNeverLeak() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long original = artifacts.createUnlinked();
            files.putText(original, "main.py", "print('original')");
            files.putText(original, "data.txt", "source data");
            assertTrue(artifacts.touch(original, "main.py"));
            long firstChat = chats.create("");
            long secondChat = chats.create("");
            long firstCopy = artifacts.attachIsolatedCopy(firstChat, original, files);
            long secondCopy = artifacts.attachIsolatedCopy(secondChat, original, files);
            assertNotEquals(original, firstCopy);
            assertNotEquals(original, secondCopy);
            assertNotEquals(firstCopy, secondCopy);
            assertEquals(firstCopy, artifacts.forChat(firstChat));
            assertEquals(secondCopy, artifacts.forChat(secondChat));
            files.putText(firstCopy, "main.py", "print('first chat')");
            files.putText(firstCopy, "data.txt", "first only");
            assertEquals("print('original')", files.text(original, "main.py"));
            assertEquals("print('original')", files.text(secondCopy, "main.py"));
            assertEquals("source data", files.text(secondCopy, "data.txt"));
            assertEquals("first only", files.text(firstCopy, "data.txt"));
            assertTrue(chats.delete(firstChat));
            artifacts.unlinkChat(firstChat);
            assertEquals(0L, artifacts.forChat(firstChat));
            assertEquals(secondCopy, artifacts.forChat(secondChat));
            assertEquals("print('original')", files.text(secondCopy, "main.py"));
            assertTrue(contains(artifacts.list(files), original));
        }
    }

    @Test public void oldSharedLinksAreNotExposedBeforeSafeMigration() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long original = artifacts.createUnlinked();
            files.putText(original, "main.py", "print('safe')");
            long first = chats.create("");
            long second = chats.create("");
            assertTrue(artifacts.attachChat(first, original));
            assertTrue(artifacts.attachChat(second, original));
            assertEquals(0L, artifacts.forChat(first));
            assertEquals(0L, artifacts.forChat(second));
            long firstCopy = artifacts.ensureIsolatedForChat(first, files);
            assertEquals(firstCopy, artifacts.ensureIsolatedForChat(first, files));
            long secondCopy = artifacts.ensureIsolatedForChat(second, files);
            assertNotEquals(firstCopy, secondCopy);
            files.putText(firstCopy, "main.py", "print('first')");
            assertEquals("print('safe')", files.text(secondCopy, "main.py"));
            assertEquals("print('safe')", files.text(original, "main.py"));
        }
    }

    @Test public void reconnectUsesSameProjectAndDoesNotCreateExtraArtifacts() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long chat = chats.create("");
            long otherChat = chats.create("");
            long original = artifacts.createUnlinked();
            files.putText(original, "main.py", "print('original')");
            long assigned = artifacts.attachIsolatedCopy(chat, original, files);
            assertTrue(assigned > 0);
            assertTrue(artifacts.setConnected(chat, false));
            assertEquals(0L, artifacts.forChat(chat));
            assertEquals(assigned, artifacts.assignedForChat(chat));
            assertEquals(assigned, artifacts.ensureIsolatedForChat(chat, files));
            files.putText(assigned, "main.py", "print('modified')");
            assertTrue(artifacts.setConnected(chat, true));
            assertEquals(assigned, artifacts.forChat(chat));
            assertEquals(assigned, artifacts.attachIsolatedCopy(chat, original, files));
            assertEquals("print('modified')", files.text(assigned, "main.py"));
            assertEquals(0L, artifacts.assignedForChat(otherChat));
            assertEquals("print('original')", files.text(original, "main.py"));
        }
    }

    @Test public void existingChatCannotBeSilentlyReassignedToAnotherProject() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long chat = chats.create("");
            long first = artifacts.createUnlinked();
            long second = artifacts.createUnlinked();
            files.putText(first, "main.py", "first");
            files.putText(second, "main.py", "second");
            long firstCopy = artifacts.attachIsolatedCopy(chat, first, files);
            long ignored = artifacts.attachIsolatedCopy(chat, second, files);
            assertEquals(firstCopy, ignored);
            assertEquals(firstCopy, artifacts.forChat(chat));
            assertEquals("first", files.text(firstCopy, "main.py"));
            assertEquals("second", files.text(second, "main.py"));
            assertTrue(artifacts.setConnected(chat, false));
            assertEquals(firstCopy, artifacts.attachIsolatedCopy(chat, second, files));
            assertTrue(artifacts.setConnected(chat, true));
            assertEquals(firstCopy, artifacts.forChat(chat));
        }
    }

    @Test public void aNewChatGetsOneEmptyProjectAndOldChatKeepsItsFiles() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long oldChat = chats.create("");
            long newChat = chats.create("");
            long oldProject = artifacts.createEmptyForChat(oldChat, files);
            long newProject = artifacts.createEmptyForChat(newChat, files);
            assertNotEquals(oldProject, newProject);
            assertEquals(oldProject, artifacts.createEmptyForChat(oldChat, files));
            assertArrayEquals(new String[]{"main.py"}, files.paths(newProject));
            assertEquals("", files.text(newProject, "main.py"));
            files.putText(oldProject, "main.py", "print('old')");
            files.putText(newProject, "main.py", "print('new')");
            assertTrue(artifacts.setConnected(newChat, false));
            assertEquals(0L, artifacts.forChat(newChat));
            assertEquals(newProject, artifacts.assignedForChat(newChat));
            assertEquals("print('old')", files.text(oldProject, "main.py"));
            assertEquals("print('new')", files.text(newProject, "main.py"));
        }
    }

    @Test public void manuallySavedChatAppearsInHistoryWithoutAiOrProject() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository chats = new TaskRepository(context)) {
            long saved = chats.create("");
            long unsaved = chats.create("");
            assertFalse(chats.hasExplicitlySavedChat(saved));
            assertTrue(chats.markSavedChat(saved));
            assertTrue(chats.hasExplicitlySavedChat(saved));
            assertTrue(chats.list().stream().anyMatch(entry -> entry.id == saved));
            assertFalse(chats.list().stream().anyMatch(entry -> entry.id == unsaved));
            assertTrue(chats.delete(saved));
            assertFalse(chats.list().stream().anyMatch(entry -> entry.id == saved));
        }
    }

    @Test public void migrationCopiesLegacyBytesAndPreservesOriginalTombstone() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore legacy = new PythonProjectStore(context);
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long chat = chats.create("");
            legacy.putText(chat, "script.py", "print('original')");
            long original = artifacts.registerLegacy(chat, true, "Python · script.py");
            legacy.copyTo(chat, files, original);
            assertTrue(artifacts.touch(original, "script.py"));
            assertEquals(0L, artifacts.forChat(chat));
            long privateCopy = artifacts.ensureIsolatedForChat(chat, files);
            assertNotEquals(original, privateCopy);
            assertEquals(privateCopy, artifacts.forChat(chat));
            assertEquals("print('original')", legacy.text(chat, "script.py"));
            assertEquals("print('original')", files.text(privateCopy, "script.py"));
            assertTrue(artifacts.delete(original));
            files.deleteTask(original);
            assertEquals(privateCopy, artifacts.forChat(chat));
            assertEquals(0L, artifacts.registerLegacy(chat, true, "Python · script.py"));
            assertEquals("print('original')", files.text(privateCopy, "script.py"));
        }
    }

    @Test public void orphanedArtifactFilesRebuildCatalogButTombstonesRemainDeleted() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (PythonArtifactRepository catalog = new PythonArtifactRepository(context)) {
            long orphan = 9_000_000_000L + System.nanoTime() % 1_000_000;
            files.putText(orphan, "main.py", "print('found')");
            assertFalse(catalog.exists(orphan));
            catalog.recoverSavedFiles(files);
            assertTrue(catalog.exists(orphan));
            assertTrue(contains(catalog.list(files), orphan));
            assertTrue(catalog.delete(orphan));
            // Simulate file deletion failing: a durable tombstone still hides the file.
            catalog.recoverSavedFiles(files);
            assertFalse(catalog.exists(orphan));
            assertFalse(contains(catalog.list(files), orphan));
        }
    }

    @Test public void orphanLegacyFilesAreRecoverableWithoutChatResurrection() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore legacy = new PythonProjectStore(context);
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long missingChat = 8_000_000_000L + System.nanoTime() % 1_000_000;
            legacy.putText(missingChat, "lost.py", "print('recovered')");
            assertNull(chats.load(missingChat));
            long project = artifacts.registerLegacy(missingChat, false, "Восстановленное");
            legacy.copyTo(missingChat, files, project);
            assertTrue(artifacts.touch(project, "lost.py"));
            assertTrue(contains(artifacts.list(files), project));
            assertEquals(0L, artifacts.forChat(missingChat));
            assertNull(chats.load(missingChat));
        }
    }
}
