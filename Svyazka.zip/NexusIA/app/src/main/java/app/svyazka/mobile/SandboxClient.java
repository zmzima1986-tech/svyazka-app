package app.svyazka.mobile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class SandboxClient {
    private static final String PISTON_URL = "https://emkc.org/api/v2/piston/execute";
    static final String PISTON_VERSION = "3.10.0";
    static final int MAX_CODE = 100_000;
    static final int MAX_STDIN = 16_000;
    private static final int MAX_RESPONSE = 256_000;
    private static final Pattern FENCE = Pattern.compile("(?m)^( {0,3})(`{3,}|~{3,})([^\\r\\n]*)\\r?$");
    private static final Pattern PYTHON = Pattern.compile("(?i)^(python|python3|py)(?:\\s.*)?$");

    static final class Result {
        final String stdout;
        final String stderr;
        final String engine;
        final Integer exitCode;
        final String status;
        /** Visual artifacts originate only from local Pyodide, not model text. */
        final String html;
        final String pngBase64;

        Result(String stdout, String stderr, String engine, Integer exitCode, String status) {
            this(stdout, stderr, engine, exitCode, status, "", "");
        }

        Result(String stdout, String stderr, String engine, Integer exitCode,
               String status, String html, String pngBase64) {
            this.html = html;
            this.pngBase64 = pngBase64;
            this.stdout = stdout;
            this.stderr = stderr;
            this.engine = engine;
            this.exitCode = exitCode;
            this.status = status;
        }

        String diagnostic() {
            String value = stderr.trim().isEmpty() ? "" : stderr;
            if (value.isEmpty() && exitCode != null && exitCode == 0) return "";
            if (!status.isEmpty()) value = value.isEmpty() ? status : value + "\n" + status;
            if (exitCode != null && exitCode != 0) {
                value += (value.isEmpty() ? "" : "\n") + "Код завершения: " + exitCode;
            }
            return value;
        }
    }

    static List<String> pythonBlocks(String answer) {
        List<String> blocks = new ArrayList<>();
        Matcher line = FENCE.matcher(answer);
        String opened = "";
        boolean python = false;
        int start = 0;
        int indent = 0;
        while (line.find()) {
            String delimiter = line.group(2);
            String details = line.group(3).trim();
            if (opened.isEmpty()) {
                if (delimiter.charAt(0) == '`' && details.indexOf('`') >= 0) continue;
                opened = delimiter;
                python = delimiter.charAt(0) == '`' && PYTHON.matcher(details).matches();
                start = line.end();
                if (start < answer.length() && answer.charAt(start) == '\r') start++;
                if (start < answer.length() && answer.charAt(start) == '\n') start++;
                indent = line.group(1).length();
            } else if (delimiter.charAt(0) == opened.charAt(0)
                    && delimiter.length() >= opened.length() && details.isEmpty()) {
                if (python) {
                    String code = answer.substring(start, line.start());
                    if (indent > 0) code = code.replaceAll("(?m)^ {1," + indent + "}", "");
                    if (!code.trim().isEmpty()) blocks.add(code);
                }
                opened = "";
            }
        }
        return blocks;
    }

    static void validate(String code, String stdin) {
        if (code.trim().isEmpty()) throw new IllegalArgumentException("Блок Python пуст.");
        if (code.length() > MAX_CODE) throw new IllegalArgumentException("Блок Python длиннее 100 000 символов.");
        if (stdin.length() > MAX_STDIN) throw new IllegalArgumentException("Ввод длиннее 16 000 символов.");
    }

    static JSONObject pistonBody(String code, String stdin) throws JSONException {
        validate(code, stdin);
        return new JSONObject().put("language", "python").put("version", PISTON_VERSION)
                .put("files", new JSONArray().put(new JSONObject().put("name", "main.py")
                        .put("content", code)))
                .put("stdin", stdin).put("run_timeout", 3000).put("run_memory_limit", 134_217_728);
    }

    Result execute(String code, String stdin, String token, ModelClient.Cancellation cancel)
            throws IOException, JSONException {
        byte[] body = pistonBody(code, stdin).toString().getBytes(StandardCharsets.UTF_8);
        HttpsURLConnection connection = (HttpsURLConnection) new URL(PISTON_URL).openConnection();
        try {
            cancel.attach(connection);
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(12_000);
            connection.setReadTimeout(20_000);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Authorization", "Bearer " + token);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setDoOutput(true);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
            }
            int status = connection.getResponseCode();
            if (status == 401 || status == 403) {
                throw new IOException("Piston отклонил токен. Для запуска на телефоне отключи Piston.");
            }
            if (status != 200) {
                String reason = readFailure(connection, token);
                throw new IOException("Piston вернул HTTP " + status + reason);
            }
            return parsePiston(readJson(connection.getInputStream()));
        } finally {
            cancel.detach();
            connection.disconnect();
        }
    }

    static Result parsePiston(JSONObject response) throws JSONException {
        JSONObject run = response.optJSONObject("run");
        if (run == null) throw new JSONException("Piston не вернул результат запуска.");
        String signal = string(run, "signal");
        String status = string(run, "status");
        String message = string(run, "message");
        if ("TO".equals(status) || "SIGKILL".equals(signal)) {
            message = message.isEmpty() ? "Выполнение прервано (сигнал или лимит)." : message;
        } else if (message.isEmpty() && !signal.isEmpty()) {
            message = "Процесс завершён сигналом " + signal;
        } else if (message.isEmpty() && !status.isEmpty() && !"OK".equals(status)) {
            message = "Статус Piston: " + status;
        }
        Integer exit = run.isNull("code") ? null : run.getInt("code");
        return new Result(string(run, "stdout"), string(run, "stderr"),
                "Piston · Python " + response.optString("version", PISTON_VERSION), exit, message);
    }

    private static String readFailure(HttpsURLConnection connection, String token) {
        InputStream error = connection.getErrorStream();
        if (error == null) return ".";
        try {
            String message = readJson(error).optString("message", "");
            if (!token.isEmpty()) message = message.replace(token, "[токен скрыт]");
            return message.isEmpty() ? "." : ". " + message.substring(0, Math.min(message.length(), 800));
        } catch (IOException | JSONException ignored) {
            return ".";
        }
    }

    private static JSONObject readJson(InputStream stream) throws IOException, JSONException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder text = new StringBuilder();
            char[] buffer = new char[4096];
            int count;
            while ((count = reader.read(buffer)) != -1) {
                if (text.length() + count > MAX_RESPONSE) throw new IOException("Ответ Piston слишком большой.");
                text.append(buffer, 0, count);
            }
            return new JSONObject(text.toString());
        }
    }

    private static String string(JSONObject value, String key) {
        return value.isNull(key) ? "" : value.optString(key, "");
    }
}
