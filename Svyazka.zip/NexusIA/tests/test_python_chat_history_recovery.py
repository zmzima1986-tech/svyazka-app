"""Static contracts for chat/artifact separation. Runtime Android checks are separate."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'


class PythonArtifactArchitectureTests(unittest.TestCase):
    def test_chat_history_no_longer_projects_python_only_files(self):
        repo = (JAVA / 'TaskRepository.java').read_text(encoding='utf-8')
        activity = (JAVA / 'MainActivity.java').read_text(encoding='utf-8')
        self.assertIn('WHERE TRIM(task)', repo)
        self.assertIn('for (TaskRepository.Entry entry : repository.list())', activity)
        self.assertNotIn('repository.listIncludingPythonProjects(pythonProjects())', activity)
        self.assertNotIn('repository.recoverPythonProjects(pythonProjects())', activity)

    def test_new_chat_and_standalone_project_have_separate_identifiers(self):
        activity = (JAVA / 'MainActivity.java').read_text(encoding='utf-8')
        compose = (JAVA / 'ui/NexusComposeUi.kt').read_text(encoding='utf-8')
        self.assertIn('activeArtifactId = artifactRepository.forChat(activeTaskId);', activity)
        self.assertIn('activeArtifactId = id;', activity)
        self.assertIn('public boolean nexusHasSavedPythonFiles()', activity)
        self.assertIn('var projectId by mutableLongStateOf(activity.nexusArtifactId())', compose)
        self.assertIn('hasDraftContent() || activity.nexusHasSavedPythonFiles()', compose)

    def test_explicit_chat_link_and_separate_save_actions(self):
        activity = (JAVA / 'MainActivity.java').read_text(encoding='utf-8')
        project = (JAVA / 'PythonArtifactRepository.java').read_text(encoding='utf-8')
        compose = (JAVA / 'ui/NexusComposeUi.kt').read_text(encoding='utf-8')
        workspace = (JAVA / 'ui/NexusPythonWorkspace.kt').read_text(encoding='utf-8')
        chat = (JAVA / 'ui/NexusChat.kt').read_text(encoding='utf-8')
        repo = (JAVA / 'TaskRepository.java').read_text(encoding='utf-8')
        self.assertIn('artifactRepository.createUnlinked()', activity)
        self.assertNotIn('artifactRepository.ensureForChat(activeTaskId)', activity)
        self.assertIn('active_python_artifact_id', activity)
        self.assertIn('data.getLong(ACTIVE_ARTIFACT, 0)', activity)
        self.assertIn('artifactRepository.attachChat(activeTaskId, activeArtifactId)', activity)
        self.assertIn('artifactRepository.attachChat(created, project)', activity)
        self.assertIn('public void nexusSaveArtifact(String path, String code)', activity)
        self.assertIn('public void nexusSaveChat()', activity)
        self.assertIn('public void nexusDetachArtifactFromChat()', activity)
        self.assertIn('CONFLICT_REPLACE', project)
        self.assertIn('saved_in_history=1', repo)
        self.assertIn('artifacts_new_chat', compose)
        self.assertIn('artifacts_save', workspace)
        self.assertIn('artifacts_save_chat', chat)

    def test_legacy_files_preserved_and_deletions_not_resurrected(self):
        activity = (JAVA / 'MainActivity.java').read_text(encoding='utf-8')
        project = (JAVA / 'PythonArtifactRepository.java').read_text(encoding='utf-8')
        source = (JAVA / 'PythonProjectStore.java').read_text(encoding='utf-8')
        self.assertIn('legacy.copyTo(chatId, pythonProjects(), projectId)', activity)
        self.assertIn('if (deleted)', project)
        self.assertIn('row.put("legacy_chat_id", legacyChatId)', project)
        self.assertIn('prefix = artifact ? "artifact-" : "chat-"', source)

    def test_roboletric_lifecycle_cases_exist(self):
        tests = (ROOT / 'app/src/test/java/app/svyazka/mobile/PythonArtifactRepositoryTest.java').read_text()
        for name in ('offlineFileCreatesArtifactNotChatHistory',
                     'projectAndTitleSurviveReopeningBothDatabases',
                     'chatDeletionDoesNotDeleteSeparateProject',
                     'migrationPreservesOriginalAndDeletionPreventsResurrection',
                     'orphanLegacyFilesAreRecoverableWithoutChatResurrection',
                     'orphanedArtifactFilesRebuildCatalogButTombstonesRemainDeleted'):
            self.assertIn('void ' + name + '()', tests)


if __name__ == '__main__':
    unittest.main()
