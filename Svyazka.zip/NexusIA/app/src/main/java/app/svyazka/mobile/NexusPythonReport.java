package app.svyazka.mobile;

/** UI-only report from a completed Python attempt; no tokens or private credentials. */
public final class NexusPythonReport {
    public final String engine;
    public final String stdout;
    public final String stderr;
    public final String status;
    public final String diagnostic;
    public final Integer exitCode;
    public final boolean hasVisual;
    public final boolean inputRequired;
    public final String artifactsJson;
    public final String testsJson;
    public final String snapshotSha256;

    /** A successful process exit can still have failed functional tests. */
    public boolean hasFailedTests() {
        try {
            org.json.JSONArray items = new org.json.JSONArray(testsJson);
            for (int i = 0; i < items.length(); i++) {
                org.json.JSONObject test = items.optJSONObject(i);
                if (test != null && !test.optBoolean("passed", false)) return true;
            }
        } catch (org.json.JSONException invalid) {
            return false;
        }
        return false;
    }

    public NexusPythonReport(String engine, String stdout, String stderr, String status,
                             String diagnostic, Integer exitCode, boolean hasVisual) {
        this(engine, stdout, stderr, status, diagnostic, exitCode, hasVisual, "[]", "[]", "");
    }

    public NexusPythonReport(String engine, String stdout, String stderr, String status,
                             String diagnostic, Integer exitCode, boolean hasVisual,
                             String artifactsJson, String testsJson, String snapshotSha256) {
        this(engine, stdout, stderr, status, diagnostic, exitCode, hasVisual, artifactsJson, testsJson, snapshotSha256, false);
    }

    public NexusPythonReport(String engine, String stdout, String stderr, String status,
                             String diagnostic, Integer exitCode, boolean hasVisual,
                             String artifactsJson, String testsJson, String snapshotSha256, boolean inputRequired) {
        this.inputRequired = inputRequired;
        this.artifactsJson = artifactsJson;
        this.testsJson = testsJson;
        this.snapshotSha256 = snapshotSha256;
        this.engine = engine;
        this.stdout = stdout;
        this.stderr = stderr;
        this.status = status;
        this.diagnostic = diagnostic;
        this.exitCode = inputRequired && (exitCode == null || exitCode == 0) ? null : exitCode;
        this.hasVisual = hasVisual;
    }
}
