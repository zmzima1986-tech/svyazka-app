package app.svyazka.mobile;

import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.util.Collections;
import org.json.JSONObject;
import org.junit.Test;
import static org.junit.Assert.*;

/** Verify the emitted request objects, not string occurrences in source files. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 33)
public final class PrivacyRequestTest {
    @Test public void openRouterDenyIsDefaultAndCanBeDisabled() throws Exception {
        Workflow.Stage stage = Workflow.defaultStages().get(0);
        Workflow.Run request = Workflow.Run.quick("privacy test", stage.model,
                Workflow.defaultStages().get(1));
        JSONObject defaultRequest = ModelClient.materialBody(request, stage.model, Collections.emptyList());
        assertEquals("deny", defaultRequest.getJSONObject("provider").getString("data_collection"));
        assertTrue(defaultRequest.getJSONObject("provider").has("max_price"));
        JSONObject optedOut = ModelClient.materialBody(request, stage.model, Collections.emptyList(), false);
        assertFalse(optedOut.getJSONObject("provider").has("data_collection"));
        assertTrue(optedOut.getJSONObject("provider").has("max_price"));
    }

    @Test public void otherProvidersDoNotInheritOpenRouterFields() throws Exception {
        Workflow.Stage stage = Workflow.defaultStages().get(0);
        Workflow.Run request = Workflow.Run.quick("privacy test", stage.model,
                Workflow.defaultStages().get(1));
        assertFalse(ModelClient.groqBody(request, stage.model).has("provider"));
    }
}
