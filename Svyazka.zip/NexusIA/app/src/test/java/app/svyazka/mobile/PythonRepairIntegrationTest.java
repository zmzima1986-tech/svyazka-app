package app.svyazka.mobile;

import static org.junit.Assert.*;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;

import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.LooperMode;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Real Activity, callback routing, persistence and retry logic; offline transport fixtures. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 33, qualifiers = "ru-rRU")
@LooperMode(LooperMode.Mode.PAUSED)
public class PythonRepairIntegrationTest {
    private MainActivity activity;
    private ActivityController<MainActivity> controller;
    private Transport transport;
    private static final String FENCE = "\u0060\u0060\u0060";

    static final class Transport extends AbstractExecutorService {
        int submitted;
        boolean closed;

        public void execute(Runnable r) {
            submitted++;
        } // Transport completions are delivered by network().

        public void shutdown() {
            closed = true;
        }

        public List<Runnable> shutdownNow() {
            closed = true;
            return Collections.emptyList();
        }

        public boolean isShutdown() {
            return closed;
        }

        public boolean isTerminated() {
            return closed;
        }

        public boolean awaitTermination(long time, TimeUnit unit) {
            return closed;
        }
    }

    private Field field(String key) throws Exception {
        Field f = MainActivity.class.getDeclaredField(key);
        f.setAccessible(true);
        return f;
    }

    private static void call(Object target, String name, Class<?>[] signature, Object... args)
            throws Exception {
        Method m = target.getClass().getDeclaredMethod(name, signature);
        m.setAccessible(true);
        m.invoke(target, args);
    }

    private Workflow.Run run() throws Exception {
        return (Workflow.Run) field("run").get(activity);
    }

    private Object attempt() throws Exception {
        return field("attempt").get(activity);
    }

    @Before
    public void setup() throws Exception {
        Context ctx = ApplicationProvider.getApplicationContext();
        String fixture;
        try (InputStream in = getClass().getResourceAsStream("/openrouter-models.json");
                Scanner s = new Scanner(in, "UTF-8").useDelimiter("\\A")) {
            fixture = s.next();
        }
        ctx.getSharedPreferences("workspace", Context.MODE_PRIVATE)
                .edit()
                .putString(
                        "catalog",
                        ModelCatalog.fromOpenRouter(new JSONObject(fixture)).cacheData().toString())
                .putLong("catalog_time", System.currentTimeMillis())
                .putBoolean("privacy_notice_acknowledged", true)
                .commit();
        // Robolectric resets the data directory between tests; start a matching cold app process.
        field("sharedStore").set(null, null);
        controller = Robolectric.buildActivity(MainActivity.class).setup();
        activity = controller.get();
        transport = new Transport();
        field("worker").set(activity, transport);
        field("vault")
                .set(
                        activity,
                        new CredentialStore() {
                            public String read(Workflow.Provider p) {
                                return p == Workflow.Provider.OPENROUTER ? "offline-fixture" : "";
                            }

                            public String readPiston() {
                                return "";
                            }

                            public void save(String r, String g, String q, String p) {
                                throw new AssertionError("Unexpected key update");
                            }
                        });
    }

    @After
    public void close() {
        if (controller != null) controller.pause().stop().destroy();
    }

    private static ModelClient.Reply stop(String text) {
        return new ModelClient.Reply(text, ModelClient.Finish.STOP, "");
    }

    private void network(Object token, ModelClient.Reply reply) throws Exception {
        assertNotNull(token);
        call(
                activity,
                "receive",
                new Class<?>[] {token.getClass(), ModelClient.Reply.class},
                token,
                reply);
    }

    private String block(String expr) {
        return FENCE + "python\ndef inc(x):\n    return " + expr + "\n" + FENCE;
    }

    private void editor(String answer) throws Exception {
        Workflow.Run team = new Workflow.Run("assert inc(0) == 1", Workflow.defaultStages());
        activity.nexusDraftChanged(team.task);
        call(activity, "begin", new Class<?>[] {Workflow.Run.class}, team);
        network(attempt(), stop("Solution."));
        network(attempt(), stop("Проверено.\n[[REVIEW: PASS]]"));
        assertEquals(Workflow.Step.REVISION, run().nextStep());
        network(attempt(), stop(answer));
    }

    @Test public void savedRoleIsIndependentOfRunningExecutor() throws Exception {
        Workflow.Run initial = new Workflow.Run("Clock", Workflow.defaultStages());
        call(activity,"begin",new Class<?>[]{Workflow.Run.class},initial);
        String frozen = run().nextStage().selected.id;
        assertTrue(activity.nexusUpdateStage(0,"Architect","Write the file.",ModelCatalog.NORTH.id));
        assertEquals(ModelCatalog.NORTH.id, activity.nexusConfiguredStages().get(0).modelId);
        assertEquals(frozen,run().nextStage().selected.id);
        String persisted = activity.getSharedPreferences("workspace",0).getString("stages","");
        assertEquals(ModelCatalog.NORTH.id, Workflow.stagesFromJson(new org.json.JSONArray(persisted)).get(0).selected.id);
        network(attempt(), ModelClient.Reply.error("","Timeout",408));
        assertEquals(frozen,run().nextStage().selected.id);
        assertNotEquals(frozen,run().nextStage().model.id);
        assertFalse(run().nextStage().routeReason.isEmpty());
        assertTrue(activity.nexusSnapshot().stages.get(0).modelLabel.contains("Резерв"));
    }

    @Test public void strictSelectionStopsAndRecoversDraft() throws Exception {
        Workflow.Run strict = new Workflow.Run("Clock",Workflow.defaultStages()).withFallbackPolicy(false);
        call(activity,"begin",new Class<?>[]{Workflow.Run.class},strict);
        network(attempt(),ModelClient.Reply.error("```python\ndef clock():\n","Timeout",408));
        assertNull(attempt());
        assertEquals(1,transport.submitted);
        Workflow.Run restored = Workflow.Run.fromJson(run().toJson());
        assertFalse(restored.complete());
        assertFalse(restored.nextStage().allowFallback);
        assertEquals("```python\ndef clock():\n",restored.draft.text);
        activity.nexusChangePausedModel(ModelCatalog.NORTH.id);
        activity.nexusResume();
        assertEquals(ModelCatalog.NORTH.id,run().nextStage().selected.id);
        assertEquals(2,transport.submitted);
    }

    private void worker(String status, String reason, String signature) throws Exception {
        Object sandbox = field("automaticPython").get(activity);
        assertNotNull("Worker should be open", sandbox);
        JSONObject report =
                new JSONObject()
                        .put("status", status)
                        .put("diagnostic", reason)
                        .put("signature", signature)
                        .put("syntax", true)
                        .put("ran", status.equals("ERROR") || status.equals("PASSED"))
                        .put("passed", status.equals("PASSED") ? 1 : 0)
                        .put("total", 1);
        call(
                sandbox,
                "accept",
                new Class<?>[] {String.class},
                new JSONObject().put("verification", report).toString());
    }

    @Test
    public void fallbackThenCorrectionIsRetestedAndPersisted() throws Exception {
        editor(block("x"));
        worker("ERROR", "Ожидалось 1, получено 0.", "wrong-1");
        assertTrue(
                run().prompt().contains("Ожидалось 1, получено 0.")
                        && run().prompt().contains("return x"));
        Object first = attempt();
        network(first, ModelClient.Reply.error("", "HTTP 429", 429));
        Object fallback = attempt();
        assertNotSame(first, fallback);
        network(first, stop("late reply"));
        assertSame(fallback, attempt());
        network(fallback, stop(block("x+1")));
        worker("PASSED", "", "");
        assertEquals(5, transport.submitted);
        assertEquals(2, run().verification.requests);
        assertEquals(PythonVerification.Status.PASSED, run().verification.status);
        assertTrue(activity.nexusSnapshot().log.contains("429"));
        assertTrue(run().verification.diagnosticsHistory().contains("получено 0"));
        WorkspaceStore store = (WorkspaceStore) field("store").get(activity);
        CountDownLatch flush = new CountDownLatch(1);
        AtomicBoolean saved = new AtomicBoolean();
        store.save(
                field("storeSession").getLong(activity),
                store.current(),
                ok -> {
                    saved.set(ok);
                    flush.countDown();
                });
        assertTrue(flush.await(8, TimeUnit.SECONDS));
        assertTrue(saved.get());
        TaskRepository db = (TaskRepository) field("repository").get(activity);
        Workflow.Run restored =
                Workflow.Run.fromJson(new JSONObject(db.load(activity.nexusTaskId()).runJson));
        assertEquals(PythonVerification.Status.PASSED, restored.verification.status);
        assertEquals(block("x+1"), restored.displayAnswer(restored.finalIndex()));
        assertEquals("offline-fixture", activity.nexusKeysForEditing()[0]);
    }

    @Test
    public void quickChecksCodeWithoutSpendingOnARepair() throws Exception {
        Workflow.Run quick = Workflow.Run.quick("assert inc(0) == 1", ModelCatalog.NORTH, Workflow.defaultStages().get(1));
        call(activity, "begin", new Class<?>[] {Workflow.Run.class}, quick);
        network(attempt(), stop(block("x")));
        worker("ERROR", "expected one", "case");
        assertTrue(run().complete());
        assertEquals(PythonVerification.Status.ERROR, run().verification.status);
        assertEquals(1, transport.submitted);
        assertEquals(block("x"), activity.nexusSnapshot().result);
    }

    @Test
    public void globalSearchIncludesArchivedMessagesBeyondTheDisplayLimit() throws Exception {
        long original = activity.nexusTaskId();
        TaskRepository db = (TaskRepository) field("repository").get(activity);
        Workflow.Run quick = Workflow.Run.quick("первый вопрос", ModelCatalog.NORTH, Workflow.defaultStages().get(1));
        for (int i = 0; i < 43; i++)
            assertTrue(db.preserveVersion(original, quick.receive(stop("ответ " + i)).toJson().toString()));
        long other = db.create("чужой вопрос");
        assertTrue(db.preserveVersion(other, quick.receive(stop("только второй чат")).toJson().toString()));
        List<NexusState.SearchMessage> one = activity.nexusSearchMessages(original);
        assertTrue(one.stream().anyMatch(m -> m.text.equals("ответ 0")));
        assertTrue(one.stream().anyMatch(m -> m.text.equals("ответ 42")));
        assertFalse(one.stream().anyMatch(m -> m.taskId == other));
        assertTrue(activity.nexusSearchMessages(0).stream().anyMatch(m -> m.taskId == other && m.text.equals("только второй чат")));
    }

    @Test
    public void standaloneEditorCanRunCloseAndStartAgain() throws Exception {
        app.svyazka.mobile.ui.NexusComposeUi ui = (app.svyazka.mobile.ui.NexusComposeUi) field("nexusUi").get(activity);
        assertNull(run());
        ui.editPython("print(7)");
        ui.openRight();
        assertTrue(activity.nexusExecutePython(-1, ui.getPythonEditingCode(), "", false, false));
        ui.closePanel();
        assertTrue(ui.getPythonBusy());
        assertEquals("print(7)", activity.nexusBuffer("python"));
        activity.nexusCancelPython();
        assertFalse(ui.getPythonBusy());
        assertTrue(activity.nexusExecutePython(-1, "print(8)", "", false, false));
        activity.nexusCancelPython();
    }

    @Test
    public void sizeRejectionRetainsEditor() throws Exception {
        editor(block("0"));
        worker("ERROR", "wrong result", "case");
        network(attempt(), ModelClient.Reply.error("", "HTTP 413", 413));
        assertTrue(run().complete());
        assertEquals(PythonVerification.Status.STOPPED, run().verification.status);
        assertTrue(run().verification.diagnostic.contains("413"));
        assertEquals(3, run().stages.size());
        assertEquals(4, transport.submitted);
        assertEquals(block("0"), activity.nexusSnapshot().result);
    }

    @Test
    public void timeoutAndFallbackShareBudget() throws Exception {
        editor(block("0"));
        worker("ERROR", "wrong result", "case");
        Object first = attempt();
        Field f = first.getClass().getDeclaredField("deadline");
        f.setAccessible(true);
        ((Runnable) f.get(first)).run();
        network(attempt(), ModelClient.Reply.error("", "HTTP 429", 429));
        network(attempt(), ModelClient.Reply.error("", "HTTP 503", 503));
        assertEquals(6, transport.submitted);
        assertEquals(3, run().verification.requests);
        assertTrue(activity.nexusSnapshot().log.contains("TIMED_OUT"));
        assertTrue(run().complete());
        assertEquals(block("0"), activity.nexusSnapshot().result);
    }

    @Test
    public void repeatedFailureStops() throws Exception {
        editor(block("0"));
        worker("ERROR", "got 0", "wrong-1");
        network(attempt(), stop(block("2")));
        worker("ERROR", "got 2", "wrong-1");
        assertEquals(4, transport.submitted);
        assertEquals(PythonVerification.Status.STOPPED, run().verification.status);
        assertEquals(block("2"), activity.nexusSnapshot().result);
        assertTrue(
                run().verification.diagnosticsHistory().contains("got 0")
                        && run().verification.diagnosticsHistory().contains("got 2"));
    }

    @Test
    public void proseAndUnchangedSource() throws Exception {
        editor("Обычный ответ.");
        assertNull(field("automaticPython").get(activity));
        assertEquals(PythonVerification.Status.NONE, run().verification.status);
        editor(block("0"));
        worker("ERROR", "wrong result", "case");
        network(attempt(), stop(block("0")));
        assertNull(field("automaticPython").get(activity));
        assertEquals(PythonVerification.Status.STOPPED, run().verification.status);
        assertEquals(7, transport.submitted);
    }

    @Test
    public void threeDistinctRepairsStop() throws Exception {
        editor(block("0"));
        for (int i = 0; i < 3; i++) {
            worker("ERROR", "failure " + i, "case-" + i);
            assertEquals(i + 1, run().verification.requests);
            network(attempt(), stop(block(Integer.toString(i + 1))));
        }
        worker("ERROR", "failure 3", "case-3");
        assertEquals(PythonVerification.Status.STOPPED, run().verification.status);
        assertEquals(6, transport.submitted);
        assertEquals(3, run().verification.rounds);
        assertEquals(block("3"), activity.nexusSnapshot().result);
    }

    @Test
    public void missingRepairCodeKeepsPreviousAnswer() throws Exception {
        editor(block("0"));
        worker("ERROR", "wrong", "case");
        network(attempt(), stop("Я всё исправил."));
        assertEquals(PythonVerification.Status.STOPPED, run().verification.status);
        assertEquals(block("0"), activity.nexusSnapshot().result);
        assertEquals(4, transport.submitted);
    }

    @Test
    public void unsupportedAndCancelledRunsSpendNoRepairRequests() throws Exception {
        editor(FENCE + "python\nimport neo4j\n" + FENCE);
        worker("LIMITED", "neo4j unavailable", "");
        assertEquals(PythonVerification.Status.LIMITED, run().verification.status);
        assertEquals(3, transport.submitted);
        editor(block("x+1"));
        Object previous = field("automaticPython").get(activity);
        activity.nexusStop();
        assertEquals(PythonVerification.Status.STOPPED, run().verification.status);
        call(previous, "accept", new Class<?>[] {String.class}, "{\"error\":\"late\"}");
        assertEquals(6, transport.submitted);
        assertEquals(PythonVerification.Status.STOPPED, run().verification.status);
    }
}
