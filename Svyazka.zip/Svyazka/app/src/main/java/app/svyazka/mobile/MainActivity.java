package app.svyazka.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.Consumer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final int BG = 0xff0e1520;
    private static final int SURFACE = 0xff172233;
    private static final int BORDER = 0xff2b3a4c;
    private static final int FG = 0xfff1f5fc;
    private static final int MUTED = 0xffa9b9ce;
    private static final int ACCENT = 0xff8ce5dc;
    private static final int ACCENT_INK = 0xff10232a;
    private static final int ACCENT_DARK = 0xff203a42;
    private static final int WARNING = 0xffffcb9b;
    private static final int DANGER = 0xffff6e72;
    private static final int EXPORT_REQUEST = 71;
    private static final int ANSWER_PREVIEW = 3500;
    private static final long CATALOG_TTL = 6 * 60 * 60 * 1000L;
    private static final String GROQ_RESERVE = "groq_reserve";
    private static final long CHECKPOINT_INTERVAL = 2_500;
    private static WorkspaceStore sharedStore;

    // A cancelled HTTP call may keep its thread blocked briefly; retries must not queue behind it.
    private final ExecutorService worker = RequestExecutor.create();
    private final ExecutorService cancellationWorker = Executors.newFixedThreadPool(2);
    private final ExecutorService catalogWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService sandboxWorker = Executors.newSingleThreadExecutor();
    private final ModelClient client = new ModelClient();
    private final ModelPool.Cooldowns cooldowns = new ModelPool.Cooldowns();
    private final SandboxClient sandboxClient = new SandboxClient();
    private final List<Consumer<String>> catalogListeners = new ArrayList<>();
    private SharedPreferences data;
    private WorkspaceStore store;
    private long storeSession;
    private String taskDraft;
    private Workflow.Mode selectedMode;
    private ModelCatalog.Model quickModel;
    private String attemptHistory;
    private boolean clearing;
    private boolean checkpointPending;
    private CredentialStore vault;
    private ModelCatalog catalog;
    private long catalogTime;
    private ModelClient.Cancellation catalogRequest;
    private List<Workflow.Stage> stages;
    private Workflow.Run run;
    private boolean resultsVisible;
    private boolean active;
    private StagePool stagePool;
    private Attempt attempt;
    private SandboxJob sandboxJob;
    private ScrollView scroll;
    private LinearLayout content;
    private EditText taskInput;
    private final android.os.Handler progressHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable saveDraft = this::persistRun;
    private final Runnable checkpoint = this::persistRun;
    private TextView liveText;
    private TextView liveStatus;

    private static final class StagePool {
        final List<ModelCatalog.Model> models;
        final EnumMap<Workflow.Provider, String> keys;
        final List<String> failures = new ArrayList<>();
        int next;
        boolean quotaChecked;
        boolean catalogChecked;

        StagePool(List<ModelCatalog.Model> models, EnumMap<Workflow.Provider, String> keys) {
            this.models = models;
            this.keys = keys;
        }

    }

    private static final class Attempt {
        final Workflow.Run input;
        final ModelClient.Cancellation cancellation = new ModelClient.Cancellation();
        final long started = android.os.SystemClock.elapsedRealtime();
        volatile String received = "";
        boolean timedOut;
        Future<?> future;
        Runnable deadline;

        Attempt(Workflow.Run input) { this.input = input; }
    }

    private static final class SandboxJob {
        final ModelClient.Cancellation cancellation = new ModelClient.Cancellation();
        final AlertDialog progress;
        PythonExecutor local;
        Future<?> future;

        SandboxJob(AlertDialog progress) { this.progress = progress; }
    }

    @Override public void onCreate(Bundle restored) {
        super.onCreate(restored);
        data = getSharedPreferences("workspace", MODE_PRIVATE);
        vault = new KeyVault(getSharedPreferences("credentials", MODE_PRIVATE));
        catalog = restoreCatalog();
        catalogTime = data.getLong("catalog_time", 0);
        stages = restoreStages();
        selectedMode = "QUICK".equals(data.getString("selected_mode", "")) ? Workflow.Mode.QUICK : Workflow.Mode.TEAM;
        quickModel = restoreQuickModel();
        if (sharedStore == null) {
            WorkspaceStore.State previous = new WorkspaceStore.State(
                    data.getString(WorkspaceStore.TASK, ""), restoreRun(),
                    data.getBoolean(WorkspaceStore.RESULTS, false),
                    data.getString(WorkspaceStore.HISTORY, ""));
            SharedPreferences preferences = data;
            sharedStore = new WorkspaceStore(previous, Executors.newSingleThreadExecutor(),
                    changes -> writeWorkspace(preferences, changes));
        }
        store = sharedStore;
        storeSession = store.attach();
        WorkspaceStore.State previous = store.current();
        run = interrupted(previous.run);
        taskDraft = previous.task;
        attemptHistory = previous.history;
        resultsVisible = previous.resultsVisible;
        if (resultsVisible) renderRun(false);
        else renderTask();
        refreshModels(false, problem -> {});
    }

    private ModelCatalog restoreCatalog() {
        String saved = data.getString("catalog", "");
        if (!saved.isEmpty()) {
            try {
                return ModelCatalog.fromCache(new JSONArray(saved));
            } catch (JSONException ignored) {
                // A missing or invalid cache can be rebuilt from the public catalog.
            }
        }
        return ModelCatalog.starter();
    }

    private void refreshModels(boolean force, Consumer<String> listener) {
        long age = System.currentTimeMillis() - catalogTime;
        if (!force && catalog.refreshed && age >= 0 && age < CATALOG_TTL) {
            listener.accept("");
            return;
        }
        catalogListeners.add(listener);
        if (catalogRequest != null) return;
        ModelClient.Cancellation stop = new ModelClient.Cancellation();
        catalogRequest = stop;
        catalogWorker.submit(() -> {
            try {
                ModelCatalog updated = client.models(stop);
                String cached = updated.cacheData().toString();
                runOnUiThread(() -> finishCatalog(updated, cached));
            } catch (IOException | JSONException | ModelClient.Problem e) {
                runOnUiThread(() -> finishCatalog(null, null));
            }
        });
    }

    private void finishCatalog(ModelCatalog updated, String cached) {
        if (isDestroyed()) return;
        catalogRequest = null;
        String problem = "";
        if (updated == null) {
            problem = "Каталог не обновился. Показан последний доступный список.";
        } else {
            catalog = updated;
            catalogTime = System.currentTimeMillis();
            data.edit().putString("catalog", cached).putLong("catalog_time", catalogTime).apply();
        }
        List<Consumer<String>> listeners = new ArrayList<>(catalogListeners);
        catalogListeners.clear();
        for (Consumer<String> listener : listeners) listener.accept(problem);
    }

    private List<Workflow.Stage> restoreStages() {
        try {
            return Workflow.stagesFromJson(new JSONArray(data.getString("stages", "[]")));
        } catch (JSONException e) {
            return Workflow.defaultStages();
        }
    }

    private ModelCatalog.Model restoreQuickModel() {
        String id = data.getString("quick_model", "");
        if (!id.isEmpty()) {
            try {
                return ModelCatalog.storedModel(id, data.getString("quick_model_label", ""));
            } catch (JSONException ignored) {
                // The architect remains the default when the saved selection is invalid.
            }
        }
        return null;
    }

    private ModelCatalog.Model quickModel() {
        return quickModel == null ? stages.get(0).model : quickModel;
    }

    private Workflow.Run restoreRun() {
        String saved = data.getString(WorkspaceStore.RUN, "");
        if (saved.isEmpty()) return null;
        try {
            return Workflow.Run.fromJson(new JSONObject(saved));
        } catch (JSONException e) {
            return null;
        }
    }

    private Workflow.Run interrupted(Workflow.Run value) {
        if (value != null && !value.complete() && (value.note.isEmpty() || "Ответ ещё поступает.".equals(value.note))) {
            return value.withNote("Разбор прерван. Можно продолжить с незавершённого шага.");
        }
        return value;
    }

    private static boolean writeWorkspace(SharedPreferences preferences, Map<String, Object> changes) {
        SharedPreferences.Editor edit = preferences.edit();
        for (Map.Entry<String, Object> change : changes.entrySet()) {
            Object value = change.getValue();
            if (value == null) edit.remove(change.getKey());
            else if (value instanceof Boolean) edit.putBoolean(change.getKey(), (Boolean) value);
            else edit.putString(change.getKey(), (String) value);
        }
        return edit.commit();
    }

    private void persistRun() {
        progressHandler.removeCallbacks(saveDraft);
        progressHandler.removeCallbacks(checkpoint);
        checkpointPending = false;
        if (clearing) return;
        Workflow.Run snapshot = run;
        Attempt current = attempt;
        if (current != null && !current.received.isEmpty()) {
            snapshot = current.input.receive(ModelClient.Reply.error(current.received, "Ответ ещё поступает."));
        }
        store.save(storeSession, new WorkspaceStore.State(taskDraft, snapshot, resultsVisible, attemptHistory),
                saved -> { if (!saved) runOnUiThread(() -> {
                    if (!isDestroyed() && !clearing) toast("Не удалось сохранить рабочие данные.");
                }); });
    }

    private void scheduleCheckpoint() {
        if (checkpointPending) return;
        checkpointPending = true;
        progressHandler.postDelayed(checkpoint, CHECKPOINT_INTERVAL);
    }

    private void makeScreen() {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        root.setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();

        LinearLayout top = row();
        top.setPadding(dp(20), dp(8), dp(20), dp(8));
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.ic_svyazka);
        top.addView(mark, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView name = text("Связка", 21, FG, true);
        LinearLayout.LayoutParams nameLayout = weighted();
        nameLayout.leftMargin = dp(10);
        top.addView(name, nameLayout);
        Button models = button("Модели", false, view -> showKeys(""));
        models.setEnabled(!clearing);
        top.addView(models);
        root.addView(top);
        View rule = new View(this);
        rule.setBackgroundColor(BORDER);
        root.addView(rule, new LinearLayout.LayoutParams(-1, dp(1)));

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        content = column();
        content.setPadding(dp(20), dp(22), dp(20), dp(24));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        root.requestFocus();
    }

    private void renderTask() {
        if (resultsVisible) {
            resultsVisible = false;
            persistRun();
        }
        makeScreen();
        boolean quick = selectedMode == Workflow.Mode.QUICK;
        add(content, text(quick ? "Вопрос для модели" : "Задача для команды", 28, FG, true), 0);
        Button newTask = button("Начать новую задачу", false, view -> confirmClearWorkspace());
        newTask.setEnabled(!clearing);
        add(content, newTask, 10);
        LinearLayout modes = row();
        Button fast = button("Быстрый ответ (1 ИИ)", quick, view -> selectMode(Workflow.Mode.QUICK));
        Button team = button("Разбор командой", !quick, view -> selectMode(Workflow.Mode.TEAM));
        fast.setSelected(quick);
        team.setSelected(!quick);
        modes.addView(fast, weighted());
        LinearLayout.LayoutParams second = weighted();
        second.leftMargin = dp(8);
        modes.addView(team, second);
        add(content, modes, 12);
        taskInput = field(taskDraft,
                "Например, предложи план приложения и проверь его на ошибки.",
                0, 4, false);
        taskInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (clearing) return;
                taskDraft = s.toString();
                progressHandler.removeCallbacks(saveDraft);
                progressHandler.postDelayed(saveDraft, 600);
            }
            @Override public void afterTextChanged(Editable value) {}
        });
        add(content, taskInput, 18);

        if (quick) {
            ModelCatalog.Model model = quickModel();
            add(content, button("Модель: " + model.label, false, view -> chooseModel(model, choice -> {
                quickModel = choice;
                data.edit().putString("quick_model", choice.id).putString("quick_model_label", choice.label).apply();
                renderTask();
            })), 14);
        } else {
            addTeamCards();
        }
        add(content, button(quick ? "Получить ответ" : "Запустить разбор", true, view -> startRun()), 18);
        if (run != null) {
            add(content, button(run.mode == Workflow.Mode.QUICK ? "Последний ответ" : "Последний разбор",
                    false, view -> renderRun(false)), 8);
        }
    }

    private void selectMode(Workflow.Mode value) {
        if (selectedMode == value) return;
        selectedMode = value;
        data.edit().putString("selected_mode", value.name()).apply();
        renderTask();
    }

    private void addTeamCards() {
        add(content, text("Команда", 19, FG, true), 22);
        for (int i = 0; i < stages.size(); i++) {
            Workflow.Stage stage = stages.get(i);
            LinearLayout item = row();
            item.setPadding(dp(13), dp(10), dp(14), dp(10));
            item.setMinimumHeight(dp(61));
            item.setBackground(ripple(SURFACE, BORDER, 14));
            item.addView(badge(i + 1));
            LinearLayout descriptions = column();
            descriptions.addView(text(stage.role, 16, FG, true));
            add(descriptions, text(stage.model.label + " · " + stage.model.provider.label,
                    13, MUTED, false), 3);
            LinearLayout.LayoutParams descriptionLayout = weighted();
            descriptionLayout.leftMargin = dp(12);
            descriptionLayout.rightMargin = dp(8);
            item.addView(descriptions, descriptionLayout);
            item.addView(text("›", 25, MUTED, false));
            int index = i;
            item.setFocusable(true);
            item.setOnClickListener(view -> editStage(index));
            item.setContentDescription("Шаг " + (i + 1) + ". " + stage.role + ". "
                    + stage.model.label + ". Изменить роль.");
            add(content, item, 8);
        }
    }

    private void renderRun(boolean keepPosition) {
        int lastY = keepPosition && scroll != null ? scroll.getScrollY() : 0;
        if (!resultsVisible) {
            resultsVisible = true;
            persistRun();
        }
        liveStatus = null;
        liveText = null;
        makeScreen();
        String title = run.mode == Workflow.Mode.QUICK ? (run.complete() ? "Ответ готов" : "Быстрый ответ")
                : (run.complete() ? "Разбор готов" : "Разбор задачи");
        add(content, text(title, 28, FG, true), 0);
        add(content, selectable(preview(run.task), 15, MUTED), 8);
        if (run.task.length() > ANSWER_PREVIEW) {
            add(content, button("Открыть задачу", false, view -> showText("Задача", run.task)), 6);
        }

        LinearLayout status = row();
        if (active) {
            ProgressBar spinner = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
            spinner.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));
            status.addView(spinner, new LinearLayout.LayoutParams(dp(20), dp(20)));
        }
        String statusText = run.answers.size() + " из " + run.stages.size() + " шагов";
        if (run.revisionSkipped()) statusText += " · правка пропущена";
        TextView statusLabel = text(statusText, 14, ACCENT, true);
        LinearLayout.LayoutParams statusLayout = weighted();
        statusLayout.leftMargin = active ? dp(8) : 0;
        status.addView(statusLabel, statusLayout);
        if (active) status.addView(button("Остановить", false, view -> stopRun()));
        add(content, status, 12);
        if (!run.note.isEmpty()) {
            TextView warning = text(run.note, 14, WARNING, false);
            warning.setPadding(dp(12), dp(10), dp(12), dp(10));
            warning.setBackground(shape(SURFACE, BORDER, 12));
            add(content, warning, 8);
        }
        for (int i = 0; i < run.stages.size(); i++) addAnswerCard(content, i);
        if (!run.complete() && !active) {
            String label = "Продолжить разбор";
            if (run.draftMode == Workflow.DraftMode.CONTINUE) label = "Дописать ответ";
            if (run.draftMode == Workflow.DraftMode.REPEAT_REVIEW) label = "Повторить ревью";
            add(content, button(label, true, view -> resumeRun()), 16);
        }
        if (!active) {
            if (!run.answers.isEmpty() || !run.draft.text.isEmpty()) {
                add(content, button("Сохранить разбор в JSON", false, view -> chooseExport()), 10);
            }
            if (!attemptHistory.isEmpty()) {
                add(content, button("Журнал запросов", false, view -> showAttemptHistory()), 8);
            }
            add(content, button("К задаче", false, view -> renderTask()), 8);
            add(content, button("Начать новую задачу", false, view -> confirmClearWorkspace()), 8);
        }
        if (lastY > 0) {
            ScrollView current = scroll;
            current.post(() -> current.scrollTo(0, lastY));
        }
    }

    private void addAnswerCard(LinearLayout panel, int i) {
        Workflow.Stage stage = run.stages.get(i);
        boolean done = run.hasAnswer(i);
        boolean current = !run.complete() && i == run.nextIndex();
        boolean running = active && current;
        boolean hasDraft = current && !run.draft.text.isEmpty();
        boolean finalAnswer = run.complete() && i == run.finalIndex();
        boolean skipped = run.revisionSkipped() && i == Workflow.Step.REVISION.ordinal();
        String status = done ? (finalAnswer ? "Итог" : "Готово")
                : running ? hasDraft ? "Продолжает ответ" : "Готовит ответ"
                : current ? hasDraft ? "Сохранён черновик" : "Ждёт запуска"
                : skipped ? "Пропущен · ревью без замечаний" : "В очереди";
        LinearLayout card = column();
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(shape(SURFACE, finalAnswer ? ACCENT : running ? ACCENT_DARK : BORDER, 15));
        LinearLayout heading = row();
        heading.addView(badge(i + 1));
        LinearLayout description = column();
        description.addView(text(stage.role, 16, FG, true));
        String modelLabel = stage.model.label;
        if (done) modelLabel = contributorLabels(run.answerAt(i), stage.model);
        add(description, text(modelLabel + " · " + status, 13,
                running ? ACCENT : MUTED, false), 3);
        LinearLayout.LayoutParams item = weighted();
        item.leftMargin = dp(10);
        heading.addView(description, item);
        card.addView(heading);
        if (done || hasDraft) {
            String answer = done ? run.displayAnswer(i) : run.draft.text;
            if (hasDraft) {
                add(card, text("Черновик · " + contributorLabels(run.draft, stage.model),
                        13, WARNING, true), 12);
            }
            Workflow.Artifact artifact = done ? run.answerAt(i) : run.draft;
            if (!artifact.warnings.isEmpty()) {
                add(card, text("⚠ Проверь продолжение ответа:\n" + String.join("\n", artifact.warnings),
                        13, WARNING, false), 10);
            }
            TextView response = selectable(preview(answer), 15, FG);
            response.setLineSpacing(dp(4), 1f);
            add(card, response, 14);
            if (answer.length() > ANSWER_PREVIEW) {
                add(card, button("Открыть весь текст", false, view -> showText(stage.role, answer)), 10);
            }
            add(card, button("Копировать ответ", false, view -> {
                try {
                    ClipboardManager clipboard = getSystemService(ClipboardManager.class);
                    clipboard.setPrimaryClip(ClipData.newPlainText(stage.role, answer));
                    toast("Ответ скопирован");
                } catch (RuntimeException e) {
                    toast("Не удалось скопировать. Сохрани разбор в JSON.");
                }
            }), 10);
            List<String> blocks = SandboxClient.pythonBlocks(answer);
            if (done && !blocks.isEmpty()) {
                Button execute = button("Запустить код", false, view -> choosePythonBlock(run, i, blocks));
                execute.setEnabled(!active);
                add(card, execute, 10);
            }
        }
        if (running) {
            String waiting = stagePool != null && !stagePool.failures.isEmpty()
                    ? "Пробую резервную модель · попытка " + stagePool.next + " из " + stagePool.models.size()
                    : "Ожидание модели · максимум 60 секунд на попытку";
            liveStatus = text(waiting, 13, ACCENT, false);
            liveText = selectable("", 15, FG);
            add(card, liveStatus, 10);
            add(card, liveText, 10);
        }
        if (current && !active) {
            add(card, button("Сменить модель шага", false, view -> chooseModel(stage.model, model -> {
                run = run.withModel(model);
                persistRun();
                renderRun(true);
            })), 10);
        }
        add(panel, card, 10);
    }

    private String contributorLabels(Workflow.Artifact artifact, ModelCatalog.Model fallback) {
        List<String> names = new ArrayList<>();
        for (String id : artifact.models) {
            try {
                names.add(catalog.details(ModelCatalog.storedModel(id, "")).label);
            } catch (JSONException e) {
                names.add(id);
            }
        }
        return names.isEmpty() ? fallback.label : String.join(" + ", names);
    }

    private void choosePythonBlock(Workflow.Run source, int index, List<String> blocks) {
        if (blocks.size() == 1) {
            showSandboxInput(source, index, blocks.get(0), "", false);
            return;
        }
        String[] labels = new String[blocks.size()];
        for (int i = 0; i < labels.length; i++) {
            String firstLine = blocks.get(i).trim().split("\\R", 2)[0];
            labels[i] = "Блок " + (i + 1) + " · "
                    + (firstLine.length() > 70 ? firstLine.substring(0, 70) + "…" : firstLine);
        }
        new AlertDialog.Builder(this).setTitle("Выбрать блок Python").setItems(labels,
                (dialog, which) -> showSandboxInput(source, index, blocks.get(which), "", false))
                .setNegativeButton("Отмена", null).show();
    }

    private void showSandboxInput(Workflow.Run source, int index, String code, String previousInput,
                                  boolean usePiston) {
        LinearLayout form = dialogForm();
        add(form, text("Введи данные для input(), по одному ответу на строку. "
                + "Пустое поле означает конец ввода.", 14, MUTED, false), 0);
        EditText stdin = field(previousInput, "Ввод программы (stdin)", 0, 3, false);
        add(form, stdin, 8);
        String pistonKey = readPistonForEdit();
        CheckBox remote = new CheckBox(this);
        if (!pistonKey.isEmpty()) {
            remote.setText("Piston · Python " + SandboxClient.PISTON_VERSION + "\nКод и ввод отправятся в Piston.");
            remote.setChecked(usePiston);
            add(form, remote, 8);
        }
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Запустить код")
                .setView(dialogArea(form)).setPositiveButton("Запустить", null)
                .setNegativeButton("Отмена", null).show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String input = stdin.getText().toString();
            try {
                SandboxClient.validate(code, input);
            } catch (IllegalArgumentException e) {
                stdin.setError(e.getMessage());
                return;
            }
            dialog.dismiss();
            runSandbox(source, index, code, input, remote.isChecked() ? pistonKey : "");
        });
    }

    private void runSandbox(Workflow.Run source, int index, String code, String stdin, String pistonKey) {
        if (clearing || source != run || sandboxJob != null) return;
        boolean remote = !pistonKey.isEmpty();
        AlertDialog progress = new AlertDialog.Builder(this).setTitle("Запускаю Python")
                .setMessage(remote ? "В песочнице Piston…" : "На телефоне…")
                .setNegativeButton("Остановить", null).show();
        SandboxJob job = new SandboxJob(progress);
        sandboxJob = job;
        progress.setOnDismissListener(dialog -> {
            if (sandboxJob == job) cancelSandbox();
        });
        Consumer<SandboxClient.Result> result = output -> {
            if (sandboxJob != job || isDestroyed()) return;
            sandboxJob = null;
            progress.dismiss();
            showSandboxResult(source, index, code, stdin, remote, output);
        };
        Consumer<String> problem = message -> {
            if (sandboxJob != job || isDestroyed()) return;
            sandboxJob = null;
            progress.dismiss();
            new AlertDialog.Builder(this).setTitle("Запуск недоступен").setMessage(message)
                    .setNegativeButton("Закрыть", null)
                    .setPositiveButton("Повторить", (dialog, which) ->
                            showSandboxInput(source, index, code, stdin, false)).show();
        };
        if (remote) {
            job.future = sandboxWorker.submit(() -> {
                try {
                    SandboxClient.Result output = sandboxClient.execute(code, stdin, pistonKey, job.cancellation);
                    runOnUiThread(() -> result.accept(output));
                } catch (IOException e) {
                    String message = e.getMessage();
                    if (message == null || !message.startsWith("Piston")) {
                        message = "Нет ответа от Piston. Можно повторить запуск на телефоне.";
                    }
                    String safe = message;
                    runOnUiThread(() -> problem.accept(safe));
                } catch (JSONException e) {
                    runOnUiThread(() -> problem.accept("Piston вернул неполный результат запуска."));
                }
            });
        } else {
            job.local = new AndroidPythonExecutor(this, result, problem);
            job.local.execute(code, stdin);
        }
    }

    private void showSandboxResult(Workflow.Run source, int index, String code, String stdin,
                                   boolean usedPiston, SandboxClient.Result result) {
        LinearLayout form = dialogForm();
        String header = result.engine;
        if (result.exitCode != null) header += " · код завершения " + result.exitCode;
        add(form, text(header, 14, MUTED, true), 0);
        if (!result.status.isEmpty()) add(form, selectable(result.status, 14, WARNING), 8);
        add(form, text("Вывод (stdout)", 14, MUTED, true), 12);
        add(form, consoleText(result.stdout.isEmpty() ? "Нет вывода." : result.stdout, FG), 6);
        if (!result.stderr.isEmpty()) {
            add(form, text("Ошибки (stderr)", 14, MUTED, true), 12);
            add(form, consoleText(result.stderr, WARNING), 6);
        }
        AlertDialog.Builder dialog = new AlertDialog.Builder(this).setTitle("Результат запуска")
                .setView(dialogArea(form)).setNegativeButton("Закрыть", null)
                .setNeutralButton("Повторить", (which, button) ->
                        showSandboxInput(source, index, code, stdin, usedPiston));
        String error = result.diagnostic();
        if (!error.isEmpty()) {
            add(form, text("Ревьюер получит код, ввод и сообщение об ошибке.", 13, MUTED, false), 12);
            dialog.setPositiveButton("Отправить ошибку Ревьюеру", (window, button) -> {
                if (active || run != source || !run.hasAnswer(index)) return;
                boolean wasComplete = run.complete();
                run = run.addRepair(new Workflow.RepairInput(index, code, stdin, error));
                persistRun();
                if (wasComplete) resumeRun();
                if (!active) {
                    if (!wasComplete) toast("Шаг исправления добавлен после текущих шагов.");
                    renderRun(true);
                }
            });
        }
        dialog.show();
    }

    private TextView consoleText(String value, int color) {
        TextView output = selectable(value, 14, color);
        output.setTypeface(Typeface.MONOSPACE);
        return output;
    }

    private void cancelSandbox() {
        SandboxJob job = sandboxJob;
        if (job == null) return;
        sandboxJob = null;
        if (job.local != null) job.local.cancel();
        if (job.future != null) {
            job.future.cancel(true);
            new Thread(job.cancellation::cancel, "cancel-sandbox").start();
        }
        job.progress.dismiss();
    }

    private String preview(String text) {
        if (text.length() <= ANSWER_PREVIEW) return text;
        int end = Character.isLowSurrogate(text.charAt(ANSWER_PREVIEW))
                ? ANSWER_PREVIEW - 1 : ANSWER_PREVIEW;
        return text.substring(0, end) + "…";
    }

    private void showText(String title, String value) {
        LinearLayout form = dialogForm();
        TextView answer = selectable(value, 15, FG);
        answer.setLineSpacing(dp(4), 1f);
        add(form, answer, 0);
        ScrollView area = new ScrollView(this);
        area.addView(form);
        new AlertDialog.Builder(this).setTitle(title).setView(area)
                .setPositiveButton("Закрыть", null).show();
    }

    private void startRun() {
        if (active || clearing) return;
        String task = taskInput.getText().toString().trim();
        if (task.isEmpty()) {
            taskInput.setError("Введи задачу.");
            taskInput.requestFocus();
            return;
        }
        if (task.length() > Workflow.TASK_LIMIT) {
            taskInput.setError("Задача превышает 100 000 символов. Сократи её перед запуском.");
            taskInput.requestFocus();
            return;
        }
        InputMethodManager keyboard = getSystemService(InputMethodManager.class);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(taskInput.getWindowToken(), 0);
        begin(selectedMode == Workflow.Mode.QUICK
                ? Workflow.Run.quick(task, quickModel(), stages.get(Workflow.Step.REVIEW.ordinal()))
                : new Workflow.Run(task, stages));
    }

    private void resumeRun() {
        if (active || clearing || run == null || run.complete()) return;
        begin(run);
    }

    private StagePool modelsFor(Workflow.Run input) {
        EnumMap<Workflow.Provider, String> keys = new EnumMap<>(Workflow.Provider.class);
        for (Workflow.Provider provider : Workflow.Provider.values()) keys.put(provider, readForEdit(provider));
        List<ModelCatalog.Model> models = ModelPool.forStep(catalog, input.nextStep(), input.nextStage().model,
                !keys.get(Workflow.Provider.OPENROUTER).isEmpty(), !keys.get(Workflow.Provider.GROQ).isEmpty(),
                data.getBoolean(GROQ_RESERVE, false), !keys.get(Workflow.Provider.GEMINI).isEmpty());
        return new StagePool(models, keys);
    }

    private String keyMessage(Workflow.Stage stage) {
        return "Для шага «" + stage.role + "» нужен ключ " + stage.model.provider.label + ".";
    }

    private void begin(Workflow.Run input) {
        StagePool pool = modelsFor(input);
        if (pool.models.isEmpty()) {
            showKeys(keyMessage(input.nextStage()) + " Подключи доступную модель для этого шага.");
            return;
        }
        if (input != run) attemptHistory = "";
        stagePool = pool;
        active = true;
        run = input.withNote("");
        resultsVisible = true;
        requestNextModel(false);
    }

    private void requestNextModel(boolean keepPosition) {
        String missing = run.missingInput();
        if (!missing.isEmpty()) {
            pause(missing);
            return;
        }
        int next = availableCandidate();
        if (next < 0) {
            pause(exhaustedNote(""));
            return;
        }
        ModelCatalog.Model model = stagePool.models.get(next);
        stagePool.next = next + 1;
        String key = stagePool.keys.get(model.provider);
        StagePool pool = stagePool;
        run = run.withModel(model);
        Attempt current = new Attempt(run);
        attempt = current;
        persistRun();
        renderRun(keepPosition);
        current.deadline = () -> {
            if (attempt != current || clearing) return;
            current.timedOut = true;
            // Invalidate the old HTTP call before beginning a fallback; its late
            // callback is ignored because receive() clears the current attempt.
            if (current.future != null) current.future.cancel(true);
            disconnect(current.cancellation);
            receive(current, ModelClient.Reply.error(current.received,
                    "Превышено время ожидания модели (60 секунд).", 408));
        };
        progressHandler.postDelayed(current.deadline, ModelClient.REQUEST_TIMEOUT_MS);
        try {
            current.future = worker.submit(() -> {
                ModelClient.Reply reply;
                try {
                    reply = client.complete(current.input, model, key, current.cancellation, text -> {
                        current.received = text;
                        runOnUiThread(() -> {
                            if (attempt != current || isDestroyed() || clearing) return;
                            scheduleCheckpoint();
                            if (liveText != null) {
                                int start = Math.max(0, text.length() - 3500);
                                liveText.setText(text.substring(start));
                            }
                            if (liveStatus != null) liveStatus.setText("Получено " + text.length() + " символов");
                        });
                    });
                } catch (ModelClient.Problem e) {
                    reply = ModelClient.Reply.error("", e.getMessage(), e.failure);
                } catch (IOException e) {
                    reply = ModelClient.Reply.error("", "Нет ответа по сети. Проверь соединение.");
                } catch (JSONException e) {
                    reply = ModelClient.Reply.error("", "Не удалось прочитать ответ модели.");
                }
                ModelClient.Reply finished = verifyRouterFailure(reply, model, key, current, pool);
                runOnUiThread(() -> receive(current, finished));
            });
        } catch (RejectedExecutionException busy) {
            progressHandler.removeCallbacks(current.deadline);
            attempt = null;
            active = false;
            stagePool = null;
            run = run.withNote("Сетевые потоки заняты отменяемыми запросами. "
                    + "Подожди освобождения соединений и нажми «Продолжить разбор».");
            persistRun();
            renderRun(true);
        }
    }

    private void disconnect(ModelClient.Cancellation cancellation) {
        try {
            cancellationWorker.execute(cancellation::cancel);
        } catch (RejectedExecutionException closed) {
            // Activity is closing. Cancellation is already signalled by future.cancel().
        }
    }

    private ModelClient.Reply verifyRouterFailure(ModelClient.Reply reply, ModelCatalog.Model model,
                                                 String key, Attempt current, StagePool pool) {
        if (model.provider != Workflow.Provider.OPENROUTER
                || reply.failure.reason != RequestFailure.Reason.UNKNOWN) return reply;
        try {
            if (reply.status == 429 && !pool.quotaChecked) {
                pool.quotaChecked = true;
                if (client.routerDailyQuotaExhausted(key, current.cancellation)) {
                    return ModelClient.Reply.error(reply.text,
                            "По данным OpenRouter, дневная квота моделей :free исчерпана.",
                            reply.failure.dailyQuota(System.currentTimeMillis()));
                }
            }
            if (reply.status == 404 && !pool.catalogChecked) {
                pool.catalogChecked = true;
                ModelCatalog updated = client.models(current.cancellation);
                if (updated.routerCount() > 0 && !updated.available(model)) {
                    return ModelClient.Reply.error(reply.text, "Этой модели больше нет в бесплатном каталоге.",
                            reply.failure.unavailable());
                }
            }
        } catch (IOException | JSONException | ModelClient.Problem ignored) {
            // Keep the actual provider error when the diagnostic query fails.
        }
        return reply;
    }

    private void receive(Attempt current, ModelClient.Reply reply) {
        if (attempt != current || isDestroyed()) return;
        progressHandler.removeCallbacks(current.deadline);
        attempt = null;
        if (reply.finish == ModelClient.Finish.ERROR && reply.text.isEmpty() && !current.received.isEmpty()) {
            reply = ModelClient.Reply.error(current.received, reply.problem, reply.failure);
        }
        run = current.input.receive(reply);
        if (ModelPool.shouldTryNext(reply)) {
            ModelCatalog.Model attempted = current.input.nextStage().model;
            cooldowns.record(attempted, reply.failure, System.currentTimeMillis());
            stagePool.failures.add(attempted.label + " · " + attempted.provider.label + " · " + reply.status);
            int next = availableCandidate();
            recordAttempt(current, reply, next < 0 ? null : stagePool.models.get(next),
                    current.timedOut ? "TIMEOUT" : "");
            if (next >= 0) {
                requestNextModel(true);
                return;
            }
            pause(exhaustedNote(reply.problem));
            return;
        }
        recordAttempt(current, reply, null, current.timedOut ? "TIMEOUT" : "");
        if (!run.complete() && run.note.isEmpty()) {
            stagePool = modelsFor(run);
            if (!stagePool.models.isEmpty()) requestNextModel(true);
            else pause(keyMessage(run.nextStage()));
            return;
        }
        active = false;
        stagePool = null;
        persistRun();
        renderRun(true);
    }

    private int availableCandidate() {
        return cooldowns.next(stagePool.models, stagePool.next, System.currentTimeMillis());
    }

    private String exhaustedNote(String reason) {
        long retry = cooldowns.firstRetry(stagePool.models, System.currentTimeMillis());
        String message = "Сейчас нет доступного резерва.";
        if (retry > 0) {
            message += "\nБлижайшее время повторной попытки — "
                    + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(retry)) + ".";
        } else if (!stagePool.failures.isEmpty()) {
            message += "\nПровайдер не указал время следующей попытки.";
        }
        if (!stagePool.failures.isEmpty()) message += "\n" + String.join("\n", stagePool.failures);
        if (!reason.isEmpty()) message += "\n\n" + reason;
        return message;
    }

    private void recordAttempt(Attempt current, ModelClient.Reply reply, ModelCatalog.Model next, String outcome) {
        if (clearing) return;
        try {
            JSONArray previous = attemptHistory.isEmpty() ? new JSONArray() : new JSONArray(attemptHistory);
            JSONArray journal = new JSONArray();
            for (int i = Math.max(0, previous.length() - 39); i < previous.length(); i++) journal.put(previous.get(i));
            ModelCatalog.Model model = current.input.nextStage().model;
            JSONObject entry = new JSONObject().put("time", System.currentTimeMillis())
                    .put("step", current.input.nextIndex() + 1).put("provider", model.provider.label)
                    .put("model", model.id).put("ms", android.os.SystemClock.elapsedRealtime() - current.started)
                    .put("status", AttemptJournal.status(reply, outcome))
                    .put("has_text", !current.received.isEmpty() || (reply != null && !reply.text.isEmpty()));
            if (reply != null) {
                entry.put("code", reply.status).put("reason", reply.failure.reason.name());
                if (reply.failure.retryAt > 0) entry.put("retry_at", reply.failure.retryAt);
            }
            if (next != null) entry.put("next_model", next.id);
            journal.put(entry);
            attemptHistory = journal.toString();
        } catch (JSONException ignored) {
            // A malformed diagnostic entry must not stop generation.
        }
    }

    private void showAttemptHistory() {
        try {
            showText("Журнал запросов", AttemptJournal.normalizeAll(new JSONArray(attemptHistory)).toString(2));
        } catch (JSONException e) {
            toast("Не удалось прочитать журнал запросов.");
        }
    }

    private void pause(String message) {
        active = false;
        stagePool = null;
        run = run.withNote(message);
        persistRun();
        renderRun(true);
    }

    private void stopRun() {
        cancelRequest();
        pause("Разбор остановлен. Полученные шаги и сохранённый черновик доступны.");
    }

    private void cancelRequest() {
        Attempt current = attempt;
        attempt = null;
        stagePool = null;
        active = false;
        if (current == null) return;
        progressHandler.removeCallbacks(current.deadline);
        recordAttempt(current, null, null, "CANCELLED");
        String partial = current.received;
        if (!partial.isEmpty()) {
            run = current.input.receive(ModelClient.Reply.error(partial, "Ответ прерван."));
        }
        persistRun();
        if (current.future != null) current.future.cancel(true);
        disconnect(current.cancellation);
    }

    private void editStage(int index) {
        Workflow.Stage current = stages.get(index);
        LinearLayout form = dialogForm();
        form.addView(text("Название роли", 14, MUTED, true));
        EditText title = field(current.role, "", 42, 1, false);
        add(form, title, 6);
        add(form, text("Что должен сделать ИИ", 14, MUTED, true), 14);
        EditText instructions = field(current.instruction, "", 1600, 3, false);
        add(form, instructions, 6);
        add(form, text("Модель", 14, MUTED, true), 14);
        ModelCatalog.Model[] selection = {current.model};
        Button choose = button(current.model.label + "  ▾", false, null);
        choose.setOnClickListener(view -> chooseModel(selection[0], model -> {
            selection[0] = model;
            choose.setText(model.label + "  ▾");
        }));
        add(form, choose, 6);
        AlertDialog dialog = dialog("Шаг " + (index + 1), form);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String role = title.getText().toString().trim();
            String instruction = instructions.getText().toString().trim();
            if (role.isEmpty()) {
                title.setError("Назови роль.");
                return;
            }
            if (instruction.isEmpty()) {
                instructions.setError("Добавь задание для этой роли.");
                return;
            }
            List<Workflow.Stage> updated = new ArrayList<>(stages);
            updated.set(index, new Workflow.Stage(role, instruction, selection[0]));
            try {
                data.edit().putString("stages", Workflow.stagesToJson(updated).toString()).apply();
                stages = updated;
                dialog.dismiss();
                renderTask();
            } catch (JSONException e) {
                toast("Не удалось сохранить роль.");
            }
        });
    }

    private void chooseModel(ModelCatalog.Model selected, Consumer<ModelCatalog.Model> onChoice) {
        List<ModelCatalog.Model> choices = catalog.choices();
        String[] labels = new String[choices.size()];
        int checked = -1;
        for (int i = 0; i < choices.size(); i++) {
            ModelCatalog.Model model = choices.get(i);
            labels[i] = model.label + " · " + model.provider.label;
            if (model.id.equals(selected.id)) checked = i;
        }
        AlertDialog picker = new AlertDialog.Builder(this).setTitle("Выбрать модель")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    dialog.dismiss();
                    onChoice.accept(choices.get(which));
                })
                .setNegativeButton("Отмена", null).setNeutralButton("Обновить", null).show();
        Button refresh = picker.getButton(AlertDialog.BUTTON_NEUTRAL);
        refresh.setOnClickListener(view -> {
            refresh.setEnabled(false);
            refresh.setText("Обновление…");
            refreshModels(true, problem -> {
                if (!picker.isShowing()) return;
                if (problem.isEmpty()) {
                    picker.dismiss();
                    chooseModel(selected, onChoice);
                } else {
                    refresh.setEnabled(true);
                    refresh.setText("Обновить");
                    toast(problem);
                }
            });
        });
    }

    private void showKeys(String message) {
        LinearLayout form = dialogForm();
        if (!message.isEmpty()) add(form, text(message, 14, WARNING, false), 0);
        add(form, text("Команде по умолчанию нужен один ключ OpenRouter.", 15, FG, false),
                message.isEmpty() ? 0 : 10);
        add(form, text("OpenRouter", 14, MUTED, true), 14);
        EditText router = field(readForEdit(Workflow.Provider.OPENROUTER),
                "Вставь ключ OpenRouter", 512, 1, true);
        add(form, router, 5);
        add(form, button("Получить ключ OpenRouter", false,
                view -> openLink("https://openrouter.ai/settings/keys")), 6);
        TextView catalogStatus = text(catalogLabel(), 13, MUTED, false);
        add(form, catalogStatus, 11);
        Button refresh = button("Обновить бесплатные модели", false, null);
        refresh.setOnClickListener(view -> {
            refresh.setEnabled(false);
            catalogStatus.setText("Обновляю список OpenRouter…");
            refreshModels(true, problem -> {
                refresh.setEnabled(true);
                catalogStatus.setText(problem.isEmpty() ? catalogLabel() : problem);
            });
        });
        add(form, refresh, 5);
        add(form, text("Groq · Free Plan", 14, MUTED, true), 14);
        EditText groq = field(readForEdit(Workflow.Provider.GROQ),
                "Вставь ключ Groq", 512, 1, true);
        add(form, groq, 5);
        add(form, button("Получить ключ Groq", false,
                view -> openLink("https://console.groq.com/keys")), 6);
        CheckBox groqReserve = new CheckBox(this);
        groqReserve.setText("Использовать Groq Free в резерве");
        groqReserve.setChecked(data.getBoolean(GROQ_RESERVE, false));
        add(form, groqReserve, 5);
        add(form, text("Google Gemini · по желанию", 14, MUTED, true), 14);
        EditText gemini = field(readForEdit(Workflow.Provider.GEMINI),
                "Вставь ключ Gemini", 512, 1, true);
        add(form, gemini, 5);
        add(form, button("Получить ключ Gemini", false,
                view -> openLink("https://aistudio.google.com/api-keys")), 6);
        add(form, text("Для бесплатной работы Gemini нужен проект Google на Free Tier.",
                13, MUTED, false), 8);
        add(form, text("Песочница Piston · по желанию", 14, MUTED, true), 14);
        EditText piston = field(readPistonForEdit(), "Токен Piston", 512, 1, true);
        add(form, piston, 5);
        add(form, text("Для запуска Python на телефоне токен не нужен.", 13, MUTED, false), 6);
        add(form, text("Очисти поле, чтобы удалить сохранённый ключ.", 13, MUTED, false), 10);
        AlertDialog dialog = dialog("Подключение моделей", form);
        refreshModels(false, problem -> {
            if (dialog.isShowing()) catalogStatus.setText(problem.isEmpty() ? catalogLabel() : problem);
        });
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String routerValue = router.getText().toString().trim();
            String geminiValue = gemini.getText().toString().trim();
            String groqValue = groq.getText().toString().trim();
            String pistonValue = piston.getText().toString().trim();
            if (!validKey(routerValue)) {
                router.setError("Вставь ключ целиком, без пробелов.");
                return;
            }
            if (!validKey(geminiValue)) {
                gemini.setError("Вставь ключ целиком, без пробелов.");
                return;
            }
            if (!validKey(groqValue)) {
                groq.setError("Вставь ключ целиком, без пробелов.");
                return;
            }
            if (!validKey(pistonValue)) {
                piston.setError("Вставь токен целиком, без пробелов.");
                return;
            }
            try {
                vault.save(routerValue, geminiValue, groqValue, pistonValue);
                data.edit().putBoolean(GROQ_RESERVE, groqReserve.isChecked() && !groqValue.isEmpty()).apply();
                dialog.dismiss();
                toast("Настройки сохранены");
            } catch (GeneralSecurityException | IOException e) {
                toast("Не удалось сохранить ключи на телефоне.");
            }
        });
    }

    private void confirmClearWorkspace() {
        if (clearing) return;
        new AlertDialog.Builder(this).setTitle("Новая задача?")
                .setMessage("Текущий разбор, черновик и журнал будут удалены. "
                        + "Ключи, выбранные модели и настройки ролей останутся.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Продолжить", (dialog, which) -> {
                    AlertDialog confirm = new AlertDialog.Builder(this)
                            .setTitle("Подтверди удаление")
                            .setMessage("Точно удалить текущую задачу, черновики и историю? Отменить удаление нельзя.")
                            .setNegativeButton("Отмена", null)
                            .setPositiveButton("Удалить", (second, button) -> clearWorkspace()).show();
                    confirm.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(DANGER);
                }).show();
    }

    private void clearWorkspace() {
        if (clearing) return;
        clearing = true;
        cancelRequest();
        cancelSandbox();
        progressHandler.removeCallbacks(saveDraft);
        progressHandler.removeCallbacks(checkpoint);
        checkpointPending = false;
        AlertDialog progress = new AlertDialog.Builder(this).setMessage("Очистка…")
                .setCancelable(false).show();
        store.clear(storeSession, saved -> runOnUiThread(() -> {
            if (isDestroyed()) return;
            if (saved) {
                run = null;
                taskDraft = "";
                attemptHistory = "";
                resultsVisible = false;
            }
            clearing = false;
            progress.dismiss();
            if (saved) renderTask();
            else if (run != null && resultsVisible) renderRun(false);
            else renderTask();
            toast(saved ? "Новая задача готова. Ключи и роли сохранены."
                    : "Очистка не удалась. Данные сохранены, попробуй снова.");
        }));
    }

    private String catalogLabel() {
        return catalog.refreshed ? "Бесплатных моделей OpenRouter: " + catalog.routerCount()
                : "Встроенный список бесплатных моделей OpenRouter";
    }

    private String readForEdit(Workflow.Provider provider) {
        try {
            return vault.read(provider);
        } catch (GeneralSecurityException | IOException e) {
            return "";
        }
    }

    private String readPistonForEdit() {
        try {
            return vault.readPiston();
        } catch (GeneralSecurityException | IOException e) {
            return "";
        }
    }

    private boolean validKey(String s) {
        return s.isEmpty() || s.length() >= 8 && s.matches("[\\x21-\\x7e]+");
    }

    private void openLink(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (android.content.ActivityNotFoundException e) {
            toast("На устройстве нет приложения для открытия ссылки.");
        }
    }

    private void chooseExport() {
        Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                .putExtra(Intent.EXTRA_TITLE, "svyazka-razbor.json");
        try {
            startActivityForResult(create, EXPORT_REQUEST);
        } catch (android.content.ActivityNotFoundException e) {
            toast("Не удалось открыть окно сохранения.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (requestCode != EXPORT_REQUEST || resultCode != RESULT_OK
                || result == null || result.getData() == null || run == null) return;
        try (OutputStream output = getContentResolver().openOutputStream(result.getData(), "w")) {
            if (output == null) throw new IOException("Output missing");
            output.write(run.toJson().toString(2).getBytes(StandardCharsets.UTF_8));
            toast("Разбор сохранён");
        } catch (IOException | JSONException e) {
            toast("Не удалось сохранить файл.");
        }
    }

    @Override public void onBackPressed() {
        if (clearing) return;
        if (!resultsVisible) {
            super.onBackPressed();
        } else if (active) {
            new AlertDialog.Builder(this).setMessage("Остановить текущий разбор?")
                    .setNegativeButton("Продолжить", null)
                    .setPositiveButton("Остановить", (dialog, which) -> stopRun()).show();
        } else {
            renderTask();
        }
    }

    @Override protected void onStop() {
        persistRun();
        super.onStop();
    }

    @Override protected void onDestroy() {
        cancelRequest();
        cancelSandbox();
        sandboxWorker.shutdownNow();
        worker.shutdownNow();
        if (catalogRequest != null) {
            ModelClient.Cancellation stop = catalogRequest;
            disconnect(stop);
        }
        catalogWorker.shutdownNow();
        cancellationWorker.shutdown();
        catalogListeners.clear();
        super.onDestroy();
    }

    private AlertDialog dialog(String title, LinearLayout form) {
        ScrollView area = dialogArea(form);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title).setView(area).setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", null).create();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.show();
        area.requestFocus();
        return dialog;
    }

    private ScrollView dialogArea(LinearLayout form) {
        ScrollView area = new ScrollView(this);
        area.addView(form);
        area.setFocusableInTouchMode(true);
        return area;
    }

    private LinearLayout dialogForm() {
        LinearLayout panel = column();
        panel.setPadding(dp(20), dp(12), dp(20), dp(6));
        return panel;
    }

    private EditText field(String value, String hint, int limit, int lines, boolean protectedText) {
        EditText field = new EditText(this);
        field.setTextColor(FG);
        field.setHintTextColor(MUTED);
        field.setTextSize(16);
        field.setHint(hint);
        field.setPadding(dp(13), dp(11), dp(13), dp(11));
        field.setBackground(shape(SURFACE, BORDER, 13));
        field.setInputType(InputType.TYPE_CLASS_TEXT | (protectedText
                ? InputType.TYPE_TEXT_VARIATION_PASSWORD
                : lines > 1 ? InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES : 0));
        if (limit > 0) field.setFilters(new InputFilter[] { new InputFilter.LengthFilter(limit) });
        if (lines > 1) {
            field.setMinLines(lines);
            field.setMaxLines(lines + 2);
            field.setGravity(Gravity.TOP | Gravity.START);
        } else {
            field.setSingleLine(true);
            if (protectedText) field.setInputType(InputType.TYPE_CLASS_TEXT
                    | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        field.setText(value);
        return field;
    }

    private TextView badge(int number) {
        TextView view = text(String.valueOf(number), 15, ACCENT, true);
        view.setGravity(Gravity.CENTER);
        view.setBackground(shape(ACCENT_DARK, Color.TRANSPARENT, 10));
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(34)));
        return view;
    }

    private TextView selectable(String value, int size, int color) {
        TextView view = text(value, size, color, false);
        view.setTextIsSelectable(true);
        return view;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return view;
    }

    private Button button(String title, boolean primary, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(primary ? 16 : 14);
        b.setTextColor(primary ? ACCENT_INK : FG);
        b.setAllCaps(false);
        b.setLetterSpacing(0f);
        b.setMinWidth(0);
        b.setMinHeight(dp(primary ? 52 : 44));
        b.setMinimumWidth(0);
        b.setMinimumHeight(dp(primary ? 52 : 44));
        b.setPadding(dp(13), dp(6), dp(13), dp(6));
        b.setStateListAnimator(null);
        b.setBackground(ripple(primary ? ACCENT : SURFACE,
                primary ? Color.TRANSPARENT : BORDER, 12));
        b.setBackgroundTintList(null);
        b.setOnClickListener(action);
        return b;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private void add(LinearLayout layout, View child, int top) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(top);
        layout.addView(child, params);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, -2, 1f);
    }

    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }

    private RippleDrawable ripple(int fill, int stroke, int radius) {
        return new RippleDrawable(ColorStateList.valueOf(0x2f8ce5dc),
                shape(fill, stroke, radius), shape(Color.WHITE, Color.TRANSPARENT, radius));
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
