package app.svyazka.mobile;

import java.util.Locale;

/**
 * Conservative, deterministic routing for omitting web-widget advice in a
 * CLEARLY prose-only request. Never edits the task, source code or history.
 * Ambiguous requests retain the original complete system instructions.
 */
final class PlainTextPromptPolicy {
    private PlainTextPromptPolicy() { }

    static boolean unambiguousProse(String userRequirements) {
        if (userRequirements == null || userRequirements.trim().isEmpty()
                || userRequirements.length() > 12000) return false;
        String text = userRequirements.trim().toLowerCase(Locale.ROOT)
                .replaceAll("\\s+", " ");
        if (text.contains("```") || text.contains("~~~")
                || text.contains("<previous_") || text.contains("<linked_python_project>"))
            return false;
        // Fail closed if an implementation or interface might be requested.
        if (text.matches("(?s).*(?:виджет|widget|сайт|приложен|интерфейс|"
                + "программ|скрипт|исходник|код|макет|верстк|консол|терминал|"
                + "\\b(?:html|css|javascript|typescript|python|kotlin|java|flutter|react|"
                + "vue|swift|sql|api|apk|ui|gui|webview|xml|js|console|terminal|"
                + "app|application|website|webpage|frontend|dashboard)\\b|"
                + "ウェブ|アプリ|コード|画面|应用|界面|代码|程序|"
                + "تطبيق|واجهة|كود|برمج).*")) return false;
        if (text.matches("(?s)^(?:привет|здравствуй|здравствуйте|спасибо|"
                + "hello|hi|thanks|你好|こんにちは|مرحبا)"
                + "(?:[!.?。！؟ ]*как дела)?[!.?。！؟ ]*$")) return true;
        if (text.matches("(?s)^(?:объясни|объясните|расскажи|расскажите|"
                + "опиши|опишите|поясни|поясните|что такое|почему|зачем|"
                + "как работает|explain|describe|summarize|what is|why)[\\s,，:：]+.+")) return true;
        if (text.matches("(?s)^(?:请解释|解释|说明|説明して|なぜ|اشرح|فسر).+")) return true;
        // Intent is unmistakably a prose deliverable, not a request to build software.
        return text.matches("(?s)^(?:напиши|составь|подготовь|дай|write|"
                + "make|list|列出|列举|اذكر)\\s+.{0,90}?"
                + "(?:список|перечень|текст|статью|эссе|руководство|советы|"
                + "обзор|стихотворение|рассказ|письмо|list|article|essay|tips|"
                + "guide|清单|列表|قائمة).*");
    }
}
