package app.svyazka.mobile;

import java.io.IOException;
import java.security.GeneralSecurityException;

/** Platform boundary for encrypted provider credentials. Never expose it to sandbox code. */
interface CredentialStore {
    String read(Workflow.Provider provider) throws GeneralSecurityException, IOException;
    String readPiston() throws GeneralSecurityException, IOException;
    void save(String routerKey, String geminiKey, String groqKey, String pistonKey)
            throws GeneralSecurityException, IOException;
}
