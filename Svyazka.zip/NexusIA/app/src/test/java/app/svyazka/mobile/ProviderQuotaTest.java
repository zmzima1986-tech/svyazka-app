package app.svyazka.mobile;

import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.json.JSONObject;
import org.junit.Test;

/** Offline coverage for values reported by the provider; never derive a made-up balance. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 33)
public class ProviderQuotaTest {
    @Test public void groqRateLimitsHaveSeparateWindows() {
        ProviderQuota quota = ProviderQuota.groq("1500", "42");
        assertEquals(1500, quota.tokensPerMinute);
        assertEquals(42, quota.requestsPerDay);
        assertTrue(quota.available());
    }

    @Test public void zeroIsExhaustedAndMissingIsUnknown() {
        ProviderQuota quota = ProviderQuota.groq("0", null);
        assertEquals(0, quota.tokensPerMinute);
        assertEquals(ProviderQuota.UNKNOWN, quota.requestsPerDay);
        assertEquals(ProviderQuota.UNKNOWN, ProviderQuota.nonNegative("?"));
        assertEquals(ProviderQuota.UNKNOWN, ProviderQuota.nonNegative("-1"));
        assertEquals(ProviderQuota.UNKNOWN, ProviderQuota.nonNegative("9999999999999999999999999"));
    }

    @Test public void absentHeadersCannotCreateFakeLimits() {
        assertFalse(ProviderQuota.groq(null, null).available());
    }

    @Test public void openRouterFreeRequestsAreNotTokenBalance() throws Exception {
        JSONObject response = new JSONObject().put("data", new JSONObject()
                .put("free_model_daily_requests", new JSONObject()
                        .put("remaining", 7).put("limit", 50)));
        ProviderQuota quota = ProviderQuota.openRouter(response);
        assertEquals(7, quota.requestsPerDay);
        assertEquals(50, quota.dailyLimit);
        assertEquals(ProviderQuota.UNKNOWN, quota.tokensPerMinute);
    }

    @Test public void openRouterMissingFreeQuotaIsUnknown() throws Exception {
        ProviderQuota quota = ProviderQuota.openRouter(new JSONObject().put("data", new JSONObject()));
        assertEquals(ProviderQuota.UNKNOWN, quota.requestsPerDay);
        assertEquals(ProviderQuota.UNKNOWN, quota.dailyLimit);
    }
}
