"""Run the same verifier asset as the APK on controlled fixtures."""

import importlib.util
import json
import unittest
from pathlib import Path

source = Path(__file__).resolve().parents[1] / "app/src/main/assets/sandbox/verify.py"
spec = importlib.util.spec_from_file_location("nexus_verify", source)
grader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grader)


class VerificationTests(unittest.TestCase):
    def verify(self, code, status, **inputs):
        if "cases" in inputs:
            inputs["specs"] = [json.dumps(inputs.pop("cases"))]
        result = json.loads(grader.verify_request(json.dumps(dict(code=code, **inputs))))
        self.assertEqual(status, result["status"], result)
        if status == "PASSED":
            self.assertTrue(
                result["ran"] and result["syntax"] and result["total"] == result["passed"] > 0
            )
        return result

    def test_repair_cannot_pass_with_previous_task_output(self):
        cases = [{"stdin": "", "stdout": "5.0"}]
        self.verify("print(250)", "ERROR", cases=cases)
        self.verify("a = 10\nb = 2\nprint(a / b)", "PASSED", cases=cases)
        result = self.verify("print(250)", "RAN")
        self.assertEqual(0, result["total"])

    def test_environment_before_unsupported_stdlib(self):
        result = self.verify("import sys, tkinter, requests, bleak", "LIMITED")
        self.assertEqual(result["category"], "ENVIRONMENT_UNSUPPORTED")
        self.assertTrue(result["syntax"] and not result["ran"])
        for detail in ("tkinter", "requests", "bleak"):
            self.assertIn(detail, result["diagnostic"])
        self.assertEqual(self.verify("import requests", "LIMITED")["category"], "REQUIRES_EXTERNAL_SERVICE")
        self.assertEqual(self.verify("import nonexisting_package", "LIMITED")["category"], "DEPENDENCY_UNAVAILABLE")
        self.assertTrue(grader.manual_limit("import tkinter"))
        self.assertFalse(grader.manual_limit("print(4)"))

    def test_observed_isolation_request_stays_blocked_without_weather_claim(self):
        code = (Path(__file__).parent / "fixtures/security/observed-isolation-request-r23.py").read_text()
        result = self.verify(code, "LIMITED")
        self.assertEqual(result["category"], "REQUIRES_EXTERNAL_SERVICE")
        self.assertTrue(result["syntax"])
        self.assertFalse(result["ran"])
        self.assertFalse(result["workspace_eligible"])
        self.assertIn("socket", result["diagnostic"])
        self.assertNotIn("погод", result["diagnostic"])
        self.assertEqual(grader.manual_limit(code), result["diagnostic"])

    def test_clock_calendar_and_syntax(self):
        self.verify("import calendar\nfrom datetime import datetime\nprint(datetime.now().hour, calendar.monthrange(2024, 2))", "RAN")
        bad = self.verify("def log_bt(self    def log_bt(self, msg):\n    print(msg)", "ERROR")
        self.assertEqual(bad["category"], "SYNTAX_ERROR")
        self.assertIn("1", bad["diagnostic"])

    def test_repair_keeps_features_and_reports_unverified_ble(self):
        original = "import bleak, calendar\ndef log_bt(self    def log_bt(self, msg): pass"
        lost = self.verify("import calendar\nprint(calendar.month(2024, 2))", "LIMITED", previous_code=original)
        self.assertEqual(lost["category"], "REQUIREMENTS_CHANGED")
        kept = self.verify("import calendar, bleak\ndef log_bt(self, msg): print(msg)", "LIMITED", previous_code=original)
        self.assertEqual(kept["category"], "ENVIRONMENT_UNSUPPORTED")

    def test_porting_report_uses_indicators_not_claims_of_execution(self):
        previous = "function updateClock(){}; function renderCalendar(){}; navigator.bluetooth.requestDevice(); fetchWeather()"
        result = self.verify("import calendar\nfrom datetime import datetime\nprint(datetime.now().strftime('%H:%M'))",
                             "LIMITED", previous_web=previous)
        self.assertEqual(result["feature_review"]["календарь"], "source_indicator")
        self.assertEqual(result["feature_review"]["часы"], "source_indicator")
        self.assertEqual(result["feature_review"]["Bluetooth"], "not_identified")
        self.assertFalse(result["ran"])

    def test_android_api_is_checked_before_environment(self):
        sample = (Path(__file__).parent / "fixtures/recovery/android-callbacks.py").read_text()
        issue = self.verify(sample, "ERROR")
        self.assertEqual("ANDROID_API_CONTRACT", issue["category"])
        self.assertTrue(issue["syntax"])
        self.assertFalse(issue["ran"])
        for label in ("BluetoothGattCallback", "ScanCallback", "_on_perms_result", "Строка"):
            self.assertIn(label, issue["diagnostic"])
        good = sample.replace("android/bluetooth/le/ScanCallback","org/example/ScanListener").replace(
            "android/bluetooth/BluetoothGattCallback","org/example/GattListener").replace("self, granted","self, permissions, granted")
        self.assertNotEqual("ANDROID_API_CONTRACT", self.verify(good,"LIMITED")["category"])
        self.assertEqual([], grader.android_contract_issues(grader.ast.parse("class Example:\n    __javainterfaces__=['android/bluetooth/le/ScanCallback']")))

    def test_runtime_permissions_and_declaration_are_independent(self):
        xml = '<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.BLUETOOTH_SCAN"/></manifest>'
        code = "from android.permissions import request_permissions\nrequest_permissions([])"
        r=self.verify(code,"LIMITED",android_config={"src/main/AndroidManifest.xml":xml})
        e=r["android_permissions"]
        self.assertEqual(e["declarations"]["src/main/AndroidManifest.xml"],["android.permission.BLUETOOTH_SCAN"])
        self.assertEqual(e["device_grant"],"unverified")
        self.assertEqual(e["runtime_request"],"call_observed")
        self.assertEqual(self.verify(code,"LIMITED")["android_permissions"]["declarations"],{})
        spec="[app]\nandroid.permissions = BLUETOOTH_SCAN,BLUETOOTH_CONNECT"
        r=self.verify("import jnius","LIMITED",android_config={"buildozer.spec":spec})
        self.assertEqual(r["android_permissions"]["runtime_request"],"not_identified")
        self.assertIn("BLUETOOTH_CONNECT",r["android_permissions"]["declarations"]["buildozer.spec"])

    def test_single_unittest_handoff_preserves_oracles_and_permissions(self):
        sample = (Path(__file__).parent / "fixtures/recovery/observed-single-password.py").read_text()
        result = self.verify(sample, "LIMITED")
        self.assertTrue(result["syntax"] and result["workspace_eligible"] and not result["ran"])
        for inputs in ({"cases": [{"function": "generate_password", "args": [8, 8], "expected": "fixed"}]},
                       {"files": {"private.txt": "data"}}, {"previous_code": sample}):
            self.assertFalse(self.verify(sample, "LIMITED", **inputs)["workspace_eligible"])
        self.assertFalse(self.verify(sample + "\nimport socket\n", "LIMITED")["workspace_eligible"])
        self.assertFalse(self.verify(sample + "\nimport unknown_package\n", "LIMITED")["workspace_eligible"])
        self.verify("import string, secrets\nassert len(string.ascii_letters)==52\nassert 0 <= secrets.randbelow(8) < 8", "RAN")
        self.assertFalse(self.verify("import os\nprint(os.getcwd())", "LIMITED")["workspace_eligible"])

    def test_no_oracle(self):
        self.verify("print('PASSED')", "RAN")
        self.verify("def f(x): return -999", "RAN")

    def test_parser_and_compiler(self):
        for code in ["def f(:", "return 1"]:
            self.assertFalse(self.verify(code, "ERROR")["syntax"])

    def test_dependencies_and_environment(self):
        for mod in ["neo4j", "fastapi", "numpy", "os", "js", "socket"]:
            self.assertIn(mod, self.verify("import " + mod, "LIMITED")["diagnostic"])

    def test_missing_input(self):
        self.verify("print(input())", "LIMITED")

    def test_stdio_boundaries(self):
        self.verify(
            "print(int(input())**2)",
            "PASSED",
            cases=[dict(stdin="0\n", stdout="0"), dict(stdin="-2\n", stdout="4\n")],
        )

    def test_printing_success_does_not_certify(self):
        self.verify("print('PASSED')", "ERROR", cases=[dict(stdin="", stdout="4")])

    def test_case_isolation(self):
        self.verify(
            "a=[]\ndef f(x):\n a.append(x)\n return len(a)",
            "PASSED",
            examples="assert f(0) == 1\nassert f(1) == 1",
        )

    def test_contract(self):
        code = "def factorial(n):\n total=1\n for i in range(1,n+1): total*=i\n return total"
        self.assertEqual(5, self.verify(code, "PASSED", examples="nexus-contract: factorial")["total"])
        self.verify(code.replace("total=1", "total=0"), "ERROR", examples="nexus-contract: factorial")
        self.verify("from math import gcd", "PASSED", examples="nexus-contract: gcd")

    def test_wrong_value_includes_real_input(self):
        r = self.verify("def f(x): return x", "ERROR", examples="assert f(1) == 1\nassert f(0) == 2")
        self.assertEqual((1, 2), (r["passed"], r["total"]))
        self.assertIn("Тест 2", r["diagnostic"])
        self.assertIn("получено 0", r["diagnostic"])

    def test_boolean_is_not_number(self):
        self.verify("def f(): return False", "ERROR", cases=[dict(function="f", args=[], expected=0)])
        self.verify("def f(): return [True]", "ERROR", cases=[dict(function="f", args=[], expected=[1])])

    def test_actual_arguments_remain_available(self):
        r = self.verify(
            "def f(vals):\n vals.clear()\n return 0",
            "ERROR",
            cases=[dict(function="f", args=[[1, 2]], expected=3)],
        )
        self.assertIn("[1, 2]", r["diagnostic"])

    def test_imported_module_with_cli(self):
        self.verify(
            "def f(x): return x\nif __name__ == '__main__': print(input())",
            "PASSED",
            examples=">>> f(3)\n3",
        )

    def test_text_attachment(self):
        self.verify(
            "import json\nwith open('data.json') as f:\n print(sum(json.loads(f.read())))",
            "PASSED",
            files={"data.json": "[1,-1]"},
            cases=[dict(stdin="", stdout="0")],
        )
        self.verify("open('data.json','w')", "LIMITED", files={"data.json": "original"})

    def test_runtime_error(self):
        self.assertIn("ZeroDivisionError", self.verify("x=1/0", "ERROR")["diagnostic"])

    def test_placeholders(self):
        for code in ["# comments", "def f():\n pass", "def f():\n ..."]:
            self.assertIn("Incomplete", self.verify(code, "ERROR")["diagnostic"])

    def test_limits(self):
        self.verify("print('x'*20000)", "LIMITED")
        self.verify("x=1\n" * 17000, "LIMITED")
        self.verify("print(0)", "LIMITED", cases=[dict(stdin="", stdout="0")] * 25)

    def test_invalid_test_fixture(self):
        for item in ["{broken", "[]", '[{"bad":true}]']:
            self.verify("print(0)", "LIMITED", specs=[item])
        self.verify("print(0)", "LIMITED", examples="assert f(x) == 0")

    def test_plain_io(self):
        self.verify(
            "print(abs(int(input())))", "PASSED", examples="Input: -3\nOutput: 3\nВвод: 0\nВывод: 0"
        )

    def test_ambiguous_modules(self):
        self.assertTrue(
            self.verify("", "LIMITED", syntax_only=["while True: pass", "x=2"], reason="ambiguous")[
                "syntax"
            ]
        )
        r = self.verify("", "LIMITED", syntax_only=["x=1", "x="], reason="ambiguous")
        self.assertFalse(r["syntax"])
        self.assertIn("Блок 2", r["diagnostic"])

    def test_observed_calculator_repair(self):
        fixture = Path(__file__).parent / "fixtures/recovery/observed-calculator.py"
        result = self.verify(fixture.read_text(), "RAN")
        self.assertIn("assert без ошибок: 10", result["diagnostic"])
        self.assertEqual(0, result["total"])

    def test_observed_calculator_is_integer(self):
        fixture = Path(__file__).parent / "fixtures/recovery/observed-calculator-is-integer.py"
        code = fixture.read_text(encoding="utf-8")
        result = self.verify(code, "RAN")
        self.assertTrue(result["ran"])
        self.assertIn("assert без ошибок: 10", result["diagnostic"])
        self.assertEqual((0, 0), (result["passed"], result["total"]))
        self.verify("print((2.0).is_integer(), (2.5).is_integer())", "PASSED",
                    cases=[dict(stdin="", stdout="True False")])
        self.verify(code, "PASSED", cases=[dict(
            stdin="2 + 3\n5 / 2\n1 / 0\n",
            stdout=("✅ Все автоматические тесты пройдены успешно.\n"
                    "Простой калькулятор. Введите выражение в виде: <число> <оператор> <число>\n"
                    "Поддерживаемые операторы: + - * /\n"
                    "Для выхода нажмите Ctrl+D (EOF).\n"
                    "> = 5\n> = 2.5\n> Ошибка: Деление на ноль недопустимо\n> \nЗавершение работы."))])
        self.verify("print((2.0).__class__)", "LIMITED")

    def test_typing_and_interactive_eof_repair(self):
        code = """from typing import Union
Number = Union[int, float]
def add(a: Number, b: Number) -> float:
    return float(a + b)
assert add(2, 3) == 5
try:
    input('Value: ')
except EOFError:
    print('No input')
"""
        result = self.verify(code, "RAN")
        self.assertEqual(result["total"], 0)
        self.assertIn("assert без ошибок: 1", result["diagnostic"])
        self.verify(code.replace("== 5", "== 6"), "ERROR")
        self.verify("from typing import get_type_hints", "LIMITED")
        skipped = self.verify("if False:\n    assert True", "RAN")
        self.assertNotIn("assert без ошибок", skipped["diagnostic"])

    def test_observed_console_transcript_source(self):
        fixture = Path(__file__).parent / "fixtures/recovery/observed-console-transcript.md"
        code = fixture.read_text(encoding="utf-8").split("```python\n", 1)[1].split("\n```", 1)[0] + "\n"
        result = self.verify(code, "RAN")
        self.assertIn("assert без ошибок: 6", result["diagnostic"])
        self.assertEqual((0, 0), (result["passed"], result["total"]))
        self.verify(code, "PASSED", cases=[
            dict(function="calculate", args=[7, 8, "*"], expected=56),
            dict(function="calculate", args=[5, 2, "/"], expected=2.5),
            dict(function="calculate", args=[-3, 2, "-"], expected=-5),
        ])

    def test_broad_exception_does_not_hide_policy_limitation(self):
        self.verify("try:\n    raise ValueError('ordinary')\nexcept Exception:\n    print('caught')", "PASSED",
                    cases=[dict(stdin="", stdout="caught")])
        result = self.verify("try:\n    open('unattached.txt')\nexcept Exception:\n    pass\nprint('ok')", "LIMITED")
        self.assertFalse(result["ran"])
        self.verify("from __future__ import division\nprint(1)", "LIMITED")
        self.verify("import __future__\nprint(1)", "LIMITED")
        self.verify("from typing import get_type_hints\nprint(1)", "LIMITED")

    def test_model_self_test_insufficient(self):
        self.verify("assert True\nprint('all passed')", "RAN")


if __name__ == "__main__":
    unittest.main(verbosity=2)
