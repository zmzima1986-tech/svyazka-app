"""Build 20 source contracts: annotated screenshots and tools panel recording.

These checks validate structure, not actual Android rendering or frame-time.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/svyazka/mobile/ui'


def read(name):
    return (UI / name).read_text(encoding='utf-8')


class FinalInterfaceV20(unittest.TestCase):
    def test_mat_glass_plus_and_camera_still_accessible(self):
        s = read('NexusChat.kt')
        self.assertIn('modifier = Modifier.size(46.dp)', s)
        self.assertIn('modifier = Modifier.size(30.dp)', s)
        self.assertIn('shape = RoundedCornerShape(28.dp)', s)
        self.assertIn('shadowElevation = 9.dp', s)
        self.assertIn('stringResource(R.string.attachment_camera)', s)
        self.assertIn('attachAction()', s)
        attachments = read('NexusAttachments.kt')
        self.assertIn('AttachmentAction(Icons.Outlined.PhotoCamera', attachments)
        self.assertIn('camera.launch(FileProvider.getUriForFile', attachments)
        self.assertEqual(s.count('DropdownMenuItem('), 4)

    def test_no_second_run_status_caption_inside_expanded_result(self):
        s = read('NexusPythonWorkspace.kt')
        light = read('NexusLightDesign.kt')
        self.assertIn('Text(stringResource(if (success) R.string.ws_easy_run_ok', s)
        self.assertEqual(s.count('Text(stringResource(if (success) R.string.ws_easy_run_ok'), 1)
        self.assertNotIn('.uppercase(),', s)
        report_body = light.split('internal fun NexusLightPythonReport', 1)[1]
        self.assertNotIn('if (ok) app.svyazka.mobile.R.string.ws_easy_run_ok', report_body)
        self.assertIn('report.stdout', report_body)
        self.assertIn('onClick = onToggleArtifacts', report_body)

    def test_animation_no_full_screen_slide_on_nested_tools(self):
        s = read('NexusPythonWorkspace.kt')
        self.assertIn('enter = fadeIn(tween(170))', s)
        self.assertIn('exit = fadeOut(tween(170))', s)
        self.assertNotIn('slideInHorizontally(tween(260)) { if (rtl) -it else it }', s)
        self.assertIn('detectHorizontalDragGestures(', s)
        self.assertIn('BackHandler(enabled = toolPanel != null)', s)

    def test_workspace_opaque_backing_and_project_system_navigation_clearance(self):
        drawers = read('NexusDrawers.kt')
        self.assertIn('Color(0xFFF4F7FC) else Color(0xFF071425)', drawers)
        compose = read('NexusComposeUi.kt')
        self.assertIn('.navigationBarsPadding().padding(horizontal = 16.dp)', compose)
        self.assertIn('Crossfade(targetState = ui.theme, animationSpec = tween(durationMillis = 280)', compose)

    def test_semantic_theme_not_background_color_equality(self):
        self.assertIn('LocalNexusIsLight provides !dark', read('NexusTheme.kt'))
        self.assertIn('LocalNexusIsLight.current', read('NexusLightDesign.kt'))
        self.assertNotIn('MaterialTheme.colorScheme.background ==', read('NexusLightDesign.kt'))
        self.assertIn('if (!nexusLightMode())', read('NexusFrosted.kt'))

    def test_spec_no_deprecated_top_chat_buttons(self):
        spec = (ROOT / 'docs/NEXUS_AI_DESIGN_STANDARD.md').read_text(encoding='utf-8')
        self.assertIn('Две прежние верхние кнопки чата не возвращать', spec)
        self.assertNotIn('переключатель режимов, две кнопки', spec)


if __name__ == '__main__':
    unittest.main()
