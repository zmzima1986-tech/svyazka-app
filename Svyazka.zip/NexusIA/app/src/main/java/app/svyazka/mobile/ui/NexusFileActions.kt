package app.svyazka.mobile.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import app.svyazka.mobile.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class SavePayload(val filename: String, val text: String)

@Composable
fun rememberSaveResultAction(answer: String): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<SavePayload?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val payload = pending
        pending = null
        if (uri != null && payload != null) {
            scope.launch {
                val saved = withContext(Dispatchers.IO) {
                    runCatching {
                        val output = context.contentResolver.openOutputStream(uri, "w")
                            ?: throw IllegalStateException("Cannot open output")
                        output.bufferedWriter(Charsets.UTF_8).use { it.write(payload.text) }
                    }.isSuccess
                }
                Toast.makeText(context, if (saved) R.string.file_saved else R.string.file_save_error,
                    if (saved) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show()
            }
        }
    }
    return {
        if (answer.isNotBlank()) {
            val payload = chooseSavePayload(answer)
            pending = payload
            launcher.launch(payload.filename)
        }
    }
}

/** A single fenced code block is exported as code; a multi-file answer stays intact as Markdown. */
private fun chooseSavePayload(answer: String): SavePayload {
    val fence = Regex("(?m)^\\s*```([a-zA-Z0-9_+.-]*)[^\\n]*\\n([\\s\\S]*?)^\\s*```\\s*$")
    val matches = fence.findAll(answer).toList()
    if (matches.isEmpty()) return SavePayload("result.txt", answer)
    if (matches.size > 1) return SavePayload("result.md", answer)
    val language = matches[0].groupValues[1].lowercase()
    val code = matches[0].groupValues[2].trimEnd('\n', '\r')
    if (code.isBlank()) return SavePayload("result.md", answer)
    val filename = when (language) {
        "python", "py" -> "code.py"
        "javascript", "js" -> "code.js"
        "typescript", "ts" -> "code.ts"
        "html" -> "index.html"
        "css" -> "style.css"
        "kotlin", "kt" -> "Main.kt"
        "java" -> "Main.java"
        "json" -> "data.json"
        "bash", "sh" -> "script.sh"
        "sql" -> "query.sql"
        else -> "result.txt"
    }
    return SavePayload(filename, code + "\n")
}
