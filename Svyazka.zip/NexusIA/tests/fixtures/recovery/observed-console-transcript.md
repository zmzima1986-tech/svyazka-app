**Формат:** консольный Python‑скрипт `main.py` (один файл, готов к запуску).

```python
# file=main.py
# -*- coding: utf-8 -*-

"""
Простой консольный калькулятор.

Поддерживает четыре арифметических операции:
    +  – сложение
    -  – вычитание
    *  – умножение
    /  – деление (защита от деления на ноль)

При запуске сначала выполняются автоматические тесты (assert).
После успешного прохождения тестов начинается интерактивный режим.
EOF (Ctrl‑D / Ctrl‑Z) корректно завершает программу.
"""

from __future__ import annotations
from typing import Callable, Tuple


def add(a: float, b: float) -> float:
    return a + b


def sub(a: float, b: float) -> float:
    return a - b


def mul(a: float, b: float) -> float:
    return a * b


def div(a: float, b: float) -> float:
    """Деление с защитой от деления на ноль."""
    if b == 0:
        raise ZeroDivisionError("Деление на ноль запрещено")
    return a / b


# Словарь операторов → соответствующая функция
OPERATIONS: dict[str, Callable[[float, float], float]] = {
    '+': add,
    '-': sub,
    '*': mul,
    '/': div,
}


def calculate(a: float, b: float, op: str) -> float:
    """
    Выполняет вычисление a op b.
    :raises ValueError: неизвестный оператор
    :raises ZeroDivisionError: деление на ноль
    """
    if op not in OPERATIONS:
        raise ValueError(f"Неизвестный оператор: {op}")
    return OPERATIONS[op](a, b)


def _run_self_tests() -> None:
    """Набор простых тестов, запускаемых через assert."""
    # базовые операции
    assert calculate(2, 3, '+') == 5
    assert calculate(5, 2, '-') == 3
    assert calculate(4, 3, '*') == 12
    assert calculate(10, 2, '/') == 5

    # тесты с отрицательными и дробными числами
    assert calculate(-1, -1, '+') == -2
    assert calculate(2.5, 0.5, '*') == 1.25

    # проверка защиты от деления на ноль
    try:
        calculate(1, 0, '/')
    except ZeroDivisionError:
        pass
    else:
        assert False, "ZeroDivisionError должен быть возбужден"

    # проверка неизвестного оператора
    try:
        calculate(1, 1, '^')
    except ValueError:
        pass
    else:
        assert False, "ValueError должен быть возбужден для неизвестного оператора"

    # если дошли сюда – все тесты прошли
    print("✅ Все встроенные тесты пройдены.")


def _parse_input(line: str) -> Tuple[float, str, float]:
    """
    Принимает строку вида 'a op b' (пробелы необязательны) и возвращает кортеж.
    Примеры:
        "2+3"   -> (2.0, '+', 3.0)
        " 4 / 5 " -> (4.0, '/', 5.0)
    """
    line = line.strip()
    for op in OPERATIONS.keys():
        if op in line:
            left, right = line.split(op, 1)
            return float(left.strip()), op, float(right.strip())
    raise ValueError("Неверный формат ввода. Ожидается: <число> <оператор> <число>")


def repl() -> None:
    """Простой REPL‑цикл калькулятора."""
    print("\nКалькулятор готов. Введите выражение, например: 2 + 3")
    print("Для выхода нажмите Ctrl‑D (Unix) или Ctrl‑Z (Windows).\n")

    while True:
        try:
            line = input("> ")
        except EOFError:
            print("\nВыход.")
            break

        # игнорируем пустые строки
        if not line.strip():
            continue

        try:
            a, op, b = _parse_input(line)
            result = calculate(a, b, op)
        except ValueError as ve:
            print(f"Ошибка ввода: {ve}")
        except ZeroDivisionError as zde:
            print(f"Ошибка вычисления: {zde}")
        except Exception as e:  # защита от непредвиденных ошибок
            print(f"Неожиданная ошибка: {e}")
        else:
            print(f"Результат: {result}")


if __name__ == "__main__":
    # 1️⃣ Сначала запускаем автотесты
    _run_self_tests()

    # 2️⃣ Затем переходим в интерактивный режим
    repl()
```

### Как пользоваться
1. Сохраните файл как `main.py`.
2. Запустите командой `python main.py`.
3. Сначала увидите сообщение о пройденных тестах, затем откроется интерактивный ввод:
   ```
   > 7 * 8
   Результат: 56.0
   > 10 / 0
   Ошибка вычисления: Деление на ноль запрещено
   ```
4. Для завершения нажмите `Ctrl‑D` (Linux/macOS) или `Ctrl‑Z` + `Enter` (Windows).  

Все требования выполнены:
- четыре арифметических операции,
- защита от деления на ноль,
- автоматические тесты через `assert`,
- корректная обработка `EOFError`.