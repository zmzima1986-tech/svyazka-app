package app.svyazka.mobile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.List;
import java.util.Collections;
import java.util.function.Consumer;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class ModelClient {
    static final int MAX_EVENT_CHARS = 1_048_576;
    static final int MAX_ANSWER_CHARS = 2_097_152;
    private static final int MAX_STREAM_CHARS = 32 * 1_048_576;
    private static final int MAX_JSON_CHARS = 8 * 1_048_576;
    private static final class ResponseLimit extends IOException { }
    private static final String LIMIT_MESSAGE = "Provider response exceeds the size limit.";
    private static RequestFailure sizeFailure() {
        return new RequestFailure(0, RequestFailure.Reason.RESPONSE_LIMIT, 0);
    }

    static final int REQUEST_TIMEOUT_MS = 60_000;
    private static final String ROUTER_BASE = "https://openrouter.ai/api/v1/";
    private static final String GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
    private static final String GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/";
    private static final String CONTINUE_PROMPT = "Дополни оборванный ответ с места обрыва. "
            + "Верни только продолжение, сохрани пробелы и переносы для соединения частей. "
            + "Не повторяй начало, не открывай заново уже открытый блок кода.";
    private static final String NO_CONNECTION = "Связь с моделью прервалась. Можно продолжить с этого шага.";

    static final class Problem extends Exception {
        final int status;
        final RequestFailure failure;

        Problem(String message) { this(0, message); }

        Problem(int status, String message) {
            this(RequestFailure.of(status), message);
        }

        Problem(RequestFailure failure, String message) {
            super(message);
            this.failure = failure;
            this.status = failure.status;
        }
    }

    enum Finish { STOP, LENGTH, ERROR }

    static final class Reply {
        final String text;
        final Finish finish;
        final String problem;
        final int status;
        final RequestFailure failure;
        final ProviderQuota quota;

        Reply(String text, Finish finish, String problem) {
            this(text, finish, problem, RequestFailure.of(0));
        }

        private Reply(String text, Finish finish, String problem, RequestFailure failure) {
            this.text = text;
            this.finish = finish;
            this.problem = problem;
            this.status = failure.status;
            this.failure = failure;
            this.quota = null;
        }

        private Reply(String text, Finish finish, String problem, RequestFailure failure,
                      ProviderQuota quota) {
            this.text = text;
            this.finish = finish;
            this.problem = problem;
            this.status = failure.status;
            this.failure = failure;
            this.quota = quota;
        }

        Reply withQuota(ProviderQuota limits) {
            return new Reply(text, finish, problem, failure, limits);
        }

        static Reply error(String text, String problem) {
            return error(text, problem, 0);
        }

        static Reply error(String text, String problem, int status) {
            return error(text, problem, RequestFailure.of(status));
        }

        static Reply error(String text, String problem, RequestFailure failure) {
            return new Reply(text, Finish.ERROR, problem, failure);
        }

        static Reply rejected(String text, String problem) {
            return error(text, problem, new RequestFailure(0, RequestFailure.Reason.RESPONSE_REJECTED, 0));
        }
    }

    static final class Cancellation {
        private volatile boolean cancelled;
        private volatile HttpURLConnection connection;

        synchronized void attach(HttpURLConnection current) throws IOException {
            if (cancelled || Thread.currentThread().isInterrupted()) {
                current.disconnect();
                throw new IOException("Request cancelled");
            }
            connection = current;
        }

        synchronized void signal() { cancelled = true; }

        void cancel() {
            HttpURLConnection current;
            synchronized (this) {
                cancelled = true;
                current = connection;
            }
            if (current != null) current.disconnect();
        }

        synchronized void detach() { connection = null; }
    }

    private interface Decoder<T> {
        T read(BufferedReader source, String contentType) throws IOException, JSONException, Problem;
    }

    ModelCatalog models(Cancellation cancellation) throws IOException, JSONException, Problem {
        return request(ROUTER_BASE + "models", null, null, null, false, cancellation,
                (source, type) -> ModelCatalog.fromOpenRouter(readJson(source)));
    }

    boolean routerDailyQuotaExhausted(String key, Cancellation cancellation)
            throws IOException, JSONException, Problem {
        return request(ROUTER_BASE + "key", "Authorization", "Bearer " + key, null, false, cancellation,
                (source, type) -> routerDailyQuotaExhausted(readJson(source)));
    }

    ProviderQuota routerFreeQuota(String key, Cancellation cancellation)
            throws IOException, JSONException, Problem {
        return request(ROUTER_BASE + "key", "Authorization", "Bearer " + key,
                null, false, cancellation, (source, type) -> ProviderQuota.openRouter(readJson(source)));
    }

    static boolean routerDailyQuotaExhausted(JSONObject response) {
        JSONObject data = response.optJSONObject("data");
        JSONObject daily = data == null ? null : data.optJSONObject("free_model_daily_requests");
        return daily != null && daily.optInt("limit", 0) > 0 && daily.optInt("remaining", -1) == 0;
    }

    private volatile boolean noTrainingOnly = true;

    void setNoTrainingOnly(boolean enabled) { noTrainingOnly = enabled; }

    Reply complete(Workflow.Run run, ModelCatalog.Model model, String key,
                   Cancellation cancellation, Consumer<String> progress)
            throws IOException, JSONException, Problem {
        return complete(run, model, key, cancellation, progress, Collections.emptyList());
    }

    Reply complete(Workflow.Run run, ModelCatalog.Model model, String key,
                   Cancellation cancellation, Consumer<String> progress, List<InputMaterial.Image> images)
            throws IOException, JSONException, Problem {
        String missing = run.missingInput();
        if (!missing.isEmpty()) throw new Problem(missing);
        if (model.provider == Workflow.Provider.GEMINI) {
            return request(GEMINI_URL + model.id + ":streamGenerateContent?alt=sse", "x-goog-api-key", key,
                    materialBody(run, model, images, noTrainingOnly), true, cancellation,
                    (source, type) -> type.contains("application/json") ? parseGemini(readJson(source))
                            : parseGeminiStream(source, progress));
        }
        boolean groq = model.provider == Workflow.Provider.GROQ;
        if (!groq && !ModelCatalog.isFreeId(model.id)) {
            throw new Problem("Выбери бесплатную модель OpenRouter.");
        }
        String url = groq ? GROQ_URL : ROUTER_BASE + "chat/completions";
        JSONObject body = materialBody(run, model, images, noTrainingOnly);
        return request(url, "Authorization", "Bearer " + key, body, true, cancellation,
                (source, type) -> type.contains("application/json") ? parseRouterJson(readJson(source))
                        : parseRouterStream(source, progress));
    }

    static JSONObject materialBody(Workflow.Run run, ModelCatalog.Model model, List<InputMaterial.Image> images)
            throws JSONException, AttachmentProblem, Problem {
        return materialBody(run, model, images, true);
    }

    static JSONObject materialBody(Workflow.Run run, ModelCatalog.Model model,
                                   List<InputMaterial.Image> images, boolean noTrainingOnly)
            throws JSONException, AttachmentProblem, Problem {
        InputMaterial.validate(run, model, images);
        JSONObject body = model.provider == Workflow.Provider.GEMINI ? geminiBody(run, model)
                : model.provider == Workflow.Provider.GROQ ? groqBody(run, model) : routerBody(run, model, noTrainingOnly);
        if (!images.isEmpty()) {
            JSONArray content = new JSONArray().put(new JSONObject().put("type", "text").put("text", run.prompt()));
            for (InputMaterial.Image image : images) {
                content.put(new JSONObject().put("type", "text").put("text", "Attached image: " + image.ref.name));
                content.put(new JSONObject().put("type", "image_url").put("image_url", new JSONObject()
                        .put("url", "data:" + image.ref.mime + ";base64," + image.base64)));
            }
            body.getJSONArray("messages").getJSONObject(1).put("content", content);
        }
        if (!run.materials.isEmpty() && InputMaterial.utf8(body.toString()) > InputMaterial.MAX_REQUEST_BYTES)
            throw new AttachmentProblem(AttachmentProblem.Code.HTTP_SIZE);
        return body;
    }

    static JSONObject routerBody(Workflow.Run run, ModelCatalog.Model model) throws JSONException, Problem {
        return routerBody(run, model, true);
    }

    static JSONObject routerBody(Workflow.Run run, ModelCatalog.Model model, boolean noTrainingOnly)
            throws JSONException, Problem {
        return chatBody(run, model, false, noTrainingOnly);
    }

    static JSONObject groqBody(Workflow.Run run, ModelCatalog.Model model) throws JSONException, Problem {
        return chatBody(run, model, true, false);
    }

    private static JSONObject chatBody(Workflow.Run run, ModelCatalog.Model model,
                                       boolean groq, boolean noTrainingOnly)
            throws JSONException, Problem {
        String rules = run.instructions();
        String prompt = run.prompt();
        String previous = precedingPart(run);
        JSONArray messages = new JSONArray().put(message("system", rules)).put(message("user", prompt));
        if (!previous.isEmpty()) {
            messages.put(message("assistant", previous)).put(message("user", continuationPrompt(run)));
        }
        JSONObject body = new JSONObject().put("model", model.id).put("stream", true)
                .put("messages", messages);
        int outputBudget = budget(run, model, rules, prompt, previous);
        if (groq) {
            return body.put("max_completion_tokens", outputBudget)
                    .put("reasoning_effort", "medium")
                    .put("reasoning_format", "hidden");
        }
        JSONObject priceLimit = new JSONObject().put("prompt", 0).put("completion", 0).put("request", 0);
        JSONObject provider = new JSONObject().put("max_price", priceLimit);
        if (noTrainingOnly) provider.put("data_collection", "deny");
        body.put("max_tokens", outputBudget).put("provider", provider);
        if (model.reasoning) {
            JSONObject reasoning = new JSONObject().put("exclude", true);
            if (ModelCatalog.NEMOTRON.id.equals(model.id)) reasoning.put("effort", "medium");
            body.put("reasoning", reasoning);
        }
        return body;
    }

    private static JSONObject geminiBody(Workflow.Run run, ModelCatalog.Model model) throws JSONException, Problem {
        String rules = run.instructions();
        String prompt = run.prompt();
        String previous = precedingPart(run);
        JSONArray contents = new JSONArray().put(geminiContent("user", prompt));
        if (!previous.isEmpty()) {
            contents.put(geminiContent("model", previous)).put(geminiContent("user", continuationPrompt(run)));
        }
        return new JSONObject().put("systemInstruction", geminiContent(null, rules))
                .put("contents", contents).put("generationConfig",
                        new JSONObject().put("maxOutputTokens", budget(run, model, rules, prompt, previous)));
    }

    private static String continuationPrompt(Workflow.Run run) {
        if (ContinuationIntegrity.unclosedFence(run.draft.text))
            return "Continue the existing unfinished file, starting with the exact last 64 characters of the draft "
                    + "(or the entire draft if shorter). Preserve every earlier file. Do not open another fence before "
                    + "the anchor. Complete the unfinished code and close its fence only when complete.";
        if (run.needsReplacement()) return "Return the entire answer from the beginning, including every previously received file. "
                + "Preserve all received source bytes and file paths exactly; complete only unfinished portions. "
                + "Do not return just the tail, discard earlier files, or rewrite the project.";
        return CONTINUE_PROMPT;
    }

    private static String precedingPart(Workflow.Run run) {
        return run.draftMode == Workflow.DraftMode.CONTINUE && !TaskHistory.readOnlyTurn(run.task) ? run.draft.text : "";
    }

    static int requestedOutput(Workflow.Run run, ModelCatalog.Model model, long inputTokens) {
        int ceiling = Math.min(run.nextStep().outputBudget, model.maxOutput > 0 ? model.maxOutput : 32_768);
        if (run.nextStep() == Workflow.Step.REVIEW) ceiling = Math.min(ceiling, 4096);
        else if (run.task.length() < 2000 && run.nextStep() == Workflow.Step.SOLUTION
                && PlainTextPromptPolicy.unambiguousProse(TaskHistory.forRepair(run.task)))
            ceiling = Math.min(ceiling, 4096);
        // Groq free-tier TPM is limited. Reserve space for input as well as reasoning/output.
        // This is a conservative local estimate, not an account-specific quota guarantee.
        if (model.provider == Workflow.Provider.GROQ)
            ceiling = Math.min(ceiling, (int)Math.max(512L, 8000L - inputTokens));
        if (model.context == 0) return ceiling;
        long room = model.context - 1024L - inputTokens;
        return room < 512L ? 0 : (int) Math.min(ceiling, room);
    }

    private static int budget(Workflow.Run run, ModelCatalog.Model model, String rules,
                              String prompt, String previous) throws Problem {
        int result = requestedOutput(run, model, estimatedInput(run, rules, prompt, previous));
        if (result == 0) throw new Problem("По оценке запроса недостаточно контекста выбранной модели. "
                + "Текст и сохранённый черновик не сокращены автоматически. "
                + "Выбери модель с большим окном контекста или сократи исходные материалы.");
        return result;
    }

    private static long estimatedInput(Workflow.Run run, String rules, String prompt, String previous) {
        long estimate = estimatedTokens(rules) + estimatedTokens(prompt) + InputMaterial.imageTokens(run.materials);
        return previous.isEmpty() ? estimate : estimate + estimatedTokens(previous) + estimatedTokens(continuationPrompt(run));
    }

    static long estimatedInput(Workflow.Run run) throws JSONException {
        return estimatedInput(run, run.instructions(), run.prompt(), precedingPart(run));
    }

    /** Compare the actual outgoing prompt against its unoptimized local baseline.
     * The byte counts cover system+user text only, not HTTP framing, images or
     * the unchanged continuation; token counts are estimates, NOT API usage.
     */
    static final class InputComparison {
        final long estimatedBefore, estimatedAfter;
        final long textBytesBefore, textBytesAfter;

        InputComparison(long estimatedBefore, long estimatedAfter,
                        long textBytesBefore, long textBytesAfter) {
            this.estimatedBefore = estimatedBefore;
            this.estimatedAfter = estimatedAfter;
            this.textBytesBefore = textBytesBefore;
            this.textBytesAfter = textBytesAfter;
        }
    }

    static InputComparison compareInput(Workflow.Run run) throws JSONException {
        String beforeRules = run.unoptimizedInstructions();
        String afterRules = run.instructions();
        String beforePrompt = run.unoptimizedPrompt();
        String afterPrompt = run.prompt();
        String previous = precedingPart(run);
        return new InputComparison(
                estimatedInput(run, beforeRules, beforePrompt, previous),
                estimatedInput(run, afterRules, afterPrompt, previous),
                (long) InputMaterial.utf8(beforeRules) + InputMaterial.utf8(beforePrompt),
                (long) InputMaterial.utf8(afterRules) + InputMaterial.utf8(afterPrompt));
    }

    static int estimatedTokens(String text) {
        // A heuristic, never a provider token count. Keep additional room for chat framing.
        int ascii = 0, cyrillic = 0, other = 0;
        for (int i = 0; i < text.length();) {
            int ch = text.codePointAt(i);
            if (ch < 128) ascii++;
            else if (ch >= 0x400 && ch <= 0x52f) cyrillic++;
            else other += Character.charCount(ch);
            i += Character.charCount(ch);
        }
        return (ascii + 2) / 3 + (cyrillic + 1) / 2 + other;
    }

    private static JSONObject geminiContent(String role, String text) throws JSONException {
        JSONObject content = new JSONObject()
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
        if (role != null) content.put("role", role);
        return content;
    }

    private static JSONObject message(String role, String content) throws JSONException {
        return new JSONObject().put("role", role).put("content", content);
    }

    static Reply parseGemini(JSONObject reply) throws JSONException {
        StringBuilder answer = new StringBuilder();
        Reply result = readGeminiEvent(reply, answer);
        return result != null ? result
                : Reply.error(answer.toString(), "Gemini завершил передачу без статуса ответа.");
    }

    static Reply parseGeminiStream(BufferedReader source, Consumer<String> progress) {
        return parseStream(source, progress, ModelClient::readGeminiEvent);
    }

    private static Reply readGeminiEvent(JSONObject reply, StringBuilder answer) throws JSONException {
        JSONObject error = reply.optJSONObject("error");
        if (error != null) return serviceError(answer.toString(), error.optInt("code", 0), error);
        JSONArray candidates = reply.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) {
            JSONObject feedback = reply.optJSONObject("promptFeedback");
            String blockReason = feedback == null ? "" : value(feedback, "blockReason");
            if (!blockReason.isEmpty() && !"BLOCK_REASON_UNSPECIFIED".equals(blockReason)) {
                return Reply.rejected(answer.toString(), "Gemini отклонил запрос. Попробуй уточнить задачу.");
            }
            return null;
        }
        JSONObject candidate = candidates.getJSONObject(0);
        String finish = candidate.optString("finishReason");
        JSONObject content = candidate.optJSONObject("content");
        JSONArray parts = content == null ? null : content.optJSONArray("parts");
        if (parts != null) {
            for (int i = 0; i < parts.length(); i++) {
                JSONObject part = parts.getJSONObject(i);
                if (!part.optBoolean("thought")) answer.append(value(part, "text"));
            }
        }
        if ("MAX_TOKENS".equals(finish)) return new Reply(answer.toString(), Finish.LENGTH, "");
        if ("STOP".equals(finish)) return new Reply(answer.toString(), Finish.STOP, "");
        if (finish.isEmpty() || "FINISH_REASON_UNSPECIFIED".equals(finish)) return null;
        return Reply.rejected(answer.toString(), "Gemini остановил ответ. Попробуй уточнить задачу.");
    }

    private static Reply parseRouterJson(JSONObject reply) {
        return readRouterEvent(reply, new StringBuilder(), "message");
    }

    static Reply parseRouterStream(BufferedReader source) {
        return parseRouterStream(source, text -> {});
    }

    static Reply parseRouterStream(BufferedReader source, Consumer<String> progress) {
        return parseStream(source, progress, (event, answer) -> readRouterEvent(event, answer, "delta"));
    }

    private interface StreamEvent {
        Reply decode(JSONObject event, StringBuilder answer) throws JSONException;
    }

    private static Reply parseStream(BufferedReader source, Consumer<String> progress, StreamEvent decoder) {
        long reported = 0;
        int reportedLength = 0;
        StringBuilder answer = new StringBuilder();
        StringBuilder event = new StringBuilder();
        try {
            String line;
            long total = 0;
            while ((line = streamLine(source)) != null) {
                total += line.length() + 1L;
                if (total > MAX_STREAM_CHARS) throw new ResponseLimit();
                if (line.startsWith("data:")) {
                    if (event.length() > 0) event.append('\n');
                    int start = line.startsWith("data: ") ? 6 : 5;
                    if ((long) event.length() + line.length() - start > MAX_EVENT_CHARS) throw new ResponseLimit();
                    event.append(line, start, line.length());
                } else if (line.isEmpty() && event.length() > 0) {
                    Reply complete = parseEvent(event, answer, decoder);
                    long now = System.nanoTime();
                    if (answer.length() != reportedLength
                            && (reportedLength == 0 || complete != null || now - reported > 750_000_000L)) {
                        progress.accept(answer.toString());
                        reported = now;
                        reportedLength = answer.length();
                    }
                    if (complete != null) return complete;
                    event.setLength(0);
                }
            }
            if (event.length() > 0) {
                Reply complete = parseEvent(event, answer, decoder);
                if (complete != null) return complete;
            }
        } catch (ResponseLimit e) {
            return Reply.error(answer.toString(), LIMIT_MESSAGE, sizeFailure());
        } catch (IOException e) {
            return Reply.error(answer.toString(), NO_CONNECTION);
        } catch (JSONException e) {
            return Reply.error(answer.toString(), "Не удалось прочитать часть ответа модели.");
        }
        return Reply.error(answer.toString(), "Провайдер прервал ответ до завершения.");
    }

    private static String streamLine(BufferedReader source) throws IOException {
        StringBuilder line = new StringBuilder();
        int c;
        while ((c = source.read()) >= 0) {
            if (c == '\n') break;
            if (c == '\r') {
                source.mark(1);
                if (source.read() != '\n') source.reset();
                break;
            }
            if (line.length() >= MAX_EVENT_CHARS) throw new ResponseLimit();
            line.append((char)c);
        }
        return c < 0 && line.length() == 0 ? null : line.toString();
    }

    private static Reply parseEvent(StringBuilder event, StringBuilder answer, StreamEvent decoder)
            throws JSONException {
        String data = event.toString().trim();
        if (data.isEmpty()) return null;
        if ("[DONE]".equals(data)) {
            return Reply.error(answer.toString(), "Провайдер закончил передачу без статуса ответа.");
        }
        int before = answer.length();
        Reply result = decoder.decode(new JSONObject(data), answer);
        if (answer.length() > MAX_ANSWER_CHARS) {
            answer.setLength(before);
            return Reply.error(answer.toString(), LIMIT_MESSAGE, sizeFailure());
        }
        return result;
    }

    private static Reply readRouterEvent(JSONObject event, StringBuilder answer, String contentField) {
        JSONArray choices = event.optJSONArray("choices");
        JSONObject choice = choices == null ? null : choices.optJSONObject(0);
        if (choice != null) {
            JSONObject delta = choice.optJSONObject(contentField);
            if (delta != null) answer.append(value(delta, "content"));
        }
        JSONObject error = event.optJSONObject("error");
        if (error == null && choice != null) error = choice.optJSONObject("error");
        if (error != null) {
            int status = error.optInt("code", 0);
            if (status == 0) {
                String code = error.optString("code");
                String type = error.optString("type");
                if ("rate_limit_exceeded".equals(code) || "rate_limit_error".equals(type)) status = 429;
                else if ("service_unavailable".equals(code)) status = 503;
            }
            return serviceError(answer.toString(), status, error);
        }
        String reason = choice == null ? "" : value(choice, "finish_reason");
        switch (reason) {
            case "stop": return new Reply(answer.toString(), Finish.STOP, "");
            case "length": return new Reply(answer.toString(), Finish.LENGTH, "");
            case "content_filter":
                return Reply.rejected("", "Провайдер остановил ответ. Попробуй уточнить задачу.");
            case "error": return Reply.error(answer.toString(), summary(0, null));
            case "":
                return contentField.equals("delta") ? null
                        : Reply.error(answer.toString(), "Провайдер не сообщил, завершён ли ответ.");
            default: return Reply.error(answer.toString(), "Модель не завершила текстовый ответ.");
        }
    }

    private static Reply serviceError(String partial, int status, JSONObject error) {
        RequestFailure failure = RequestFailure.read(status, error, null, System.currentTimeMillis());
        return Reply.error(partial, explain(status, error), failure);
    }

    private static String value(JSONObject item, String field) {
        return item.isNull(field) ? "" : item.optString(field, "");
    }

    private static String explain(int status, JSONObject error) {
        return summary(status, error);
    }

    private static String summary(int status, JSONObject error) {
        RequestFailure.Reason reason = RequestFailure.classify(status, error);
        if (reason == RequestFailure.Reason.TOKEN_RATE_LIMIT)
            return "Превышен лимит токенов в минуту (TPM) у провайдера. "
                    + "Это не размер контекстного окна. Подожди сброса лимита или выбери другой сервис.";
        if (reason == RequestFailure.Reason.CONTEXT_LIMIT)
            return "Задача и полученные ответы не помещаются в контекст модели. Выбери модель с большим контекстом.";
        if (reason == RequestFailure.Reason.REQUEST_SIZE)
            return "Провайдер отклонил объём запроса (HTTP 413). Нужен меньший модуль или другая модель.";
        if (reason == RequestFailure.Reason.DAILY_QUOTA)
            return "Провайдер сообщил об исчерпании суточной квоты.";
        if (status == 0) return NO_CONNECTION;
        if (status == 413)
            return "Провайдер отклонил размер запроса (HTTP 413), но точный тип ограничения не указан. "
                    + "Проверь детали отказа и лимиты сервиса.";
        switch (status) {
            case 400: return "Провайдер отклонил запрос. Проверь выбранную модель.";
            case 401:
            case 403: return "Проверь ключ и доступ к модели в настройках провайдера.";
            case 402: return "Провайдер отклонил запрос по условиям тарифа.";
            case 404: return "Провайдер не нашёл доступный маршрут для этой модели. Можно выбрать другую.";
            case 408:
            case 504: return "Модель не успела ответить. Можно продолжить с этого шага.";
            case 429: return "Достигнут лимит запросов провайдера. Попробуй продолжить позже.";
            default: return "Сервис модели недоступен. Можно продолжить с этого шага.";
        }
    }

    private static JSONObject readJson(BufferedReader source) throws IOException, JSONException {
        StringBuilder text = new StringBuilder();
        char[] buffer = new char[8192];
        int count;
        while ((count = source.read(buffer)) != -1) {
            if ((long) text.length() + count > MAX_JSON_CHARS) throw new ResponseLimit();
            text.append(buffer, 0, count);
        }
        return new JSONObject(text.toString());
    }

    private static JSONObject readError(HttpURLConnection connection) throws ResponseLimit {
        InputStream stream = connection.getErrorStream();
        if (stream == null) return null;
        try (BufferedReader input = reader(stream)) {
            return readJson(input).optJSONObject("error");
        } catch (ResponseLimit excess) {
            throw excess;
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    private static BufferedReader reader(InputStream source) {
        return new BufferedReader(new InputStreamReader(source, StandardCharsets.UTF_8));
    }

    private static <T> T request(String url, String authHeader, String authValue, JSONObject body,
                                 boolean stream, Cancellation cancellation, Decoder<T> decoder)
            throws IOException, JSONException, Problem {
        HttpsURLConnection connection = (HttpsURLConnection) new URL(url).openConnection();
        try {
            cancellation.attach(connection);
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(20_000);
            connection.setReadTimeout(body == null ? 20_000 : REQUEST_TIMEOUT_MS);
            connection.setRequestProperty("Accept", stream ? "text/event-stream" : "application/json");
            if (authHeader != null) connection.setRequestProperty(authHeader, authValue);
            if (body != null) {
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setDoOutput(true);
                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(payload.length);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(payload);
                }
            }
            int status = connection.getResponseCode();
            if (status != 200) {
                String retry = connection.getHeaderField("Retry-After");
                JSONObject error = readError(connection);
                RequestFailure failure = RequestFailure.read(status, error, retry, System.currentTimeMillis());
                String detail = explain(status, error);
                if (retry != null) detail += "\nRetry-After: " + retry;
                if (authValue != null) detail = detail.replace(authValue, "[ключ скрыт]")
                        .replace(authValue.replace("Bearer ", ""), "[ключ скрыт]");
                throw new Problem(failure, detail);
            }
            try (BufferedReader source = reader(connection.getInputStream())) {
                String contentType = connection.getContentType();
                T result = decoder.read(source, contentType == null ? "" : contentType);
                if (result instanceof Reply && ((Reply) result).text.length() > MAX_ANSWER_CHARS)
                    throw new Problem(sizeFailure(), LIMIT_MESSAGE);
                if (result instanceof Reply && GROQ_URL.equals(url)) {
                    // The headers describe Groq's own minute/day windows, not a lifetime token balance.
                    @SuppressWarnings("unchecked")
                    T enriched = (T) ((Reply) result).withQuota(ProviderQuota.groq(connection));
                    return enriched;
                }
                return result;
            }
        } catch (ResponseLimit excess) {
            throw new Problem(sizeFailure(), LIMIT_MESSAGE);
        } finally {
            cancellation.detach();
            connection.disconnect();
        }
    }
}
