"""Guard the Python-only chat history path, including the failed on-device scenario.

Source checks: these do not replace Robolectric or an Android device run.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'


class PythonChatHistoryRecoveryTests(unittest.TestCase):
    def test_history_uses_python_file_store_as_second_source(self):
        repo = (JAVA / 'TaskRepository.java').read_text(encoding='utf-8')
        activity = (JAVA / 'MainActivity.java').read_text(encoding='utf-8')
        self.assertIn('listIncludingPythonProjects(PythonProjectStore projects)', repo)
        self.assertIn('projects.savedTaskIds()', repo)
        self.assertIn('Entry stored = load(taskId)', repo)
        self.assertIn('if (stored == null) continue', repo)
        self.assertIn('repository.listIncludingPythonProjects(pythonProjects())', activity)

    def test_new_chat_respects_persisted_python_files(self):
        activity = (JAVA / 'MainActivity.java').read_text(encoding='utf-8')
        compose = (JAVA / 'ui/NexusComposeUi.kt').read_text(encoding='utf-8')
        self.assertIn('public boolean nexusHasSavedPythonFiles()', activity)
        self.assertIn('&& !nexusUi.hasDraftContent() && !nexusHasSavedPythonFiles()', activity)
        self.assertIn('hasDraftContent() || activity.nexusHasSavedPythonFiles()', compose)

    def test_android_integration_cases_exist(self):
        tests = (ROOT / 'app/src/test/java/app/svyazka/mobile/PythonChatHistoryTest.java').read_text(encoding='utf-8')
        for name in ('historyFindsPythonFilesEvenWithoutDatabaseTitle',
                     'newChatDoesNotHidePreviousPythonOnlyChat',
                     'deletedChatIsNotResurrectedByOldProjectData'):
            self.assertIn('void ' + name + '()', tests)


if __name__ == '__main__':
    unittest.main()
