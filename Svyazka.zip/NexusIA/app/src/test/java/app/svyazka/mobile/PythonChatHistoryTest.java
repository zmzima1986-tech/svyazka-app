package app.svyazka.mobile;

import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class PythonChatHistoryTest {
    @Test public void legacyPythonOnlyChatIsNotTreatedAsAiConversation() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository repository = new TaskRepository(context)) {
            long id = repository.create("");
            assertTrue(repository.list().stream().noneMatch(item -> item.id == id));
            PythonProjectStore projects = new PythonProjectStore(context);
            projects.putText(id, "test.py", "print(10)\n");
            repository.markPythonProject(id, "test.py", true);
            TaskRepository.Entry recorded = repository.load(id);
            assertEquals("", recorded.task);
            assertEquals("Python · test.py", recorded.title);
            assertFalse(repository.list().stream().anyMatch(item -> item.id == id));
        }
    }

    @Test public void olderHiddenPythonChatIsRecoveredAfterRestart() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        long id;
        PythonProjectStore projects = new PythonProjectStore(context);
        try (TaskRepository repository = new TaskRepository(context)) {
            id = repository.create("");
            projects.putText(id, "main.py", "print('kept')\n");
            assertTrue(repository.list().stream().noneMatch(item -> item.id == id));
        }
        try (TaskRepository repository = new TaskRepository(context)) {
            repository.recoverPythonProjects(projects);
            assertFalse(repository.list().stream().anyMatch(item -> item.id == id));
            assertEquals("Python · main.py", repository.load(id).title);
            assertEquals("print('kept')\n", projects.text(id, "main.py"));
        }
    }

    @Test public void historyFindsPythonFilesEvenWithoutDatabaseTitle() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore projects = new PythonProjectStore(context);
        long chat;
        try (TaskRepository repository = new TaskRepository(context)) {
            chat = repository.create("");
            projects.putText(chat, "check.py", "print(1)");
            // Reproduce missing UI bookkeeping in the previous release.
            assertTrue(repository.list().stream().noneMatch(item -> item.id == chat));
            TaskRepository.Entry fallback = repository.listIncludingPythonProjects(projects)
                    .stream().filter(item -> item.id == chat).findFirst().orElse(null);
            assertNotNull(fallback);
            assertEquals("Python · check.py", fallback.title);
        }
        try (TaskRepository repository = new TaskRepository(context)) {
            assertTrue(repository.listIncludingPythonProjects(projects)
                    .stream().anyMatch(item -> item.id == chat));
        }
    }

    @Test public void newChatDoesNotHidePreviousPythonOnlyChat() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore projects = new PythonProjectStore(context);
        try (TaskRepository repository = new TaskRepository(context)) {
            long previous = repository.create("");
            projects.putText(previous, "test.py", "print(42)");
            // A separate chat must receive its own row and Python files.
            long next = repository.create("");
            projects.putText(next, "check.py", "print(8)");
            assertNotEquals(previous, next);
            assertEquals("print(42)", projects.text(previous, "test.py"));
            assertEquals("", projects.text(next, "test.py"));
            assertEquals(2L, repository.listIncludingPythonProjects(projects).stream()
                    .filter(item -> item.id == previous || item.id == next).count());
        }
    }

    @Test public void deletedChatIsNotResurrectedByOldProjectData() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore projects = new PythonProjectStore(context);
        try (TaskRepository repository = new TaskRepository(context)) {
            long deleted = repository.create("");
            projects.putText(deleted, "orphan.py", "print(7)");
            assertTrue(repository.delete(deleted));
            assertTrue(repository.listIncludingPythonProjects(projects)
                    .stream().noneMatch(item -> item.id == deleted));
        }
    }

    @Test public void missingChatCannotSilentlyClaimPythonHistoryWasSaved() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore projects = new PythonProjectStore(context);
        try (TaskRepository repository = new TaskRepository(context)) {
            long id = repository.create("");
            assertTrue(repository.delete(id));
            assertFalse(repository.markPythonProject(id, "check.py", true));
            assertNull(repository.load(id));
            // Even an older orphaned project must not resurrect a deleted chat.
            projects.putText(id, "check.py", "print(123)");
            assertTrue(repository.listIncludingPythonProjects(projects).stream()
                    .noneMatch(item -> item.id == id));
        }
    }

    @Test public void markedPythonChatCanBeFoundAfterDatabaseReopen() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore projects = new PythonProjectStore(context);
        long id;
        try (TaskRepository repository = new TaskRepository(context)) {
            id = repository.create("");
            assertNotNull(repository.load(id));
            projects.putText(id, "check.py", "print('offline')");
            assertTrue(repository.markPythonProject(id, "check.py", true));
            assertTrue(repository.listIncludingPythonProjects(projects).stream()
                    .anyMatch(item -> item.id == id));
        }
        try (TaskRepository reopened = new TaskRepository(context)) {
            assertTrue(reopened.listIncludingPythonProjects(projects).stream()
                    .anyMatch(item -> item.id == id));
            assertEquals("print('offline')", projects.text(id, "check.py"));
        }
    }

    @Test public void noEmptyChatOrForeignTitleIsAddedToHistory() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository repository = new TaskRepository(context)) {
            long empty = repository.create("");
            repository.recoverPythonProjects(new PythonProjectStore(context));
            assertTrue(repository.list().stream().noneMatch(item -> item.id == empty));
            long custom = repository.create("");
            assertTrue(repository.rename(custom, "Мой проект"));
            PythonProjectStore projects = new PythonProjectStore(context);
            projects.putText(custom, "main.py", "print(42)");
            repository.markPythonProject(custom, "main.py", true);
            assertEquals("Мой проект", repository.load(custom).title);
        }
    }
}
