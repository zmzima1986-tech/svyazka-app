'use strict';

window.addEventListener('message', start, { once: true });

function start(event) {
    const appPort = event.ports[0];
    if (!appPort) return;
    const input = JSON.parse(event.data);
    const worker = new Worker('worker.mjs', { type: 'module' });
    const channel = new MessageChannel();
    const port = channel.port1;
    let output = { stdout: '', stderr: '' };
    let engine = 'Python на телефоне';
    let executionTimer;
    const initializationTimer = setTimeout(() => finish({ error: 'Python не запустился за 30 секунд.' }), 30000);
    let finished = false;

    function finish(data) {
        if (finished) return;
        finished = true;
        clearTimeout(initializationTimer);
        clearTimeout(executionTimer);
        port.close();
        worker.terminate();
        appPort.postMessage(JSON.stringify({ ...output, engine, ...data }));
        appPort.close();
    }

    port.onmessage = ({ data }) => {
        if (data.kind === 'ready') {
            engine = data.engine;
            clearTimeout(initializationTimer);
            const budget = input.allow_matplotlib === true ? 170000 : 5000;
            executionTimer = setTimeout(() => finish({
                status: input.allow_matplotlib === true
                    ? 'Загрузка Matplotlib или выполнение остановлены по лимиту.'
                    : 'Выполнение остановлено через 5 секунд.',
                code: null,
            }), budget);
            port.postMessage(input);
        } else if (data.kind === 'output') {
            output = { stdout: data.stdout, stderr: data.stderr };
        } else if (data.kind === 'done') {
            finish({ stdout: data.stdout, stderr: data.stderr, code: data.code,
                status: data.status, image_png: data.image_png || '', html: data.html || '' });
        } else if (data.kind === 'error') {
            finish({ error: data.error });
        }
    };
    worker.onerror = () => finish({ error: 'Движок Python не смог запуститься. Проверь обновления Android System WebView.' });
    worker.postMessage(null, [channel.port2]);
}
