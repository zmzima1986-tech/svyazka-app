package app.svyazka.mobile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservatively joins streamed text; never silently rewrites an ambiguous continuation. */
final class ContinuationIntegrity {
    private static final Pattern FENCE = Pattern.compile("^\\s*(`{3,}|~{3,})(.*)$");
    static final String WARNING_RESTART = "Новая модель повторила начало предыдущего текста. Проверь стык вручную.";
    static final String WARNING_OVERLAP = "При продолжении обнаружен и удалён повтор текста. Проверь границу частей.";
    static final String WARNING_JOIN = "Продолжение не имеет подтверждённого стыка. Проверь границу фрагментов.";
    static final String WARNING_FENCE = "Продолжение начинает новый блок кода внутри незакрытого блока. Проверь разметку.";
    static final String WARNING_REPLACED = "Другая модель вернула самостоятельный законченный блок кода: "
            + "он заменил незавершённый фрагмент, а не был к нему присоединён. "
            + "Корректность кода требует отдельной проверки.";
    static final String WARNING_UNCLOSED = "Ответ содержит незакрытый блок кода Markdown. Проверь полноту кода.";

    static final class Merge {
        final String text;
        final List<String> warnings;

        Merge(String text, List<String> warnings) {
            this.text = text;
            this.warnings = Collections.unmodifiableList(new ArrayList<>(warnings));
        }
    }

    private ContinuationIntegrity() { }

    static Merge merge(String previous, String next) {
        if (previous.isEmpty()) return new Merge(next, Collections.emptyList());
        if (next.isEmpty()) return new Merge(previous, Collections.emptyList());
        List<String> warnings = new ArrayList<>();
        if (unclosedFence(previous) && startsNewFence(next)) {
            PythonInputs.Candidate replacement = PythonInputs.candidate(next);
            if (replacement != null && !replacement.ambiguous && replacement.issue.isEmpty()) {
                // A full, self-contained replacement is safer than nesting a new
                // fenced file inside an unfinished source. The old fragment is
                // retained in the attempt history, not mixed into executable code.
                warnings.add(WARNING_REPLACED);
                return new Merge(next, warnings);
            }
            warnings.add(WARNING_FENCE);
        }

        // Complete echoes are common after switching providers. Remove only an EXACT repeat.
        if (previous.length() >= 48 && next.startsWith(previous)) {
            warnings.add(WARNING_OVERLAP);
            return new Merge(next, warnings);
        }
        int overlap = exactOverlap(previous, next);
        if (overlap >= 32) {
            warnings.add(WARNING_OVERLAP);
            return new Merge(previous + next.substring(overlap), warnings);
        }
        // If a model restarted from the beginning but changed the wording, do not discard data.
        if (commonPrefix(previous, next) >= 48) warnings.add(WARNING_RESTART);
        if (overlap == 0 && wordBoundaryAmbiguous(previous, next)) warnings.add(WARNING_JOIN);
        return new Merge(previous + next, warnings);
    }

    static boolean unclosedFence(String text) {
        String open = null;
        for (String line : text.split("\\r?\\n", -1)) {
            Matcher match = FENCE.matcher(line);
            if (!match.matches()) continue;
            String delimiter = match.group(1);
            if (open == null) open = delimiter;
            else if (delimiter.charAt(0) == open.charAt(0) && delimiter.length() >= open.length()
                    && match.group(2).trim().isEmpty()) open = null;
        }
        return open != null;
    }

    private static boolean startsNewFence(String text) {
        String first = text.split("\\r?\\n", 2)[0];
        Matcher fence = FENCE.matcher(first);
        return fence.matches() && !fence.group(2).trim().isEmpty();
    }

    private static int exactOverlap(String previous, String next) {
        int max = Math.min(4096, Math.min(previous.length(), next.length()));
        for (int size = max; size >= 32; size--) {
            if (previous.regionMatches(previous.length() - size, next, 0, size)) return size;
        }
        return 0;
    }

    private static int commonPrefix(String previous, String next) {
        int max = Math.min(previous.length(), next.length());
        int i = 0;
        while (i < max && previous.charAt(i) == next.charAt(i)) i++;
        return i;
    }

    private static boolean wordBoundaryAmbiguous(String previous, String next) {
        char a = previous.charAt(previous.length() - 1);
        char b = next.charAt(0);
        return Character.isLetterOrDigit(a) && Character.isLetterOrDigit(b);
    }
}
