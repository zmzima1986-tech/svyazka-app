package app.svyazka.mobile;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/** Full-window launch artwork. The reference phone image is 691 by 1536. */
final class NexusLaunchView extends ViewGroup {
    private static final int ART_WIDTH = 691;
    private static final int ART_HEIGHT = 512;
    private final ImageView waves;
    private final ImageView art;
    private final TextView title;
    private final TextView caption;
    private final Rect ink = new Rect();
    private float scale;

    NexusLaunchView(Context context) {
        super(context);
        setBackgroundColor(context.getColor(R.color.nexus_launch_background));
        setClickable(true);
        waves = picture(R.drawable.nexus_launch_waves_animated);
        art = picture(R.drawable.nexus_launch_animated);
        title = label(R.string.app_name, R.color.nexus_launch_text);
        caption = label(R.string.ui_loading, R.color.nexus_launch_label);
    }

    private ImageView picture(int resource) {
        ImageView image = new ImageView(getContext());
        image.setImageResource(resource);
        image.setScaleType(ImageView.ScaleType.FIT_XY);
        image.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        addView(image);
        return image;
    }

    private TextView label(int text, int color) {
        TextView view = new TextView(getContext());
        view.setText(text);
        view.setTextColor(getContext().getColor(color));
        view.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        view.setIncludeFontPadding(false);
        view.setMaxLines(1);
        addView(view);
        return view;
    }

    private static int exact(float value) {
        return MeasureSpec.makeMeasureSpec(Math.max(1, Math.round(value)), MeasureSpec.EXACTLY);
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        int height = MeasureSpec.getSize(heightSpec);
        // On a short or split-screen window keep the caption clear of the waves.
        scale = Math.min(width / (float) ART_WIDTH, height / 1120f);
        waves.measure(exact(width), exact(height * (307f / 1536f)));
        int artWidth = exact(ART_WIDTH * scale);
        art.measure(artWidth, exact(ART_HEIGHT * scale));
        measureLabel(title, artWidth, 62f * scale);
        measureLabel(caption, artWidth, 26f * scale);
        setMeasuredDimension(width, height);
    }

    private static void measureLabel(TextView label, int widthSpec, float textSize) {
        if (label.getTextSize() != textSize) label.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
        label.measure(widthSpec, MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
    }

    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = r - l;
        int h = b - t;
        waves.layout(0, h - waves.getMeasuredHeight(), w, h);
        centerAt(art, w, (h - art.getMeasuredHeight()) / 2);
        positionLabel(title, w, h / 2f + 52f * scale);
        positionLabel(caption, w, h / 2f + 238f * scale);
    }

    private void positionLabel(TextView label, int width, float inkCenterY) {
        String text = label.getText().toString();
        label.getPaint().getTextBounds(text, 0, text.length(), ink);
        centerAt(label, width, Math.round(inkCenterY - ink.exactCenterY() - label.getBaseline()));
    }

    private static void centerAt(View child, int width, int top) {
        int left = (width - child.getMeasuredWidth()) / 2;
        child.layout(left, top, left + child.getMeasuredWidth(), top + child.getMeasuredHeight());
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (ValueAnimator.areAnimatorsEnabled()) {
            ((Animatable) art.getDrawable()).start();
            ((Animatable) waves.getDrawable()).start();
        }
    }

    @Override protected void onDetachedFromWindow() {
        ((Animatable) art.getDrawable()).stop();
        ((Animatable) waves.getDrawable()).stop();
        super.onDetachedFromWindow();
    }
}
