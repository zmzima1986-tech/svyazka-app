package app.svyazka.fixture;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.SystemClock;
import app.svyazka.mobile.MainActivity;
import app.svyazka.mobile.NexusState;
import app.svyazka.mobile.ui.NexusComposeUi;
import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/** An end-to-end offline probe on a disposable real Android emulator.
 * Uses the same Compose -> MainActivity -> SQLite/file-store path as the app.
 * Run in three fresh app processes: python_seed, python_verify, python_deleted.
 */
final class PythonHistoryProbe {
    private static final String PREFS = "nexus_python_history_probe";
    private static final String FILE = "history_probe.py";
    private static final String SOURCE = "print('python-history-probe')\n";
    private PythonHistoryProbe() { }

    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static void main(Instrumentation instrumentation, Runnable action) {
        AtomicReference<Throwable> error = new AtomicReference<>();
        instrumentation.runOnMainSync(() -> {
            try { action.run(); }
            catch (Throwable failure) { error.set(failure); }
        });
        if (error.get() != null) throw new AssertionError("Android main-thread call failed", error.get());
    }

    private static MainActivity launch(Instrumentation instrumentation) {
        Intent launch = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClass(instrumentation.getTargetContext(), MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY);
        MainActivity activity = (MainActivity) instrumentation.startActivitySync(launch);
        instrumentation.waitForIdleSync();
        return activity;
    }

    private static NexusComposeUi compose(MainActivity activity) throws Exception {
        Field view = MainActivity.class.getDeclaredField("nexusUi");
        view.setAccessible(true);
        NexusComposeUi ui = (NexusComposeUi) view.get(activity);
        require(ui != null, "Compose chat was not initialized");
        return ui;
    }

    private static String diagnostics(MainActivity activity, long id) {
        StringBuilder data = new StringBuilder("taskId=").append(id)
                .append("; activityTaskId=").append(activity.nexusTaskId());
        try (SQLiteDatabase db = SQLiteDatabase.openDatabase(
                activity.getDatabasePath("svyazka_tasks.db").getPath(), null, SQLiteDatabase.OPEN_READONLY)) {
            try (Cursor row = db.rawQuery("SELECT task,run_json,custom_title FROM tasks WHERE id=?",
                    new String[]{Long.toString(id)})) {
                if (row.moveToFirst()) data.append("; dbRow=yes; draftLen=").append(row.getString(0).length())
                        .append("; runLen=").append(row.getString(1).length())
                        .append("; customTitle=").append(row.getString(2));
                else data.append("; dbRow=missing");
            }
            try (Cursor row = db.rawQuery("SELECT value FROM metadata WHERE key='active_task_id'", null)) {
                data.append("; dbActive=").append(row.moveToFirst() ? row.getString(0) : "missing");
            }
            try (Cursor row = db.rawQuery("SELECT COUNT(*) FROM tasks WHERE id=? AND "
                    + "(task<>'' OR run_json<>'' OR custom_title IS NOT NULL OR pinned<>0)",
                    new String[]{Long.toString(id)})) {
                data.append("; sqlHistoryVisible=").append(row.moveToFirst() && row.getLong(0) > 0);
            }
        } catch (Exception e) {
            data.append("; databaseError=").append(e.getClass().getSimpleName());
        }
        try {
            app.svyazka.mobile.PythonProjectStore projects = new app.svyazka.mobile.PythonProjectStore(activity);
            data.append("; projectPaths=").append(java.util.Arrays.toString(projects.paths(id)));
        } catch (Exception e) {
            data.append("; fileError=").append(e.getClass().getSimpleName());
        }
        return data.toString();
    }

    private static void hasChat(MainActivity activity, long id, boolean expected) {
        boolean found = false;
        NexusState state = activity.nexusSnapshot();
        for (NexusState.Task entry : state.tasks) if (entry.id == id) found = true;
        if (found != expected) throw new AssertionError("History projection for chat " + id
                + ": expected=" + expected + ", actual=" + found + "; " + diagnostics(activity, id));
    }

    private static void awaitChatSwitch(Instrumentation instrumentation, MainActivity activity, long expected) {
        long end = SystemClock.elapsedRealtime() + 12_000;
        AtomicLong current = new AtomicLong();
        while (SystemClock.elapsedRealtime() < end) {
            main(instrumentation, () -> current.set(activity.nexusTaskId()));
            if (current.get() == expected) return;
            SystemClock.sleep(40);
        }
        throw new AssertionError("Chat switch was not durably completed, current=" + current.get() + ", expected=" + expected);
    }

    private static void awaitNewChat(Instrumentation instrumentation, MainActivity activity, long oldId) {
        long end = SystemClock.elapsedRealtime() + 12_000;
        AtomicLong current = new AtomicLong();
        while (SystemClock.elapsedRealtime() < end) {
            main(instrumentation, () -> current.set(activity.nexusTaskId()));
            if (current.get() > 0 && current.get() != oldId) return;
            SystemClock.sleep(40);
        }
        throw new AssertionError("New-chat action did not change the active chat ID");
    }

    static void run(Instrumentation instrumentation, String step) throws Exception {
        require(Build.FINGERPRINT.contains("generic") || Build.MODEL.contains("SDK")
                        || Build.HARDWARE.startsWith("ranchu"), "Only a disposable Android emulator is permitted");
        Context app = instrumentation.getTargetContext();
        SharedPreferences checkpoint = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (step.equals("python_seed")) {
            require(app.getSharedPreferences("credentials", Context.MODE_PRIVATE).getAll().isEmpty(),
                    "This test must run without AI API keys");
            require(!checkpoint.contains("first"), "Seed has already been written; use a fresh emulator");
            MainActivity activity = launch(instrumentation);
            NexusComposeUi ui = compose(activity);
            long first = activity.nexusTaskId();
            require(first > 0, "No database-backed chat ID on initial launch");
            main(instrumentation, () -> {
                ui.openRight();
                ui.addPythonFile(FILE);
                require(ui.getPythonProjectIssue().isEmpty(), "UI file creation failed: " + ui.getPythonProjectIssue());
                ui.editPython(SOURCE);
                activity.nexusPythonFlushPending();
                ui.closePanel();
                activity.nexusOpenHistory();
                require(ui.getPage() == NexusComposeUi.Page.HISTORY, "History UI did not open");
                hasChat(activity, first, true);
                activity.nexusOpenTask(first);
                activity.nexusCreateTask();
            });
            awaitNewChat(instrumentation, activity, first);
            long second = activity.nexusTaskId();
            require(second != first, "Different chats share an identifier");
            main(instrumentation, () -> {
                require(!activity.nexusHasSavedPythonFiles(), "New chat inherited the old Python project");
                activity.nexusOpenHistory();
                hasChat(activity, first, true);
                require(SOURCE.equals(readSource(activity, first)), "First Python file was lost on switch");
            });
            require(checkpoint.edit().putLong("first", first).putLong("second", second).commit(),
                    "Failed to save the probe checkpoint");
            main(instrumentation, activity::finish);
        } else if (step.equals("python_verify")) {
            long first = checkpoint.getLong("first", 0);
            long second = checkpoint.getLong("second", 0);
            require(first > 0 && second > 0 && first != second, "Missing seed from previous Android process");
            MainActivity activity = launch(instrumentation);
            main(instrumentation, () -> {
                activity.nexusOpenHistory();
                hasChat(activity, first, true);
                require(SOURCE.equals(readSource(activity, first)), "File was lost after process restart");
                activity.nexusOpenTask(first);
            });
            awaitChatSwitch(instrumentation, activity, first);
            main(instrumentation, () -> {
                NexusComposeUi ui = uncheckedCompose(activity);
                require(ui.getPythonFileList().contains(FILE), "Compose did not restore original Python files");
                require(SOURCE.equals(activity.nexusPythonRead(FILE)), "Restored chat returned wrong file content");
                activity.nexusOpenTask(second);
            });
            awaitChatSwitch(instrumentation, activity, second);
            main(instrumentation, () -> {
                require(!activity.nexusHasSavedPythonFiles(), "Second chat inherited first chat files");
                activity.nexusDeleteTask(first);
                hasChat(activity, first, false);
            });
            require(checkpoint.edit().putBoolean("deleted", true).commit(), "Deletion checkpoint failed");
            main(instrumentation, activity::finish);
        } else if (step.equals("python_deleted")) {
            require(checkpoint.getBoolean("deleted", false), "Deletion step not completed");
            long first = checkpoint.getLong("first", 0);
            MainActivity activity = launch(instrumentation);
            main(instrumentation, () -> {
                activity.nexusOpenHistory();
                hasChat(activity, first, false);
                require(readSource(activity, first).isEmpty(), "Deleted chat's Python file came back");
            });
            main(instrumentation, activity::finish);
        } else throw new IllegalArgumentException("Unknown Python probe step: " + step);
    }

    private static NexusComposeUi uncheckedCompose(MainActivity activity) {
        try { return compose(activity); }
        catch (Exception e) { throw new AssertionError(e); }
    }

    private static String readSource(MainActivity activity, long taskId) {
        try {
            app.svyazka.mobile.PythonProjectStore files = new app.svyazka.mobile.PythonProjectStore(activity);
            return files.text(taskId, FILE);
        } catch (java.io.IOException e) { throw new AssertionError(e); }
    }
}
