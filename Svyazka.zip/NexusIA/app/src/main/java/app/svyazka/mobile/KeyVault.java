package app.svyazka.mobile;

import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class KeyVault implements CredentialStore {
    private static final String ALIAS = "svyazka.provider-credentials.v1";
    private static final int IV_LENGTH = 12;
    private static final String PISTON = "PISTON";
    private final SharedPreferences prefs;

    KeyVault(SharedPreferences prefs) { this.prefs = prefs; }

    @Override public String read(Workflow.Provider provider) throws GeneralSecurityException, IOException {
        return readNamed(provider.name());
    }

    @Override public String readPiston() throws GeneralSecurityException, IOException {
        return readNamed(PISTON);
    }

    private String readNamed(String name) throws GeneralSecurityException, IOException {
        String value = prefs.getString("key." + name, "");
        if (value.isEmpty()) return "";
        byte[] encoded;
        try {
            encoded = Base64.getDecoder().decode(value);
        } catch (IllegalArgumentException e) {
            throw new GeneralSecurityException("Invalid credential encoding", e);
        }
        if (encoded.length < IV_LENGTH + 16) throw new GeneralSecurityException("Invalid credential");
        ByteBuffer data = ByteBuffer.wrap(encoded);
        byte[] iv = new byte[IV_LENGTH];
        data.get(iv);
        byte[] sealed = new byte[data.remaining()];
        data.get(sealed);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, secretKey(false), new GCMParameterSpec(128, iv));
        cipher.updateAAD(name.getBytes(StandardCharsets.UTF_8));
        return new String(cipher.doFinal(sealed), StandardCharsets.UTF_8);
    }

    @Override public void save(String routerKey, String geminiKey, String groqKey, String pistonKey)
            throws GeneralSecurityException, IOException {
        SharedPreferences.Editor editor = prefs.edit();
        write(editor, Workflow.Provider.OPENROUTER.name(), routerKey);
        write(editor, Workflow.Provider.GEMINI.name(), geminiKey);
        write(editor, Workflow.Provider.GROQ.name(), groqKey);
        write(editor, PISTON, pistonKey);
        if (!editor.commit()) throw new IOException("Credential storage failed");
    }

    private void write(SharedPreferences.Editor editor, String name, String value)
            throws GeneralSecurityException, IOException {
        String prefKey = "key." + name;
        if (value.isEmpty()) {
            editor.remove(prefKey);
            return;
        }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey(true));
        cipher.updateAAD(name.getBytes(StandardCharsets.UTF_8));
        byte[] iv = cipher.getIV();
        if (iv.length != IV_LENGTH) throw new GeneralSecurityException("Invalid IV length");
        byte[] sealed = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        byte[] combined = ByteBuffer.allocate(iv.length + sealed.length).put(iv).put(sealed).array();
        editor.putString(prefKey, Base64.getEncoder().encodeToString(combined));
    }

    private SecretKey secretKey(boolean create) throws GeneralSecurityException, IOException {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(ALIAS)) return (SecretKey) store.getKey(ALIAS, null);
        if (!create) throw new GeneralSecurityException("Credential key missing");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,
                "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return generator.generateKey();
    }
}
