package app.svyazka.mobile;

/** One user-authorized Python invocation; callbacks are supplied by the platform adapter. */
interface PythonExecutor {
    void execute(String code, String stdin);
    /** Explicit user opt-in. Default keeps current sandbox behaviour. */
    default void execute(String code, String stdin, boolean loadMatplotlib) {
        execute(code, stdin);
    }
    void cancel();
}
