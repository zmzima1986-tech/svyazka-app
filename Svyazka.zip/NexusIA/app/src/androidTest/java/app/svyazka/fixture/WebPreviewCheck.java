package app.svyazka.fixture;

import android.app.Activity;
import app.svyazka.mobile.ui.WebWorkspaceKt;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.WebView;
import org.json.JSONTokener;
import java.io.InputStream;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Run the same shell and iframe as the workspace in a visible Android WebView. */
final class WebPreviewCheck {
    private static String asset(Context context, String name) throws Exception {
        try (InputStream stream = context.getAssets().open(name); Scanner input = new Scanner(stream, "UTF-8")) {
            return input.useDelimiter("\\A").next();
        }
    }

    static void run(Instrumentation test) throws Exception {
        Context app = test.getTargetContext();
        String code = asset(test.getContext(),"web-fixture.html");
        Intent launch = new Intent().setClassName(app.getPackageName(),"app.svyazka.mobile.MainActivity")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Activity host = test.startActivitySync(launch);
        Handler main = new Handler(Looper.getMainLooper());
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<WebView> surface = new AtomicReference<>();
        AtomicReference<Throwable> error = new AtomicReference<>();
        AtomicReference<String> stage = new AtomicReference<>("creating view");
        test.runOnMainSync(() -> {
            try {
                // The fixture signals from inside the same opaque frame that the Compose screen uses.
                WebView web = WebWorkspaceKt.createWebPreview(host, code, "html", true, report -> {
                    stage.set(report);
                    return kotlin.Unit.INSTANCE;
                });
                surface.set(web);
                host.addContentView(web,new ViewGroup.LayoutParams(-1,-1));
                main.post(new Runnable() {
                    @Override public void run() {
                        if (done.getCount()==0) return;
                        web.evaluateJavascript("if(!window.watching){window.watching=true;addEventListener('message',e=>{if(e.source===document.querySelector('iframe')?.contentWindow)window.fixtureResult=e.data})};window.fixtureResult || null", value -> {
                            if (value == null || "null".equals(value)) { main.postDelayed(this,250); return; }
                            try {
                                if (!"tick / isolated / offline".equals(new JSONTokener(value).nextValue()))
                                    throw new AssertionError(value);
                            } catch (Throwable failure) { error.set(failure); }
                            done.countDown();
                        });
                    }
                });
            } catch (Throwable failure) { error.set(failure); done.countDown(); }
        });
        try {
            if (!done.await(100, TimeUnit.SECONDS))
                throw new AssertionError("WebView timeout at " + stage.get());
            if (error.get()!=null) throw new AssertionError(error.get());
        } finally {
            done.countDown();
            test.runOnMainSync(() -> {
                WebView web = surface.get();
                if (web!=null) {
                    if (web.getParent() instanceof ViewGroup) ((ViewGroup)web.getParent()).removeView(web);
                    web.destroy();
                }
                host.finish();
            });
        }
    }
}
