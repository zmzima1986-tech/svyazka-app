#!/usr/bin/env bash
# Fresh disposable emulator; no release signing, real accounts or API keys.
set -euo pipefail
cd "$(dirname "$0")/.."
runs="${1:?Expected run count (1 or 3)}"
[[ "$runs" == 1 || "$runs" == 3 ]]
[[ "$(adb -e shell getprop ro.kernel.qemu | tr -d '\r')" == 1 ]]
report="$PWD/build/p0-evidence"
mkdir -p "$report"
app=app/build/outputs/apk/debug/app-debug.apk
test=app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
{
    git rev-parse HEAD
    sha256sum "$app" "$test"
    adb -e shell getprop ro.build.version.sdk
    adb -e shell getprop ro.build.fingerprint
} > "$report/environment.txt"
for ((i=1; i<=runs; i++)); do
    dir="$report/run-$i"
    mkdir -p "$dir"
    adb -e logcat -c
    rc=0
    NEXUS_ANDROID_REPORT_DIR="$dir" python3 -B scripts/test-android-python-history.py "$app" "$test" > "$dir/runner.log" 2>&1 || rc=$?
    printf '%s\n' "$rc" > "$dir/exit-code.txt"
    cat "$dir/runner.log"
    # Diagnostics after the run, not proof of WebView visibility.
    adb -e logcat -d -v threadtime > "$dir/logcat.txt" || echo 'Logcat unavailable' >&2
    adb -e exec-out screencap -p > "$dir/final-screen.png" || { rm -f "$dir/final-screen.png"; echo 'Screenshot unavailable' >&2; }
    if [[ "$rc" != 0 ]]; then exit "$rc"; fi
    if ((i<runs)); then
        adb -e uninstall app.svyazka.team.test
        adb -e uninstall app.svyazka.team
    fi
done
