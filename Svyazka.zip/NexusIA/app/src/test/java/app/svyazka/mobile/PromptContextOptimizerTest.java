package app.svyazka.mobile;

import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONObject;
import org.junit.Test;

public class PromptContextOptimizerTest {
    private static String longCode(String name) {
        StringBuilder text = new StringBuilder("# " + name + "\n");
        for (int i = 0; i < 80; i++) text.append("print('Привет").append(i).append("')\n");
        return text.toString();
    }

    private static JSONObject request(String task, String solution) throws Exception {
        return new JSONObject().put("task", task).put("inputs",
                new JSONObject().put("solution", new JSONObject().put("text", solution)));
    }

    @Test public void identicalLinkedFileIsReplacedByInRequestReference() throws Exception {
        String code = longCode("main.py");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Исправь проект", files, 100000);
        JSONObject payload = request(task, "```python file=main.py\n" + code + "```");
        int before = payload.toString().getBytes(StandardCharsets.UTF_8).length;
        PromptContextOptimizer.compact(payload);
        String optimized = payload.getString("task");
        assertTrue(optimized.contains("Exact copy of inputs.solution.text"));
        assertFalse(optimized.contains(code));
        assertTrue(payload.getJSONObject("inputs").getJSONObject("solution").getString("text").contains(code));
        assertTrue(before - payload.toString().getBytes(StandardCharsets.UTF_8).length > 512);
    }

    @Test public void changedLinkedFileMustRemainComplete() throws Exception {
        String code = longCode("first");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Исправь проект", files, 100000);
        JSONObject payload = request(task, "```python\n" + longCode("different") + "```");
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));
    }

    @Test public void preserveDifferentFileAndOnlyElideIdenticalOne() throws Exception {
        String first = longCode("first");
        String second = longCode("second");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", first.getBytes(StandardCharsets.UTF_8));
        files.put("module.py", second.getBytes(StandardCharsets.UTF_8));
        JSONObject payload = request(ChatProjectContext.append("Задача", files, 100000), first);
        PromptContextOptimizer.compact(payload);
        assertFalse(payload.getString("task").contains(first));
        assertTrue(payload.getString("task").contains(second));
    }

    @Test public void doNotElideTruncatedSource() throws Exception {
        String code = "print('x')\n".repeat(2000);
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Измени", files, 100000);
        JSONObject payload = request(task, code);
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));
        assertTrue(task.contains("truncated"));
    }

    @Test public void noProjectOrSolutionIsUnchanged() throws Exception {
        JSONObject payload = request("Простой вопрос", longCode("sample"));
        String before = payload.toString();
        PromptContextOptimizer.compact(payload);
        assertEquals(before, payload.toString());
        JSONObject withoutSolution = new JSONObject().put("task", "Задача").put("inputs", new JSONObject());
        assertEquals(withoutSolution.toString(), PromptContextOptimizer.compact(withoutSolution).toString());
    }

    @Test public void repairKeepsExactlyOneSourceAndEveryFilePath() throws Exception {
        String code = longCode("main");
        String extra = longCode("different module");
        JSONObject project = new JSONObject().put("main.py", code).put("utils.py", extra);
        JSONObject diagnostic = new JSONObject().put("python_code", code).put("complete_project", project);
        JSONObject payload = new JSONObject().put("task", "Исправь код")
                .put("inputs", new JSONObject().put("sandbox_result", diagnostic));
        String before = payload.toString();
        PromptContextOptimizer.compact(payload);
        assertEquals(code, diagnostic.getString("python_code"));
        assertTrue(project.getString("main.py").contains("Exact copy"));
        assertEquals(extra, project.getString("utils.py"));
        assertTrue(before.length() > payload.toString().length());
    }

    @Test public void repairDoesNotModifyNonidenticalProjectFile() throws Exception {
        String code = longCode("draft");
        JSONObject project = new JSONObject().put("main.py", longCode("different"));
        JSONObject diagnostic = new JSONObject().put("python_code", code).put("complete_project", project);
        String before = diagnostic.toString();
        PromptContextOptimizer.compact(new JSONObject().put("inputs",
                new JSONObject().put("sandbox_result", diagnostic)));
        assertEquals(before, diagnostic.toString());
    }

    @Test public void sameRequestCompactionIsIdempotent() throws Exception {
        String code = longCode("main.py");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        JSONObject payload = request(ChatProjectContext.append("Задача", files, 100000), code);
        PromptContextOptimizer.compact(payload);
        String once = payload.toString();
        PromptContextOptimizer.compact(payload);
        assertEquals(once, payload.toString());
    }

    @Test public void shortFileIsNeverReplacedWithLongReference() throws Exception {
        String code = "print('hello')\n";
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Задача", files, 100000);
        JSONObject payload = request(task, code);
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));
    }

    @Test public void unicodeMetadataUsesUtf8ByteOffsets() throws Exception {
        String code = "# ✅ 中文 Привет 🌍\n".repeat(50);
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        JSONObject payload = request(ChatProjectContext.append("Проверка", files, 100000), code);
        PromptContextOptimizer.compact(payload);
        assertTrue(payload.getString("task").contains("Exact copy of inputs.solution.text"));
        assertTrue(payload.getJSONObject("inputs").getJSONObject("solution").getString("text").contains(code));
    }

    @Test public void unknownProjectFormatIsUntouched() throws Exception {
        String malformed = "Задача\n\n<linked_python_project>\n--- main.py (not bytes) ---\nhello</linked_python_project>";
        JSONObject payload = request(malformed, "hello");
        PromptContextOptimizer.compact(payload);
        assertEquals(malformed, payload.getString("task"));
    }
}
