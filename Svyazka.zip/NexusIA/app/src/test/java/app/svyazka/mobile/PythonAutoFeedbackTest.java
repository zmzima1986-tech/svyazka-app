package app.svyazka.mobile;

import org.junit.Test;
import static org.junit.Assert.*;

/** Pure checks: never require a provider call or a real device. */
public final class PythonAutoFeedbackTest {
    private static String longText(int length) {
        char[] chars = new char[length];
        java.util.Arrays.fill(chars, 'x');
        return new String(chars);
    }
    @Test public void actualInterpreterFailureProducesOneBoundedDiagnostic() {
        String prompt = PythonAutoFeedback.prompt("Исправь программу", "main.py",
                "raise ValueError('broken')\n", 1,
                "Traceback (most recent call last):\nValueError: broken", "");
        assertTrue(PythonAutoFeedback.isFeedback(prompt));
        assertTrue(prompt.contains("Код завершения Python: 1"));
        assertTrue(prompt.contains("ValueError: broken"));
        assertTrue(prompt.contains("raise ValueError"));
        assertEquals("Исправь программу", TaskHistory.forRepair(prompt));
    }

    @Test public void successAndUnconfirmedRunNeverSendError() {
        assertEquals("", PythonAutoFeedback.prompt("Измени код", "main.py", "print(1)",
                0, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Измени код", "main.py", "print(1)",
                null, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Измени код", "main.py", "print(1)",
                1, "", ""));
    }

    @Test public void environmentLimitIsNotAnAIFix() {
        for (String error : new String[] { "ModuleNotFoundError: numpy",
                "PermissionError: denied", "network is unreachable", "timeout" }) {
            assertEquals(error, "", PythonAutoFeedback.prompt("Исправь код", "main.py",
                    "print(1)", 1, error, ""));
        }
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "main.py",
                "print(1)", 1, "ValueError: bad", "Time limit exceeded"));
    }

    @Test public void neverPassUnknownPathOrTruncatedCode() {
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "unknown.js",
                "print(1)", 1, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "../main.py",
                "print(1)", 1, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "main.py",
                longText(16001), 1, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "main.py",
                "print(1)", 1, longText(5001), ""));
    }

    @Test public void preSaveVerificationErrorAlsoReachesAIWithoutFakeExitCode() {
        String prompt = PythonAutoFeedback.verificationPrompt("Измени программу", "main.py",
                "print(unknown)\n", "NameError: name 'unknown' is not defined (строка 1)");
        assertTrue(PythonAutoFeedback.isFeedback(prompt));
        assertTrue(prompt.contains("Ошибка локальной проверки"));
        assertFalse(prompt.contains("Код завершения Python: 1"));
        assertEquals("Измени программу", TaskHistory.forRepair(prompt));
        assertFalse(PythonAutoStage.requested(prompt));
    }

    @Test public void preSaveUnsupportedDependencyDoesNotTriggerModel() {
        assertEquals("", PythonAutoFeedback.verificationPrompt("Измени программу", "main.py",
                "import lost_package", "ModuleNotFoundError: No module named lost_package"));
    }

    @Test public void verifiedZeroDivisionWithAliasedMainPyRoutesOneDiagnostic() throws Exception {
        String user = "Измени подключённый main.py. Добавь в main() строку print(1 / 0).";
        String code = "# src/main.py\ndef main() -> None:\n    print(1 / 0)\n\n"
                + "if __name__ == \"__main__\":\n    main()\n";
        String answer = "Python – src/main.py\n\n```python\n" + code + "```";
        PythonVerification check = PythonVerification.NONE.start(0, "\n" + code)
                .report(new org.json.JSONObject()
                        .put("status", "ERROR").put("syntax", true).put("ran", true)
                        .put("passed", 0).put("total", 0)
                        .put("diagnostic", "ZeroDivisionError: division by zero (строка 3)")
                        .put("signature", "zero-division").put("category", "RUNTIME_ERROR"));
        String prompt = PythonAutoFeedback.verifiedPrompt(user, user, answer,
                new String[] { "main.py" }, check);
        assertTrue(prompt, PythonAutoFeedback.isFeedback(prompt));
        assertTrue(prompt.contains("Имя файла: main.py"));
        assertTrue(prompt.contains("ZeroDivisionError"));
        assertTrue(prompt.contains("print(1 / 0)"));
    }

    @Test public void verificationFeedbackRejectsStaleOrAmbiguousSource() throws Exception {
        String code = "# main.py\nprint(1 / 0)\n";
        PythonVerification check = PythonVerification.NONE.start(0, "\n" + code)
                .report(new org.json.JSONObject()
                        .put("status", "ERROR").put("syntax", true).put("ran", true)
                        .put("passed", 0).put("total", 0)
                        .put("diagnostic", "ZeroDivisionError: division by zero (строка 2)")
                        .put("signature", "zero-division").put("category", "RUNTIME_ERROR"));
        String task = "Измени main.py";
        assertEquals("", PythonAutoFeedback.verifiedPrompt(task, task,
                "```python\n# main.py\nprint(2 / 0)\n```",
                new String[] { "main.py" }, check));
        assertEquals("", PythonAutoFeedback.verifiedPrompt(task, task,
                "```python\n" + code + "```\n```python\nprint(2)\n```",
                new String[] { "main.py" }, check));
        assertEquals("", PythonAutoFeedback.verifiedPrompt(task, task,
                "```python\n" + code + "```", new String[] { "other.py" }, check));
        assertEquals("", PythonAutoFeedback.verifiedPrompt("Измени main.py, но не запускай",
                "Измени main.py, но не запускай", "```python\n" + code + "```",
                new String[] { "main.py" }, check));
    }

    @Test public void verifiedNamedFileRoutesOnlyItsOwnCode() throws Exception {
        String code = "print(1 / 0)\n";
        PythonVerification check = PythonVerification.NONE.start(0, "\n" + code)
                .report(new org.json.JSONObject()
                        .put("status", "ERROR").put("syntax", true).put("ran", true)
                        .put("passed", 0).put("total", 0)
                        .put("diagnostic", "ZeroDivisionError: division by zero")
                        .put("signature", "zero-division").put("category", "RUNTIME_ERROR"));
        String user = "Измени код src/main.py";
        String prompt = PythonAutoFeedback.verifiedPrompt(user, user,
                "```python file=src/main.py\n" + code + "```",
                new String[] { "src/main.py", "src/util.py" }, check);
        assertTrue(PythonAutoFeedback.isFeedback(prompt));
        assertTrue(prompt.contains("Имя файла: src/main.py"));
        assertEquals("", PythonAutoFeedback.verifiedPrompt(user, user,
                "```python file=src/unknown.py\n" + code + "```",
                new String[] { "src/main.py", "src/util.py" }, check));
    }

    @Test public void errorAnswerNeverAutomaticallyEditsProject() {
        String prompt = PythonAutoFeedback.prompt("Исправь код", "main.py",
                "print(unknown)\n", 1, "NameError: unknown", "");
        assertFalse(PythonAutoStage.requested(prompt));
        assertEquals("", PythonAutoFeedback.prompt(prompt, "main.py",
                "print(unknown)", 1, "NameError: unknown", ""));
    }
}
