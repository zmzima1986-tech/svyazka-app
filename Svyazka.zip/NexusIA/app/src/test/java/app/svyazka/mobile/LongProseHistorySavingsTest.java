package app.svyazka.mobile;

import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.junit.Assert.*;
import org.junit.Test;

/** Prose-only follow-ups save instructions, not source, user requirements or history. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 33)
public final class LongProseHistorySavingsTest {
    private static Workflow.Run quick(String task) {
        return Workflow.Run.quick(task, ModelCatalog.GROQ_120B,
                Workflow.defaultStages().get(Workflow.Step.REVIEW.ordinal()));
    }

    @Test public void longProseConversationRetainsEveryUniqueUserRequest() throws Exception {
        String history = "Напиши список из 5 способов экономить батарею Android.";
        for (int i = 1; i <= 12; i++) {
            history = TaskHistory.followUp(history,
                    "1. Уменьши яркость.\n2. Включи энергосбережение.",
                    "Добавь самостоятельный совет номер " + i + " и не удаляй предыдущие.");
        }
        Workflow.Run r = quick(history);
        String requirements = TaskHistory.forRepair(history);
        for (int i = 1; i <= 12; i++) {
            assertTrue(requirements.contains("Добавь самостоятельный совет номер " + i));
        }
        assertTrue(r.plainTextInstructionBytesSaved() > 682);
        assertFalse(r.instructions().contains("data-nexus"));
        assertFalse(r.instructions().contains("file=src/main.py"));
        assertTrue(r.instructions().contains("Сохраняй прежние требования пользователя"));
        assertTrue(r.instructions().contains("Не выдумывай данные"));
        assertTrue(r.unoptimizedInstructions().contains("file=src/main.py"));
        assertEquals(history, r.task);
        assertTrue(r.prompt().contains("Добавь самостоятельный совет номер 12"));
        assertTrue(r.prompt().contains("1. Уменьши яркость"));
        ModelClient.InputComparison comparison = ModelClient.compareInput(r);
        assertEquals(r.plainTextInstructionBytesSaved(),
                comparison.textBytesBefore - comparison.textBytesAfter);
    }

    @Test public void implementationAddedToFollowUpRestoresFullInstructions() {
        String history = TaskHistory.followUp("Напиши список советов по Android.",
                "1. Включи энергосбережение.",
                "Теперь создай Android-приложение с исходным кодом.");
        Workflow.Run r = quick(history);
        assertEquals(0, r.plainTextInstructionBytesSaved());
        assertTrue(r.instructions().contains("file=src/main.py"));
        assertTrue(r.instructions().contains("data-nexus"));
    }

    @Test public void consolePythonKeepsAllCodeAndVerifierInstructions() {
        Workflow.Run r = quick("Создай на Python программу для консоли [console].");
        assertTrue(r.instructions().contains("file=src/main.py"));
        assertTrue(r.instructions().contains("technical_checks"));
        assertEquals(0, r.plainTextInstructionBytesSaved());
    }

    @Test public void ambiguousLongRequestKeepsOriginalInstructions() {
        String task = "Объясни " + "всё ".repeat(4000);
        Workflow.Run r = quick(task);
        assertEquals(0, r.plainTextInstructionBytesSaved());
        assertEquals(r.unoptimizedInstructions(), r.instructions());
    }
}
