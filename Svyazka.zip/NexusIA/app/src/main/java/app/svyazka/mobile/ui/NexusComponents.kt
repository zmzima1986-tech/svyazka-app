package app.svyazka.mobile.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.R

@Composable
fun NexusTopBar(ui: NexusComposeUi) {
    val title = when (ui.page) {
        NexusComposeUi.Page.TASK -> stringResource(R.string.app_name)
        NexusComposeUi.Page.RESULT -> stringResource(R.string.result_title)
        NexusComposeUi.Page.MODELS -> stringResource(R.string.models_title)
        NexusComposeUi.Page.HISTORY -> stringResource(R.string.history_title)
        NexusComposeUi.Page.SETTINGS -> stringResource(R.string.settings_title)
    }
    Surface(modifier = Modifier.statusBarsPadding(),
        color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
        Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically) {
            if (ui.page == NexusComposeUi.Page.TASK) {
                Image(painterResource(R.drawable.ic_nexus), null, Modifier.size(43.dp))
                Spacer(Modifier.width(10.dp))
                Text("Nexus", style = MaterialTheme.typography.titleLarge)
                Text(" IA", style = MaterialTheme.typography.titleLarge, color = NexusCyan)
            } else {
                IconButton(onClick = { ui.navigateBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.action_back))
                }
                Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            }
            if (ui.page == NexusComposeUi.Page.TASK) {
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { ui.open(NexusComposeUi.Page.SETTINGS) }) {
                    Icon(Icons.Outlined.Settings, stringResource(R.string.settings_title))
                }
            }
        }
    }
}

@Composable
fun NexusCard(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val stroke = BorderStroke(if (highlighted) 1.4.dp else 0.8.dp,
        if (highlighted) NexusCyan else MaterialTheme.colorScheme.outline.copy(alpha = .55f))
    if (onClick == null) {
        Surface(modifier = modifier, shape = shape, color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp, border = stroke) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Surface(onClick = onClick, modifier = modifier, shape = shape,
            color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp,
            border = stroke) { Column(Modifier.padding(16.dp), content = content) }
    }
}

@Composable
fun NexusLabel(text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Text(text, color = color, style = MaterialTheme.typography.bodyMedium)
}

@Composable
fun StatusPill(label: String, success: Boolean = false) {
    val foreground = if (success) Color(0xFF12C89A) else MaterialTheme.colorScheme.primary
    Surface(shape = RoundedCornerShape(50),
        color = foreground.copy(alpha = .11f),
        border = BorderStroke(1.dp, foreground.copy(alpha = .40f))) {
        Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            color = foreground, style = MaterialTheme.typography.labelLarge)
    }
}

/** No HTML rendering and no network. Plain text, headings, fences and common Markdown spans. */
internal data class MarkdownBlock(val kind: String, val value: String)

internal fun parseMarkdown(source: String): List<MarkdownBlock> {
    val out = ArrayList<MarkdownBlock>()
    val lines = source.replace("\r\n", "\n").split('\n')
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trimStart()
        if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
            val marker = trimmed.takeWhile { it == trimmed[0] }
            val code = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trimStart().startsWith(marker)) {
                if (code.isNotEmpty()) code.append('\n')
                code.append(lines[i]); i++
            }
            out.add(MarkdownBlock("code", code.toString()))
        } else if (trimmed.startsWith("#") && trimmed.takeWhile { it == '#' }.length in 1..6 &&
            trimmed.dropWhile { it == '#' }.startsWith(' ')) {
            out.add(MarkdownBlock("heading", trimmed.dropWhile { it == '#' }.trim()))
        } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ") ||
            Regex("^\\d+[.)] ").containsMatchIn(trimmed)) {
            out.add(MarkdownBlock("bullet", trimmed))
        } else if (line.isNotBlank()) {
            out.add(MarkdownBlock("body", line))
        } else if (out.isNotEmpty() && out.last().kind != "space") {
            out.add(MarkdownBlock("space", ""))
        }
        i++
    }
    return out
}

internal fun inlineMarkup(source: String) = buildAnnotatedString {
    val pattern = Regex("(`[^`\\n]+`|\\*\\*[^*\\n]+\\*\\*|\\*[^*\\n]+\\*)")
    var previous = 0
    pattern.findAll(source).forEach { match ->
        append(source.substring(previous, match.range.first))
        val word = match.value
        when {
            word.startsWith("**") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                append(word.drop(2).dropLast(2))
            }
            word.startsWith('`') -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace)) {
                append(word.drop(1).dropLast(1))
            }
            else -> withStyle(SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)) {
                append(word.drop(1).dropLast(1))
            }
        }
        previous = match.range.last + 1
    }
    append(source.substring(previous))
}

@Composable
fun NexusMarkdown(markdown: String) {
    val blocks = remember(markdown) { parseMarkdown(markdown) }
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            blocks.forEach { block ->
                when (block.kind) {
                    "code" -> Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.background,
                        border = BorderStroke(.7.dp, MaterialTheme.colorScheme.outline.copy(alpha = .5f))
                    ) {
                        Text(block.value, Modifier.fillMaxWidth().padding(12.dp),
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    "heading" -> Text(inlineMarkup(block.value),
                        style = MaterialTheme.typography.titleLarge)
                    "bullet" -> Text(inlineMarkup(block.value),
                        style = MaterialTheme.typography.bodyMedium)
                    "space" -> Spacer(Modifier.height(4.dp))
                    else -> Text(inlineMarkup(block.value), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
