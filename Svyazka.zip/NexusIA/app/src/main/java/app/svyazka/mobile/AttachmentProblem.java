package app.svyazka.mobile;

import java.io.IOException;

/** Stable, localizable diagnostics for input materials; never contains credentials. */
public final class AttachmentProblem extends IOException {
    public enum Code {
        FILE_COUNT, FILE_SIZE, TOTAL_SIZE, TEXT_SIZE, REQUEST_TEXT_SIZE, IMAGE_PIXELS, PACKAGE_SIZE, ZIP_COUNT, ZIP_PATH, ZIP_RATIO,
        UNSUPPORTED, ENCODING, NOT_TEXT, CORRUPT, DOCX_STRUCTURE, DOCX_SCOPE, PDF_SCOPE, PDF_NO_TEXT,
        PDF_LOCKED, PDF_PAGES, PDF_PAGE_EMPTY, NESTED_ARCHIVE, BINARY_ENTRY, IO, INTERRUPTED,
        NOT_READY, MODEL_IMAGES, MODEL_CONTEXT, UNKNOWN_CONTEXT, HTTP_SIZE, IMAGE_SIZE,
        IMAGE_INVALID, MISSING, INTEGRITY, LOADING
    }
    public final Code code;
    public final String detail;
    public AttachmentProblem(Code code, String detail) {
        super(code.name() + (detail.isEmpty() ? "" : ": " + detail));
        this.code = code;
        this.detail = detail;
    }
    public AttachmentProblem(Code code) { this(code, ""); }
}
