"""Check installation and draft preservation on a disposable Android emulator."""
import re
import subprocess
import sys
import time
import uuid
import xml.etree.ElementTree as ET
from pathlib import Path

PACKAGE = "app.svyazka.team"
ACTIVITY = PACKAGE + "/app.svyazka.mobile.MainActivity"


def adb(*args, timeout=120):
    return subprocess.check_output(["adb", "-e", *map(str, args)], text=True, timeout=timeout)


def wait_for_ui(predicate):
    deadline = time.monotonic() + 150
    while time.monotonic() < deadline:
        try:
            adb("shell", "uiautomator", "dump", "/data/local/tmp/nexus-upgrade-ui.xml", timeout=30)
            xml = adb("shell", "cat", "/data/local/tmp/nexus-upgrade-ui.xml", timeout=15)
            match = next((n for n in ET.fromstring(xml).iter("node") if predicate(n)), None)
            if match is not None:
                return match
        except (subprocess.SubprocessError, ET.ParseError):
            pass
        time.sleep(1)
    raise RuntimeError("Expected content was not visible in the Android UI")


def install(apk):
    target = "/data/local/tmp/nexus-upgrade-test.apk"
    print("Transferring", Path(apk).name, flush=True)
    adb("push", apk, target, timeout=180)
    print("Installing", Path(apk).name, flush=True)
    result = adb("shell", "pm", "install", "-r", target, timeout=300)
    if "Success" not in result:
        raise RuntimeError(result)
    info = adb("shell", "dumpsys", "package", PACKAGE)
    version = int(re.search(r"versionCode=(\d+)", info).group(1))
    print("Installed versionCode", version, flush=True)
    return version


def fixture(step):
    runner = "app.svyazka.team.test/app.svyazka.fixture.UpgradeProbe"
    result = adb("shell", "am", "instrument", "-w", "-e", "step", step, runner, timeout=300)
    expected = {"seed": "NEXUS_PROBE_SEEDED", "verify": "NEXUS_PROBE_RESTORED", "web": "NEXUS_WEBVIEW_TESTED"}[step]
    if expected not in result:
        raise RuntimeError(result)


def main(previous, update, test_apk=None):
    assert Path(previous).is_file() and Path(update).is_file()
    assert adb("shell", "getprop", "ro.kernel.qemu").strip() == "1", "Select a test emulator"
    earlier = install(previous)
    if test_apk:
        adb("install", "-r", "-t", test_apk, timeout=240)
        fixture("seed")
        newer = install(update)
        assert newer > earlier
        fixture("verify")
        fixture("web")
        adb("shell", "am", "start", "-n", ACTIVITY)
        print("Update from", earlier, "to", newer, "preserved the chat, saved version and encrypted test key")
        return
    adb("shell", "input", "keyevent", "KEYCODE_WAKEUP")
    adb("shell", "wm", "dismiss-keyguard")
    adb("shell", "am", "start", "-n", ACTIVITY)
    node = wait_for_ui(lambda n: n.get("class") == "android.widget.EditText")
    left, top, right, bottom = map(int, re.findall(r"\d+", node.get("bounds")))
    adb("shell", "input", "tap", (left + right)//2, (top + bottom)//2)
    marker = "NexusUpgrade" + uuid.uuid4().hex[:10]
    adb("shell", "input", "text", marker)
    wait_for_ui(lambda n: marker in n.get("text", ""))
    adb("shell", "input", "keyevent", "KEYCODE_HOME")
    time.sleep(2)
    newer = install(update)
    assert newer > earlier
    adb("shell", "am", "start", "-n", ACTIVITY)
    wait_for_ui(lambda n: marker in n.get("text", ""))
    print("Update from", earlier, "to", newer, "preserved the draft", flush=True)


if __name__ == "__main__":
    main(*sys.argv[1:])
