"""Exercise inventory detection independently of the repository's reference file."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('source_integrity', ROOT / 'scripts/check-source-integrity.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class SourceIntegrityTests(unittest.TestCase):
    def test_changed_extra_missing_and_exclusions(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in ('a.txt', 'b.txt'):
                (root / name).write_text(name)
            before = module.inventory(root)
            (root / 'a.txt').write_text('changed')
            (root / 'b.txt').unlink()
            (root / 'c.txt').write_text('extra')
            (root / 'build').mkdir()
            (root / 'build/cache').write_text('generated')
            (root / 'local.properties').write_text('private')
            (root / 'docs').mkdir()
            (root / module.MANIFEST).write_text('self')
            self.assertEqual(module.differences(before, module.inventory(root)),
                             (['b.txt'], ['c.txt'], ['a.txt']))

    def test_unsafe_and_duplicate_paths(self):
        digest = 'a' * 64
        for name in ('../x', '/x', 'a/../x', 'a//x', module.MANIFEST, 'local.properties'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                module.parse_manifest(f'{digest}  {name}\n')
        with self.assertRaises(ValueError):
            module.parse_manifest(f'{digest}  x\n{digest}  x\n')
        self.assertEqual(module.parse_manifest(f'{digest}  x\n'), {'x': digest})


if __name__ == '__main__':
    unittest.main()
