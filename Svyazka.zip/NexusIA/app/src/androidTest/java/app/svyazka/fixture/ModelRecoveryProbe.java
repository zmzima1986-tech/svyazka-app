package app.svyazka.fixture;

import java.io.BufferedReader;
import java.io.StringReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Offline replay through the real model stream parser, workflow and routing policies.
 * No credentials, network, injected success reports or production hooks. */
public final class ModelRecoveryProbe {
    private static final String BASE = "app.svyazka.mobile.";
    private final ClassLoader loader;
    private ModelRecoveryProbe(ClassLoader loader) { this.loader = loader; }

    private Class<?> type(String name) throws Exception { return Class.forName(BASE + name, true, loader); }
    private static Object call(Class<?> owner, Object target, String name, Class<?>[] types, Object... args) throws Exception {
        Method method = owner.getDeclaredMethod(name, types);
        method.setAccessible(true);
        return method.invoke(target, args);
    }
    private static Object field(Class<?> owner, Object target, String name) throws Exception {
        Field field = owner.getDeclaredField(name);
        field.setAccessible(true);
        return field.get(target);
    }
    private static Object create(Class<?> owner, Class<?>[] types, Object... args) throws Exception {
        Constructor<?> constructor = owner.getDeclaredConstructor(types);
        constructor.setAccessible(true);
        return constructor.newInstance(args);
    }
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    private static final Class<?>[] NONE = new Class<?>[0];
    private static String event(String text, String finish) throws Exception {
        return "data: " + new JSONObject().put("choices", new JSONArray().put(new JSONObject()
                .put("delta", new JSONObject().put("content", text))
                .put("finish_reason", finish == null ? JSONObject.NULL : finish))) + "\n\n";
    }
    private Object stream(String text) throws Exception {
        return call(type("ModelClient"), null, "parseRouterStream", new Class<?>[]{BufferedReader.class},
                new BufferedReader(new StringReader(text)));
    }
    private JSONObject json(Object run) throws Exception {
        return (JSONObject) call(type("Workflow$Run"), run, "toJson", NONE);
    }
    private Object restore(Object run) throws Exception {
        return call(type("Workflow$Run"), null, "fromJson", new Class<?>[]{JSONObject.class},
                new JSONObject(json(run).toString()));
    }
    private Object receive(Object run, Object reply) throws Exception {
        return call(type("Workflow$Run"), run, "receive", new Class<?>[]{type("ModelClient$Reply")}, reply);
    }
    private boolean fallback(Object reply) throws Exception {
        return (Boolean) call(type("ModelPool"), null, "shouldTryNext", new Class<?>[]{type("ModelClient$Reply")}, reply);
    }
    private void recovery() throws Exception {
        Class<?> runType = type("Workflow$Run"), replyType = type("ModelClient$Reply");
        Class<?> catalogType = type("ModelCatalog"), modelType = type("ModelCatalog$Model");
        String task = "Создай программу из трёх файлов: main.py, lib.py и test_lib.py. Проверь.";
        String main = "```file=main.py\nprint(1)\n```\n";
        String lib = "```file=lib.py\nx=1\n```\n";
        String tests = "```file=test_lib.py\nassert True\n```\n";
        String prefix = main + "```file=lib.py\nx=";
        for (String end : new String[]{"", "data: [DONE]\n\n", "data: {\"error\":{\"code\":429}}\n\n", "length"}) {
            Object run = create(runType, new Class<?>[]{String.class, List.class}, task,
                    call(type("Workflow"), null, "defaultStages", NONE));
            Object interrupted = stream("length".equals(end) ? event(prefix, "length") : event(prefix, null) + end);
            check(prefix.equals(field(replyType, interrupted, "text")), "Lost streamed prefix");
            check(field(replyType, interrupted, "finish").toString().equals("length".equals(end) ? "LENGTH" : "ERROR"),
                    "Incomplete stream accepted as finished");
            check(fallback(interrupted) == !"length".equals(end), "Wrong stream fallback policy");
            run = restore(receive(run, interrupted));
            JSONObject saved = json(run);
            check(!saved.getBoolean("complete") && saved.getJSONArray("answers").length() == 0
                    && prefix.equals(saved.getJSONObject("draft").getString("text")), "Draft lost or prematurely accepted");
            Object reserve = field(catalogType, null, "FLINT");
            run = call(runType, run, "restartForRecovery", NONE);
            run = call(runType, run, "withExecutor", new Class<?>[]{modelType, String.class}, reserve, "fixture");
            run = restore(run);
            JSONObject stage = json(run).getJSONArray("stages").getJSONObject(0);
            check(stage.getString("model").equals(field(modelType, field(catalogType, null, "LING"), "id"))
                    && stage.getString("executor").equals(field(modelType, reserve, "id")), "Reserve changed selected model");
            JSONObject body = (JSONObject) call(type("ModelClient"), null, "routerBody", new Class<?>[]{runType, modelType}, run, reserve);
            check(body.getJSONArray("messages").length() == 2, "Unsafe fragment appended to reserve prompt");
            JSONObject price = body.getJSONObject("provider").getJSONObject("max_price");
            check(price.getInt("prompt") == 0 && price.getInt("completion") == 0 && price.getInt("request") == 0,
                    "Paid OpenRouter fallback allowed");
            Object rejected = receive(run, stream(event(lib, "stop")));
            check(json(rejected).getJSONArray("answers").length() == 0, "Incomplete replacement accepted");
            Object recovered = receive(rejected, stream(event(lib + tests, "stop")));
            JSONObject solved = json(recovered);
            check(solved.getJSONArray("answers").length() == 1 && !solved.getBoolean("complete"), "Recovery skipped review");
            String accepted = solved.getJSONArray("answers").getJSONObject(0).getString("text");
            Object files = call(type("PythonInputs"), null, "namedFiles", new Class<?>[]{String.class}, accepted);
            check(files instanceof java.util.Map && ((java.util.Map<?,?>) files).size() == 3
                    && "print(1)\n".equals(((java.util.Map<?,?>) files).get("main.py")), "Recovered files changed or lost");
            Object review = restore(receive(recovered, stream(event("Partial review", null))));
            check(json(review).getJSONArray("answers").length() == 1 && !json(review).getBoolean("complete"), "Interrupted review advanced role");
            review = call(runType, review, "restartForRecovery", NONE);
            JSONObject result = json(receive(review, stream(event("Checked.\n[[REVIEW: PASS]]", "stop"))));
            check(result.getBoolean("complete") && result.getBoolean("revision_skipped")
                    && accepted.equals(result.getJSONArray("answers").getJSONObject(0).getString("text")), "Recovered review changed accepted solution");
        }
    }
    private void routing() throws Exception {
        Class<?> failure = type("RequestFailure"), reply = type("ModelClient$Reply"), model = type("ModelCatalog$Model");
        Class<?> catalog = type("ModelCatalog"), cooldownType = type("ModelPool$Cooldowns");
        long now = 1_800_000_000_000L;
        for (int status : new int[]{401, 403, 402, 400, 404, 408, 429, 500, 502, 503, 504}) {
            Object error = call(reply, null, "error", new Class<?>[]{String.class, String.class, int.class}, "", "fixture", status);
            check(fallback(error) == (status == 408 || status == 429 || status >= 500), "Wrong retry for HTTP " + status);
        }
        Object route = call(failure, null, "read", new Class<?>[]{int.class, JSONObject.class, String.class, long.class},
                429, new JSONObject().put("metadata", new JSONObject().put("provider_name", "fixture")), "30", now);
        Object quota = call(failure, null, "of", new Class<?>[]{int.class}, 429);
        quota = call(failure, quota, "dailyQuota", new Class<?>[]{long.class}, now);
        Object first = field(catalog, null, "LING"), second = field(catalog, null, "NEMOTRON"), third = field(catalog, null, "GROQ_20B");
        Object cooldown = create(cooldownType, NONE);
        List<Object> models = Arrays.asList(first, second, third);
        Class<?>[] record = {model, failure, long.class};
        Class<?>[] next = {List.class, int.class, long.class};
        call(cooldownType, cooldown, "record", record, first, route, now);
        check((Integer) call(cooldownType, cooldown, "next", next, models, 0, now) == 1, "429 route cooldown not respected");
        check((Integer) call(cooldownType, cooldown, "next", next, models, 0, now + 30_000) == 0, "Retry-After not released");
        call(cooldownType, cooldown, "record", record, second, quota, now);
        String snapshot = (String) call(cooldownType, cooldown, "snapshot", new Class<?>[]{long.class}, now);
        cooldown = create(cooldownType, NONE);
        call(cooldownType, cooldown, "restore", new Class<?>[]{String.class, long.class}, snapshot, now);
        check((Integer) call(cooldownType, cooldown, "next", next, models, 0, now) == 2, "Daily quota not retained across restore");
        Object starter = call(catalog, null, "starter", NONE);
        Object step = field(type("Workflow$Step"), null, "SOLUTION");
        Class<?>[] args = {catalog, type("Workflow$Step"), model, boolean.class, boolean.class, boolean.class, boolean.class};
        List<?> candidates = (List<?>) call(type("ModelPool"), null, "candidates", args, starter, step, first, true, true, false, true);
        for (Object item : candidates) check(field(model, item, "provider").toString().equals("OPENROUTER"), "Unapproved provider reserve");
    }
    private void limits() throws Exception {
        Class<?> budget = type("AutonomyQuotaGuard$Session"), recovery = type("AutonomyQuotaGuard$Recovery");
        long now = 1000;
        Object session = create(budget, new Class<?>[]{long.class}, now);
        Class<?>[] reserve = {long.class, long.class};
        for (int i=0;i<18;i++) check((Boolean) call(budget, session, "reserve", reserve, now, 100L), "Premature request limit");
        check(!(Boolean) call(budget, session, "reserve", reserve, now, 100L), "Request budget exceeded");
        session = create(budget, new Class<?>[]{long.class}, now);
        check((Boolean) call(budget, session, "reserve", reserve, now, 180000L)
                && !(Boolean) call(budget, session, "reserve", reserve, now, 1L), "Token budget exceeded");
        session = create(budget, new Class<?>[]{long.class}, now);
        check(!(Boolean) call(budget, session, "reserve", reserve, now+600000, 1L), "Time budget exceeded");
        Object policy = create(recovery, NONE);
        Class<?>[] retry = {String.class, String.class};
        check(call(recovery, policy, "next", retry, "A", "same").toString().equals("RETRY"), "First retry denied");
        check(call(recovery, policy, "next", retry, "A", "same").toString().equals("SWITCH"), "Repeated failure not switched");
        check(call(recovery, policy, "next", retry, "B", "same").toString().equals("STOP"), "Repeated failure not stopped");
    }
    static void run(ClassLoader loader) throws Exception {
        ModelRecoveryProbe probe = new ModelRecoveryProbe(loader);
        probe.recovery();
        probe.routing();
        probe.limits();
    }
    public static void main(String[] args) throws Exception {
        run(ModelRecoveryProbe.class.getClassLoader());
        System.out.println("ModelRecoveryProbe: PASS");
    }
}
