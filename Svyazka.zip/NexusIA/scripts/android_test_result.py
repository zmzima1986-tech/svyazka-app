"""Accept only an unambiguous successful Android instrumentation result."""


def require_result(output, marker, step):
    lines = [line.strip() for line in output.splitlines()]
    codes = [line for line in lines if line.startswith('INSTRUMENTATION_CODE:')]
    streams = [line for line in lines if line.startswith('INSTRUMENTATION_RESULT: stream=')]
    if (codes != ['INSTRUMENTATION_CODE: -1']
            or streams != ['INSTRUMENTATION_RESULT: stream=' + marker]
            or any('FAILURES' in line or line.startswith('INSTRUMENTATION_FAILED:') for line in lines)):
        raise RuntimeError(f'{step} failed:\n{output}')
