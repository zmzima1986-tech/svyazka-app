package app.svyazka.mobile;

import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class PythonChatHistoryTest {
    @Test public void pythonOnlyChatAppearsInHistoryWithoutAiMessage() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository repository = new TaskRepository(context)) {
            long id = repository.create("");
            assertTrue(repository.list().stream().noneMatch(item -> item.id == id));
            PythonProjectStore projects = new PythonProjectStore(context);
            projects.putText(id, "test.py", "print(10)\n");
            repository.markPythonProject(id, "test.py", true);
            TaskRepository.Entry recorded = repository.load(id);
            assertEquals("", recorded.task);
            assertEquals("Python · test.py", recorded.title);
            assertTrue(repository.list().stream().anyMatch(item -> item.id == id));
        }
    }

    @Test public void olderHiddenPythonChatIsRecoveredAfterRestart() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        long id;
        PythonProjectStore projects = new PythonProjectStore(context);
        try (TaskRepository repository = new TaskRepository(context)) {
            id = repository.create("");
            projects.putText(id, "main.py", "print('kept')\n");
            assertTrue(repository.list().stream().noneMatch(item -> item.id == id));
        }
        try (TaskRepository repository = new TaskRepository(context)) {
            repository.recoverPythonProjects(projects);
            assertTrue(repository.list().stream().anyMatch(item -> item.id == id));
            assertEquals("Python · main.py", repository.load(id).title);
            assertEquals("print('kept')\n", projects.text(id, "main.py"));
        }
    }

    @Test public void noEmptyChatOrForeignTitleIsAddedToHistory() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository repository = new TaskRepository(context)) {
            long empty = repository.create("");
            repository.recoverPythonProjects(new PythonProjectStore(context));
            assertTrue(repository.list().stream().noneMatch(item -> item.id == empty));
            long custom = repository.create("");
            assertTrue(repository.rename(custom, "Мой проект"));
            PythonProjectStore projects = new PythonProjectStore(context);
            projects.putText(custom, "main.py", "print(42)");
            repository.markPythonProject(custom, "main.py", true);
            assertEquals("Мой проект", repository.load(custom).title);
        }
    }
}
