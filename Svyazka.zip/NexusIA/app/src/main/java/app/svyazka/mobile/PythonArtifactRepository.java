package app.svyazka.mobile;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Durable artifact catalog, independent of the chat database and API providers. */
final class PythonArtifactRepository extends SQLiteOpenHelper {
    private static final String DATABASE = "nexus_python_artifacts.db";
    private static final String DEFAULT_TITLE = "Python-проект";

    PythonArtifactRepository(Context context) {
        super(context.getApplicationContext(), DATABASE, null, 3);
    }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "title TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, "
                + "legacy_chat_id INTEGER UNIQUE, deleted INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE chat_projects (chat_id INTEGER PRIMARY KEY, "
                + "project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE, "
                + "private_copy INTEGER NOT NULL DEFAULT 0, "
                + "connected INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE INDEX projects_recent ON projects(deleted, updated_at DESC)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion == 1) {
            // Existing shared links remain unsafe until isolated by the existing migration.
            db.execSQL("ALTER TABLE chat_projects ADD COLUMN private_copy INTEGER NOT NULL DEFAULT 0");
            oldVersion = 2;
        }
        if (oldVersion == 2) {
            // A disabled chat keeps its private project assignment for reconnection.
            db.execSQL("ALTER TABLE chat_projects ADD COLUMN connected INTEGER NOT NULL DEFAULT 1");
            tidyOldGeneratedTitles(db);
            return;
        }
        throw new IllegalStateException("Unknown artifact database schema: " + oldVersion);
    }

    /** Only fix machine-generated numeric suffixes, never user-chosen titles. */
    private static void tidyOldGeneratedTitles(SQLiteDatabase db) {
        try (Cursor cursor = db.rawQuery(
                "SELECT p.id, p.title, c.chat_id FROM projects p "
                        + "LEFT JOIN chat_projects c ON c.project_id=p.id "
                        + "WHERE p.deleted=0", null)) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(0);
                String title = cursor.getString(1);
                if (title == null || !title.startsWith("Python · ")) continue;
                String base = title.replaceFirst("(?: · [0-9]+)+$", "");
                if (base.equals(title)) continue;
                boolean linked = !cursor.isNull(2);
                long chatId = linked ? cursor.getLong(2) : 0;
                if (linked && !title.endsWith(" · " + chatId)) continue;
                if (!linked && !title.matches(".*(?: · [0-9]+){2,}$")) continue;
                ContentValues values = new ContentValues();
                values.put("title", base + (linked ? " — чат " + chatId : " (сохранённая копия)"));
                db.update("projects", values, "id=?", new String[]{Long.toString(id)});
            }
        }
    }

    private static long insert(SQLiteDatabase db, String title, Long legacyChatId) {
        long now = System.currentTimeMillis();
        ContentValues row = new ContentValues();
        row.put("title", title);
        row.put("created_at", now);
        row.put("updated_at", now);
        if (legacyChatId != null) row.put("legacy_chat_id", legacyChatId);
        return db.insertOrThrow("projects", null, row);
    }

    private long linkedProject(SQLiteDatabase db, long chatId) {
        try (Cursor cursor = db.rawQuery("SELECT p.id FROM chat_projects c "
                + "JOIN projects p ON p.id=c.project_id WHERE c.chat_id=? "
                + "AND p.deleted=0 AND c.private_copy=1",
                new String[]{Long.toString(chatId)})) {
            return cursor.moveToFirst() ? cursor.getLong(0) : 0;
        }
    }

    /** Permanent private assignment, including chats where Python is switched off. */
    synchronized long assignedForChat(long chatId) {
        return chatId <= 0 ? 0 : linkedProject(getReadableDatabase(), chatId);
    }

    /** An inactive connection must not send project contents to the model. */
    synchronized long forChat(long chatId) {
        if (chatId <= 0) return 0;
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT p.id FROM chat_projects c JOIN projects p ON p.id=c.project_id "
                        + "WHERE c.chat_id=? AND c.private_copy=1 AND c.connected=1 AND p.deleted=0",
                new String[]{Long.toString(chatId)})) {
            return cursor.moveToFirst() ? cursor.getLong(0) : 0;
        }
    }

    /** Toggle visibility to the chat; never unlink or duplicate its project. */
    synchronized boolean setConnected(long chatId, boolean enabled) {
        if (chatId <= 0 || linkedProject(getReadableDatabase(), chatId) == 0) return false;
        ContentValues values = new ContentValues();
        values.put("connected", enabled ? 1 : 0);
        return getWritableDatabase().update("chat_projects", values,
                "chat_id=? AND private_copy=1", new String[]{Long.toString(chatId)}) == 1;
    }

    private static void link(SQLiteDatabase db, long chatId, long projectId, boolean privateCopy) {
        ContentValues values = new ContentValues();
        values.put("chat_id", chatId);
        values.put("project_id", projectId);
        values.put("private_copy", privateCopy ? 1 : 0);
        db.insertWithOnConflict("chat_projects", null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    /** Only an actual file creation causes a chat's first project to be allocated. */
    synchronized long ensureForChat(long chatId) {
        if (chatId <= 0) throw new IllegalArgumentException("Missing chat ID");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long result = linkedProject(db, chatId);
            if (result == 0) {
                // Never allocate a phantom project over an older, unisolated link.
                try (Cursor existing = db.rawQuery(
                        "SELECT 1 FROM chat_projects WHERE chat_id=?",
                        new String[]{Long.toString(chatId)})) {
                    if (existing.moveToFirst())
                        throw new IllegalStateException("Сначала отделите старый проект чата.");
                }
                result = insert(db, DEFAULT_TITLE, null);
                link(db, chatId, result, true);
                if (linkedProject(db, chatId) != result)
                    throw new IllegalStateException("Не удалось подключить отдельный проект.");
            }
            db.setTransactionSuccessful();
            return result;
        } finally {
            db.endTransaction();
        }
    }

    synchronized long createUnlinked() {
        return insert(getWritableDatabase(), DEFAULT_TITLE, null);
    }

    /** Create a single private empty project directly in this chat; no orphan copy. */
    synchronized long createEmptyForChat(long chatId, PythonProjectStore files) throws IOException {
        if (chatId <= 0 || files == null) throw new IOException("Активный чат недоступен.");
        long assigned = assignedForChat(chatId);
        if (assigned > 0) return assigned;
        SQLiteDatabase db = getWritableDatabase();
        long created = 0;
        boolean success = false;
        db.beginTransaction();
        try {
            try (Cursor c = db.rawQuery("SELECT 1 FROM chat_projects WHERE chat_id=?",
                    new String[]{Long.toString(chatId)})) {
                if (c.moveToFirst()) throw new IOException("Сначала требуется изолировать старый проект.");
            }
            created = insert(db, DEFAULT_TITLE + " — чат " + chatId, null);
            files.putText(created, "main.py", "");
            ContentValues row = new ContentValues();
            row.put("chat_id", chatId);
            row.put("project_id", created);
            row.put("private_copy", 1);
            row.put("connected", 1);
            if (db.insertWithOnConflict("chat_projects", null, row,
                    SQLiteDatabase.CONFLICT_ABORT) == -1)
                throw new IOException("Не удалось закрепить проект за чатом.");
            db.setTransactionSuccessful();
            success = true;
            return created;
        } finally {
            try { db.endTransaction(); }
            finally { if (!success && created > 0) files.deleteTask(created); }
        }
    }

    /** Explicit independent Python task: archive the former project without editing it,
     * and atomically switch the existing enabled chat link to a new blank project. */
    synchronized long switchToEmptyForIndependentTask(long chatId, PythonProjectStore files) throws IOException {
        long old = forChat(chatId);
        if (old <= 0) return 0;
        SQLiteDatabase db = getWritableDatabase();
        long created = 0;
        boolean success = false;
        db.beginTransaction();
        try {
            created = insert(db, DEFAULT_TITLE + " — чат " + chatId, null);
            files.putText(created, "main.py", "");
            ContentValues row = new ContentValues();
            row.put("project_id", created);
            if (db.update("chat_projects", row, "chat_id=? AND project_id=? AND connected=1 AND private_copy=1",
                    new String[]{Long.toString(chatId), Long.toString(old)}) != 1)
                throw new IOException("Не удалось закрепить проект за чатом.");
            db.setTransactionSuccessful();
            success = true;
            return created;
        } finally {
            try { db.endTransaction(); }
            finally { if (!success && created > 0) files.deleteTask(created); }
        }
    }

    /** Backward-compatible legacy association only. New UI paths MUST use
     * attachIsolatedCopy(): an old shared link is deliberately not visible in forChat(). */
    @Deprecated
    synchronized boolean attachChat(long chatId, long projectId) {
        if (chatId <= 0 || projectId <= 0) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            try (Cursor cursor = db.rawQuery(
                    "SELECT 1 FROM projects WHERE id=? AND deleted=0",
                    new String[]{Long.toString(projectId)})) {
                if (!cursor.moveToFirst()) return false;
            }
            ContentValues row = new ContentValues();
            row.put("chat_id", chatId);
            row.put("project_id", projectId);
            row.put("private_copy", 0);
            if (db.insertWithOnConflict("chat_projects", null, row,
                    SQLiteDatabase.CONFLICT_REPLACE) == -1) return false;
            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }

    /** Copy-on-attach: never share writable Python bytes between two chats.
     * File copying and chat linking either both succeed or leave the previous link intact.
     * The independent source artifact is never modified. */
    synchronized long attachIsolatedCopy(long chatId, long sourceId, PythonProjectStore files)
            throws IOException {
        if (chatId <= 0 || sourceId <= 0 || files == null)
            throw new IOException("Неверный чат или проект.");
        SQLiteDatabase db = getWritableDatabase();
        long current = linkedProject(db, chatId);
        if (current > 0) return current; // A chat can NEVER silently switch projects.
        String title;
        try (Cursor c = db.rawQuery("SELECT title FROM projects WHERE id=? AND deleted=0",
                new String[]{Long.toString(sourceId)})) {
            if (!c.moveToFirst()) throw new IOException("Исходный проект не найден.");
            title = c.getString(0);
        }
        // Never copy a damaged/empty snapshot or replace a link before validation.
        if (files.paths(sourceId).length == 0) throw new IOException("Исходный проект пуст.");
        long copyId = 0;
        boolean committed = false;
        db.beginTransaction();
        try {
            String baseTitle = title.replaceFirst("(?: \u00b7 \\d+)+$", "")
                    .replaceFirst("(?: — чат \\d+)+$", "");
            copyId = insert(db, baseTitle + " — чат " + chatId, null);
            files.copyTo(sourceId, files, copyId);
            ContentValues row = new ContentValues();
            row.put("chat_id", chatId);
            row.put("project_id", copyId);
            row.put("private_copy", 1);
            if (db.insertWithOnConflict("chat_projects", null, row,
                    SQLiteDatabase.CONFLICT_REPLACE) == -1)
                throw new IOException("Не удалось сохранить связь с отдельным проектом.");
            db.setTransactionSuccessful();
            committed = true;
            return copyId;
        } finally {
            try { db.endTransaction(); }
            finally { if (!committed && copyId > 0) files.deleteTask(copyId); }
        }
    }

    /** Upgrade a pre-isolation chat link lazily without touching its original files.
     * On copy failure the old shared link stays inaccessible to normal chat operations. */
    synchronized long ensureIsolatedForChat(long chatId, PythonProjectStore files)
            throws IOException {
        if (chatId <= 0) return 0;
        SQLiteDatabase db = getReadableDatabase();
        long current = linkedProject(db, chatId);
        if (current > 0) return current;
        long old = 0;
        try (Cursor c = db.rawQuery("SELECT p.id FROM chat_projects c "
                + "JOIN projects p ON p.id=c.project_id "
                + "WHERE c.chat_id=? AND c.private_copy=0 AND p.deleted=0",
                new String[]{Long.toString(chatId)})) {
            if (c.moveToFirst()) old = c.getLong(0);
        }
        return old == 0 ? 0 : attachIsolatedCopy(chatId, old, files);
    }

    /** A tombstone is retained if an imported artifact was deleted, preventing re-import. */
    synchronized long registerLegacy(long chatId, boolean chatExists, String title) {
        if (chatId <= 0) throw new IllegalArgumentException("Invalid legacy chat ID");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long project = 0;
            boolean deleted = false;
            try (Cursor cursor = db.rawQuery("SELECT id, deleted FROM projects WHERE legacy_chat_id=?",
                    new String[]{Long.toString(chatId)})) {
                if (cursor.moveToFirst()) {
                    project = cursor.getLong(0);
                    deleted = cursor.getInt(1) != 0;
                }
            }
            if (deleted) {
                db.setTransactionSuccessful();
                return 0;
            }
            if (project == 0) project = insert(db, title, chatId);
            if (chatExists) link(db, chatId, project, false);
            db.setTransactionSuccessful();
            return project;
        } finally {
            db.endTransaction();
        }
    }

    /** Restore catalog rows for actual artifact files after an interrupted index write.
     * Explicit deletion tombstones are never restored, even if file cleanup failed. */
    synchronized void recoverSavedFiles(PythonProjectStore files) {
        SQLiteDatabase db = getWritableDatabase();
        for (long id : files.savedTaskIds()) {
            try (Cursor cursor = db.rawQuery("SELECT 1 FROM projects WHERE id=?",
                    new String[]{Long.toString(id)})) {
                if (cursor.moveToFirst()) continue; // Includes deliberate deletion tombstones.
            }
            ContentValues recovered = new ContentValues();
            long now = System.currentTimeMillis();
            recovered.put("id", id);
            recovered.put("title", "Восстановленный Python-проект");
            recovered.put("created_at", now);
            recovered.put("updated_at", now);
            db.insertWithOnConflict("projects", null, recovered, SQLiteDatabase.CONFLICT_IGNORE);
        }
    }

    synchronized boolean exists(long id) {
        if (id <= 0) return false;
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT 1 FROM projects WHERE id=? AND deleted=0", new String[]{Long.toString(id)})) {
            return cursor.moveToFirst();
        }
    }

    synchronized boolean touch(long id, String path) {
        if (id <= 0) return false;
        SQLiteDatabase db = getWritableDatabase();
        android.database.sqlite.SQLiteStatement statement = db.compileStatement(
                "UPDATE projects SET updated_at=?, title=CASE WHEN title=? THEN ? ELSE title END "
                        + "WHERE id=? AND deleted=0");
        try {
            statement.bindLong(1, System.currentTimeMillis());
            statement.bindString(2, DEFAULT_TITLE);
            statement.bindString(3, "Python · " + path);
            statement.bindLong(4, id);
            return statement.executeUpdateDelete() == 1;
        } finally {
            statement.close();
        }
    }

    synchronized List<NexusArtifact> list(PythonProjectStore files) {
        List<NexusArtifact> result = new ArrayList<>();
        Set<Long> saved = new HashSet<>();
        for (long id : files.savedTaskIds()) saved.add(id);
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id, title, updated_at FROM projects WHERE deleted=0 "
                        + "ORDER BY updated_at DESC, id DESC", null)) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(0);
                if (!saved.contains(id)) continue; // Never display a failed, empty allocation.
                int count = 0;
                try { count = files.paths(id).length; }
                catch (IOException ignored) { /* Keep a damaged saved artifact visible for diagnosis. */ }
                result.add(new NexusArtifact(id, cursor.getString(1), cursor.getLong(2), count));
            }
        }
        return result;
    }

    synchronized boolean rename(long id, String name) {
        String title = name == null ? "" : name.trim();
        if (id <= 0 || title.isEmpty() || title.length() > 100) return false;
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("updated_at", System.currentTimeMillis());
        return getWritableDatabase().update("projects", values, "id=? AND deleted=0",
                new String[]{Long.toString(id)}) == 1;
    }

    synchronized void unlinkChat(long chatId) {
        if (chatId > 0) getWritableDatabase().delete("chat_projects", "chat_id=?",
                new String[]{Long.toString(chatId)});
    }

    synchronized boolean delete(long id) {
        if (id <= 0) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put("deleted", 1);
            int changed = db.update("projects", values, "id=? AND deleted=0",
                    new String[]{Long.toString(id)});
            if (changed != 1) return false;
            db.delete("chat_projects", "project_id=?", new String[]{Long.toString(id)});
            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }
}
