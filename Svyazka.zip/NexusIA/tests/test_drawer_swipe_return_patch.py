"""Source-level regression checks for the short-swipe drawer snap.

These checks do not replace a real-device Compose interaction test.
"""
from pathlib import Path
import unittest

DRAWER = (Path(__file__).resolve().parents[1] /
          "app/src/main/java/app/svyazka/mobile/ui/NexusDrawers.kt")


class DrawerSwipeReturnTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = DRAWER.read_text(encoding="utf-8")

    def test_both_drawers_animate_short_swipe_return(self):
        for name in ("left", "right"):
            with self.subTest(drawer=name):
                self.assertIn(f"{name}Offset = animateFloatAsState(", self.source)
                self.assertIn(f"targetValue = if ({name}Returning) 0f else {name}Drag", self.source)
                self.assertIn(f"animationSpec = if ({name}Returning) tween(170) else snap()", self.source)
                self.assertIn(f"onDragCancel = {{ {name}Returning = true }}", self.source)
                self.assertIn(f"else {name}Returning = true", self.source)
                self.assertIn(f".offset {{ IntOffset({name}Offset.value.roundToInt(), 0) }}", self.source)

    def test_reopen_resets_offset_without_waiting_for_old_delay(self):
        immediate, delayed = self.source.split("        delay(300)", 1)
        for name, direction in (("left", "LEFT"), ("right", "RIGHT")):
            with self.subTest(drawer=name):
                self.assertIn(f"if (ui.panel == NexusComposeUi.Panel.{direction})", immediate)
                self.assertIn(f"{name}Drag = 0f", immediate)
                self.assertIn(f"{name}Returning = false", immediate)
                self.assertIn(f"if (ui.panel != NexusComposeUi.Panel.{direction})", delayed)

    def test_completed_swipe_keeps_exit_transition(self):
        self.assertIn("leftDrag * leftDismissDirection >= leftThreshold) ui.closePanel()", self.source)
        self.assertIn("rightDrag * rightDismissDirection >= rightThreshold) ui.closePanel()", self.source)
        self.assertIn("slideOutHorizontally(tween(240))", self.source)


if __name__ == "__main__":
    unittest.main()
