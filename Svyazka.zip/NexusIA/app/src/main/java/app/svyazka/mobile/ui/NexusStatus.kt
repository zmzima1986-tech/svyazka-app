package app.svyazka.mobile.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.NexusPythonReport
import app.svyazka.mobile.PythonVerification
import app.svyazka.mobile.R
import app.svyazka.mobile.ResultSeverity

internal fun PythonVerification.severity(hasPython: Boolean = true) =
    ResultSeverity.verification(status.name, hasPython)

internal fun NexusPythonReport.severity() = ResultSeverity.execution(exitCode, hasFailedTests())

internal fun NexusPythonReport.noticeSeverity(): ResultSeverity = ResultSeverity.executionNotice(
    exitCode, hasFailedTests(), runCatching { org.json.JSONArray(testsJson).length() }.getOrDefault(0), status)

internal fun ResultSeverity.drawable(): Int = when (this) {
    ResultSeverity.SUCCESS -> R.drawable.ic_status_success
    ResultSeverity.WARNING -> R.drawable.ic_status_warning
    ResultSeverity.ERROR -> R.drawable.ic_status_error
    ResultSeverity.NEUTRAL -> R.drawable.ic_status_neutral
}

@Composable
internal fun ResultSeverity.textColor(): Color = if (this == ResultSeverity.NEUTRAL)
    MaterialTheme.colorScheme.onSurfaceVariant else Color(if (nexusLightMode()) lightColor else darkColor)

@Composable
internal fun ResultStatusIcon(severity: ResultSeverity, modifier: Modifier = Modifier.size(22.dp)) {
    Icon(painterResource(severity.drawable()), contentDescription = null,
        modifier = modifier, tint = Color.Unspecified)
}

@Composable
internal fun ResultStatusLine(label: String, severity: ResultSeverity,
                              style: TextStyle = MaterialTheme.typography.bodyMedium,
                              modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        ResultStatusIcon(severity)
        Text(label, style = style, color = severity.textColor(), modifier = Modifier.weight(1f))
    }
}

/** RAN confirms execution, not independent testing. The legacy verifier puts the
 * measured self-assert count in a trusted diagnostic; extract it for presentation only. */
@Composable
internal fun VerificationDiagnostic(check: PythonVerification) {
    if (check.status == PythonVerification.Status.RAN) {
        val count = ResultSeverity.selfAssertCount(check.status.name, check.diagnostic)
        val suite = check.generatedSuitePassed()
        if (suite > 0) {
            ResultStatusLine(stringResource(R.string.verify_generated_suite, suite), ResultSeverity.SUCCESS)
        } else if (count >= 0) {
            ResultStatusLine(stringResource(R.string.verify_self_asserts, count), ResultSeverity.SUCCESS)
        } else if (check.diagnostic.isNotBlank()) {
            SelectionContainer { ResultStatusLine(check.diagnostic, ResultSeverity.WARNING) }
        }
        ResultStatusLine(stringResource(R.string.verify_no_independent), ResultSeverity.WARNING)
    } else if (check.diagnostic.isNotBlank()) {
        SelectionContainer { ResultStatusLine(check.diagnostic, check.severity()) }
    }
}
