package app.svyazka.mobile;

import java.util.ArrayDeque;
import java.util.Deque;
import org.json.JSONObject;

public final class HistoryChecks {
    private static int passed;

    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        passed++;
    }

    public static void main(String[] args) throws Exception {
        check(TaskHistory.title("   Первая\nзадача ").equals("Первая задача"), "readable title");
        check(TaskHistory.title("  ").equals("Новая задача"), "empty title");
        StringBuilder emojis = new StringBuilder();
        for (int i = 0; i < 60; i++) emojis.append("😀");
        check(TaskHistory.title(emojis.toString()).length() <= 74, "title preserves surrogate pairs");

        String refined = TaskHistory.followUp("Напиши сайт", "<h1>Готово</h1>", "Добавь настройки");
        check(refined.contains("Напиши сайт") && refined.contains("<h1>Готово</h1>")
                && refined.contains("Добавь настройки"), "follow-up carries original, last answer and new request");
        check(TaskHistory.displayTask(refined).equals("Уточнение: Добавь настройки"),
                "follow-up header shows latest clarification");
        check(refined.indexOf("Предыдущий готовый ответ") < refined.indexOf("Новое уточнение"),
                "user update is the final instruction");
        boolean rejected = false;
        try { TaskHistory.followUp("X", "Answer", "  "); }
        catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "blank clarification rejected");
        rejected = false;
        try { TaskHistory.followUp("X", "", "Поправь"); }
        catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "missing prior answer rejected");
        rejected = false;
        StringBuilder enormous = new StringBuilder();
        for (int i = 0; i < Workflow.TASK_LIMIT; i++) enormous.append('a');
        try { TaskHistory.followUp("X", enormous.toString(), "Поправь"); }
        catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "over-budget context rejected without silent truncation");

        String python = "```python\nimport calendar\nprint(calendar.month(2026,11))\n```";
        String modified = TaskHistory.followUp("Напиши календарь", "Объяснение на 100 строк.\n"
                + python + "\nПодробное обсуждение реализации", "Добавь уведомления");
        check(modified.contains("<previous_python_source>")
                        && modified.contains("import calendar")
                        && !modified.contains("Подробное обсуждение"),
                "follow-up preserves exact code while excluding long generated commentary");
        check(TaskHistory.displayTask(modified).equals("Уточнение: Добавь уведомления"),
                "compact code follow-up remains readable in history");
        String iterated = TaskHistory.followUp(modified, python, "Добавь Bluetooth");
        check(iterated.contains("Напиши календарь")
                        && iterated.contains("Добавь уведомления")
                        && iterated.contains("Добавь Bluetooth")
                        && iterated.length() < modified.length() + 250,
                "nested follow-up does not endlessly duplicate generated code");
        check(TaskHistory.forRepair(iterated).contains("Добавь Bluetooth")
                        && !TaskHistory.forRepair(iterated).contains("<previous_python_source>"),
                "repair request reuses user requirements, not a duplicate old code blob");
        Workflow.Run quick = Workflow.Run.quick("Напиши код", ModelCatalog.NORTH,
                Workflow.defaultStages().get(1));
        Workflow.Run original = quick.receive(new ModelClient.Reply("print(1)", ModelClient.Finish.STOP, ""));
        String version = original.toJson().toString();
        Workflow.Run newCycle = Workflow.Run.quick(TaskHistory.followUp("Напиши код",
                original.displayAnswer(0), "Добавь комментарий"), ModelCatalog.NORTH,
                Workflow.defaultStages().get(1));
        check(newCycle.nextIndex() == 0 && !newCycle.complete(), "a follow-up starts a fresh cycle");
        check(Workflow.Run.fromJson(new JSONObject(version)).complete()
                && Workflow.Run.fromJson(new JSONObject(version)).displayAnswer(0).equals("print(1)"),
                "prior version remains complete and readable");

        Deque<Runnable> queue = new ArrayDeque<>();
        WorkspaceStore workspace = new WorkspaceStore(
                new WorkspaceStore.State(101, "Первая", original, true, "[{}]"),
                queue::addLast, changes -> true);
        long first = workspace.attach();
        workspace.save(first, new WorkspaceStore.State(101, "Первая", original, true, "[{}]"), saved -> {});
        long second = workspace.switchTo(new WorkspaceStore.State(102, "Вторая", null, false, ""));
        workspace.save(first, new WorkspaceStore.State(101, "Старая запись", original, true, ""), saved -> {
            throw new AssertionError("expired session must not save");
        });
        workspace.save(second, new WorkspaceStore.State(102, "Вторая", null, false, ""), saved -> {});
        while (!queue.isEmpty()) queue.removeFirst().run();
        check(workspace.current().taskId == 102 && workspace.current().task.equals("Вторая"),
                "old session cannot overwrite switched task");
        check(workspace.current().changes().get(WorkspaceStore.TASK_ID).equals(102L),
                "every snapshot targets the exact SQLite task ID");
        check(workspace.current().run == null, "switching tasks does not mix runs");
        System.out.println(passed + " history checks passed");
    }
}
