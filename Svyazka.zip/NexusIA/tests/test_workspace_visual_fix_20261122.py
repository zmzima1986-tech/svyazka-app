"""Source-level UI regression guards. Real touch/render behavior needs Android testing."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "app/src/main/java/app/svyazka/mobile/ui"


def read(name):
    return (UI / name).read_text(encoding="utf-8")


class WorkspaceVisualFixes(unittest.TestCase):
    def test_project_info_is_an_action_with_a_real_dialog(self):
        source = read("NexusPythonWorkspace.kt")
        self.assertIn(".clickable(role = Role.Button) { showProjectInfo = true }", source)
        self.assertIn("if (showProjectInfo) {", source)
        self.assertIn("Text(stringResource(R.string.ws_project_scope))", source)
        self.assertIn("onClick = { showProjectInfo = false }", source)

    def test_both_mode_tabs_occupy_the_entire_switch_width(self):
        components = read("NexusComponents.kt")
        chat = read("NexusChat.kt")
        self.assertIn("Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center)", components)
        self.assertIn("ModeChip(quick, single, Modifier.weight(1f))", components)
        self.assertIn("ModeChip(!quick, team, Modifier.weight(1f))", components)
        self.assertIn("modifier.clip(shape)", chat)
        self.assertIn("Modifier.padding(horizontal = 9.dp, vertical = 9.dp)", chat)
        self.assertIn("fontSize = 12.sp", chat)

    def test_nested_tools_slide_out_without_fade_and_swipe_dismiss(self):
        source = read("NexusPythonWorkspace.kt")
        self.assertIn("AnimatedVisibility(\n            visible = toolPanel != null", source)
        self.assertIn("enter = fadeIn(tween(130))", source)
        self.assertIn("exit = slideOutHorizontally(tween(240, easing = FastOutSlowInEasing))", source)
        self.assertIn("(if (rtl) -width else width) - toolDrag.roundToInt()", source)
        self.assertIn("delay(280)", source)
        self.assertNotIn("enter = slideInHorizontally(tween(260))", source)
        self.assertNotIn("exit = ExitTransition.None", source)
        self.assertIn("detectHorizontalDragGestures(", source)
        self.assertIn("toolDrag * dismissDirection >= dismissThreshold", source)
        self.assertIn("onDragCancel = { settleToolDrag() }", source)
        self.assertIn("else settleToolDrag()", source)
        self.assertIn("if (ui.pythonToolsOpen) Modifier else Modifier.pointerInput", read("NexusDrawers.kt"))

    def test_android_back_closes_nested_tools_first(self):
        source = read("NexusPythonWorkspace.kt")
        self.assertIn("BackHandler(enabled = toolPanel != null)", source)
        self.assertIn("toolPanel = if (toolPanel == PythonToolPanel.MENU) null else PythonToolPanel.MENU", source)
        self.assertIn("SideEffect { ui.pythonToolsOpen = toolPanel != null }", source)

    def test_files_tab_displays_imported_python_project_and_chat_attachments_separately(self):
        source = read("NexusDrawers.kt")
        state = read("NexusComposeUi.kt")
        self.assertIn("enum class WorkspaceFilesView { PROJECT, ATTACHMENTS }", state)
        self.assertIn("var workspaceFilesView by mutableStateOf(WorkspaceFilesView.PROJECT)", state)
        self.assertIn("if (projectView) {", source)
        self.assertIn("PythonProjectFileManager(ui)", source)
        self.assertIn("AttachmentSummary(attachments)", source)
        self.assertIn("ui.workspaceFilesView = NexusComposeUi.WorkspaceFilesView.ATTACHMENTS", source)

    def test_nested_panel_does_not_duplicate_system_insets(self):
        source = read("NexusPythonWorkspace.kt")
        self.assertIn("Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 10.dp))", source)
        section = source.split("val panel = toolPanel ?: retainedToolPanel", 1)[1].split("if (showProjectInfo)", 1)[0]
        self.assertNotIn("statusBarsPadding", section)
        self.assertNotIn("navigationBarsPadding", section)
        self.assertNotIn(".background(Color.Black.copy(alpha = .52f))", source)
        self.assertIn("NexusFrostedPanel(", source)


if __name__ == "__main__":
    unittest.main()
