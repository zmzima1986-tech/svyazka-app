package app.svyazka.mobile.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.NexusArtifact
import app.svyazka.mobile.R
import java.text.DateFormat
import java.util.Date

/** Project browser: only durable artifact records with saved files are shown. */
@Composable
fun ArtifactsScreen(ui: NexusComposeUi) {
    val projects = ui.artifacts
    var rename by remember { mutableStateOf<NexusArtifact?>(null) }
    var name by remember { mutableStateOf("") }
    var delete by remember { mutableStateOf<NexusArtifact?>(null) }
    val format = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(stringResource(R.string.artifacts_description),
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { ui.activity.nexusCreateArtifact() }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.artifacts_new))
            }
        }
        if (projects.isEmpty()) item { NexusCard { Text(stringResource(R.string.artifacts_empty)) } }
        items(projects, key = { it.id }) { project ->
            NexusCard(onClick = { ui.activity.nexusOpenArtifact(project.id) }, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Code, null, Modifier.size(30.dp),
                        tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(project.title, style = MaterialTheme.typography.titleMedium)
                        Text(format.format(Date(project.updatedAt)),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(stringResource(R.string.artifacts_files, project.fileCount),
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { name = project.title; rename = project }) {
                        Text(stringResource(R.string.chat_rename))
                    }
                    TextButton(onClick = { delete = project }) {
                        Text(stringResource(R.string.action_delete), color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
    rename?.let { project ->
        NexusFrostedAlertDialog(onDismissRequest = { rename = null },
            title = { Text(stringResource(R.string.artifacts_name)) },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    ui.activity.nexusRenameArtifact(project.id, name)
                    rename = null
                }, enabled = name.trim().isNotEmpty()) { Text(stringResource(R.string.action_save)) }
            },
            dismissButton = {
                TextButton(onClick = { rename = null }) { Text(stringResource(R.string.action_cancel)) }
            })
    }
    delete?.let { project ->
        NexusFrostedAlertDialog(onDismissRequest = { delete = null },
            title = { Text(stringResource(R.string.action_delete)) },
            text = { Text(stringResource(R.string.artifacts_delete_warning)) },
            confirmButton = {
                TextButton(onClick = {
                    ui.activity.nexusDeleteArtifact(project.id)
                    delete = null
                }) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { delete = null }) { Text(stringResource(R.string.action_cancel)) }
            })
    }
}
