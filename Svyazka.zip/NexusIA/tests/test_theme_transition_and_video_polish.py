"""Regression guards for the two Nov 22 recordings and annotated screenshots.

These assertions validate wiring and layout contracts, not frame-time behavior on a device.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "app/src/main/java/app/svyazka/mobile/ui"
MAIN = ROOT / "app/src/main/java/app/svyazka/mobile/MainActivity.java"


class ThemeAndWorkspaceVideoPolish(unittest.TestCase):
    def test_switch_theme_never_changes_platform_night_mode_live(self):
        java = MAIN.read_text(encoding="utf-8")
        action = java.split("public void nexusThemeChanged(String theme) {", 1)[1].split(
            "public void nexusLanguageChanged(String language)", 1
        )[0]
        self.assertIn('data.edit().putString("ui_theme", theme).apply()', action)
        self.assertIn('nexusUi.onThemeChanged(theme)', action)
        self.assertNotIn('syncPlatformSplashTheme(theme);', action)
        self.assertNotIn('setApplicationNightMode(', action.split("// UI changes", 1)[0])
        self.assertIn('syncPlatformSplashTheme(data.getString("ui_theme", "system"))', java)

    def test_theme_animates_without_reinitializing_main_activity(self):
        compose = (UI / "NexusComposeUi.kt").read_text(encoding="utf-8")
        self.assertIn('Crossfade(targetState = ui.theme, animationSpec = tween(durationMillis = 280)', compose)
        self.assertIn('NexusTheme(displayedTheme)', compose)
        self.assertIn('NexusAppThemeContent(ui, displayedTheme)', compose)
        self.assertIn('private fun NexusAppThemeContent(ui: NexusComposeUi, displayedTheme: String)', compose)
        self.assertIn('SideEffect {', compose)
        self.assertIn('BackHandler(enabled = true)', compose)

    def test_light_workspace_masks_chat_but_preserves_glass(self):
        drawers = (UI / "NexusDrawers.kt").read_text(encoding="utf-8")
        self.assertIn('Color(0xFFF4F7FC)', drawers)
        self.assertIn('lightBackground = NexusLightDesign.glass', drawers)
        self.assertIn('shape = workspaceShape', drawers)
        self.assertNotIn('val headerShape = RoundedCornerShape(24.dp)', drawers)
        self.assertIn('fontSize = 20.sp, fontWeight = FontWeight.Bold', drawers)

    def test_project_import_is_visible_without_disclosure(self):
        python = (UI / "NexusPythonWorkspace.kt").read_text(encoding="utf-8")
        self.assertIn('PythonProjectFiles(ui)', python)
        self.assertNotIn('projectActionsExpanded', python)
        self.assertIn('PythonToolRow(Icons.Outlined.SaveAlt,', python)
        self.assertIn('ui.activity.nexusSaveArtifact(ui.pythonFileName, ui.pythonEditingCode)', python)
        self.assertIn('shape = RoundedCornerShape(0.dp)', python)

    def test_link_checkmark_comes_from_repository_state(self):
        python = (UI / "NexusPythonWorkspace.kt").read_text(encoding="utf-8")
        self.assertIn('ui.linkedProjectId == ui.projectId', python)
        self.assertIn('Icons.Filled.CheckCircle else Icons.Outlined.ChatBubbleOutline', python)
        self.assertIn('if (light) NexusLightDesign.success else NexusDarkDesign.success', python)
        self.assertIn('R.string.ws_chat_unlinked_status', python)


if __name__ == "__main__":
    unittest.main()
