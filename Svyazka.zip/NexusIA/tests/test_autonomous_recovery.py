"""Run the actual local Java quota/retry policy without network or Android."""
from pathlib import Path
import shutil, subprocess, tempfile, unittest
ROOT=Path(__file__).resolve().parents[1]
@unittest.skipUnless(shutil.which('java') and shutil.which('javac'),'JDK unavailable')
class AutonomyPolicy(unittest.TestCase):
    def test_limits_and_repeated_failures(self):
        with tempfile.TemporaryDirectory() as tmp:
            subprocess.run(['javac','-encoding','UTF-8','-d',tmp,str(ROOT/'app/src/main/java/app/svyazka/mobile/AutonomyQuotaGuard.java'),str(ROOT/'tests/AutonomyQuotaGuardChecks.java')],check=True)
            subprocess.run(['java','-ea','-cp',tmp,'app.svyazka.mobile.AutonomyQuotaGuardChecks'],check=True)
