"""Static UI architecture regression guards. These do NOT replace Android/Compose tests."""
from pathlib import Path
import re
import unittest
import xml.etree.ElementTree as ET

PROJECT = Path(__file__).resolve().parents[1]
CODE = PROJECT / 'app/src/main/java/app/svyazka/mobile'
UI = CODE / 'ui'
RES = PROJECT / 'app/src/main/res'


def read(name):
    return (UI / name).read_text(encoding='utf-8')


class MinimalHiTechContract(unittest.TestCase):
    def test_single_chat_for_task_and_result(self):
        ui = read('NexusComposeUi.kt')
        self.assertIn('Page.TASK, NexusComposeUi.Page.RESULT -> NexusChatScreen(ui)', ui)
        self.assertNotIn('NexusBottomBar(ui)', ui)

    def test_both_drawers_animate_from_their_edges_and_close_by_swipe(self):
        drawers = read('NexusDrawers.kt')
        self.assertIn('slideInHorizontally', drawers)
        self.assertIn('slideOutHorizontally', drawers)
        self.assertIn('ui.openRight()', drawers)
        self.assertEqual(drawers.count('detectHorizontalDragGestures('), 2)
        self.assertIn('Modifier.align(Alignment.CenterStart).width(leftWidth)', drawers)
        self.assertIn('Modifier.align(Alignment.CenterEnd).width(rightWidth)', drawers)
        self.assertIn('leftThreshold', drawers)
        self.assertIn('rightThreshold', drawers)
        self.assertIn('ui.closePanel()', drawers)
        self.assertNotIn('horizontalScroll(', drawers)


    def test_compact_chat_and_workspace_have_no_ellipsized_tabs_or_extraneous_prompts(self):
        chat = read('NexusChat.kt')
        tools = read('NexusPythonWorkspace.kt')
        controls = read('NexusComponents.kt')
        screens = read('NexusScreens.kt')
        self.assertNotIn('Text(stringResource(R.string.ui_welcome_subtitle)', chat)
        self.assertIn('NexusBrandMark(Modifier.size(46.dp))', chat)
        self.assertIn('maxLines = 1, softWrap = false', chat)
        self.assertNotIn('Text(stringResource(R.string.ws_project_ready)', tools)
        self.assertNotIn('horizontalScroll(', screens)
        self.assertIn('FlowRow(Modifier.fillMaxWidth()', screens)
        self.assertIn('DropdownMenu(expanded = expanded', controls)
        self.assertNotIn('val requiredWidth = chipWidth(single) + chipWidth(team)', controls)
        self.assertIn('val fontSize = (13 downTo 9)', controls)

    def test_python_not_owned_by_drawer_visibility(self):
        drawers = read('NexusDrawers.kt')
        ui = read('NexusComposeUi.kt')
        self.assertNotIn('cancelSandbox(', drawers)
        self.assertNotIn('nexusCancelPython()', drawers)
        self.assertIn('NexusPythonWorkspace(ui)', drawers)
        self.assertIn('var pythonReport by mutableStateOf', ui)
        self.assertNotIn('PythonDialogs(ui)', ui)

    def test_main_chat_uses_real_workflow_and_versions(self):
        java = (CODE / 'MainActivity.java').read_text(encoding='utf-8')
        self.assertIn('repository.versions(activeTaskId)', java)
        self.assertIn('nexusExchanges()', java)
        self.assertIn('new NexusState.Exchange', java)
        self.assertIn('nexusFollowUp(message)', read('NexusComposeUi.kt'))

    def test_solid_white_and_black_main_backgrounds(self):
        theme = read('NexusTheme.kt')
        self.assertIn('background = Color.Black', theme)
        self.assertIn('val NexusLightBackground = Color.White', theme)

    def test_new_strings_present_for_each_locale(self):
        names = ['values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN']
        parsed = []
        for name in names:
            resources = ET.parse(RES / name / 'strings.xml').getroot()
            parsed.append({v.attrib['name'] for v in resources.findall('string')})
        for values in parsed:
            self.assertEqual(parsed[0], values)
            self.assertTrue({'ui_chat', 'ui_workspace', 'ui_quick', 'ui_team'}.issubset(values))


if __name__ == '__main__':
    unittest.main()
