"""Replay the captured provider response, parser and local project runner.
Pure parser methods are compiled unchanged, without Android or org.json.
The full Workflow/JSON handoff contract is in RecoveryChecks.java.
"""
from pathlib import Path
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'
FIXTURE = ROOT / 'tests/fixtures/recovery/observed-expenses-project.md'
COMMENT_FIXTURE = FIXTURE.with_name('observed-expenses-comment-header.md')
ASSETS = ROOT / 'app/src/main/assets/sandbox'


def asset(name):
    spec = importlib.util.spec_from_file_location('nexus_' + name, ASSETS / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def captured_files(fixture=FIXTURE):
    if fixture == COMMENT_FIXTURE:
        files = {path: body for body, path in re.findall(r'^```python\n((?:# file=([^\n]+)\n).*?)^```', fixture.read_text(), re.M | re.S)}
        assert set(files) == {'main.py', 'expenses.py', 'test_expenses.py'}
        return files
    files = {}
    for path, body in re.findall(r'^```file=([^\n]+)\n(.*?)^```', FIXTURE.read_text(), re.M | re.S):
        if body.strip():
            if path in files:
                assert files[path] == body
            files[path] = body
    assert set(files) == {'main.py', 'expenses.py', 'test_expenses.py'}
    return files


class MultiProjectChain(unittest.TestCase):
    @unittest.skipUnless(shutil.which('javac') and shutil.which('java'), 'JDK unavailable')
    def test_real_parser_with_captured_response(self):
        source = (JAVA / 'PythonInputs.java').read_text()
        # Extract the actual parser, not a second implementation of its rules.
        source = re.sub(r'^import org\.json\..*;\n', '', source, flags=re.M)
        start = source.index('    /** Same canonical complete project')
        end = source.index('    public static boolean hasNamedFiles(', start)
        source = source[:start] + source[end:source.index('    public static String copySource(', end)] + '}\n'
        harness = r'''package app.svyazka.mobile;
import java.nio.file.*;
import java.util.*;
public class MultiCheck {
  static void check(boolean ok, String label) {if(!ok)throw new AssertionError(label);}
  static String file(String path,String code){return "```file="+path+"\n"+code+"```\n";}
  public static void main(String[] args)throws Exception {
    String raw=Files.readString(Path.of(args[0]));
    Map<String,String> got=PythonInputs.namedFiles(raw);
    check(got.size()==3,"captured file count");
    check(PythonInputs.hasPythonDelivery(raw),"accept complete package");
    check(PythonInputs.multiPythonProject(raw).equals(got),"same project at validation");
    check(PythonInputs.candidate(raw).parts.size()==3,"exactly three Python sources");
    check(PythonAutoStage.projectRunAllowed("Создай программу учёта расходов на Python из трёх файлов: main.py, expenses.py и test_expenses.py. Реализуй добавление расходов, подсчёт общей суммы и группировку по категориям. Добавь 10 автоматических тестов. Проверь работоспособность всего проекта.\nВ консоли [console]",got),"actual request permits whole-project test");
    check(!PythonAutoStage.projectRunAllowed("Создай программу на Python. Не запускай.",got),"execution prohibited by user");
    check(!PythonAutoStage.projectRunAllowed("Создай программу на Python с тестами.",got),"no inferred permission");
    for(var e:got.entrySet()) Files.writeString(Path.of(args[1],e.getKey()),e.getValue());
    String main=file("main.py","print(1)\n"), lib=file("lib.py","x=1\n");
    String project=main+lib;
    check(PythonInputs.namedFiles(project+project).size()==2,"identical duplicate");
    check(PythonInputs.namedFiles(project+file("main.py","")).size()==2,"empty old snapshot");
    check(PythonInputs.namedFiles(project+file("lib.py","x=2\n")).isEmpty(),"conflicting duplicate");
    check(PythonInputs.namedFiles(project+file("LIB.py","x=1\n")).isEmpty(),"case collision");
    check(PythonInputs.namedFiles(project+file("../outside.py","x=1\n")).isEmpty(),"unsafe path");
    check(PythonInputs.namedFiles(project+file("lib.py/child.py","x=1\n")).isEmpty(),"prefix collision");
    check(PythonInputs.namedFiles(project+file("missing.py","")).isEmpty(),"missing source");
    check(PythonInputs.namedFiles(project+"```file=more.py\nprint(2)\n").isEmpty(),"unfinished source");
    check(PythonInputs.namedFiles(project+"```bash\npython main.py\npython -m unittest lib.py\n```\n").size()==2,"launch docs");
    check(PythonInputs.namedFiles(project+"```bash\npython unknown.py\n```\n").isEmpty(),"unrelated commands");
    check(!PythonInputs.hasPythonDelivery("```file=index.html\n<html></html>\n```"),"wrong language");
    check(PythonInputs.candidate(main).code.equals("print(1)\n"),"single source still works");
    String comment="```python\n# file=lib.py\nx=1\n```\n";
    check(PythonInputs.namedFiles(main+comment).get("lib.py").equals("# file=lib.py\nx=1\n"),"comment preserved exactly");
    check(PythonInputs.namedFiles(main+"## `lib.py`\n\n```py\nx=1\n```\n").size()==2,"exact heading");
    check(PythonInputs.namedFiles(main+"```python\n#!/usr/bin/env python3\n# coding: utf-8\n# file: `lib.py`\nx=1\n```\n").size()==2,"header after shebang");
    check(PythonInputs.namedFiles(main+"```python file=lib.py\n# file=other.py\nx=1\n```\n").isEmpty(),"conflicting fence and comment");
    check(PythonInputs.namedFiles(main+"## lib.py\n```python\n# file=other.py\nx=1\n```\n").isEmpty(),"conflicting heading and comment");
    check(PythonInputs.namedFiles(main+"```python\n# file=../secret.py\nx=1\n```\n").isEmpty(),"unsafe comment path");
    check(!PythonInputs.hasPythonDelivery("```python\n# file=../secret.py\nx=1\n```"),"no unsafe single-file fallback");
    check(PythonInputs.candidate("```python\n# file=../secret.py\nx=1\n```").ambiguous,"no unsafe automatic execution");
    check(PythonInputs.namedFiles(main+"```python\nx=1\n# file=lib.py\n```\n").isEmpty(),"late comment is not metadata");
    check(PythonInputs.namedFiles(main+"## lib.py\nExample only:\n```python\nx=1\n```\n").isEmpty(),"heading must be adjacent");
    check(PythonInputs.namedFiles(main+"```python\n# file=lib.py\n# file=other.py\nx=1\n```\n").isEmpty(),"conflicting comments");
    check(PythonInputs.namedFiles(main+"```python\n# file=lib.py\nx=1\n").isEmpty(),"unclosed comment block");
    check(PythonInputs.namedFiles(main+comment+comment).size()==2,"identical commented duplicate");
    check(PythonInputs.namedFiles(main+comment+comment.replace("x=1","x=2")).isEmpty(),"different commented duplicate");
    check(PythonInputs.namedFiles(main+"```python\n# file=MAIN.py\nx=1\n```\n").isEmpty(),"case collision in comment");
    check(PythonInputs.namedFiles(main+comment+"```bash\npython lib.py\n```\n").size()==2,"launch after comment metadata");
    check(PythonInputs.namedFiles(main+"```python\n# file=lib.py\nx=1\n```\n```text\n# file=notes.py\n```\n").isEmpty(),"non-Python comment not delivery");
  }
}'''
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)
            (p / 'PythonInputs.java').write_text(source)
            (p / 'MultiCheck.java').write_text(harness)
            # Compile the real permission/size gate, omitting only the unrelated
            # single-file edit selector. Use the actual feedback marker constant.
            stage = (JAVA/'PythonAutoStage.java').read_text()
            stage = stage[:stage.index('    static Selection select(')] + '}\n'
            (p/'PythonAutoStage.java').write_text(stage)
            marker = re.search(r'static final String MARKER = [^;]+;', (JAVA/'PythonAutoFeedback.java').read_text()).group()
            (p/'PythonAutoFeedback.java').write_text('package app.svyazka.mobile; final class PythonAutoFeedback {' + marker + '}')
            subprocess.run(['javac','-encoding','UTF-8','-d',tmp,str(p/'PythonInputs.java'),str(p/'MultiCheck.java'),str(p/'PythonAutoStage.java'),str(p/'PythonAutoFeedback.java'),str(JAVA/'PythonProjectPaths.java'),str(JAVA/'ContinuationIntegrity.java')],check=True)
            for fixture in (FIXTURE, COMMENT_FIXTURE):
                with self.subTest(fixture=fixture.name):
                    subprocess.run(['java','-cp',tmp,'app.svyazka.mobile.MultiCheck',str(fixture),tmp],check=True)
                    for name, body in captured_files(fixture).items():
                        self.assertEqual((p/name).read_bytes(),body.encode())

    def test_syntax_every_file_not_execution(self):
        grader = asset('verify')
        files = captured_files()
        def check(sources):
            return json.loads(grader.verify_request(json.dumps({'project_sources':sources,'reason':'syntax only'})))
        for fixture in (FIXTURE, COMMENT_FIXTURE):
            good = check(captured_files(fixture))
            self.assertEqual(good['status'],'LIMITED')
            self.assertTrue(good['syntax'])
            self.assertFalse(good['ran'])
            self.assertEqual(good['total'],0)
        bad = check(dict(files, **{'expenses.py':'def broken('}))
        self.assertEqual(bad['status'],'ERROR')
        self.assertIn('expenses.py',bad['diagnostic'])
        self.assertFalse(bad['ran'])

    def test_generated_suite_actual_and_failure(self):
        ws = asset('workspace')
        cwd, old_path = Path.cwd(), list(sys.path)
        with tempfile.TemporaryDirectory() as tmp:
            ws.ROOT = Path(tmp)/'workspace'
            try:
                for fixture in (FIXTURE, COMMENT_FIXTURE):
                    ws.reset_workspace({k:v.encode() for k,v in captured_files(fixture).items()})
                    result = ws.run_generated_tests()
                    self.assertEqual(result, dict(status='PASSED',discovered=10,ran=10,passed=10,failed=0,skipped=0))
                    for name,module in list(sys.modules.items()):
                        if str(getattr(module,'__file__','')).startswith(str(ws.ROOT)+'/'):
                            sys.modules.pop(name,None)
                ws.reset_workspace({'main.py':b'print(1)', 'test_bad.py':b'import unittest\nclass T(unittest.TestCase):\n def test_bad(self): self.assertEqual(1,2)\n'})
                result = ws.run_generated_tests()
                self.assertEqual((result['status'],result['failed'],result['passed']),('FAILED',1,0))
                ws.reset_workspace({'main.py':b'print(1)'})
                self.assertEqual(ws.run_generated_tests()['status'],'LIMITED')
            finally:
                os.chdir(cwd)
                sys.path[:] = old_path
                for name,module in list(sys.modules.items()):
                    if str(getattr(module,'__file__','')).startswith(str(ws.ROOT)+'/'):
                        sys.modules.pop(name,None)
