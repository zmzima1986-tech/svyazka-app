package app.svyazka.mobile;

import org.junit.Test;
import static org.junit.Assert.*;

/** Bounded repair metadata does not require a provider or emulator. */
public final class PythonAutoRepairTest {
    private static final String PATH = "src/main.py";
    private static final String BASE = "print('last good')\n";
    private static final String ERROR1 = "ZeroDivisionError: division by zero (строка 3)";
    private static final String ERROR2 = "NameError: name 'x' is not defined (строка 4)";
    private static final String ERROR3 = "ValueError: invalid literal (строка 5)";

    private static String diagnostic(String source, String error) {
        return PythonAutoFeedback.verificationPrompt("Измени main.py", PATH, source, error);
    }

    @Test public void remembersOriginalRequirementsAndExactFile() {
        String first = PythonAutoRepair.first(diagnostic("print(1/0)", ERROR1), PATH,
                "print(1/0)", ERROR1, BASE);
        assertNotEquals("", first);
        PythonAutoRepair.State state = PythonAutoRepair.parse(first);
        assertNotNull(state);
        assertEquals(1, state.attempt);
        assertEquals(PATH, state.path);
        assertEquals("Измени main.py", TaskHistory.forRepair(first));
        assertTrue(state.unchangedProject(BASE));
        assertFalse(state.unchangedProject("print('user edited')"));
        assertTrue(state.alreadyTried("print(1/0)"));
        assertFalse(PythonAutoStage.requested(first));
    }

    @Test public void atMostThreeDistinctAttempts() {
        String first = PythonAutoRepair.first(diagnostic("print(1/0)", ERROR1), PATH,
                "print(1/0)", ERROR1, BASE);
        String second = PythonAutoRepair.next(PythonAutoRepair.parse(first),
                diagnostic("print(x)", ERROR2), PATH, "print(x)", ERROR2, BASE);
        assertEquals(2, PythonAutoRepair.parse(second).attempt);
        String third = PythonAutoRepair.next(PythonAutoRepair.parse(second),
                diagnostic("raise ValueError('bad')", ERROR3), PATH,
                "raise ValueError('bad')", ERROR3, BASE);
        PythonAutoRepair.State last = PythonAutoRepair.parse(third);
        assertEquals(3, last.attempt);
        assertFalse(last.canContinue());
        assertEquals("", PythonAutoRepair.next(last, diagnostic("print(4)", "TypeError: bad"),
                PATH, "print(4)", "TypeError: bad", BASE));
    }

    @Test public void stopsOnSameCodeSameErrorAndChangedProject() {
        String first = PythonAutoRepair.first(diagnostic("print(1/0)", ERROR1), PATH,
                "print(1/0)", ERROR1, BASE);
        PythonAutoRepair.State state = PythonAutoRepair.parse(first);
        assertEquals("", PythonAutoRepair.next(state, diagnostic("print(1/0)", ERROR2),
                PATH, "print(1/0)", ERROR2, BASE));
        assertEquals("", PythonAutoRepair.next(state,
                diagnostic("print(x)", "ZeroDivisionError: division by zero (строка 88)"),
                PATH, "print(x)", "ZeroDivisionError: division by zero (строка 88)", BASE));
        assertEquals("", PythonAutoRepair.next(state, diagnostic("print(x)", ERROR2),
                PATH, "print(x)", ERROR2, "print('changed while running')"));
    }

    @Test public void rejectsPathChangeAndUntrustedMetadata() {
        String first = PythonAutoRepair.first(diagnostic("print(1/0)", ERROR1), PATH,
                "print(1/0)", ERROR1, BASE);
        assertEquals("", PythonAutoRepair.next(PythonAutoRepair.parse(first),
                PythonAutoFeedback.verificationPrompt("Измени main.py", "other.py", "print(x)", ERROR2),
                "other.py", "print(x)", ERROR2, BASE));
        assertNull(PythonAutoRepair.parse(first.replace("attempt=1", "attempt=999")));
        assertNull(PythonAutoRepair.parse(first.replace("path=src/main.py", "path=../main.py")));
        assertEquals("", PythonAutoRepair.first("not a diagnostic", PATH, "print(1/0)", ERROR1, BASE));
    }
}
