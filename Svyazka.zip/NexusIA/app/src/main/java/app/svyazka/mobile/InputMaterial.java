package app.svyazka.mobile;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Immutable references and request limits. No Android, filesystem, keys or request scheduling. */
public final class InputMaterial {
    public static final int MAX_FILES = 10;
    public static final long MAX_FILE_BYTES = 10L * 1024 * 1024;
    public static final long MAX_TOTAL_BYTES = 30L * 1024 * 1024;
    public static final int MAX_TEXT_CHARS = 200_000;
    public static final int MAX_REQUEST_TEXT_BYTES = 96_000;
    public static final int MAX_REQUEST_BYTES = 8 * 1024 * 1024;
    public static final int MAX_IMAGE_BYTES = 4 * 1024 * 1024;
    private static final Pattern UUID = Pattern.compile("[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}");
    private InputMaterial() {}

    public static final class Ref {
        public final long taskId;
        public final String id, name, mime, sha256;
        public final long size;
        public final int width, height;
        public Ref(long taskId, String id, String name, String mime, String sha256,
                   long size, int width, int height) {
            if (taskId <= 0 || !UUID.matcher(id).matches() || name.isEmpty() || name.length() > 1024
                    || !sha256.matches("[a-f0-9]{64}") || size < 0 || size > MAX_FILE_BYTES
                    || width < 0 || height < 0 || (long) width * height > 40_000_000L
                    || mime.startsWith("image/") && (!imageMime(mime) || width == 0 || height == 0)) {
                throw new IllegalArgumentException("Invalid material reference");
            }
            this.taskId = taskId; this.id = id; this.name = name; this.mime = mime;
            this.sha256 = sha256; this.size = size; this.width = width; this.height = height;
        }
        public boolean isImage() { return imageMime(mime); }
        public JSONObject toJson() throws JSONException {
            return new JSONObject().put("task_id", taskId).put("id", id).put("name", name)
                    .put("mime", mime).put("sha256", sha256).put("size", size)
                    .put("width", width).put("height", height);
        }
        public static Ref fromJson(JSONObject value) throws JSONException {
            try {
                return new Ref(value.getLong("task_id"), value.getString("id"), value.getString("name"),
                        value.getString("mime"), value.getString("sha256"), value.getLong("size"),
                        value.optInt("width"), value.optInt("height"));
            } catch (IllegalArgumentException e) { throw new JSONException("Invalid material reference"); }
        }
    }

    public static final class Image {
        public final Ref ref;
        public final String base64;
        public Image(Ref ref, byte[] bytes) throws AttachmentProblem {
            if (!ref.isImage() || bytes.length != ref.size || !sha256(bytes).equals(ref.sha256))
                throw new AttachmentProblem(AttachmentProblem.Code.INTEGRITY, ref.name);
            if (bytes.length > MAX_IMAGE_BYTES) throw new AttachmentProblem(AttachmentProblem.Code.IMAGE_SIZE, ref.name);
            this.ref = ref;
            this.base64 = Base64.getEncoder().encodeToString(bytes);
        }
    }

    public static boolean imageMime(String mime) {
        return "image/jpeg".equals(mime) || "image/png".equals(mime) || "image/webp".equals(mime);
    }
    public static String sha256(byte[] bytes) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
            StringBuilder result = new StringBuilder(64);
            for (byte item : digest) result.append(String.format(Locale.ROOT, "%02x", item & 0xff));
            return result.toString();
        } catch (NoSuchAlgorithmException impossible) { throw new IllegalStateException(impossible); }
    }
    public static List<Ref> readRefs(JSONArray array) throws JSONException {
        if (array == null) return Collections.emptyList();
        if (array.length() > MAX_FILES) throw new JSONException("Too many input materials");
        List<Ref> result = new ArrayList<>();
        java.util.Set<String> ids = new java.util.HashSet<>();
        for (int i = 0; i < array.length(); i++) {
            Ref ref = Ref.fromJson(array.getJSONObject(i));
            if (!ids.add(ref.id)) throw new JSONException("Duplicate input material");
            result.add(ref);
        }
        return Collections.unmodifiableList(result);
    }
    static long imageTokens(List<Ref> refs) {
        long tokens = 0;
        for (Ref ref : refs) if (ref.isImage()) {
            tokens += Math.max(16_384L, ((ref.width + 223L) / 224) * ((ref.height + 223L) / 224) * 512L);
        }
        return tokens;
    }
    static void validate(Workflow.Run run, ModelCatalog.Model model, List<Image> images)
            throws AttachmentProblem, JSONException {
        if (run.materials.isEmpty()) {
            if (!images.isEmpty()) throw new AttachmentProblem(AttachmentProblem.Code.INTEGRITY);
            return;
        }
        List<Ref> expected = new ArrayList<>();
        long imageBytes = 0;
        for (Ref ref : run.materials) if (ref.isImage()) { expected.add(ref); imageBytes += ref.size; }
        if (imageBytes > MAX_IMAGE_BYTES) throw new AttachmentProblem(AttachmentProblem.Code.IMAGE_SIZE);
        if (images.size() != expected.size()) throw new AttachmentProblem(AttachmentProblem.Code.MISSING);
        for (int i = 0; i < images.size(); i++) {
            if (!images.get(i).ref.id.equals(expected.get(i).id)
                    || !images.get(i).ref.sha256.equals(expected.get(i).sha256))
                throw new AttachmentProblem(AttachmentProblem.Code.INTEGRITY);
        }
        if (!images.isEmpty() && (model.provider != Workflow.Provider.OPENROUTER || !model.imageInput))
            throw new AttachmentProblem(AttachmentProblem.Code.MODEL_IMAGES, model.label);
        if (model.context <= 0) throw new AttachmentProblem(AttachmentProblem.Code.UNKNOWN_CONTEXT, model.label);
        long input = utf8(run.instructions()) + utf8(run.prompt()) + imageTokens(run.materials);
        if (run.draftMode == Workflow.DraftMode.CONTINUE) input += utf8(run.draft.text);
        if (input + 8192L > model.context)
            throw new AttachmentProblem(AttachmentProblem.Code.MODEL_CONTEXT,
                    model.label + ": " + input + " / " + model.context);
    }
    public static int utf8(String text) { return text.getBytes(StandardCharsets.UTF_8).length; }
}
