package app.svyazka.mobile.ui

import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.res.stringResource
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import app.svyazka.mobile.MainActivity
import app.svyazka.mobile.NexusState
import app.svyazka.mobile.NexusPythonReport
import app.svyazka.mobile.R
import app.svyazka.mobile.attachments.AttachmentStore

/** Only state and UI navigation. Requests, Python execution and persistence remain in Java. */
class NexusComposeUi(val activity: MainActivity) {
    enum class Page { TASK, RESULT, MODELS, HISTORY, ARTIFACTS, PROJECT, SETTINGS }
    enum class Panel { NONE, LEFT, RIGHT }
    enum class WorkspaceTab { PYTHON, CODE, LOGS, FILES }
    enum class WorkspaceFilesView { PROJECT, ATTACHMENTS }

    var snapshot by mutableStateOf(activity.nexusSnapshot())
        private set
    var verification by mutableStateOf(activity.nexusVerification())
        private set
    fun updateVerification() { verification = activity.nexusVerification() }
    var taskId by mutableLongStateOf(activity.nexusTaskId())
        private set
    var projectId by mutableLongStateOf(activity.nexusArtifactId())
        private set
    var artifacts by mutableStateOf(activity.nexusArtifacts())
        private set
    fun refreshArtifacts() { artifacts = activity.nexusArtifacts() }
    fun projectCreated(id: Long) {
        if (projectId == 0L) activity.nexusBuffer("python", "")
        projectId = id
        refreshPythonFiles()
        refreshArtifacts()
    }
    init { AttachmentStore.get(activity).ensure(taskId) }
    var draft by mutableStateOf(snapshot.task)
        private set
    fun draftChanged(value: String) { draft = value; activity.nexusDraftChanged(value) }
    var chatText by mutableStateOf(if (snapshot.hasRun) activity.nexusBuffer("message") else snapshot.task)
        private set
    fun chatTextChanged(value: String) {
        chatText = value
        if (!snapshot.hasRun) draftChanged(value) else activity.nexusBuffer("message", value)
    }
    fun submitChat() {
        if (snapshot.active || snapshot.clearing) return
        val message = chatText.trim()
        if (message.isBlank()) return
        if (!snapshot.hasRun) {
            draftChanged(message)
            activity.nexusStart()
        } else if (snapshot.complete) {
            activity.nexusFollowUp(message)
        }
        // Clear only after the Java workflow actually enters the running state.
    }
    var page by mutableStateOf(Page.TASK)
        private set
    var panel by mutableStateOf(Panel.NONE)
        private set
    // When a destination was opened from the left drawer, Back returns to that drawer.
    private var drawerReturnPage by mutableStateOf<Page?>(null)
    private var rightOpenedFromLeft = false
    private var teamSettingsFromLeft = false
    var workspaceTab by mutableStateOf(WorkspaceTab.PYTHON)
    var workspaceFilesView by mutableStateOf(WorkspaceFilesView.PROJECT)
    var pythonToolsOpen by mutableStateOf(false)
    var searching by mutableStateOf(false)
    var historySearching by mutableStateOf(false)
    var teamSettingsRequested by mutableStateOf(false)
    var streaming by mutableStateOf("")
        private set
    private var lastStreamAt = 0L

    var visualPng by mutableStateOf("")
        private set
    var visualHtml by mutableStateOf("")
        private set
    var visualOpen by mutableStateOf(false)
        private set
    var pythonCodeBlocks by mutableStateOf(emptyList<String>())
        private set
    var pythonFileName by mutableStateOf("main.py")
        private set
    var pythonFileList by mutableStateOf(listOf("main.py"))
        private set
    var pythonProjectIssue by mutableStateOf("")
        private set
    var pythonFileDirty by mutableStateOf(false)
        private set
    fun pythonFileSaved(task: Long, name: String) {
        if (task == taskId && name == pythonFileName) pythonFileDirty = false
    }
    var pythonEditingCode by mutableStateOf(activity.nexusPythonRead("main.py")
        .ifEmpty { if (projectId == 0L) activity.nexusBuffer("python") else "" })
        private set
    // Must be initialized before refreshPythonFiles() runs in the init block.
    var pythonRemote by mutableStateOf(false)
    init {
        refreshPythonFiles()
        val previous = activity.nexusPythonRestoredVisual()
        if (previous[0].isNotEmpty() || previous[1].isNotEmpty()) cacheVisual(previous[0],previous[1])
    }
    fun refreshPythonFiles() {
        pythonFileList = (listOf("main.py") + activity.nexusPythonPaths().toList()).distinct().sorted()
        if (pythonFileList.size > 1) pythonRemote = false
    }
    fun editPython(value: String) {
        pythonEditingCode = value
        if (pythonFileName == "main.py" && projectId == 0L)
            activity.nexusBuffer("python", value)
        pythonFileDirty = true
        activity.nexusPythonStageFile(taskId, pythonFileName, value)
    }
    fun openPythonFile(name: String) {
        if (pythonBusy || !pythonFileList.contains(name) || name == pythonFileName) return
        if (name.endsWith(".png") || name.endsWith(".zip")) {
            pythonProjectIssue = activity.getString(R.string.ws_binary_file)
            return
        }
        activity.nexusPythonFlushPending()
        pythonFileName = name
        pythonEditingCode = activity.nexusPythonRead(name)
        pythonProjectIssue = ""
        pythonFileDirty = false
    }
    fun reloadPythonFile() {
        activity.nexusPythonFlushPending()
        pythonEditingCode = activity.nexusPythonRead(pythonFileName)
        pythonFileDirty = false
    }
    fun addPythonFile(name: String) {
        if (pythonBusy) return
        if (!app.svyazka.mobile.PythonProjectStore.validPath(name) || pythonFileList.contains(name)) {
            pythonProjectIssue = activity.getString(R.string.ws_invalid_name)
            return
        }
        pythonProjectIssue = activity.nexusPythonPut(name, ByteArray(0))
        if (pythonProjectIssue.isEmpty()) { refreshPythonFiles(); openPythonFile(name) }
    }
    fun removePythonFile() {
        if (pythonBusy) return
        pythonProjectIssue = activity.nexusPythonRemove(pythonFileName)
        if (pythonProjectIssue.isEmpty()) {
            pythonFileName = "main.py"
            pythonEditingCode = activity.nexusPythonRead("main.py")
            pythonFileDirty = false
            refreshPythonFiles()
        }
    }
    fun renamePythonFile(newName: String) {
        if (pythonBusy) return
        pythonProjectIssue = activity.nexusPythonRename(pythonFileName, newName)
        if (pythonProjectIssue.isEmpty()) { pythonFileName = newName; refreshPythonFiles() }
    }
    fun projectChanged(result: String) {
        pythonProjectIssue = result
        if (result.isEmpty()) {
            refreshPythonFiles()
            if (pythonFileList.contains(pythonFileName) && !pythonFileDirty) {
                pythonEditingCode = activity.nexusPythonRead(pythonFileName)
            }
        }
    }
    var pendingPython by mutableStateOf<String?>(null)
    private var pendingStep = -1
    fun loadPython(step: Int, code: String) {
        if (pythonEditingCode.isNotBlank() && code != pythonEditingCode) {
            pendingStep = step; pendingPython = code
        } else { pythonStep = step; pythonFileName = "main.py"; editPython(code); refreshPythonFiles() }
    }
    fun confirmPythonLoad() {
        pendingPython?.let { pythonStep = pendingStep; pythonFileName = "main.py"; editPython(it); refreshPythonFiles() }
        pendingPython = null
    }
    var webKind by mutableStateOf(activity.nexusBuffer("web_kind").ifEmpty { "html" })
        private set
    fun selectWebKind(kind: String) { webKind = kind; activity.nexusBuffer("web_kind", kind) }
    var webCode by mutableStateOf(activity.nexusBuffer("web"))
        private set
    fun editWeb(value: String) { webCode = value; activity.nexusBuffer("web", value) }

    var pythonStdin by mutableStateOf("")
    var pythonMatplotlib by mutableStateOf(false)
    var pythonStep by mutableIntStateOf(-1)
        private set
    var pythonHasPiston by mutableStateOf(activity.nexusHasPiston())
        private set
    var pythonBusy by mutableStateOf(false)
        private set
    var pythonReport by mutableStateOf<NexusPythonReport?>(activity.nexusPythonRestoredReport())
        private set
    var pythonError by mutableStateOf<String?>(null)
        private set

    fun requestPython(step: Int, codes: Array<String>, hasPiston: Boolean) {
        pythonCodeBlocks = codes.toList()
        codes.firstOrNull()?.let { loadPython(step, it) }
        pythonHasPiston = hasPiston
        workspaceTab = WorkspaceTab.PYTHON
        openRight()
    }
    fun dismissPythonInput() { pythonCodeBlocks = emptyList() }
    fun pythonStarted() { pythonCodeBlocks = emptyList(); pythonBusy = true; pythonReport = null; pythonError = null }
    fun pythonFinished(report: NexusPythonReport) { pythonBusy = false; pythonReport = report }
    fun pythonFailed(error: String) { pythonBusy = false; pythonError = error }
    fun pythonCancelled() { pythonBusy = false; pythonError = null; pythonReport = null }
    fun dismissPythonResult() { pythonReport = null; pythonError = null }

    var versionsRequested by mutableStateOf(false)
        private set
    fun requestVersions() { versionsRequested = true }
    fun dismissVersions() { versionsRequested = false }
    var keysRequested by mutableStateOf(false)
        private set
    var keyProvider by mutableIntStateOf(0)
    fun requestKeys() { keyProvider = 0; keysRequested = true }

    fun saveNavigation(state: Bundle) {
        state.putString("nexus.page", page.name)
        drawerReturnPage?.let { state.putString("nexus.drawerReturnPage", it.name) }
        state.putBoolean("nexus.keysOpen", keysRequested)
        if (keysRequested) state.putInt("nexus.keyProvider", keyProvider)
    }

    fun restoreNavigation(state: Bundle) {
        val restored = Page.values().firstOrNull { it.name == state.getString("nexus.page") } ?: return
        selectPage(restored)
        drawerReturnPage = Page.values().firstOrNull {
            it.name == state.getString("nexus.drawerReturnPage")
        }
        keysRequested = state.getBoolean("nexus.keysOpen")
        keyProvider = state.getInt("nexus.keyProvider").coerceIn(0, 3)
    }
    fun dismissKeys() { keysRequested = false }
    var newTaskConfirm by mutableIntStateOf(0)
        private set
    fun hasDraftContent(): Boolean {
        val store = AttachmentStore.get(activity)
        return chatText.isNotBlank() || pythonEditingCode.isNotBlank() || webCode.isNotBlank() ||
            pythonFileList.any { it != "main.py" } ||
            store.states.value[taskId]?.items?.isNotEmpty() == true || (store.operations.value[taskId] ?: 0) > 0
    }
    fun requestNewTask() {
        if (snapshot.clearing || newTaskConfirm != 0) return
        if (hasDraftContent() || activity.nexusHasSavedPythonFiles() || snapshot.active || pythonBusy) newTaskConfirm = 1
        else activity.nexusCreateTask()
    }
    var deleteTarget by mutableStateOf<Long?>(null)
    fun dismissNewTask() { newTaskConfirm = 0 }
    fun closeVisual() { visualOpen = false }

    fun openLeft() { panel = Panel.LEFT }
    fun openRight() {
        rightOpenedFromLeft = panel == Panel.LEFT
        pythonHasPiston = activity.nexusHasPiston()
        panel = Panel.RIGHT
    }
    fun closePanel() { panel = Panel.NONE; rightOpenedFromLeft = false }
    fun openTeamSettingsFromDrawer() {
        teamSettingsFromLeft = panel == Panel.LEFT
        closePanel()
        teamSettingsRequested = true
    }
    fun dismissTeamSettings() {
        teamSettingsRequested = false
        if (teamSettingsFromLeft) panel = Panel.LEFT
        teamSettingsFromLeft = false
    }
    fun selectPage(newPage: Page) {
        if (panel == Panel.LEFT && page != newPage) drawerReturnPage = page
        page = newPage
        closePanel()
    }

    fun mount() {
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        val compose = ComposeView(activity).apply { id = R.id.nexus_compose_root }
        compose.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
        activity.attachChatContent(compose)
        compose.setContent { NexusApp(this) }
    }

    fun render(updated: NexusState, newPage: Page?) {
        val changedTask = taskId != activity.nexusTaskId()
        val changedProject = projectId != activity.nexusArtifactId()
        snapshot = updated
        updateVerification()
        taskId = activity.nexusTaskId()
        projectId = activity.nexusArtifactId()
        refreshArtifacts()
        AttachmentStore.get(activity).ensure(taskId)
        if (updated.task != draft) draft = updated.task
        if (changedTask) {
            searching = false
            historySearching = false
            chatText = if (updated.hasRun) activity.nexusBuffer("message") else updated.task
            webCode = activity.nexusBuffer("web")
            webKind = activity.nexusBuffer("web_kind").ifEmpty { "html" }
        } else if (updated.active && chatText.isNotEmpty()) {
            chatText = ""
            activity.nexusBuffer("message", "")
        } else if (!updated.hasRun && updated.task != chatText) {
            chatText = updated.task
        }
        if (changedTask || changedProject) {
            pythonReport = activity.nexusPythonRestoredReport()
            val previousVisual = activity.nexusPythonRestoredVisual()
            cacheVisual(previousVisual[0], previousVisual[1])
            pythonError = null
            pythonCodeBlocks = emptyList()
            pythonFileName = "main.py"
            pythonFileDirty = false
            pythonEditingCode = activity.nexusPythonRead("main.py")
                .ifEmpty { if (projectId == 0L) activity.nexusBuffer("python") else "" }
            refreshPythonFiles()
            pendingPython = null
            pythonStep = -1
            pythonStdin = ""
            pythonProjectIssue = ""
        }
        if (newPage != null) {
            // TASK and RESULT are one physical chat; Java keeps its persistence flags.
            val destination = if (newPage == Page.RESULT) Page.TASK else newPage
            if (panel == Panel.LEFT) selectPage(destination) else {
                page = destination
                if (destination == Page.TASK) drawerReturnPage = null
            }
        }
        if (!updated.active) streaming = ""
    }

    fun open(newPage: Page) { selectPage(newPage) }
    fun onStreaming(text: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastStreamAt < 110) return
        lastStreamAt = now
        streaming = if (text.length > 5000) text.takeLast(5000) else text
    }
    var theme by mutableStateOf(activity.nexusThemeChoice())
        private set
    fun onThemeChanged(value: String) { theme = value }
    fun onVisualAvailable(available: Boolean) {
        if (!available) { visualPng = ""; visualHtml = "" }
        snapshot = activity.nexusSnapshot()
    }
    fun cacheVisual(png: String, html: String) { visualPng = png; visualHtml = html }
    fun showVisual(png: String, html: String) { cacheVisual(png, html); visualOpen = true }
    fun openVisual() { if (visualPng.isNotBlank() || visualHtml.isNotBlank()) visualOpen = true }

    fun navigateBack(): Boolean {
        if (visualOpen) { visualOpen = false; return true }
        if (panel == Panel.NONE && ((page == Page.HISTORY && historySearching) || (page == Page.TASK && searching))) {
            searching = false; historySearching = false; return true
        }
        if (teamSettingsRequested) { dismissTeamSettings(); return true }
        if (panel == Panel.RIGHT && rightOpenedFromLeft) {
            rightOpenedFromLeft = false
            panel = Panel.LEFT
            return true
        }
        if (panel != Panel.NONE) { closePanel(); return true }
        if (page == Page.PROJECT) {
            page = Page.ARTIFACTS
            refreshArtifacts()
            return true
        }
        drawerReturnPage?.let { origin ->
            drawerReturnPage = null
            page = origin
            panel = Panel.LEFT
            return true
        }
        if (page == Page.MODELS || page == Page.SETTINGS || page == Page.HISTORY || page == Page.ARTIFACTS) {
            page = Page.TASK
            return true
        }
        return false
    }
}

@Composable
private fun NexusApp(ui: NexusComposeUi) {
    val activity = ui.activity
    val darkMode = ui.theme == "dark" ||
        (ui.theme == "system" && NexusSystemIsDark())
    SideEffect {
        @Suppress("DEPRECATION")
        activity.window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        activity.window.navigationBarColor = Color.TRANSPARENT
        val controller = WindowInsetsControllerCompat(activity.window, activity.window.decorView)
        controller.isAppearanceLightStatusBars = !darkMode
        controller.isAppearanceLightNavigationBars = !darkMode
    }
    NexusTheme(ui.theme) {
        BackHandler(enabled = true) {
            if (!ui.navigateBack()) activity.finish()
        }
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            Scaffold(
                modifier = Modifier.fillMaxSize().imePadding(),
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground,
                topBar = { NexusTopBar(ui) }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (ui.page) {
                        NexusComposeUi.Page.TASK, NexusComposeUi.Page.RESULT -> NexusChatScreen(ui)
                        NexusComposeUi.Page.HISTORY -> HistoryScreen(ui)
                        NexusComposeUi.Page.ARTIFACTS -> ArtifactsScreen(ui)
                        NexusComposeUi.Page.PROJECT -> Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { activity.nexusNewChatForArtifact() },
                                    enabled = !ui.snapshot.active && !ui.snapshot.clearing && !ui.pythonBusy,
                                    modifier = Modifier.weight(1f)) {
                                    Text(stringResource(R.string.artifacts_new_chat))
                                }
                                if (activity.nexusChatProjectId() == ui.projectId && ui.projectId > 0L) {
                                    TextButton(onClick = { activity.nexusDetachArtifactFromChat() },
                                        enabled = !ui.snapshot.active && !ui.snapshot.clearing && !ui.pythonBusy) {
                                        Text(stringResource(R.string.artifacts_detach_chat))
                                    }
                                }
                            }
                            Box(Modifier.weight(1f)) { NexusPythonWorkspace(ui) }
                        }
                        NexusComposeUi.Page.MODELS -> ModelsScreen(ui)
                        NexusComposeUi.Page.SETTINGS -> SettingsScreen(ui)
                    }
                }
            }
            NexusSidePanels(ui)
            if (ui.newTaskConfirm > 0) {
                NexusFrostedAlertDialog(onDismissRequest = { ui.dismissNewTask() },
                    title = { Text(stringResource(R.string.ui_new_chat)) },
                    text = { Text(stringResource(R.string.new_chat_consequences)) },
                    confirmButton = { TextButton(onClick = {
                        ui.dismissNewTask()
                        ui.activity.nexusCreateTask()
                    }) { Text(stringResource(R.string.action_create)) } },
                    dismissButton = { TextButton(onClick = { ui.dismissNewTask() }) {
                        Text(stringResource(R.string.action_cancel))
                    } })
            }
            ui.deleteTarget?.let { id ->
                NexusFrostedAlertDialog(onDismissRequest = { ui.deleteTarget = null },
                    title = { Text(stringResource(R.string.history_delete_first)) },
                    text = { Text(stringResource(R.string.history_delete_warning)) },
                    confirmButton = { TextButton(onClick = {
                        ui.deleteTarget = null
                        activity.nexusDeleteTask(id)
                    }) { Text(stringResource(R.string.action_delete)) } },
                    dismissButton = { TextButton(onClick = { ui.deleteTarget = null }) {
                        Text(stringResource(R.string.action_cancel))
                    } })
            }
            if (ui.keysRequested) KeysDialog(ui) { ui.dismissKeys() }
            if (ui.versionsRequested) VersionsDialog(ui)
            if (ui.teamSettingsRequested) NexusTeamSettings(ui)
            // Python runs and results are nonmodal: only the right panel renders them.
            VisualResultOverlay(ui)
        }
    }
}
