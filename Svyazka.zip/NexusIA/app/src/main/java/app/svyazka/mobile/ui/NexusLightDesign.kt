package app.svyazka.mobile.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.shadow
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Light-only design targets from the four approved Frosted Glass screenshots.
 *  Alpha, dp and gradients are implementation targets, not original Figma layer values.
 *  Dark theme is configured separately in NexusDarkDesign.kt.
 */
internal object NexusLightDesign {
    val ink = Color(0xFF111318)
    val secondary = Color(0xFF5F6678)
    val blue = Color(0xFF1F7BFF)
    val cyan = Color(0xFF35CFFF)
    val purple = Color(0xFFB93CFF)
    val paleBlue = Color(0xFFE6EBF7)
    val border = Color(0xFFD2DCEE).copy(alpha = .85f)
    // Match the existing left drawer translucency across all light-theme glass.
    val glass = Color.White.copy(alpha = .88f)
    val glassHighlight = Color.White.copy(alpha = .84f)
    val mint = Color(0xFFE6F5EE)
    val success = Color(0xFF20C95A)
    val folder = Color(0xFFF4C21A)
    val resultBackground = Color(0xFFEAF0FC)
    val console = Color(0xFFEFF1F8)
    val disabled = Color(0xFFE3E6EF)
    val disabledText = Color(0xFFA6ACB9)
    val destructive = Color(0xFFE53935)
    val buttonShape = RoundedCornerShape(24.dp)
    val cardShape = RoundedCornerShape(26.dp)
    val actionGradient = Brush.horizontalGradient(
        0f to Color(0xFF1EA2FF), .5f to Color(0xFF4D73FF), 1f to Color(0xFFC03DFF))
    val selectedChatGradient = Brush.horizontalGradient(
        listOf(Color(0xFF3B82F6), Color(0xFF35CFFF)))
}

/** Green success badge with black outline, shared by import and execution result. */
@Composable
internal fun NexusLightSuccessIcon(modifier: Modifier = Modifier.size(27.dp)) {
    androidx.compose.foundation.layout.Box(
        modifier.background(NexusLightDesign.success,
                androidx.compose.foundation.shape.CircleShape)
            .border(1.dp, NexusLightDesign.ink,
                androidx.compose.foundation.shape.CircleShape),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            androidx.compose.material.icons.Icons.Filled.Check,
            contentDescription = null, tint = Color.White,
            modifier = Modifier.fillMaxSize(.76f)
        )
    }
}

@Composable
internal fun nexusLightMode(): Boolean = LocalNexusIsLight.current

/** Decorative waves are drawn only behind content, and never intercept touches. */
@Composable
internal fun NexusLightBackdrop(modifier: Modifier = Modifier) {
    Box(modifier.background(Brush.verticalGradient(listOf(
        Color(0xFFEEF1F7), Color(0xFFF8FAFD), Color(0xFFEFF1FA))))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val foreground = Path().apply {
                moveTo(0f, h * .88f)
                quadraticBezierTo(w * .38f, h * .96f, w * .57f, h * .95f)
                quadraticBezierTo(w * .8f, h * .87f, w, h * .875f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(foreground, Color(0xFFE6EBF7).copy(alpha = .55f))
            val highlights = Path().apply {
                moveTo(w * .48f, h)
                quadraticBezierTo(w * .72f, h * .89f, w, h * .9f)
                lineTo(w, h)
                close()
            }
            drawPath(highlights, Color(0xFFE9E7F6).copy(alpha = .42f))
        }
    }
}

/** Project-only call to action; does not alter chat creation semantics. */
@Composable
internal fun NexusProjectNewChatButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    androidx.compose.material3.Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            .then(Modifier.shadow(2.dp, NexusLightDesign.buttonShape)),
        shape = NexusLightDesign.buttonShape,
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF5C98FF))
    ) {
        androidx.compose.material3.Text(
            text = text,
            modifier = Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(
                Color(0xFFE6F0FC), Color(0xFFD9EDFF)))).padding(horizontal = 8.dp, vertical = 12.dp),
            color = NexusLightDesign.blue,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            fontSize = 16.sp,
            maxLines = 1,
            softWrap = false,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
        )
    }
}

/** Ready ribbon uses the actual project state and existing localized resource. */
@Composable
internal fun NexusLightReadyRibbon(fileCount: Int) {
    androidx.compose.material3.Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        color = NexusLightDesign.mint.copy(alpha = .84f),
        border = androidx.compose.foundation.BorderStroke(1.dp, NexusLightDesign.glassHighlight)
    ) {
        androidx.compose.foundation.layout.Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            NexusLightSuccessIcon(Modifier.size(24.dp))
            androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
            androidx.compose.material3.Text(
                androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.ws_easy_import_success, fileCount),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                fontSize = 12.sp,
                color = Color(0xFF123A54),
                maxLines = 1,
                softWrap = false,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }
    }
}

/** Single light-only report layout. Dark rendering is still the original implementation. */
@Composable
internal fun NexusLightPythonReport(
    ui: NexusComposeUi,
    report: app.svyazka.mobile.NexusPythonReport,
    showArtifacts: Boolean,
    onToggleArtifacts: () -> Unit
) {
    val ok = report.exitCode == 0
    val accent = if (ok) NexusLightDesign.blue else MaterialTheme.colorScheme.error
    var showDiagnostics by androidx.compose.runtime.remember(report) {
        androidx.compose.runtime.mutableStateOf(false)
    }
    val tests = androidx.compose.runtime.remember(report.testsJson) {
        runCatching { org.json.JSONArray(report.testsJson) }.getOrNull()
    }
    val passed = if (tests != null) (0 until tests.length()).count {
        tests.optJSONObject(it)?.optBoolean("passed") == true
    } else 0
    val count = tests?.length() ?: 0
    val artifactCount = androidx.compose.runtime.remember(report.artifactsJson) {
        runCatching { org.json.JSONArray(report.artifactsJson).length() }.getOrDefault(0)
    }
    androidx.compose.material3.Surface(
        modifier = Modifier.fillMaxWidth().shadow(5.dp, NexusLightDesign.cardShape),
        shape = NexusLightDesign.cardShape,
        color = NexusLightDesign.glass,
        border = androidx.compose.foundation.BorderStroke(1.dp,
            if (ok) NexusLightDesign.glassHighlight else MaterialTheme.colorScheme.error)
    ) {
        androidx.compose.foundation.layout.Column(
            Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(
                Color.White.copy(alpha = .36f), NexusLightDesign.resultBackground.copy(alpha = .40f),
                Color(0xFFF1EAFF).copy(alpha = .32f))))
                .padding(14.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)
        ) {
            // Status is shown in the collapsible summary above; do not repeat it.
            if (report.stdout.isNotBlank()) {
                androidx.compose.material3.Surface(
                    shape = RoundedCornerShape(13.dp),
                    color = NexusLightDesign.console,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFB9C5DD))
                ) {
                    androidx.compose.foundation.layout.Column {
                        androidx.compose.foundation.layout.Row(
                            Modifier.fillMaxWidth().height(24.dp)
                                .background(Color(0xFFDCE2F0).copy(alpha = .8f)).padding(horizontal = 12.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            repeat(3) {
                                Box(Modifier.padding(end = 5.dp).size(7.dp)
                                    .background(Color(0xFF9298B0), RoundedCornerShape(50)))
                            }
                            androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                            androidx.compose.material3.Text("›_", color = Color(0xFF66769A),
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                        androidx.compose.foundation.text.selection.SelectionContainer {
                            androidx.compose.material3.Text(report.stdout,
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                style = MaterialTheme.typography.bodyLarge,
                                color = NexusLightDesign.ink, maxLines = 8)
                        }
                    }
                }
            }
            if (ui.verification.total > 0) {
                androidx.compose.material3.Text(
                    androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.verify_count,
                        ui.verification.passed, ui.verification.total),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    color = if (ui.verification.passed == ui.verification.total)
                        NexusLightDesign.blue else MaterialTheme.colorScheme.error,
                    maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            if (count > 0) {
                androidx.compose.material3.Text(
                    androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.ws_easy_tests_summary,
                        passed, count),
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexusLightDesign.secondary,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            if (report.status.isNotBlank()) {
                androidx.compose.material3.Text(report.status,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (ok) NexusLightDesign.secondary else MaterialTheme.colorScheme.error)
            }
            if (artifactCount > 0) {
                androidx.compose.material3.TextButton(onClick = onToggleArtifacts) {
                    androidx.compose.material3.Text(
                        androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.ws_easy_artifacts, artifactCount))
                }
            }
            if (showArtifacts) PythonRunArtifacts(ui)
            if (report.stderr.isNotBlank()) {
                if (ok) {
                    androidx.compose.material3.TextButton(onClick = { showDiagnostics = !showDiagnostics }) {
                        androidx.compose.material3.Text(androidx.compose.ui.res.stringResource(
                            if (showDiagnostics) app.svyazka.mobile.R.string.ws_hide_run_diagnostics
                            else app.svyazka.mobile.R.string.ws_show_run_diagnostics))
                    }
                }
                if (!ok || showDiagnostics) {
                    androidx.compose.foundation.text.selection.SelectionContainer {
                        androidx.compose.material3.Text(report.stderr,
                            color = if (ok) MaterialTheme.colorScheme.onSurfaceVariant else accent,
                            maxLines = if (ok) 20 else 6)
                    }
                }
            }
            if (report.hasVisual) {
                androidx.compose.material3.TextButton(onClick = { ui.openVisual() }) {
                    androidx.compose.material3.Text(
                        androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.action_show_result))
                }
            }
        }
    }
}
