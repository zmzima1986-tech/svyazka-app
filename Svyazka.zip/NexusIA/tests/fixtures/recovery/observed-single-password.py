# file=src/password_generator.py
"""
Генератор случайных паролей.

Пароль генерируется длиной от 8 до 32 символов (включительно) из:
- заглавные и строчные латинские буквы,
- цифры,
- специальные символы: !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~

Для проверки корректности работы реализовано 5 автоматических тестов
на базе unittest. При запуске скрипта тесты выполняются автоматически,
затем выводится один сгенерированный пароль.
"""

import string
import secrets
import unittest


# -------------------------- Основная логика -------------------------- #
def generate_password(min_length: int = 8, max_length: int = 32) -> str:
    """
    Генерирует случайный пароль.

    :param min_length: минимальная длина пароля (включительно). По умолчанию 8.
    :param max_length: максимальная длина пароля (включительно). По умолчанию 32.
    :return: строка‑пароль.
    :raises ValueError: если ограничения некорректны.
    """
    if not (1 <= min_length <= max_length):
        raise ValueError("min_length должно быть >= 1 и <= max_length")

    # набор допустимых символов
    alphabet = (
        string.ascii_letters +  # a-zA-Z
        string.digits +         # 0-9
        string.punctuation      # специальные символы
    )

    length = secrets.randbelow(max_length - min_length + 1) + min_length
    password = ''.join(secrets.choice(alphabet) for _ in range(length))
    return password


# -------------------------- Тесты -------------------------- #
class TestPasswordGenerator(unittest.TestCase):
    def test_length_bounds(self):
        """Пароль должен быть в заданных границах."""
        for _ in range(100):
            pwd = generate_password(8, 32)
            self.assertGreaterEqual(len(pwd), 8)
            self.assertLessEqual(len(pwd), 32)

    def test_allowed_characters(self):
        """Все символы пароля должны принадлежать набору разрешённых."""
        allowed = set(string.ascii_letters + string.digits + string.punctuation)
        pwd = generate_password()
        self.assertTrue(all(ch in allowed for ch in pwd),
                        "Пароль содержит недопустимые символы")

    def test_randomness(self):
        """Два подряд сгенерированных пароля, как правило, различаются."""
        pwd1 = generate_password()
        pwd2 = generate_password()
        # небольшая вероятность совпадения, но в тесте считаем её недопустимой
        self.assertNotEqual(pwd1, pwd2, "Два пароля не должны совпадать")

    def test_custom_lengths(self):
        """Проверка генерации пароля с пользовательскими границами."""
        pwd = generate_password(10, 10)  # фиксированная длина
        self.assertEqual(len(pwd), 10)

    def test_invalid_arguments(self):
        """Неправильные границы должны вызывать ValueError."""
        with self.assertRaises(ValueError):
            generate_password(0, 5)          # min < 1
        with self.assertRaises(ValueError):
            generate_password(20, 10)        # min > max


# -------------------------- Точка входа -------------------------- #
def _run_tests_and_print_password():
    """Запускает тесты, а затем выводит один пароль."""
    # Запускаем unittest, но не завершаем процесс (exit=False)
    test_result = unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)
    # Если все тесты прошли, выводим пароль
    if test_result.result.wasSuccessful():
        print("\nСгенерированный пароль:", generate_password())
    else:
        print("\nТесты не прошли. Пароль не будет сгенерирован.")


if __name__ == '__main__':
    try:
        _run_tests_and_print_password()
    except EOFError:
        # Обеспечиваем корректную работу при отсутствии stdin (например, в автоматических раннеров)
        _run_tests_and_print_password()
