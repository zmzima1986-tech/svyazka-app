#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

sdk="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$sdk" || ! -f "$sdk/platforms/android-35/android.jar" ||
      ! -x "$sdk/build-tools/35.0.0/aapt2" ]]; then
    echo "Нужны Android SDK Platform 35 и Android SDK Build-Tools 35.0.0. Укажи ANDROID_HOME." >&2
    exit 1
fi
platform="$sdk/platforms/android-35/android.jar"
tools="$sdk/build-tools/35.0.0"
javac="${JAVA_HOME:+$JAVA_HOME/bin/}javac"
jar="${JAVA_HOME:+$JAVA_HOME/bin/}jar"
keytool="${JAVA_HOME:+$JAVA_HOME/bin/}keytool"
output="$PWD/build/manual"
mkdir -p "$output"
stage=$(mktemp -d "$output/temp.XXXXXX")
trap 'rm -r -- "$stage"' EXIT
mkdir -p "$stage/generated" "$stage/classes" "$stage/dex"

application_id=$(awk -F "'" '/applicationId / {print $2; exit}' app/build.gradle)
version_name=$(awk -F "'" '/versionName / {print $2; exit}' app/build.gradle)
version_code=$(awk '/versionCode / {print $2; exit}' app/build.gradle)
sed "1s/<manifest /<manifest package=\"$application_id\" /" \
    app/src/main/AndroidManifest.xml > "$stage/AndroidManifest.xml"
"$tools/aapt2" compile --dir app/src/main/res -o "$stage/resources.zip"
"$tools/aapt2" link -I "$platform" --manifest "$stage/AndroidManifest.xml" \
    --java "$stage/generated" --custom-package app.svyazka.mobile -A app/src/main/assets \
    --min-sdk-version 26 --target-sdk-version 35 --version-code "$version_code" \
    --version-name "$version_name" -o "$stage/unsigned.apk" "$stage/resources.zip"
sources=()
while IFS= read -r -d '' path; do sources+=("$path"); done < <(
    find app/src/main/java "$stage/generated" -name '*.java' -print0
)
"$javac" -source 8 -target 8 -Xlint:-options -encoding UTF-8 \
    -bootclasspath "$platform:$tools/core-lambda-stubs.jar" \
    -d "$stage/classes" "${sources[@]}"
"$jar" cf "$stage/classes.jar" -C "$stage/classes" .
"$tools/d8" --min-api 26 --lib "$platform" --output "$stage/dex" "$stage/classes.jar"
(cd "$stage/dex" && zip -q -u "$stage/unsigned.apk" classes*.dex)
"$tools/zipalign" -f 4 "$stage/unsigned.apk" "$stage/aligned.apk"

if [[ ! -f "$output/signing.p12" ]]; then
    (
        umask 077
        od -An -N24 -tx1 /dev/urandom | tr -d ' \n' > "$output/signing.pass"
        "$keytool" -genkeypair -alias svyazka -keyalg RSA -keysize 3072 \
            -validity 3650 -dname "CN=Svyazka local build" -keystore "$output/signing.p12" \
            -storetype PKCS12 -storepass:file "$output/signing.pass"
    )
fi
apk="$output/Svyazka-$version_name.apk"
"$tools/apksigner" sign --ks "$output/signing.p12" --ks-pass "file:$output/signing.pass" \
    --v4-signing-enabled false --out "$apk" "$stage/aligned.apk"
"$tools/apksigner" verify "$apk"
echo "$apk"
