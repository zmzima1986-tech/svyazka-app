#!/usr/bin/env python3
"""Real Android Python-artifact lifecycle and WebView on a fresh disposable emulator.

Requires Gradle's app APK and androidTest APK (signed by the project's existing
Gradle configuration). Does not reset installed data or touch signing material.
"""
import subprocess
import hashlib
import os
import time
import xml.etree.ElementTree as ET
import sys
from pathlib import Path
from android_test_result import require_result

PACKAGE = 'app.svyazka.team'
RUNNER = PACKAGE + '.test/app.svyazka.fixture.UpgradeProbe'
STEPS = ('python_seed', 'python_verify', 'python_deleted', 'python_linked_candidate', 'model_recovery',
         'python_chat_context_seed', 'python_chat_context_verify', 'python_security', 'web',
         'project_roundtrip', 'project_merge', 'project_conflict', 'project_incomplete',
         'project_budget', 'project_rollback', 'runtime_typing', 'runtime_stdin',
         'runtime_assert_fail', 'runtime_import', 'runtime_output', 'runtime_cancel')
DEPENDS = {'python_verify': 'python_seed', 'python_deleted': 'python_verify',
           'python_chat_context_verify': 'python_chat_context_seed'}


def adb(*args, timeout=180):
    return subprocess.check_output(['adb', '-e', *args], stderr=subprocess.STDOUT,
                                   timeout=timeout, text=True)


def main(app_apk, test_apk):
    report_path = os.environ.get('NEXUS_ANDROID_REPORT_DIR')
    report = Path(report_path) if report_path else None
    suite = ET.Element('testsuite', name='Nexus Android probes')
    cases = []
    if report:
        report.mkdir(parents=True, exist_ok=True)

    def record(name, action):
        case = ET.SubElement(suite, 'testcase', name=name, classname='NexusAndroid')
        cases.append(case)
        started = time.monotonic()
        try:
            action()
        except Exception as exc:
            ET.SubElement(case, 'failure', message=type(exc).__name__).text = str(exc)
            raise
        finally:
            case.set('time', f'{time.monotonic() - started:.3f}')

    def setup():
        for path in (app_apk, test_apk):
            if not Path(path).is_file():
                raise FileNotFoundError(path)
        if adb('shell', 'getprop', 'ro.kernel.qemu').strip() != '1':
            raise RuntimeError('Only a disposable Android emulator is allowed')
        for label, path in (('app', app_apk), ('androidTest', test_apk)):
            print(f'{label} SHA-256: {hashlib.sha256(Path(path).read_bytes()).hexdigest()}', flush=True)
        print('Android API: ' + adb('shell', 'getprop', 'ro.build.version.sdk').strip(), flush=True)
        adb('install', '-r', app_apk, timeout=240)
        adb('install', '-r', '-t', test_apk, timeout=240)

    def probe(step):
        # A genuine app process restart, not an Activity-only recreation.
        adb('shell', 'am', 'force-stop', PACKAGE)
        output = adb('shell', 'am', 'instrument', '-w', '-e', 'step', step, RUNNER,
                     timeout=300)
        if report:
            (report / (step + '.txt')).write_text(output, encoding='utf-8')
        expected = ('NEXUS_WEBVIEW_TESTED' if step == 'web'
                    else 'NEXUS_PYTHON_HISTORY_' + step.upper())
        require_result(output, expected, step)
        print(f'{step}: {expected}; INSTRUMENTATION_CODE: -1', flush=True)
        print(f'{step}: PASS', flush=True)

    try:
        record('setup', setup)
        failed = {}
        unavailable = set()
        for step in STEPS:
            predecessor = DEPENDS.get(step)
            if predecessor in unavailable:
                unavailable.add(step)
                case = ET.SubElement(suite, 'testcase', name=step, classname='NexusAndroid')
                cases.append(case)
                ET.SubElement(case, 'skipped', message='Prerequisite failed: ' + predecessor)
                continue
            try:
                record(step, lambda: probe(step))
            except Exception as exc:
                failed[step] = exc
                unavailable.add(step)
        if failed:
            raise RuntimeError(' | '.join(f'{name} failed: {exc}' for name, exc in failed.items()))
        print('Python artifacts lifecycle and WebView on Android emulator: PASS', flush=True)
    finally:
        if report:
            # An aborted run must never turn unexecuted probes into successes.
            names = {case.get('name') for case in cases}
            for name in ('setup', *STEPS):
                if name not in names:
                    case = ET.SubElement(suite, 'testcase', name=name, classname='NexusAndroid')
                    ET.SubElement(case, 'skipped', message='Earlier failure')
            suite.set('tests', str(len(suite)))
            suite.set('failures', str(len(suite.findall('testcase/failure'))))
            suite.set('skipped', str(len(suite.findall('testcase/skipped'))))
            ET.ElementTree(suite).write(report / 'android-probes.xml', encoding='utf-8', xml_declaration=True)


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: test-android-python-history.py app.apk app-debug-androidTest.apk')
    main(*sys.argv[1:])
