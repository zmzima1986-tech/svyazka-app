'use strict';

window.addEventListener('message', start, { once: true });

function start(event) {
    const appPort = event.ports[0];
    if (!appPort) return;
    const input = JSON.parse(event.data);
    const worker = new Worker('worker.mjs', { type: 'module' });
    const channel = new MessageChannel();
    const port = channel.port1;
    let output = { stdout: '', stderr: '' };
    let engine = 'Python на телефоне';
    let executionTimer;
    let preparationTimer;
    const EXECUTION_TIMEOUT_MS = 5000;
    const MATPLOTLIB_PREPARATION_TIMEOUT_MS = 120000;
    const initializationTimer = setTimeout(() => finish({ error: 'Python не запустился за 30 секунд.' }), 30000);
    let finished = false;

    function finish(data) {
        if (finished) return;
        finished = true;
        clearTimeout(initializationTimer);
        clearTimeout(executionTimer);
        clearTimeout(preparationTimer);
        port.close();
        worker.terminate();
        appPort.postMessage(JSON.stringify({ ...output, engine, ...data }));
        appPort.close();
    }

    function executionTimeout() {
        finish({ status: 'Выполнение Python остановлено через 5 секунд.', code: null });
    }

    port.onmessage = ({ data }) => {
        if (data.kind === 'ready') {
            engine = data.engine;
            clearTimeout(initializationTimer);
            if (input.allow_matplotlib === true) {
                preparationTimer = setTimeout(() => finish({
                    status: 'Подготовка Matplotlib остановлена по лимиту 120 секунд.',
                    code: null,
                }), MATPLOTLIB_PREPARATION_TIMEOUT_MS);
            } else {
                // Includes setup time until the worker reports that Python execution has started.
                executionTimer = setTimeout(executionTimeout, EXECUTION_TIMEOUT_MS);
            }
            port.postMessage(input);
        } else if (data.kind === 'execution_start') {
            clearTimeout(preparationTimer);
            clearTimeout(executionTimer);
            // Never give arbitrary Python code the much longer package-download budget.
            executionTimer = setTimeout(executionTimeout, EXECUTION_TIMEOUT_MS);
        } else if (input.mode === 'verify' && data.kind === 'progress') {
            appPort.postMessage(JSON.stringify({ progress: data.progress }));
        } else if (input.mode === 'verify' && data.kind === 'verified') {
            finish({ verification: data.report });
        } else if (data.kind === 'output') {
            output = { stdout: data.stdout, stderr: data.stderr };
        } else if (data.kind === 'done') {
            finish({ stdout: data.stdout, stderr: data.stderr, code: data.code,
                status: data.status, image_png: data.image_png || '', html: data.html || '' });
        } else if (data.kind === 'error') {
            finish({ error: data.error });
        }
    };
    worker.onerror = () => finish({ error: 'Движок Python не смог запуститься. Проверь обновления Android System WebView.' });
    worker.postMessage({verify: input.mode === 'verify'}, [channel.port2]);
}
