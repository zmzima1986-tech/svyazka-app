package app.svyazka.mobile;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.ImageView;
import androidx.test.core.app.ApplicationProvider;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import org.robolectric.shadows.ShadowChoreographer;
import java.io.File;
import java.io.FileOutputStream;
import java.time.Duration;
import java.util.Locale;

import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public final class LaunchArtworkTest {
    private Context launchTheme(int night) {
        Context app = ApplicationProvider.getApplicationContext();
        Configuration config = new Configuration(app.getResources().getConfiguration());
        config.setLocale(Locale.forLanguageTag("ru"));
        config.uiMode = (config.uiMode & ~Configuration.UI_MODE_NIGHT_MASK) | night;
        return new ContextThemeWrapper(app.createConfigurationContext(config), R.style.Theme_NexusIA_Launch);
    }

    private Bitmap draw(Drawable drawable, int size) {
        Bitmap image = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        drawable.setBounds(0, 0, size, size);
        drawable.draw(new Canvas(image));
        return image;
    }

    private static Rect bounds(Bitmap bitmap, int fromY, int toY, int color) {
        Rect result = new Rect();
        for (int y = fromY; y < toY; y++) {
            for (int x = 0; x < bitmap.getWidth(); x++) {
                if (bitmap.getPixel(x, y) == color) result.union(x, y, x + 1, y + 1);
            }
        }
        return result;
    }

    private static void near(Rect actual, Rect reference, int tolerance) {
        assertFalse("Missing artwork at " + reference, actual.isEmpty());
        assertEquals(actual.toString(), reference.left, actual.left, tolerance);
        assertEquals(actual.toString(), reference.right, actual.right, tolerance);
        assertEquals(actual.toString(), reference.top, actual.top, tolerance);
        assertEquals(actual.toString(), reference.bottom, actual.bottom, tolerance);
    }

    @Test public void progressAndWavesMoveOnScreen() {
        Context context = launchTheme(Configuration.UI_MODE_NIGHT_YES);
        ShadowChoreographer.setPaused(true);
        ShadowChoreographer.setFrameDelay(Duration.ofMillis(16));
        try (ActivityController<Activity> holder = Robolectric.buildActivity(Activity.class).setup()) {
            NexusLaunchView view = new NexusLaunchView(context);
            holder.get().setContentView(view);
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(32));
            assertTrue(view.isAttachedToWindow());
            Drawable waves = ((ImageView) view.getChildAt(0)).getDrawable();
            Drawable mark = ((ImageView) view.getChildAt(1)).getDrawable();
            // Drawing to a software canvas also exercises the platform's UI-thread animators.
            Bitmap first = draw(mark, 691);
            Bitmap firstWaves = draw(waves, 691);
            for (int i = 0; i < 50; i++) shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(16));
            assertTrue(((Animatable) mark).isRunning());
            assertTrue(((Animatable) waves).isRunning());
            assertFalse("The loading segment must travel along the track", first.sameAs(draw(mark, 691)));
            assertFalse("The two lower curves must move", firstWaves.sameAs(draw(waves, 691)));
        }
    }

    @Test public void fullWindowMatchesTheReferenceInBothThemes() throws Exception {
        for (int mode : new int[]{Configuration.UI_MODE_NIGHT_NO, Configuration.UI_MODE_NIGHT_YES}) {
            Context context = launchTheme(mode);
            int width = 691;
            int height = 1536;
            NexusLaunchView view = new NexusLaunchView(context);
            view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
            view.layout(0, 0, width, height);
            Bitmap frame = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            view.draw(new Canvas(frame));
            String directory = System.getProperty("nexus.screenshot.dir");
            if (directory != null) {
                File png = new File(directory, mode == Configuration.UI_MODE_NIGHT_YES ? "launch-dark.png" : "launch-light.png");
                try (FileOutputStream file = new FileOutputStream(png)) {
                    frame.compress(Bitmap.CompressFormat.PNG, 100, file);
                }
            }
            near(bounds(frame, 505, 725, 0xff22e3ff), new Rect(262, 524, 430, 617), 3);
            near(bounds(frame, 505, 725, 0xff8738f5), new Rect(262, 661, 430, 718), 3);
            near(bounds(frame, 760, 880, context.getColor(R.color.nexus_launch_text)), new Rect(228, 797, 463, 843), 7);
            near(bounds(frame, 930, 980, context.getColor(R.color.nexus_launch_active)), new Rect(114, 953, 332, 965), 3);
            near(bounds(frame, 930, 980, context.getColor(R.color.nexus_launch_track)), new Rect(338, 953, 577, 965), 3);
            near(bounds(frame, 980, 1040, context.getColor(R.color.nexus_launch_label)), new Rect(283, 996, 408, 1018), 6);
            int background = context.getColor(R.color.nexus_launch_background);
            for (int[] point : new int[][]{{1, 1310}, {65, 1278}, {281, 1387}, {490, 1290}, {689, 1237}}) {
                assertEquals(background, frame.getPixel(point[0], point[1] - 6));
                assertNotEquals(background, frame.getPixel(point[0], point[1] + 6));
                assertNotEquals(background, frame.getPixel(point[0], height - 1));
            }
            TypedArray attrs = context.obtainStyledAttributes(new int[]{android.R.attr.windowSplashScreenAnimatedIcon});
            try {
                assertEquals(Color.TRANSPARENT, ((ColorDrawable) attrs.getDrawable(0)).getColor());
            } finally {
                attrs.recycle();
            }
        }
    }

    @Test public void launcherMarkIsCenteredInsideTheSafeCircle() {
        Context context = launchTheme(Configuration.UI_MODE_NIGHT_NO);
        for (int id : new int[]{R.mipmap.ic_launcher, R.mipmap.ic_launcher_round}) {
            AdaptiveIconDrawable icon = (AdaptiveIconDrawable) context.getDrawable(id);
            Bitmap bitmap = draw(icon.getForeground(), 108);
            Rect ink = new Rect();
            for (int y = 0; y < 108; y++) {
                for (int x = 0; x < 108; x++) {
                    if (Color.alpha(bitmap.getPixel(x, y)) < 64) continue;
                    ink.union(x, y, x + 1, y + 1);
                    assertTrue("Launcher mask clips the mark", Math.hypot(x + .5 - 54, y + .5 - 54) < 33);
                }
            }
            assertTrue(ink.width() >= 48);
            assertTrue(ink.height() >= 48);
            assertEquals(54f, ink.exactCenterX(), .5f);
            assertEquals(54f, ink.exactCenterY(), .5f);
        }
    }

}
