package app.svyazka.mobile;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import androidx.test.core.app.ApplicationProvider;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class WorkspaceMigrationTest {
    @Test public void versionTwoUpgradesWithoutMixingExplicitSavedChatsWithArtifacts() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        try (SQLiteDatabase db = context.openOrCreateDatabase("svyazka_tasks.db", 0, null)) {
            db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY, title TEXT NOT NULL, "
                    + "task TEXT NOT NULL DEFAULT '', run_json TEXT NOT NULL DEFAULT '', "
                    + "attempt_log TEXT NOT NULL DEFAULT '', results_visible INTEGER NOT NULL DEFAULT 0, "
                    + "created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, "
                    + "custom_title TEXT, pinned INTEGER NOT NULL DEFAULT 0)");
            db.execSQL("CREATE TABLE versions(id INTEGER PRIMARY KEY, task_id INTEGER, "
                    + "version_no INTEGER, run_json TEXT, created_at INTEGER)");
            db.execSQL("CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT)");
            db.execSQL("INSERT INTO tasks(id,title,task,created_at,updated_at) "
                    + "VALUES(90,'Старый Python','',10,20)");
            db.execSQL("INSERT INTO tasks(id,title,task,created_at,updated_at) "
                    + "VALUES(91,'Старый чат','Вопрос ИИ',10,20)");
            db.setVersion(2);
        }
        try (TaskRepository chats = new TaskRepository(context)) {
            assertNotNull(chats.load(90));
            assertFalse(chats.list().stream().anyMatch(c -> c.id == 90));
            assertTrue(chats.list().stream().anyMatch(c -> c.id == 91));
            assertTrue(chats.markSavedChat(90));
            assertTrue(chats.list().stream().anyMatch(c -> c.id == 90));
        }
        try (TaskRepository reopened = new TaskRepository(context)) {
            assertTrue(reopened.hasExplicitlySavedChat(90));
            assertEquals("Старый чат", reopened.load(91).title);
        }
    }

    @Test public void versionOneMigratesWithoutRewritingConversationOrCredentials() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        Workflow.Run quick = Workflow.Run.quick("calendar", ModelCatalog.NORTH, Workflow.defaultStages().get(1))
                .receive(new ModelClient.Reply("saved calendar", ModelClient.Finish.STOP, ""));
        String snapshot = quick.toJson().toString();
        context.getSharedPreferences("credentials", 0).edit().putString("marker", "existing").commit();
        try (SQLiteDatabase db = context.openOrCreateDatabase("svyazka_tasks.db", 0, null)) {
            db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY,title TEXT,task TEXT,run_json TEXT,attempt_log TEXT,results_visible INTEGER,created_at INTEGER,updated_at INTEGER)");
            db.execSQL("CREATE TABLE versions(id INTEGER PRIMARY KEY,task_id INTEGER REFERENCES tasks(id) ON DELETE CASCADE,version_no INTEGER,run_json TEXT,created_at INTEGER)");
            db.execSQL("CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT)");
            db.execSQL("INSERT INTO tasks VALUES(7,'начало','calendar',?,'log',1,10,20)", new Object[]{snapshot});
            db.execSQL("INSERT INTO versions VALUES(5,7,1,?,10)", new Object[]{snapshot});
            db.execSQL("INSERT INTO metadata VALUES('active_task_id','7')");
            db.setVersion(1);
        }
        try (TaskRepository db = new TaskRepository(context)) {
            assertEquals(7, db.activeId());
            assertEquals(snapshot, db.load(7).runJson);
            assertEquals(snapshot, db.versions(7).get(0).runJson);
            assertTrue(db.rename(7, "Мой календарь"));
            assertTrue(db.pin(7, true));
        }
        try (TaskRepository db = new TaskRepository(context)) {
            assertTrue(db.list().get(0).pinned);
            assertEquals("Мой календарь", db.load(7).title);
            assertEquals(1, db.load(7).versions);
            assertTrue(Workflow.Run.fromJson(new JSONObject(db.load(7).runJson)).complete());
            assertTrue(db.pin(7, false));
            assertFalse(db.load(7).pinned);
        }
        assertEquals("existing", context.getSharedPreferences("credentials", 0).getString("marker", ""));
    }
}
