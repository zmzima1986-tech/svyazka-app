package app.svyazka.mobile

import android.app.Activity
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ProviderInfo
import android.database.Cursor
import android.database.MatrixCursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.activity.ComponentDialog
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontWeight
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.test.core.app.ApplicationProvider
import app.svyazka.mobile.attachments.AttachmentStore
import app.svyazka.mobile.ui.NexusComposeUi
import app.svyazka.mobile.ui.isStandardRole
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExternalResource
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import org.robolectric.shadows.ShadowContentResolver
import org.robolectric.shadows.ShadowDialog
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.URL
import java.net.URLConnection
import java.net.URLStreamHandler
import java.util.UUID

/** Android contract, local extraction, rotation, insets, themes and RTL. All HTTP is blocked. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33], qualifiers = "ru-rRU-w360dp-h780dp-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class AttachmentUiTest {
    @get:Rule(order = 0) val setup = object : ExternalResource() {
        override fun before() {
            val context = ApplicationProvider.getApplicationContext<Context>()
            // Match a fresh application process for each independent test database.
            MainActivity::class.java.getDeclaredField("sharedStore").apply { isAccessible = true }.set(null, null)
            AttachmentStore::class.java.getDeclaredField("instance").apply { isAccessible = true }.set(null, null)
            // This runs after Robolectric has loaded its SDK and before the Activity starts.
            try {
                URL.setURLStreamHandlerFactory { protocol -> if (protocol == "http" || protocol == "https")
                    object : URLStreamHandler() { override fun openConnection(url: URL): URLConnection = throw IOException("offline-ui-test") }
                    else null }
            } catch (_: Error) { /* A previous test in this JVM may already have installed the same guard. */ }
            val error = runCatching { URL("https://openrouter.ai/api/v1/models").openConnection() }.exceptionOrNull()
            check(error is IOException && error.message == "offline-ui-test")
            val fixture = javaClass.classLoader!!.getResourceAsStream("openrouter-models.json")!!.bufferedReader().use { it.readText() }
            context.getSharedPreferences("workspace", Context.MODE_PRIVATE).edit()
                .putString("catalog", ModelCatalog.fromOpenRouter(JSONObject(fixture)).cacheData().toString())
                .putLong("catalog_time", System.currentTimeMillis()).putString("ui_theme", "dark").commit()
            val provider = FixtureFiles()
            provider.attachInfo(context, ProviderInfo().apply { authority = "nexus.fixture"; exported = false })
            ShadowContentResolver.registerProviderInternal("nexus.fixture", provider)
        }
    }
    @get:Rule(order = 1) val compose = createAndroidComposeRule<MainActivity>()
    private val activity get() = compose.activity
    private val ui get() = MainActivity::class.java.getDeclaredField("nexusUi").run { isAccessible = true; get(activity) as NexusComposeUi }
    private val store get() = AttachmentStore.get(activity)
    private fun text(id: Int) = activity.getString(id)
    private fun fixture(name: String): File {
        val file = File(activity.cacheDir, "test-inputs/$name"); file.parentFile!!.mkdirs()
        javaClass.classLoader!!.getResourceAsStream("attachments/$name")!!.use { input -> file.outputStream().use { input.copyTo(it) } }
        return file
    }
    private fun uri(name: String, mime: String, display: String = name, knownSize: Boolean = true): Uri =
        FixtureFiles.add(fixture(name), mime, display, knownSize)
    private fun idle(task: Long, count: Int? = null): AttachmentStore.Task {
        compose.waitUntil(30000) {
            val value = store.states.value[task]
            value?.loaded == true && (store.operations.value[task] ?: 0) == 0 &&
                (count == null || value.items.size == count) && value.items.none { it.status == AttachmentStore.Status.ADDING || it.status == AttachmentStore.Status.PROCESSING }
        }
        return store.states.value.getValue(task)
    }
    private fun screenshot(name: String) {
        val directory = System.getProperty("nexus.screenshot.dir") ?: return
        compose.waitForIdle()
        val bitmap = compose.runOnIdle {
            val dialog = ShadowDialog.getLatestDialog()
            val view = if (dialog?.isShowing == true) dialog.window!!.decorView else activity.window.decorView
            check(view.width > 0 && view.height > 0)
            Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888).also { view.draw(Canvas(it)) }
        }
        File(directory, "$name.png").apply { parentFile!!.mkdirs() }.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
    private fun import(task: Long, uris: List<Uri>, count: Int): AttachmentStore.Task {
        store.add(task, uris)
        return idle(task, count)
    }
    private fun cancelPicker() {
        val request = shadowOf(activity).nextStartedActivityForResult
        assertNotNull(request)
        assertTrue(request.intent.getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false))
        val method = MainActivity::class.java.getDeclaredMethod("onActivityResult", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Intent::class.java)
        method.isAccessible = true
        compose.runOnIdle { method.invoke(activity, request.requestCode, Activity.RESULT_CANCELED, null) }
        compose.waitForIdle()
    }
    private fun checkNav() {
        for (id in listOf(R.string.ui_open_menu, R.string.search_current, R.string.ui_open_workspace)) {
            compose.onNodeWithContentDescription(text(id)).assertIsDisplayed()
        }
        val selected = text(if (ui.snapshot.quick) R.string.ui_quick else R.string.ui_team)
        val other = text(if (ui.snapshot.quick) R.string.ui_team else R.string.ui_quick)
        compose.onNodeWithText(selected).assertIsDisplayed()
        if (compose.onAllNodesWithText(other).fetchSemanticsNodes().isEmpty()) {
            compose.onNodeWithText(selected).performClick()
            compose.onNodeWithText(other).assertIsDisplayed()
            compose.onAllNodesWithText(selected).onLast().performClick()
        } else compose.onNodeWithText(other).assertIsDisplayed()
    }
    @Test fun settingsStayVisibleAcrossThemeLanguageAndKeyChanges() {
        compose.onNodeWithContentDescription(text(R.string.ui_open_menu)).performClick()
        compose.onNodeWithText(text(R.string.settings_title)).performClick()
        for ((theme, label) in listOf("light" to R.string.theme_light, "system" to R.string.theme_system,
                "dark" to R.string.theme_dark)) {
            compose.onNodeWithText(text(label)).performClick()
            compose.waitForIdle()
            assertEquals(theme, activity.nexusThemeChoice())
            compose.onNodeWithText(text(R.string.settings_title)).assertIsDisplayed()
        }
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText(text(R.string.settings_title)).assertIsDisplayed()
        compose.onNodeWithText(text(R.string.language_system)).performClick()
        compose.onNodeWithText(text(R.string.language_en)).performClick()
        compose.waitForIdle()
        assertEquals("en", activity.nexusLanguageChoice())
        compose.onNodeWithText(text(R.string.settings_title)).assertIsDisplayed()

        compose.onNodeWithText(text(R.string.settings_providers)).performClick()
        compose.onNodeWithText("Groq").performClick()
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText(text(R.string.keys_groq)).assertIsDisplayed()
        var saved = false
        compose.runOnIdle {
            MainActivity::class.java.getDeclaredField("vault").apply { isAccessible = true }.set(activity,
                object : CredentialStore {
                    override fun read(provider: Workflow.Provider) = ""
                    override fun readPiston() = ""
                    override fun save(router: String, gemini: String, groq: String, piston: String) {
                        saved = groq == "offline-test-key"
                    }
                })
        }
        compose.onNode(hasSetTextAction()).performTextInput("offline-test-key")
        compose.onNodeWithText(text(R.string.action_save)).performClick()
        compose.waitForIdle()
        assertTrue(saved)
        assertFalse(ui.keysRequested)
        compose.onNodeWithText(text(R.string.settings_title)).assertIsDisplayed()
    }

    @Test fun bothChatModeLabelsFitAtTheLargerSize() {
        for (res in listOf(R.string.ui_quick, R.string.ui_team)) {
            val layout = mutableListOf<TextLayoutResult>()
            compose.onNodeWithText(text(res), useUnmergedTree = true)
                .assertIsDisplayed().performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layout) }
            assertEquals(14f, layout.single().layoutInput.style.fontSize.value, 0.01f)
            val result = layout.single()
            assertEquals(1, result.lineCount)
            assertFalse(result.isLineEllipsized(0))
            assertFalse(result.didOverflowHeight)
            // Compose can retain a paragraph wider than the measured Text. Check
            // the actual label bounds to detect clipping at either edge.
            assertTrue(result.getLineLeft(0) >= -1f)
            assertTrue(result.getLineRight(0) <= result.size.width + 1f)
        }
    }

    @Test fun fourAttachmentsTravelWithTheFollowUpAndTheFirstAnswerSurvives() {
        val task = activity.nexusTaskId()
        idle(task, 0)
        fun field(name: String) = MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }
        val transport = PythonRepairIntegrationTest.Transport()
        val previous = Workflow.Run.quick("Сделай календарь", ModelCatalog.NORTH, Workflow.defaultStages()[1])
            .receive(ModelClient.Reply("Первый ответ", ModelClient.Finish.STOP, ""))
        compose.runOnIdle {
            field("worker").set(activity, transport)
            field("vault").set(activity, object : CredentialStore {
                override fun read(provider: Workflow.Provider) = if (provider == Workflow.Provider.OPENROUTER) "offline-fixture" else ""
                override fun readPiston() = ""
                override fun save(a: String, b: String, c: String, d: String) { error("Unexpected credential edit") }
            })
            activity.nexusModeChanged(true)
            field("run").set(activity, previous)
            ui.render(activity.nexusSnapshot(), null)
        }
        compose.onNodeWithContentDescription(text(R.string.action_attach_file)).performClick()
        compose.onNodeWithText(text(R.string.attachment_files)).performClick()
        cancelPicker()
        val source = (1..4).map { i -> uri("sample.txt", "text/plain", "follow-$i.txt") }
        val files = import(task, source, 4)
        compose.onNode(hasSetTextAction()).performTextInput("Добавь часы")
        assertEquals("Добавь часы", ui.chatText)
        compose.onNodeWithContentDescription(text(R.string.action_send)).assertIsEnabled().performClick()
        val deadline = System.nanoTime() + java.util.concurrent.TimeUnit.SECONDS.toNanos(8)
        while (transport.submitted == 0 && System.nanoTime() < deadline) {
            shadowOf(android.os.Looper.getMainLooper()).idle()
            Thread.sleep(10)
        }
        assertTrue("Follow-up not submitted: complete=" + ui.snapshot.complete + ", clearing=" + ui.snapshot.clearing +
            ", files=" + store.states.value[task]?.items?.size + ", toast=" +
            org.robolectric.shadows.ShadowToast.getTextOfLatestToast(), transport.submitted > 0)
        val next = field("run").get(activity) as Workflow.Run
        assertEquals(4, next.materials.size)
        assertEquals(files.items.map { it.id }.toSet(), next.materials.map { it.id }.toSet())
        val outgoing = ModelClient.routerBody(next, next.nextStage().model)
            .getJSONArray("messages").getJSONObject(1).getString("content")
        val sentTask = JSONObject(outgoing).getString("task")
        val serialized = sentTask.substringAfter("<attached_materials>\n").substringBefore("\n</attached_materials>")
        val sentFiles = org.json.JSONArray(serialized)
        val actual = (0 until sentFiles.length()).map { sentFiles.getJSONObject(it) }
            .associate { it.getString("name") to it.getString("text") }
        assertEquals(files.items.associate { it.name to it.content }, actual)
        assertTrue(sentTask.contains("Первый ответ"))
        assertTrue(store.prepare(task, "Ещё", next.materials).refs.isEmpty())
        idle(task, 0)
        val db = field("repository").get(activity) as TaskRepository
        assertEquals("Первый ответ", Workflow.Run.fromJson(JSONObject(db.versions(task).single().runJson)).displayAnswer(0))
        assertEquals(4, Workflow.Run.fromJson(JSONObject(db.load(task).runJson)).materials.size)
        compose.runOnIdle { activity.nexusStop() }
    }
    @Test fun materialsAndResponsiveUi() {
        val task = activity.nexusTaskId()
        idle(task, 0)
        val credentials = activity.getSharedPreferences("credentials", Context.MODE_PRIVATE)
        credentials.edit().putString("test-preserved-marker", "fixture-not-an-api-key").commit()
        val originalCredentials = HashMap(credentials.all)
        val originalStage = ui.snapshot.stages[1]
        assertTrue(isStandardRole("Ревьюер", 1)); assertFalse(isStandardRole("Проверяющий", 1))
        compose.runOnIdle { assertTrue(activity.nexusUpdateStage(1, "Проверяющий", originalStage.instruction, originalStage.modelId)) }
        assertEquals("Проверяющий", ui.snapshot.stages[1].role)
        assertEquals(originalStage.instruction, ui.snapshot.stages[1].instruction)
        compose.runOnIdle { assertTrue(activity.nexusUpdateStage(1, originalStage.role, originalStage.instruction, originalStage.modelId)) }
        compose.onNode(hasSetTextAction()).performTextInput("Read attachments; keep this draft separate.")
        val draft = ui.draft
        compose.onNodeWithContentDescription(text(R.string.action_attach_file)).performClick()
        compose.onNodeWithText(text(R.string.attachment_camera)).assertIsDisplayed()
        compose.onNodeWithText(text(R.string.attachment_photos)).assertIsDisplayed()
        compose.onNodeWithText(text(R.string.attachment_files)).assertIsDisplayed()
        screenshot("attachment-menu-dark")
        compose.runOnIdle { (ShadowDialog.getLatestDialog() as ComponentDialog).onBackPressedDispatcher.onBackPressed() }
        compose.onNodeWithText(text(R.string.attachment_files)).assertDoesNotExist()
        compose.onNodeWithContentDescription(text(R.string.action_attach_file)).performClick()
        compose.onNodeWithText(text(R.string.attachment_files)).performClick()
        cancelPicker(); assertEquals(0, store.states.value.getValue(task).items.size)
        val longName = "Очень_длинное_имя_вложения_".repeat(8) + "日本語_العربية.txt"
        val records = import(task, listOf(uri("sample.txt", "text/plain", longName), uri("sample.md", "text/markdown"),
            uri("sample.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
            uri("text.pdf", "application/pdf"), uri("mixed.pdf", "application/pdf"), uri("scan.pdf", "application/pdf"),
            uri("sample.zip", "application/zip"), uri("sample.png", "image/png"), uri("rotated.jpg", "image/jpeg"), uri("sample.webp", "image/webp")), 10)
        assertEquals(draft, ui.draft)
        assertEquals(AttachmentStore.Status.UNSUPPORTED, records.items.first { it.name == "scan.pdf" }.status)
        assertEquals(1, records.items.first { it.name == "scan.pdf" }.total)
        assertEquals(AttachmentProblem.Code.PDF_PAGE_EMPTY, records.items.first { it.name == "scan.pdf" }.notes.first().code)
        assertTrue(records.items.first { it.name == "sample.docx" }.content.contains("DOCX first paragraph Я"))
        assertTrue(records.items.first { it.name == "text.pdf" }.content.contains("alpha beta 123"))
        val mixed = records.items.first { it.name == "mixed.pdf" }
        assertTrue(mixed.partial); assertEquals(1, mixed.processed); assertEquals(2, mixed.total)
        val zip = records.items.first { it.name == "sample.zip" }
        assertTrue(zip.partial); assertEquals(2, zip.processed); assertEquals(4, zip.total)
        assertTrue(zip.notes.any { it.code == AttachmentProblem.Code.NESTED_ARCHIVE })
        assertTrue(records.items.filter { it.kind == AttachmentParser.Kind.IMAGE }.all { store.preview(task, it.id).isFile })
        val exceeded = import(task, listOf(uri("sample.txt", "text/plain")), 10)
        assertEquals(AttachmentProblem.Code.FILE_COUNT, exceeded.notice)
        screenshot("ten-attachments-dark")
        compose.onNode(hasSetTextAction()).performTextClearance()
        assertEquals("", ui.draft); assertEquals(10, store.states.value.getValue(task).items.size)
        compose.onNode(hasSetTextAction()).performTextInput(draft)
        try { store.prepare(task, draft); fail("Unreadable PDF must block sending") }
        catch (e: AttachmentProblem) { assertEquals(AttachmentProblem.Code.PDF_NO_TEXT, e.code) }
        val failed = records.items.first { it.name == "scan.pdf" }
        store.remove(task, failed.id)
        idle(task, 9)
        val prepared = store.prepare(task, draft)
        assertEquals(9, prepared.refs.size)
        assertTrue(prepared.task.contains(longName)); assertTrue(prepared.task.contains("DOCX first paragraph Я"))
        assertTrue(prepared.task.contains("alpha beta 123")); assertEquals(draft, ui.draft)
        store.retain(task, prepared.refs)
        assertEquals(3, store.images(task, prepared.refs).size)
        val constructor = AttachmentStore::class.java.getDeclaredConstructor(android.app.Application::class.java).apply { isAccessible = true }
        val cold = constructor.newInstance(activity.applicationContext)
        cold.ensure(task)
        compose.waitUntil(10000) { cold.states.value[task]?.loaded == true }
        assertEquals(9, cold.states.value.getValue(task).items.size)
        assertTrue(cold.states.value.getValue(task).items.first { it.name == "sample.docx" }.content.contains("Second paragraph"))
        compose.activityRule.scenario.recreate(); compose.waitForIdle()
        assertEquals(task, activity.nexusTaskId()); assertEquals(draft, ui.draft); idle(task, 9)
        compose.runOnIdle { activity.nexusModeChanged(true) }
        assertEquals(draft, ui.draft)
        screenshot("quick-attachments-dark")
        compose.onNodeWithContentDescription(text(R.string.action_send)).assertIsDisplayed()
        screenshot("navigation-debug-v4")
        checkNav()
        compose.runOnIdle { activity.nexusThemeChanged("light"); activity.nexusModeChanged(false) }
        screenshot("team-attachments-light"); checkNav()
        compose.onNodeWithContentDescription(text(R.string.action_attach_file)).performClick()
        screenshot("attachment-menu-light")
        compose.runOnIdle { (ShadowDialog.getLatestDialog() as ComponentDialog).onBackPressedDispatcher.onBackPressed() }
        compose.runOnIdle { RuntimeEnvironment.setQualifiers("ru-rRU-w320dp-h780dp-xhdpi"); RuntimeEnvironment.setFontScale(2f) }
        compose.activityRule.scenario.recreate(); compose.waitForIdle(); checkNav()
        screenshot("large-font-navigation")
        compose.onNode(hasSetTextAction()).performClick()
        compose.runOnIdle {
            ViewCompat.dispatchApplyWindowInsets(activity.window.decorView, WindowInsetsCompat.Builder()
                .setInsets(WindowInsetsCompat.Type.ime(), Insets.of(0, 0, 0, 600)).setVisible(WindowInsetsCompat.Type.ime(), true).build())
        }
        compose.onNode(hasSetTextAction()).assertIsDisplayed()
        screenshot("large-font-keyboard")
        compose.runOnIdle { ViewCompat.dispatchApplyWindowInsets(activity.window.decorView, WindowInsetsCompat.Builder().build()) }
        compose.runOnIdle { RuntimeEnvironment.setFontScale(1f) }
        compose.runOnIdle { activity.nexusLanguageChanged("ar") }
        compose.waitForIdle(); assertEquals(android.view.View.LAYOUT_DIRECTION_RTL, activity.resources.configuration.layoutDirection)
        screenshot("arabic-rtl"); checkNav()
        assertEquals(9, store.states.value.getValue(task).items.size)
        for (language in listOf("en", "zh-CN", "ja")) {
            compose.runOnIdle { activity.nexusLanguageChanged(language) }; compose.waitForIdle(); checkNav()
            screenshot("locale-$language")
            assertEquals(9, store.states.value.getValue(task).items.size)
        }
        compose.runOnIdle { activity.nexusLanguageChanged("ru") }; compose.waitForIdle()
        compose.onNodeWithContentDescription(text(R.string.ui_open_menu)).performClick()
        compose.onNodeWithText(text(R.string.ui_new_chat)).performClick()
        compose.onNodeWithText(text(R.string.action_create)).performClick()
        compose.waitUntil(15000) { activity.nexusTaskId() != task }
        val fresh = activity.nexusTaskId(); idle(fresh, 0)
        assertEquals(9, store.states.value[task]?.items?.size)
        assertEquals("", ui.draft); assertEquals(originalCredentials, credentials.all)
        assertTrue(ui.snapshot.tasks.any { it.id == task })
        assertEquals(3, store.images(task, prepared.refs).size)
        // Exercise the real capture intent and saved Activity Result across rotation.
        compose.onNodeWithContentDescription(text(R.string.action_attach_file)).performClick()
        compose.onNodeWithText(text(R.string.attachment_camera)).performClick()
        val capture = shadowOf(activity).nextStartedActivityForResult
        assertEquals(android.provider.MediaStore.ACTION_IMAGE_CAPTURE, capture.intent.action)
        assertTrue(capture.intent.flags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION != 0)
        @Suppress("DEPRECATION")
        val output = capture.intent.getParcelableExtra<Uri>(android.provider.MediaStore.EXTRA_OUTPUT)!!
        activity.contentResolver.openOutputStream(output, "w")!!.use { stream -> fixture("sample.jpg").inputStream().use { it.copyTo(stream) } }
        compose.activityRule.scenario.recreate(); compose.waitForIdle()
        val captureResult = MainActivity::class.java.getDeclaredMethod("onActivityResult", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Intent::class.java).apply { isAccessible = true }
        compose.runOnIdle { captureResult.invoke(activity, capture.requestCode, Activity.RESULT_OK, Intent()) }
        val photo = idle(fresh, 1).items.single()
        assertEquals(AttachmentStore.Status.READY, photo.status); assertEquals("image/jpeg", photo.mime)
        assertTrue(store.preview(fresh, photo.id).isFile)
        assertFalse(File(activity.cacheDir, "attachment-camera").listFiles().orEmpty().any { it.extension == "jpg" })
        compose.onNodeWithContentDescription(text(R.string.action_attach_file)).performClick()
        compose.onNodeWithText(text(R.string.attachment_photos)).performClick()
        val photoPicker = shadowOf(activity).nextStartedActivityForResult
        assertTrue(photoPicker.intent.type?.startsWith("image/") == true || photoPicker.intent.action?.contains("PICK_IMAGES") == true)
        compose.runOnIdle { captureResult.invoke(activity, photoPicker.requestCode, Activity.RESULT_CANCELED, null) }
        idle(fresh, 1)
        store.remove(fresh, photo.id)
        idle(fresh, 0)
        // Local acceptance (30 MB) is separate from the smaller image-request budget.
        val random = java.util.Random(7)
        val bitmap = Bitmap.createBitmap(1024, 1024, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(1024 * 1024) { random.nextInt() }
        bitmap.setPixels(pixels, 0, 1024, 0, 0, 1024, 1024)
        val noisy = File(activity.cacheDir, "test-inputs/noise.png")
        noisy.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle()
        val total = import(fresh, (1..10).map { FixtureFiles.add(noisy, "image/png", "image-$it.png") }, 10)
        assertTrue(total.items.any { it.problem == AttachmentProblem.Code.TOTAL_SIZE })
        assertTrue(total.items.filter { it.status == AttachmentStore.Status.READY }.sumOf { it.size } <= InputMaterial.MAX_TOTAL_BYTES)
        // Import immediately after clear; cleanup must not remove the new generation.
        store.clearDraft(fresh)
        val initial = import(fresh, (1..6).map { FixtureFiles.add(noisy, "image/png", "known-$it.png") }, 6)
        assertTrue(initial.items.map { it.name to it.problem }.toString(), initial.items.all { it.status == AttachmentStore.Status.READY })
        // Both providers claim zero bytes and start copying together. Actual totals must still hold.
        val gate = java.util.concurrent.CountDownLatch(2)
        store.add(fresh, listOf(FixtureFiles.add(noisy, "image/png", "underreported-1.png", declaredSize = 0, gate = gate)))
        store.add(fresh, listOf(FixtureFiles.add(noisy, "image/png", "underreported-2.png", declaredSize = 0, gate = gate)))
        val concurrent = idle(fresh, 8)
        assertTrue(concurrent.items.any { it.problem == AttachmentProblem.Code.TOTAL_SIZE })
        assertTrue(concurrent.items.filter { it.status == AttachmentStore.Status.READY }.sumOf { it.size } <= InputMaterial.MAX_TOTAL_BYTES)
        store.clearDraft(fresh); compose.waitUntil(10000) { store.states.value[fresh]?.items?.isEmpty() == true }
        val big = File(activity.cacheDir, "test-inputs/large.txt")
        RandomAccessFile(big, "rw").use { it.setLength(InputMaterial.MAX_FILE_BYTES + 1024) }
        val tooLarge = import(fresh, listOf(FixtureFiles.add(big, "text/plain", "large.txt"),
            FixtureFiles.add(big, "text/plain", "unknown-size.txt", false)), 2)
        assertTrue(tooLarge.items.all { it.status == AttachmentStore.Status.LIMIT && it.problem == AttachmentProblem.Code.FILE_SIZE })
        assertFalse(File(activity.filesDir, "input-materials/task-$fresh").listFiles().orEmpty().any { it.name.endsWith(".part") })
        val unsupported = File(activity.cacheDir, "test-inputs/data.bin").apply { writeBytes(byteArrayOf(0, 1, 2)) }
        val unsupportedState = import(fresh, listOf(FixtureFiles.add(unsupported, "application/octet-stream", "data.bin")), 3)
        assertEquals(AttachmentStore.Status.UNSUPPORTED, unsupportedState.items.last().status)
        val badEncoding = File(activity.cacheDir, "test-inputs/bad.txt").apply { writeBytes(byteArrayOf(0xc3.toByte(), 0x28)) }
        val encoding = import(fresh, listOf(FixtureFiles.add(badEncoding, "text/plain", "bad.txt"), uri("sample-utf16.txt", "text/plain")), 5)
        assertEquals(AttachmentProblem.Code.ENCODING, encoding.items.first { it.name == "bad.txt" }.problem)
        assertTrue(encoding.items.first { it.name == "sample-utf16.txt" }.content.contains("日本語 и русский"))
        compose.runOnIdle { activity.nexusDeleteTask(task) }
        compose.waitUntil(10000) { !File(activity.filesDir, "input-materials/task-$task").exists() }
        try { store.images(task, prepared.refs); fail("Deleted task images must be removed") }
        catch (e: AttachmentProblem) { assertEquals(AttachmentProblem.Code.MISSING, e.code) }
        compose.runOnIdle { ui.open(NexusComposeUi.Page.TASK) }

        val providerInfo = activity.packageManager.resolveContentProvider(activity.packageName + ".attachments", 0)!!
        assertFalse(providerInfo.exported)
        val permissions = activity.packageManager.getPackageInfo(activity.packageName, android.content.pm.PackageManager.GET_PERMISSIONS).requestedPermissions.orEmpty()
        assertFalse(permissions.contains(android.Manifest.permission.CAMERA)); assertFalse(permissions.contains(android.Manifest.permission.READ_EXTERNAL_STORAGE))
        assertEquals(originalCredentials, credentials.all)
    }
}

/** Read-only Android document-provider fixture; never included in the APK. */
class FixtureFiles : ContentProvider() {
    data class Source(val file: File, val mime: String, val display: String, val known: Boolean,
        val declaredSize: Long?, val gate: java.util.concurrent.CountDownLatch?)
    companion object {
        private val sources = java.util.concurrent.ConcurrentHashMap<String, Source>()
        fun add(file: File, mime: String, display: String, known: Boolean = true,
            declaredSize: Long? = null, gate: java.util.concurrent.CountDownLatch? = null): Uri {
            val id = UUID.randomUUID().toString(); sources[id] = Source(file, mime, display, known, declaredSize, gate)
            return Uri.parse("content://nexus.fixture/$id")
        }
    }
    private fun source(uri: Uri) = sources[uri.lastPathSegment] ?: throw java.io.FileNotFoundException()
    override fun onCreate() = true
    override fun getType(uri: Uri): String = source(uri).mime
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val source = source(uri)
        return MatrixCursor(arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)).apply {
            addRow(arrayOf(source.display, if (source.known) source.declaredSize ?: source.file.length() else null))
        }
    }
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val source = source(uri)
        source.gate?.let { it.countDown(); check(it.await(10, java.util.concurrent.TimeUnit.SECONDS)) }
        return ParcelFileDescriptor.open(source.file, ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException("Read-only test provider")
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException("Read-only test provider")
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
