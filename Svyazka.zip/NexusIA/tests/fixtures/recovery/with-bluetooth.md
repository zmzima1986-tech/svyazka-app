Ниже — самостоятельная версия `index.html`: часы, календарь, погода и Bluetooth-виджет. Все работает без внешних библиотек.

```html
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Часы, Календарь, Погода и Bluetooth</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
            color: #333;
        }

        .widget {
            background: #fff;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-top: 0;
            font-size: 1.4em;
        }

        #clock {
            font-size: 2em;
            font-weight: bold;
        }

        #date {
            font-size: 1.2em;
            margin-bottom: 10px;
        }

        table.calendar {
            border-collapse: collapse;
            width: 100%;
        }

        table.calendar th,
        table.calendar td {
            border: 1px solid #ddd;
            width: 14.28%;
            text-align: center;
            padding: 5px;
        }

        table.calendar th {
            background: #eaeaea;
        }

        .today {
            background: #ffeb3b;
            font-weight: bold;
        }

        #weather {
            font-size: 1.1em;
        }

        .weather-icon {
            vertical-align: middle;
            margin-right: 6px;
        }

        .weather-meta {
            font-size: 0.9em;
            color: #666;
            margin-top: 4px;
        }

        #btStatus {
            margin-top: 8px;
            font-size: 0.95em;
            color: #555;
        }

        #btDevices {
            margin-top: 10px;
            list-style: none;
            padding-left: 0;
        }

        #btDevices li {
            padding: 4px 0;
            border-bottom: 1px solid #eee;
        }

        button.btBtn {
            padding: 6px 12px;
            font-size: 0.95em;
            cursor: pointer;
        }

        button.btBtn:disabled {
            cursor: wait;
            opacity: 0.6;
        }

        .hint {
            font-size: 0.85em;
            color: #777;
            margin-top: 8px;
        }
    </style>
</head>
<body>

<div class="widget" id="clockWidget">
    <h2>Текущее время</h2>
    <div id="clock">--:--:--</div>
</div>

<div class="widget" id="calendarWidget">
    <h2>Календарь</h2>
    <div id="date">...</div>
    <table class="calendar" id="calendarTable"></table>
</div>

<div class="widget" id="weatherWidget">
    <h2 id="weatherTitle">Погода</h2>
    <div id="weather">Загрузка…</div>
    <div class="weather-meta" id="weatherMeta">Источник: Open-Meteo</div>
</div>

<div class="widget" id="btWidget">
    <h2>Bluetooth (Web Bluetooth API)</h2>
    <button class="btBtn" id="btConnectBtn">Подключить Bluetooth</button>
    <div id="btStatus">Не подключено.</div>
    <ul id="btDevices"></ul>
    <div class="hint">
        Требуется HTTPS или localhost. Поддержка зависит от браузера.
    </div>
</div>

<script>
/* ==================== 1. CLOCK ==================== */
function updateClock() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('ru-RU', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    document.getElementById('clock').textContent = timeStr;
}

setInterval(updateClock, 1000);
updateClock();


/* ==================== 2. CALENDAR ==================== */
function renderCalendar() {
    const now = new Date();
    const month = now.getMonth();
    const year = now.getFullYear();

    const monthNames = [
        'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
        'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
    ];

    document.getElementById('date').textContent = `${monthNames[month]} ${year}`;

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const table = document.getElementById('calendarTable');
    table.innerHTML = '';

    const header = document.createElement('tr');
    const weekDays = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];

    weekDays.forEach((name) => {
        const th = document.createElement('th');
        th.textContent = name;
        header.appendChild(th);
    });

    table.appendChild(header);

    let tr = document.createElement('tr');

    for (let i = 0; i < firstDay; i++) {
        tr.appendChild(document.createElement('td'));
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const td = document.createElement('td');
        td.textContent = day;

        if (day === now.getDate()) {
            td.classList.add('today');
        }

        tr.appendChild(td);

        if (tr.children.length === 7) {
            table.appendChild(tr);
            tr = document.createElement('tr');
        }
    }

    if (tr.children.length > 0) {
        while (tr.children.length < 7) {
            tr.appendChild(document.createElement('td'));
        }
        table.appendChild(tr);
    }
}

renderCalendar();


/* ==================== 3. WEATHER ==================== */
/*
   Источник: Open-Meteo API, https://open-meteo.com
   API работает без регистрации и API-ключа.
*/
const LATITUDE = 55.75;       // Москва
const LONGITUDE = 37.62;      // Москва
const CITY_NAME = 'Москва';

document.getElementById('weatherTitle').textContent = `Погода в ${CITY_NAME}`;

async function loadWeather() {
    const url =
        `https://api.open-meteo.com/v1/forecast?latitude=${LATITUDE}` +
        `&longitude=${LONGITUDE}&current_weather=true&windspeed_unit=ms`;

    try {
        const resp = await fetch(url);

        if (!resp.ok) {
            throw new Error(`HTTP ${resp.status}`);
        }

        const data = await resp.json();
        const w = data.current_weather;

        const temp = Math.round(w.temperature);
        const wind = Math.round(w.windspeed);
        const code = w.weathercode;

        const codeMap = {
            0: "☀️", 1: "🌤", 2: "⛅️", 3: "☁️",
            45: "🌫", 48: "🌫",
            51: "🌦", 53: "🌦", 55: "🌦",
            56: "🌨", 57: "🌨",
            61: "🌧", 63: "🌧", 65: "🌧",
            66: "🌨", 67: "🌨",
            71: "❄️", 73: "❄️", 75: "❄️", 77: "❄️",
            80: "🌧", 81: "🌧", 82: "🌧",
            85: "❄️", 86: "❄️",
            95: "⛈", 96: "⛈", 99: "⛈"
        };

        const icon = codeMap[code] || "❓";

        document.getElementById('weather').innerHTML =
            `<span class="weather-icon">${icon}</span>` +
            `<strong>${temp}°C</strong>, ветер: ${wind} м/с`;

        const now = new Date();
        document.getElementById('weatherMeta').textContent =
            `Источник: Open-Meteo · Обновлено: ` +
            now.toLocaleTimeString('ru-RU', {
                hour: '2-digit',
                minute: '2-digit'
            });
    } catch (e) {
        console.error('Weather fetch error:', e);
        document.getElementById('weather').textContent =
            'Не удалось загрузить погоду. Проверьте подключение к интернету.';
        document.getElementById('weatherMeta').textContent =
            'Источник: Open-Meteo · обновление не удалось';
    }
}

loadWeather();
setInterval(loadWeather, 15 * 60 * 1000);


/* ==================== 4. BLUETOOTH ==================== */
const btBtn = document.getElementById('btConnectBtn');
const btStatus = document.getElementById('btStatus');
const btList = document.getElementById('btDevices');

btBtn.addEventListener('click', async () => {
    if (!navigator.bluetooth) {
        btStatus.textContent =
            'Web Bluetooth API не поддерживается в этом браузере или страница открыта не по HTTPS/localhost.';
        return;
    }

    btBtn.disabled = true;

    try {
        btStatus.textContent = 'Выбор BLE-устройства…';

        const device = await navigator.bluetooth.requestDevice({
            acceptAllDevices: true,
            optionalServices: []
        });

        const li = document.createElement('li');
        li.textContent = `Найдено: ${device.name || 'Без имени'} (id: ${device.id})`;
        btList.appendChild(li);

        btStatus.textContent = 'Подключение…';
        await device.gatt.connect();

        btStatus.textContent = `Подключено к «${device.name || device.id}».`;

        device.addEventListener('gattserverdisconnected', () => {
            btStatus.textContent =
                `Устройство «${device.name || device.id}» отключено.`;
        });
    } catch (err) {
        console.error('Bluetooth error:', err);

        if (err.name === 'NotFoundError') {
            btStatus.textContent = 'Устройство не выбрано или не найдено.';
        } else if (err.name === 'NotAllowedError') {
            btStatus.textContent = 'Доступ к Bluetooth отклонён пользователем.';
        } else if (err.name === 'SecurityError') {
            btStatus.textContent = 'Bluetooth требует HTTPS или localhost.';
        } else if (err.name === 'NetworkError') {
            btStatus.textContent = 'Не удалось установить GATT-соединение.';
        } else {
            btStatus.textContent = `Ошибка Bluetooth: ${err.message}`;
        }
    } finally {
        btBtn.disabled = false;
    }
});
</script>

</body>
</html>
```

### Как открыть

1. Сохраните код в файл `index.html`.
2. Для корректной работы Bluetooth запустите файл через локальный сервер, например:
   ```bash
   python -m http.server 8000
   ```
   Затем откройте `http://localhost:8000`.
3. Погода загружается с Open-Meteo, город по умолчанию — Москва.

### Смена города

Измените три константы в блоке погоды:

```javascript
const LATITUDE = 55.75;
const LONGITUDE = 37.62;
const CITY_NAME = 'Москва';
```

Например, для Санкт-Петербурга:

```javascript
const LATITUDE = 59.93;
const LONGITUDE = 30.33;
const CITY_NAME = 'Санкт-Петербург';
```

Bluetooth-виджет выполняет поиск BLE-устройства, подключение через GATT и показывает статус. Чтение или запись характеристик устройства не добавлены — для этого нужен UUID конкретного сервиса.