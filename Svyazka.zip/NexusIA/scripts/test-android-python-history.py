#!/usr/bin/env python3
"""Real Android Python-artifact lifecycle on a fresh disposable emulator.

Requires Gradle's app APK and androidTest APK (signed by the project's existing
Gradle configuration). Does not reset installed data or touch signing material.
"""
import subprocess
import sys
from pathlib import Path

PACKAGE = 'app.svyazka.team'
RUNNER = PACKAGE + '.test/app.svyazka.fixture.UpgradeProbe'
STEPS = ('python_seed', 'python_verify', 'python_deleted')


def adb(*args, timeout=180):
    return subprocess.check_output(['adb', '-e', *args], stderr=subprocess.STDOUT,
                                   timeout=timeout, text=True)


def main(app_apk, test_apk):
    for path in (app_apk, test_apk):
        if not Path(path).is_file():
            raise FileNotFoundError(path)
    if adb('shell', 'getprop', 'ro.kernel.qemu').strip() != '1':
        raise RuntimeError('Only a disposable Android emulator is allowed')
    adb('install', '-r', app_apk, timeout=240)
    adb('install', '-r', '-t', test_apk, timeout=240)
    for step in STEPS:
        # A genuine app process restart, not an Activity-only recreation.
        adb('shell', 'am', 'force-stop', PACKAGE)
        output = adb('shell', 'am', 'instrument', '-w', '-e', 'step', step, RUNNER,
                     timeout=240)
        expected = 'NEXUS_PYTHON_HISTORY_' + step.upper()
        if expected not in output or 'FAILURES' in output or 'INSTRUMENTATION_CODE: -1' not in output:
            raise RuntimeError(f'{step} failed:\n{output}')
        print(f'{step}: PASS', flush=True)
    print('Independent Python artifacts lifecycle on Android emulator: PASS', flush=True)


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: test-android-python-history.py app.apk app-debug-androidTest.apk')
    main(*sys.argv[1:])
