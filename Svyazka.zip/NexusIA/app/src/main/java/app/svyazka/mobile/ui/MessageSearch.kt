package app.svyazka.mobile.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.NexusState
import app.svyazka.mobile.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private data class Match(val message: NexusState.SearchMessage, val offset: Int)

@Composable
internal fun MessageSearch(ui: NexusComposeUi, allChats: Boolean) {
    var query by rememberSaveable { mutableStateOf("") }
    var selected by remember(query) { mutableIntStateOf(0) }
    var rows by remember { mutableStateOf(emptyList<NexusState.SearchMessage>()) }
    var matches by remember(query) { mutableStateOf(emptyList<Match>()) }
    var expanded by remember(query, selected) { mutableStateOf(false) }
    val task = if (allChats) 0L else ui.taskId
    LaunchedEffect(task, ui.snapshot.finished, ui.snapshot.complete) {
        rows = withContext(Dispatchers.IO) { ui.activity.nexusSearchMessages(task) }
    }
    LaunchedEffect(rows, query) {
        val needle = query
        if (needle.isBlank()) { matches = emptyList(); return@LaunchedEffect }
        delay(120)
        matches = withContext(Dispatchers.Default) {
            buildList {
                for (row in rows) {
                    var from = 0
                    while (from < row.text.length) {
                        val hit = row.text.indexOf(needle, from, ignoreCase = true)
                        if (hit == -1) break
                        add(Match(row, hit))
                        from = hit + needle.length
                    }
                }
            }
        }
        selected = 0
    }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text(stringResource(if (allChats) R.string.search_all else R.string.search_current)) },
            trailingIcon = { IconButton(onClick = { ui.searching = false; ui.historySearching = false }) {
                Icon(Icons.Outlined.Close, stringResource(R.string.action_close))
            } })
        if (query.isNotBlank()) Row(verticalAlignment = Alignment.CenterVertically) {
            Text((if (matches.isEmpty()) 0 else selected + 1).toString() + " / " + matches.size, Modifier.weight(1f))
            IconButton(enabled = matches.size > 1, onClick = { selected = (selected + matches.size - 1) % matches.size }) {
                Icon(Icons.Outlined.KeyboardArrowUp, stringResource(R.string.match_prev))
            }
            IconButton(enabled = matches.size > 1, onClick = { selected = (selected + 1) % matches.size }) {
                Icon(Icons.Outlined.KeyboardArrowDown, stringResource(R.string.match_next))
            }
        }
        matches.getOrNull(selected)?.let { hit ->
            val source = hit.message.text
            val start = if (expanded) 0 else (hit.offset - 180).coerceAtLeast(0)
            val end = if (expanded) source.length else (hit.offset + query.length + 340).coerceAtMost(source.length)
            val highlight = MaterialTheme.colorScheme.primaryContainer
            val color = MaterialTheme.colorScheme.onPrimaryContainer
            Text(hit.message.title, style = MaterialTheme.typography.titleMedium)
            NexusLabel(stringResource(if (hit.message.user) R.string.search_you else R.string.app_name))
            if (!expanded && (start > 0 || end < source.length)) TextButton(onClick = { expanded = true }) {
                Text(stringResource(R.string.action_show_result))
            }
            key(hit, expanded) {
                SelectionContainer(Modifier.verticalScroll(rememberScrollState())) {
                    Text(buildAnnotatedString {
                        append(source.substring(start, end))
                        addStyle(SpanStyle(background = highlight, color = color), hit.offset - start,
                            hit.offset - start + query.length)
                    })
                }
            }
        }
    }
}
