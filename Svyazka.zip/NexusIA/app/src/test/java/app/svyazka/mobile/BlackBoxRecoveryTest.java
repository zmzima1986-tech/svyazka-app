package app.svyazka.mobile;

import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import org.junit.Test;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 33)
public class BlackBoxRecoveryTest {
    private static Workflow.Run newRun() {
        return Workflow.Run.quick("Создай main.py", ModelCatalog.NORTH,
                Workflow.defaultStages().get(1));
    }

    @Test public void verifiedCheckpointResumesOnlyUnfinishedStep() {
        Workflow.Run run = newRun();
        Workflow.Run saved = run.restoreVerifiedCheckpoint("partial code", 0);
        assertNotNull(saved);
        assertEquals("partial code", saved.draft.text);
        assertEquals(Workflow.DraftMode.CONTINUE, saved.draftMode);
        assertFalse(saved.complete());
        assertTrue(saved.note.contains("не готовый"));
    }

    @Test public void refusesWrongStepAndDivergingText() {
        Workflow.Run run = newRun();
        assertNull(run.restoreVerifiedCheckpoint("wrong step", 1));
        Workflow.Run partial = run.receive(ModelClient.Reply.error("first", "Сеть прервана"));
        assertNull(partial.restoreVerifiedCheckpoint("different", 0));
        assertEquals("first", partial.draft.text);
    }

    @Test public void alreadyDurableDraftIsNeverTruncated() {
        Workflow.Run run = newRun().receive(ModelClient.Reply.error("abcdef", "Сеть прервана"));
        Workflow.Run recovered = run.restoreVerifiedCheckpoint("abc", 0);
        assertNotNull(recovered);
        assertEquals("abcdef", recovered.draft.text);
        assertEquals(Workflow.DraftMode.CONTINUE, recovered.draftMode);
    }
}
