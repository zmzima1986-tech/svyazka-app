package app.svyazka.mobile.ui

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import app.svyazka.mobile.R
import java.util.Locale

/** Display metadata only: the actual connection provider is still shown as text. */
@DrawableRes
internal fun providerLogo(label: String, modelId: String, connectionProvider: String): Int {
    val text = "$label $modelId".lowercase(Locale.ROOT)
    fun contains(vararg names: String) = names.any { name ->
        Regex("(?<![a-z0-9])${Regex.escape(name)}(?![a-z0-9])").containsMatchIn(text)
    }
    return when {
        contains("nvidia", "nemotron") -> R.drawable.ic_provider_nvidia
        contains("cerebras") -> R.drawable.ic_provider_cerebras
        contains("gemini") -> R.drawable.ic_provider_gemini
        contains("gemma") -> R.drawable.ic_provider_gemma
        contains("deepseek") -> R.drawable.ic_provider_deepseek
        contains("qwen", "alibaba") -> R.drawable.ic_provider_qwen
        contains("meta", "meta-llama", "llama") -> R.drawable.ic_provider_meta
        contains("cohere", "cohereforai", "north") -> R.drawable.ic_provider_cohere
        contains("openai", "gpt", "gpt-oss") -> R.drawable.ic_provider_openai
        contains("anthropic", "claude") -> R.drawable.ic_provider_claude
        contains("baidu", "ernie") -> R.drawable.ic_provider_baidu
        contains("liquid", "liquidai", "lfm", "lfm2", "lfm3") -> R.drawable.ic_provider_liquid
        contains("mistral", "mistralai", "mixtral", "codestral", "devstral") -> R.drawable.ic_provider_mistral
        contains("poolside", "laguna") -> R.drawable.ic_provider_poolside
        contains("z-ai", "z.ai", "glm") -> R.drawable.ic_provider_zai
        contains("google") -> R.drawable.ic_provider_google
        contains("groq") -> R.drawable.ic_provider_groq
        contains("openrouter") -> R.drawable.ic_provider_openrouter
        else -> when (connectionProvider.lowercase(Locale.ROOT)) {
            "openrouter" -> R.drawable.ic_provider_openrouter
            "groq" -> R.drawable.ic_provider_groq
            "google gemini", "gemini" -> R.drawable.ic_provider_gemini
            "cerebras" -> R.drawable.ic_provider_cerebras
            "nvidia" -> R.drawable.ic_provider_nvidia
            else -> R.drawable.ic_nia_models
        }
    }
}

@Composable
internal fun ProviderLogo(label: String, modelId: String, provider: String, modifier: Modifier) {
    NexusGlyph(providerLogo(label, modelId, provider), null, modifier)
}
