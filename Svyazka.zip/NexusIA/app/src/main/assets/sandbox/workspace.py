"""Pyodide mini-project runner. Separate from the restricted verifier.

Input files are ephemeral; this code has no Android paths or network credentials.
"""
import base64
import builtins
import hashlib
import io
import json
import os
import shutil
import struct
import sys
import traceback
import unittest
import types
import importlib.util
from pathlib import Path

ROOT = Path('/workspace')
MAX_FILES = 48
MAX_ONE = 420_000
MAX_TOTAL = 1_800_000
MAX_ARTIFACT_TOTAL = 800_000
EXTENSIONS = {'.py', '.txt', '.csv', '.json', '.md', '.png', '.html'}


def valid_path(name):
    if not isinstance(name, str) or not 1 <= len(name) <= 180 or name.startswith('/'):
        return False
    parts = name.split('/')
    if not 1 <= len(parts) <= 4:
        return False
    for part in parts:
        if not part or len(part) > 64 or part.startswith('.'):
            return False
        if not (part[0].isascii() and (part[0].isalnum() or part[0] == '_')):
            return False
        if not all(c.isascii() and (c.isalnum() or c in '_.-') for c in part):
            return False
    return True


def decode_files(payload):
    files = json.loads(payload)
    if not isinstance(files, dict) or len(files) > MAX_FILES:
        raise ValueError('Недопустимое количество файлов.')
    values = {}
    total = 0
    for path, encoded in files.items():
        if not valid_path(path) or not isinstance(encoded, str):
            raise ValueError('Недопустимое имя или содержимое файла.')
        binary = base64.b64decode(encoded, validate=True)
        total += len(binary)
        if len(binary) > MAX_ONE or total > MAX_TOTAL:
            raise ValueError('Проект превышает лимит размера.')
        values[path] = binary
    return values


def reset_workspace(files):
    os.chdir('/')
    if ROOT.exists():
        shutil.rmtree(ROOT)
    ROOT.mkdir()
    for name, content in files.items():
        target = ROOT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    # New test case must reimport local modules from a fresh namespace.
    for name, module in list(sys.modules.items()):
        origin = getattr(module, '__file__', '')
        if isinstance(origin, str) and origin.startswith(str(ROOT) + '/'):
            sys.modules.pop(name, None)
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    os.chdir(ROOT)


def run_observed_script(source, entry):
    original = builtins.input
    needs_input = False

    def tracked(prompt=""):
        nonlocal needs_input
        if needs_input:
            # The supplied input is finite. A loop retrying the same exhausted stream cannot progress.
            raise MissingInteractiveInput()
        try:
            return original(prompt)
        except EOFError:
            needs_input = True
            raise

    builtins.input = tracked
    try:
        code = run_script(source, entry, waiting_for_input=lambda: needs_input)
    finally:
        builtins.input = original
    return json.dumps({"code": code, "input_required": needs_input and code == 0})


class MissingInteractiveInput(BaseException):
    pass


def run_script(source, entry, waiting_for_input=None):
    if not valid_path(entry) or not entry.endswith('.py'):
        raise ValueError('Неверный главный Python-файл.')
    module = types.ModuleType('__main__')
    module.__file__ = str(ROOT / entry)
    module.__package__ = None
    old_main = sys.modules.get('__main__')
    sys.modules['__main__'] = module
    try:
        exec(compile(source, entry, 'exec'), module.__dict__)
    except SystemExit as error:
        if error.code is None:
            return 0
        if isinstance(error.code, int):
            return error.code % 256
        print(str(error.code), file=sys.stderr)
        return 1
    except EOFError:
        if waiting_for_input and waiting_for_input():
            return 0
        traceback.print_exc()
        return 1
    except MissingInteractiveInput:
        return 0
    except BaseException as error:
        traceback.print_exception(type(error), error, error.__traceback__)
        return 1
    finally:
        if old_main is None:
            sys.modules.pop('__main__', None)
        else:
            sys.modules['__main__'] = old_main
    return 0



def run_generated_tests(entry=None):
    """Run discovered unittest cases in the disposable workspace. These are
    program-authored self-tests, not independent control examples."""
    loader = unittest.TestLoader()
    if entry is None:
        suite = loader.discover(str(ROOT), pattern='test*.py')
    else:
        if not valid_path(entry) or not entry.endswith('.py'):
            raise ValueError('Invalid test entry')
        name = '_nexus_single_suite'
        spec = importlib.util.spec_from_file_location(name, ROOT / entry)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        try:
            spec.loader.exec_module(module)
            suite = loader.loadTestsFromModule(module)
        finally:
            sys.modules.pop(name, None)
    total = suite.countTestCases()
    if not total or total > 24:
        return dict(status='LIMITED', discovered=total, ran=0, passed=0,
                    failed=0, skipped=0)
    # The result object, not the text printed by the submitted program, supplies counts.
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=1).run(suite)
    failed = len(result.failures) + len(result.errors) + len(result.unexpectedSuccesses)
    skipped = len(result.skipped) + len(result.expectedFailures)
    passed = max(0, result.testsRun - failed - skipped)
    status = 'FAILED' if failed else 'PASSED' if passed == total else 'LIMITED'
    return dict(status=status, discovered=total, ran=result.testsRun, passed=passed,
                failed=failed, skipped=skipped)

def prepare_matplotlib():
    """Warm the optional Agg renderer before the short user-code deadline.

    This performs real drawing once during the explicitly authorized package
    preparation stage. It creates no workspace artifact and changes no user
    source code. Any real initialization error remains visible to the caller.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as pyplot
    figure, axis = pyplot.subplots(figsize=(1, 1))
    try:
        axis.plot([0, 1], [0, 1])
        output = io.BytesIO()
        figure.savefig(output, format='png', dpi=60)
        if not valid_png(output.getvalue()):
            raise RuntimeError('Matplotlib не создал корректное изображение PNG.')
    finally:
        pyplot.close(figure)


def tests_for_entry(files, entry):
    """Legacy tests.json belongs to main.py unless a case names its entry."""
    cases = tests_from_files(files)
    return [case for case in cases if case.get('entry', 'main.py') == entry]


def tests_from_files(files):
    raw = files.get('tests.json')
    if raw is None:
        return []
    if len(raw) > 16_000:
        raise ValueError('tests.json превышает лимит.')
    cases = json.loads(raw.decode('utf-8'))
    if not isinstance(cases, list) or len(cases) > 12:
        raise ValueError('tests.json: нужно не более 12 тестов.')
    for index, case in enumerate(cases):
        if not isinstance(case, dict) or not isinstance(case.get('stdout'), str) or not isinstance(case.get('stdin', ''), str):
            raise ValueError('Тест ' + str(index + 1) + ': требуется stdout и необязательный stdin.')
        if 'entry' in case and (not valid_path(case['entry']) or not case['entry'].endswith('.py')):
            raise ValueError('Тест ' + str(index + 1) + ': неверный Python-файл.')
        if len(case.get('stdout', '')) > 4000 or len(case.get('stdin', '')) > 16000:
            raise ValueError('Слишком длинный тест.')
    return cases


def snapshot_sha256(files):
    digest = hashlib.sha256()
    for name, value in sorted(files.items()):
        digest.update(name.encode('utf-8'))
        digest.update(b'\x00')
        digest.update(len(value).to_bytes(8, 'big'))
        digest.update(value)
    return digest.hexdigest()


def valid_png(binary):
    if len(binary) < 33 or len(binary) > MAX_ONE or binary[:8] != b'\x89PNG\r\n\x1a\n' or binary[12:16] != b'IHDR':
        return False
    width, height = struct.unpack('>II', binary[16:24])
    return 0 < width <= 8192 and 0 < height <= 8192 and width * height <= 16_777_216


def collect_artifacts(before):
    items = []
    budget = MAX_ARTIFACT_TOTAL
    seen = set()

    def add(path, binary):
        nonlocal budget
        extension = Path(path).suffix.lower()
        if not valid_path(path) or extension not in EXTENSIONS or len(binary) > MAX_ONE:
            return
        if extension == '.png' and not valid_png(binary):
            return
        if extension != '.png' and len(binary) > 96_000:
            return
        if len(binary) > budget or len(items) >= 12:
            return
        if path in seen or before.get(path) == binary:
            return
        budget -= len(binary)
        seen.add(path)
        items.append({'name': path, 'mime': 'image/png' if extension == '.png' else 'text/plain',
                      'data': base64.b64encode(binary).decode('ascii'), 'size': len(binary)})

    for folder, subfolders, names in os.walk(ROOT, followlinks=False):
        subfolders[:] = [x for x in subfolders if not (Path(folder) / x).is_symlink()]
        for name in sorted(names):
            candidate = Path(folder) / name
            try:
                if candidate.is_symlink() or not candidate.is_file():
                    continue
                relative = str(candidate.relative_to(ROOT))
                if candidate.stat().st_size <= MAX_ONE:
                    add(relative, candidate.read_bytes())
            except (OSError, ValueError):
                pass
        if len(items) >= 12:
            break

    # Preserve the existing open-figure fallback, now supporting multiple figures.
    try:
        if 'matplotlib.pyplot' in sys.modules:
            pyplot = sys.modules['matplotlib.pyplot']
            for index, figure_number in enumerate(pyplot.get_fignums()[:4]):
                output = io.BytesIO()
                pyplot.figure(figure_number).savefig(output, format='png', dpi=90)
                add('figure_' + str(index + 1) + '.png', output.getvalue())
    except Exception:
        pass
    return items
