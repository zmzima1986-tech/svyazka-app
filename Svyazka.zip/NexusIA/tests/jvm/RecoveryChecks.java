package app.svyazka.mobile;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;

/** Replays actual Build 14 answer formats and verifies promotion after final editing. */
public final class RecoveryChecks {
    private static int count;
    private static void verify(boolean value,String name) {
        if (!value) throw new AssertionError(name);
        count++;
    }
    private static ModelClient.Reply stop(String text) {
        return new ModelClient.Reply(text, ModelClient.Finish.STOP, "");
    }
    private static JSONObject report(String status) throws Exception {
        return new JSONObject().put("language","html").put("status","SYNTAX_CHECKED")
                .put("tests",new JSONArray().put(new JSONObject().put("id","clock.tick").put("status",status)));
    }
    public static void main(String[] args) throws Exception {
        for (String name : new String[]{"clock-calendar-weather","with-bluetooth"}) {
            String answer=new String(Files.readAllBytes(Paths.get("tests/fixtures/recovery/"+name+".md")),StandardCharsets.UTF_8);
            String html=PythonInputs.webSource(answer,"html");
            verify(html.length()>5000 && html.trim().endsWith("</html>"),"primary HTML "+name);
            verify(PythonInputs.copySource(answer).equals(html),"clean clipboard");
            JSONObject f=PythonInputs.fileMetadata(answer).getJSONObject(0);
            verify(f.getInt("bytes")==html.getBytes(StandardCharsets.UTF_8).length && f.getString("sha256").equals(InputMaterial.sha256(html.getBytes(StandardCharsets.UTF_8))),"file identity");
        }
        String project="```python file=main.py\nprint('ok')\n```\n```ini file=buildozer.spec\n[app]\nandroid.permissions = BLUETOOTH_SCAN\n```";
        verify(PythonInputs.namedFiles(project).size()==2 && !PythonInputs.candidate(project).ambiguous,"named source and config");
        for(String unsafe:new String[]{"../main.py","/main.py","one/../../main.py","main.py/part","MAIN.PY","one\\two","a//b"}) {
            verify(PythonInputs.namedFiles(project.replace("buildozer.spec",unsafe)).isEmpty(),"unsafe path "+unsafe);
        }
        verify(PythonInputs.copySource("Объяснение\n```python\nprint('ok')\n```").equals("print('ok')\n"),"no prose in .py");
        verify(PythonInputs.webSource("<html><body>unfinished","html").isEmpty(),"truncated raw HTML");
        String clock = "<html><body><script>setInterval(()=>{},1000)</script></body></html>\n";
        String mixed = "```python file=main.py\nprint('old')\n```\n```html file=index.html\n" + clock + "```";
        verify(PythonInputs.webSource(mixed,"html").equals(clock),"standalone HTML must not disappear beside a Python file");
        String observed = Files.readString(Paths.get("tests/fixtures/recovery/observed-mixed-clock.md"), StandardCharsets.UTF_8);
        verify(PythonInputs.webSource(observed,"html").contains("function updateTime()"),"actual device clock answer is previewable");
        verify(PythonInputs.webSource(mixed + "\n```js file=main.js\nconsole.log(1)\n```","html").isEmpty(),"split web package not silently flattened");
        verify(TaskHistory.startsIndependentTask("Напиши на Python калькулятор", "Теперь создай HTML-страницу с работающими цифровыми часами и текущей датой."),"new HTML task replaces old Python task");
        verify(!TaskHistory.startsIndependentTask("Напиши на Python калькулятор", "Теперь создай HTML-страницу для калькулятора"),"port keeps previous requirements");
        verify(!TaskHistory.startsIndependentTask("Напиши на Python калькулятор", "Добавь проверку"),"ordinary edit keeps context");
        verify(TaskHistory.startsIndependentTask("old", "Новая задача: напиши текст"),"explicit new task");

        verify(PythonInputs.requiredFeatures("Создай часы и календарь. Добавь Bluetooth. Убери Bluetooth").length()==2,"explicit removal");
        verify(!PythonInputs.defaultWidget("Какая погода завтра?") && !PythonInputs.defaultWidget("Напиши часы на Python для Android"),"respect non-program and explicit target");
        String good="```html\n<html><body>working</body></html>\n```", bad=good.replace("working","broken");
        Workflow.Run run=new Workflow.Run("Сделай часы",Workflow.defaultStages()).receive(stop(good)).withWebCheck(0,report("pass"));
        verify(run.prompt().contains("clock.tick") && run.prompt().contains("required_features"),"critic sees actual test results");
        run=run.receive(stop("- Correct the clock formatting.\n[[REVIEW: FIX]]")).receive(stop(bad)).withWebCheck(2,report("fail"));
        verify(run.complete() && run.finalIndex()==0 && run.displayAnswer(2).equals(bad),"failed final author cannot replace a tested result");
        run=run.addRepair(new Workflow.RepairInput(2,PythonInputs.webSource(bad,"html"),"",report("fail").toString(),"html"));
        verify(run.prompt().contains("html_code") && run.instructions().contains("HTML"),"targeted HTML repair");
        run=Workflow.Run.fromJson(run.toJson()).receive(stop(good)).withWebCheck(3,report("pass"));
        verify(run.finalIndex()==3 && run.repairs.size()==1,"restored repair can improve file");
        Workflow.Run multi=Workflow.Run.quick("Создай на Python для Android",ModelCatalog.NORTH,Workflow.defaultStages().get(1)).receive(stop(project));
        verify(PythonInputs.request(multi,PythonInputs.candidate(project).code).getJSONObject("android_config").has("buildozer.spec"),"pass build config separately");
        multi=multi.addRepair(new Workflow.RepairInput(0,"print('ok')","","invalid callback"));
        verify(multi.prompt().contains("complete_project"),"repair receives manifest and source");
        verify(!multi.receive(stop("```py\nprint('ok')\n```")).complete(),"preserve earlier named project");
        System.out.println(count+" build 15 recovery checks passed");
    }
}
