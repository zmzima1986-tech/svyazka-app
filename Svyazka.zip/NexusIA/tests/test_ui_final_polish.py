"""Source-level safeguards for the final Nexus AI interface polish; not a device test."""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

PROJECT = Path(__file__).resolve().parents[1]
MAIN = PROJECT / 'app/src/main'
UI = MAIN / 'java/app/svyazka/mobile/ui'


class FinalPolishContract(unittest.TestCase):
    def test_visible_brand_all_locales(self):
        for folder in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            resources = ET.parse(MAIN / f'res/{folder}/strings.xml').getroot()
            name = next(item.text for item in resources.findall('string') if item.attrib['name'] == 'app_name')
            self.assertEqual(name, 'Nexus AI')
        for source in (MAIN / 'java').rglob('*'):
            if source.suffix in ('.kt', '.java'):
                self.assertNotIn('Nexus IA', source.read_text())

    def test_collapsible_chat_attachments(self):
        chat = (UI / 'NexusChat.kt').read_text()
        self.assertIn('var attachmentsExpanded by rememberSaveable(ui.taskId)', chat)
        self.assertIn('if (attachmentsExpanded)', chat)
        self.assertIn('attachment_expand', chat)
        self.assertIn('attachment_collapse', chat)
        for folder in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            names = {e.attrib['name'] for e in ET.parse(MAIN / f'res/{folder}/strings.xml').getroot()}
            self.assertTrue({'attachment_expand', 'attachment_collapse'} <= names)

    def test_key_indicator_reflects_saved_keys(self):
        keys = (UI / 'NexusKeysDialog.kt').read_text()
        self.assertIn('val isSaved = keys[index].isNotBlank()', keys)
        self.assertIn('status_key_configured', keys)
        self.assertIn('status_key_missing', keys)
        self.assertNotIn('isSaved = listOf(openRouter', keys)  # edits are not persisted yet

    def test_splash_theme_and_visual_handoff(self):
        ui = (UI / 'NexusComposeUi.kt').read_text()
        activity = (MAIN / 'java/app/svyazka/mobile/MainActivity.java').read_text()
        res = MAIN / 'res'
        android = '{http://schemas.android.com/apk/res/android}'
        self.assertIn('NexusTheme(ui.theme)', ui)
        self.assertNotIn('NexusSplashScreen(', ui)
        self.assertNotIn('showLegacySplash', ui)
        self.assertNotIn('kotlinx.coroutines.delay(', ui)
        self.assertIn('isUserDarkTheme', activity)
        self.assertIn('configuration.uiMode =', activity)
        self.assertIn('syncPlatformSplashTheme', activity)
        self.assertIn('manager.setApplicationNightMode(mode)', activity)
        self.assertIn('NexusSystemIsDark()', (UI / 'NexusTheme.kt').read_text())
        entry = ET.parse(MAIN / 'AndroidManifest.xml').find('application/activity')
        self.assertEqual(entry.get(android+'theme'), '@style/Theme.NexusIA.Launch')
        native = ET.parse(res/'values-v31/styles.xml').find(".//style[@name='NexusLaunchBase']")
        attrs = {item.get('name'): item.text for item in native.findall('item')}
        self.assertEqual(attrs['android:windowSplashScreenAnimatedIcon'], '@android:color/transparent')
        self.assertNotIn('android:windowSplashScreenBrandingImage', attrs)
        self.assertIn('activity.attachChatContent(compose)', ui)
        self.assertIn('new NexusLaunchView(this)', activity)
        launch = (MAIN / 'java/app/svyazka/mobile/NexusLaunchView.java').read_text()
        self.assertIn('R.string.ui_loading', launch)
        avd = ET.parse(res/'drawable/nexus_launch_animated.xml').getroot()
        self.assertEqual(avd.get(android+'drawable'), '@drawable/nexus_launch_art')
        target = avd.find('target')
        self.assertEqual(target.get(android+'animation'), '@animator/nexus_launch_sweep')
        art = ET.parse(res/'drawable/nexus_launch_art.xml').getroot()
        self.assertIn(target.get(android+'name'), [group.get(android+'name') for group in art.iter('group')])
        motion = ET.parse(res/'animator/nexus_launch_sweep.xml').getroot()
        self.assertEqual(motion.get(android+'propertyName'), 'translateX')
        self.assertGreater(float(motion.get(android+'valueTo')), float(motion.get(android+'valueFrom')))
        self.assertEqual(motion.get(android+'repeatCount'), 'infinite')
        self.assertEqual(motion.get(android+'repeatMode'), 'restart')
        for folder in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            self.assertIsNotNone(ET.parse(res/folder/'strings.xml').find(".//string[@name='ui_loading']"))


if __name__ == '__main__':
    unittest.main()
