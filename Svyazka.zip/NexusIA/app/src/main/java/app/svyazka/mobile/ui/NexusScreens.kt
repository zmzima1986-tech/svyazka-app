package app.svyazka.mobile.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.List
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.NexusState
import app.svyazka.mobile.R
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private fun copyText(context: Context, label: String, value: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    manager.setPrimaryClip(ClipData.newPlainText(label, value))
}

@Composable
fun TaskScreen(ui: NexusComposeUi) {
    val state = ui.snapshot
    var modelPicker by remember { mutableStateOf(false) }
    var editing by remember { mutableIntStateOf(-1) }
    val context = LocalContext.current
    LazyColumn(modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            NexusCard(highlighted = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.hero_title),
                            style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        NexusLabel(stringResource(R.string.hero_body))
                    }
                    Spacer(Modifier.width(5.dp))
                    NexusAiStack(Modifier.size(98.dp))
                }
            }
        }
        item {
            Text(stringResource(R.string.task_title), style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = state.quick, onClick = { ui.activity.nexusModeChanged(true) },
                    label = { Text(stringResource(R.string.quick_mode)) })
                FilterChip(selected = !state.quick, onClick = { ui.activity.nexusModeChanged(false) },
                    label = { Text(stringResource(R.string.team_mode)) })
            }
        }
        item {
            OutlinedTextField(value = ui.draft, onValueChange = {
                ui.draftChanged(it)
            }, modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
                enabled = !state.active && !state.clearing,
                label = { Text(stringResource(R.string.task_hint)) },
                placeholder = { Text(stringResource(R.string.task_placeholder)) },
                minLines = 4, maxLines = 12,
                shape = RoundedCornerShape(16.dp))
        }
        if (state.quick) {
            item {
                NexusCard(onClick = { modelPicker = true }) {
                    NexusLabel(stringResource(R.string.select_model))
                    Text(state.quickModelLabel, style = MaterialTheme.typography.titleMedium)
                }
            }
        } else {
            item { Text(stringResource(R.string.team_title), style = MaterialTheme.typography.titleLarge) }
            items(state.stages, key = { it.index }) { stage ->
                NexusCard(onClick = { editing = stage.index }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusPill("${stage.index + 1}")
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(stage.role, style = MaterialTheme.typography.titleMedium)
                            NexusLabel(stage.modelLabel, MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Outlined.KeyboardArrowDown, stringResource(R.string.action_edit))
                    }
                }
            }
        }
        item {
            NexusPrimaryButton(text = stringResource(R.string.action_start),
                onClick = { ui.activity.nexusStart() },
                enabled = !state.active && !state.clearing && ui.draft.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.PlayArrow, null) })
            if (state.hasRun) {
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { ui.activity.nexusOpenResults() },
                    modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.result_title))
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
    if (modelPicker) ModelPicker(ui, state.quickModelId, { modelPicker = false }) { id ->
        ui.activity.nexusChooseQuickModel(id)
        modelPicker = false
    }
    if (editing >= 0) {
        val stage = state.stages.firstOrNull { it.index == editing }
        if (stage == null) editing = -1 else RoleEditor(ui, stage, { editing = -1 })
    }
}

@Composable
private fun RoleEditor(ui: NexusComposeUi, stage: NexusState.Stage, dismiss: () -> Unit) {
    var role by remember(stage.index) { mutableStateOf(stage.role) }
    var instructions by remember(stage.index) { mutableStateOf(stage.instruction) }
    var model by remember(stage.index) { mutableStateOf(stage.modelId) }
    var picker by remember { mutableStateOf(false) }
    val context = LocalContext.current
    AlertDialog(onDismissRequest = dismiss,
        title = { Text(stringResource(R.string.edit_role)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(role, { if (it.length <= 42) role = it },
                    label = { Text(stringResource(R.string.role_name)) }, singleLine = true)
                OutlinedTextField(instructions, { if (it.length <= 1600) instructions = it },
                    label = { Text(stringResource(R.string.role_instructions)) }, maxLines = 6)
                val label = ui.snapshot.models.firstOrNull { it.id == model }?.label ?: stage.modelLabel
                OutlinedButton(onClick = { picker = true }) { Text(label, maxLines = 2) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (ui.activity.nexusUpdateStage(stage.index, role, instructions, model)) dismiss()
                else Toast.makeText(context, R.string.field_required, Toast.LENGTH_SHORT).show()
            }) { Text(stringResource(R.string.action_save)) }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text(stringResource(R.string.action_cancel)) } })
    if (picker) ModelPicker(ui, model, { picker = false }) { selected -> model = selected; picker = false }
}

@Composable
private fun ModelPicker(ui: NexusComposeUi, selected: String,
                        dismiss: () -> Unit, choose: (String) -> Unit) {
    var search by remember { mutableStateOf("") }
    val choices = ui.snapshot.models.filter { it.label.contains(search, ignoreCase = true) ||
            it.provider.contains(search, ignoreCase = true) }
    AlertDialog(onDismissRequest = dismiss,
        title = { Text(stringResource(R.string.select_model)) },
        text = {
            Column {
                OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.models_title)) },
                    singleLine = true)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(choices, key = { it.id }) { model ->
                        Row(Modifier.fillMaxWidth().clickable { choose(model.id) }.padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selected == model.id,
                                onClick = { choose(model.id) })
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(model.label, style = MaterialTheme.typography.bodyMedium)
                                NexusLabel(model.provider)
                            }
                        }
                    }
                }
            }
        }, confirmButton = {
            TextButton(onClick = dismiss) { Text(stringResource(R.string.action_close)) }
        })
}

@Composable
fun ResultScreen(ui: NexusComposeUi) {
    val state = ui.snapshot
    var expanded by remember(state.task) { mutableStateOf(false) }
    var fullAnswer by remember(state.result) { mutableStateOf(false) }
    var followUp by remember { mutableStateOf(false) }
    var journal by remember { mutableStateOf(false) }
    val context = LocalContext.current
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(stringResource(R.string.result_title), style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(5.dp))
            NexusLabel(state.task.take(220))
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (state.active) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
                else Icon(Icons.Default.CheckCircle, null, tint = if (state.complete) Color(0xFF14BF8E) else NexusBlue)
                Spacer(Modifier.width(10.dp))
                Text(stringResource(R.string.result_progress, state.finished, state.total),
                    style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.weight(1f))
                if (state.active) IconButton(onClick = { ui.activity.nexusStop() }) {
                    Icon(Icons.Default.Stop, stringResource(R.string.action_stop), tint = MaterialTheme.colorScheme.error)
                }
            }
            if (state.note.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                NexusCard { Text(state.note, color = MaterialTheme.colorScheme.error) }
            }
        }
        if (state.complete) {
            item {
                NexusCard(highlighted = true) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.result_ready),
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.weight(1f))
                        StatusPill(stringResource(R.string.status_complete), success = true)
                    }
                    Spacer(Modifier.height(14.dp))
                    if (state.resultWarnings.isNotBlank()) {
                        Text("⚠ " + stringResource(R.string.warning_integrity) + "\n" + state.resultWarnings,
                            color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(12.dp))
                    }
                    val displayed = if (fullAnswer) state.result else state.result.take(9000)
                    NexusMarkdown(displayed)
                    if (state.result.length > 9000 && !fullAnswer) {
                        TextButton(onClick = { fullAnswer = true }) {
                            Text(stringResource(R.string.action_show_result))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    NexusPrimaryButton(text = stringResource(R.string.action_copy),
                        onClick = {
                            copyText(context, state.resultRole, state.result)
                            Toast.makeText(context, R.string.status_copied, Toast.LENGTH_SHORT).show()
                        }, modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.ContentCopy, null) })
                    if (state.resultHasPython) {
                        OutlinedButton(onClick = { ui.activity.nexusRunPython(state.stages.last().index) },
                            modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Outlined.Code, null); Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.action_python))
                        }
                    }
                    if (state.visualAvailable) {
                        OutlinedButton(onClick = { ui.openVisual() }, modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.action_show_result))
                        }
                    }
                }
            }
            item {
                NexusCard(onClick = { expanded = !expanded }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.List, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Text(stringResource(R.string.work_title), style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f))
                        Icon(if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                            stringResource(R.string.work_title))
                    }
                    AnimatedVisibility(expanded, enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()) {
                        Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            state.stages.filter { it.index != state.stages.lastIndex }.forEach { stage ->
                                StepOutputCard(ui, stage)
                            }
                        }
                    }
                }
            }
        } else {
            items(state.stages, key = { it.index }) { stage -> StepOutputCard(ui, stage) }
            if (state.active && ui.streaming.isNotBlank()) {
                item {
                    NexusCard(highlighted = true) {
                        Text(stringResource(R.string.status_processing), color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(7.dp))
                        NexusMarkdown(ui.streaming.takeLast(3000))
                    }
                }
            }
        }
        if (!state.active) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!state.complete) NexusPrimaryButton(
                        text = stringResource(R.string.action_resume),
                        onClick = { ui.activity.nexusResume() }, modifier = Modifier.fillMaxWidth())
                    else NexusPrimaryButton(
                        text = stringResource(R.string.action_followup),
                        onClick = { followUp = true }, modifier = Modifier.fillMaxWidth())
                    if (state.versionCount > 0) OutlinedButton(onClick = { ui.activity.nexusOpenVersions() },
                        modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.action_versions)) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { ui.activity.nexusExport() }, Modifier.weight(1f)) {
                            Text(stringResource(R.string.action_export))
                        }
                        OutlinedButton(onClick = { journal = true }, Modifier.weight(1f),
                            enabled = state.log.isNotBlank()) {
                            Text(stringResource(R.string.action_journal))
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(18.dp)) }
    }
    if (followUp) FollowUpDialog(ui, { followUp = false })
    if (journal) AlertDialog(onDismissRequest = { journal = false },
        title = { Text(stringResource(R.string.action_journal)) },
        text = { SelectionContainer {
            Text(state.log, modifier = Modifier.heightIn(max = 450.dp).verticalScroll(rememberScrollState()),
                style = MaterialTheme.typography.bodyMedium)
        } },
        confirmButton = { TextButton(onClick = { journal = false }) { Text(stringResource(R.string.action_close)) } })
}

@Composable
private fun StepOutputCard(ui: NexusComposeUi, stage: NexusState.Stage) {
    NexusCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusPill("${stage.index + 1}")
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(stage.role, style = MaterialTheme.typography.titleMedium)
                NexusLabel(stage.modelLabel)
            }
            StatusPill(stringResource(if (stage.done) R.string.status_complete else if (stage.current)
                R.string.status_processing else R.string.status_queued), stage.done)
        }
        if (stage.warnings.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text("⚠ " + stringResource(R.string.warning_integrity) + "\n" + stage.warnings,
                color = MaterialTheme.colorScheme.error)
        }
        if (stage.answer.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            NexusMarkdown(stage.answer.take(7000))
            if (stage.hasPython && stage.done) {
                OutlinedButton(onClick = { ui.activity.nexusRunPython(stage.index) }) {
                    Text(stringResource(R.string.action_python))
                }
            }
        } else {
            Spacer(Modifier.height(10.dp)); NexusLabel(stringResource(R.string.status_waiting))
        }
    }
}

@Composable
private fun FollowUpDialog(ui: NexusComposeUi, dismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = dismiss,
        title = { Text(stringResource(R.string.followup_title)) },
        text = { Column {
            NexusLabel(stringResource(R.string.followup_body))
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.followup_hint)) }, maxLines = 6)
        } },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = {
            dismiss(); ui.activity.nexusFollowUp(text)
        }) { Text(stringResource(R.string.action_send)) } },
        dismissButton = { TextButton(onClick = dismiss) { Text(stringResource(R.string.action_cancel)) } })
}

@Composable
fun HistoryScreen(ui: NexusComposeUi) {
    val state = ui.snapshot
    var query by remember { mutableStateOf("") }
    var deleteId by remember { mutableStateOf<Long?>(null) }
    var deleteConfirmation by remember { mutableIntStateOf(0) }
    val config = LocalConfiguration.current
    val locale = config.locales[0] ?: Locale.getDefault()
    val formatter = remember(locale) { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, locale) }
    val filtered = state.tasks.filter { it.title.contains(query, ignoreCase = true) }
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(stringResource(R.string.history_title), style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(6.dp))
            NexusLabel(stringResource(R.string.history_description))
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Outlined.Search, null) },
                label = { Text(stringResource(R.string.history_search)) }, singleLine = true)
        }
        if (filtered.isEmpty()) item {
            NexusCard { NexusLabel(stringResource(R.string.history_empty)) }
        }
        items(filtered, key = { it.id }) { task ->
            NexusCard(highlighted = task.selected, onClick = { ui.activity.nexusOpenTask(task.id) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Description, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(task.title, style = MaterialTheme.typography.titleMedium, maxLines = 2,
                            overflow = TextOverflow.Ellipsis)
                        NexusLabel(formatter.format(Date(task.updatedAt)))
                    }
                    StatusPill(stringResource(if (task.completed) R.string.status_complete
                        else if (task.hasRun) R.string.status_saved else R.string.status_draft), task.completed)
                }
                if (task.versions > 0) {
                    Spacer(Modifier.height(8.dp))
                    NexusLabel(stringResource(R.string.history_versions, task.versions))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { deleteId = task.id; deleteConfirmation = 1 }) {
                        Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(5.dp))
                        Text(stringResource(R.string.action_delete), color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
    if (deleteId != null && deleteConfirmation != 0) {
        AlertDialog(onDismissRequest = { deleteConfirmation = 0; deleteId = null },
            title = { Text(stringResource(if (deleteConfirmation == 1)
                R.string.history_delete_first else R.string.history_delete_second)) },
            text = { Text(stringResource(if (deleteConfirmation == 1)
                R.string.history_delete_message else R.string.history_delete_warning)) },
            confirmButton = {
                TextButton(onClick = {
                    if (deleteConfirmation == 1) deleteConfirmation = 2
                    else {
                        deleteId?.let { ui.activity.nexusDeleteTask(it) }
                        deleteId = null; deleteConfirmation = 0
                    }
                }) { Text(stringResource(if (deleteConfirmation == 1) R.string.action_continue else R.string.action_delete)) }
            }, dismissButton = {
                TextButton(onClick = { deleteConfirmation = 0; deleteId = null }) {
                    Text(stringResource(R.string.action_cancel))
                }
            })
    }
}

@Composable
fun ModelsScreen(ui: NexusComposeUi) {
    val state = ui.snapshot
    var provider by remember { mutableStateOf("") }
    var keysOpen by remember { mutableStateOf(false) }
    val displayed = state.models.filter { provider.isEmpty() || it.provider.contains(provider, ignoreCase = true) }
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(stringResource(R.string.models_title), style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(6.dp))
            NexusLabel(stringResource(R.string.models_description))
            Spacer(Modifier.height(14.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("" to R.string.models_all, "OpenRouter" to R.string.models_openrouter,
                    "Groq" to R.string.models_groq, "Gemini" to R.string.models_gemini).forEach { (id, title) ->
                    FilterChip(selected = provider == id, onClick = { provider = id },
                        label = { Text(stringResource(title)) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NexusPrimaryButton(text = stringResource(R.string.models_settings),
                    onClick = { keysOpen = true }, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { ui.activity.nexusRefreshModels() }) {
                    Icon(Icons.Default.Refresh, stringResource(R.string.action_refresh))
                }
            }
        }
        items(displayed, key = { it.id }) { model ->
            NexusCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(model.label, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        NexusLabel(model.provider)
                    }
                    KeyStatusPill(stringResource(if (model.configured)
                        R.string.status_key_configured else R.string.status_key_missing), model.configured)
                }
            }
        }
        item { Spacer(Modifier.height(14.dp)) }
    }
    if (keysOpen) KeysDialog(ui) { keysOpen = false }
}

@Composable
fun KeysDialog(ui: NexusComposeUi, dismiss: () -> Unit) {
    val keys = remember { ui.activity.nexusKeysForEditing() }
    var openRouter by remember { mutableStateOf(keys[0]) }
    var groq by remember { mutableStateOf(keys[1]) }
    var gemini by remember { mutableStateOf(keys[2]) }
    var piston by remember { mutableStateOf(keys[3]) }
    var reserve by remember { mutableStateOf(ui.snapshot.groqReserve) }
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    AlertDialog(onDismissRequest = dismiss,
        title = { Text(stringResource(R.string.keys_title)) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(openRouter, { openRouter = it },
                    label = { Text(stringResource(R.string.keys_openrouter)) },
                    singleLine = true, visualTransformation = PasswordVisualTransformation())
                TextButton(onClick = { runCatching { uriHandler.openUri("https://openrouter.ai/settings/keys") } }) {
                    Text(stringResource(R.string.keys_get_openrouter))
                }
                OutlinedTextField(groq, { groq = it },
                    label = { Text(stringResource(R.string.keys_groq)) },
                    singleLine = true, visualTransformation = PasswordVisualTransformation())
                TextButton(onClick = { runCatching { uriHandler.openUri("https://console.groq.com/keys") } }) {
                    Text(stringResource(R.string.keys_get_groq))
                }
                OutlinedTextField(gemini, { gemini = it },
                    label = { Text(stringResource(R.string.keys_gemini)) },
                    singleLine = true, visualTransformation = PasswordVisualTransformation())
                TextButton(onClick = { runCatching { uriHandler.openUri("https://aistudio.google.com/api-keys") } }) {
                    Text(stringResource(R.string.keys_get_gemini))
                }
                OutlinedTextField(piston, { piston = it },
                    label = { Text(stringResource(R.string.keys_piston)) },
                    singleLine = true, visualTransformation = PasswordVisualTransformation())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = reserve, onCheckedChange = { reserve = it })
                    Text(stringResource(R.string.keys_reserve), style = MaterialTheme.typography.bodyMedium)
                }
                NexusLabel(stringResource(R.string.keys_warning))
                NexusLabel(stringResource(R.string.keys_hint))
            }
        },
        confirmButton = { TextButton(onClick = {
            if (ui.activity.nexusSaveKeys(openRouter, groq, gemini, piston, reserve)) {
                dismiss(); Toast.makeText(context, R.string.keys_saved, Toast.LENGTH_SHORT).show()
            } else Toast.makeText(context, R.string.keys_error, Toast.LENGTH_LONG).show()
        }) { Text(stringResource(R.string.action_save)) } },
        dismissButton = { TextButton(onClick = dismiss) { Text(stringResource(R.string.action_cancel)) } })
}

@Composable
fun SettingsScreen(ui: NexusComposeUi) {
    val theme = ui.theme
    val language = ui.activity.nexusLanguageChoice()
    var keysOpen by remember { mutableStateOf(false) }
    val themes = listOf("system" to R.string.theme_system, "dark" to R.string.theme_dark,
        "light" to R.string.theme_light)
    val languages = listOf("system" to R.string.language_system, "ru" to R.string.language_ru,
        "en" to R.string.language_en, "zh-CN" to R.string.language_zh,
        "ar" to R.string.language_ar, "ja" to R.string.language_ja)
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(stringResource(R.string.settings_title), style = MaterialTheme.typography.headlineLarge) }
        item {
            NexusCard {
                Text(stringResource(R.string.settings_appearance), style = MaterialTheme.typography.titleLarge)
                themes.forEach { (key, label) ->
                    Row(Modifier.fillMaxWidth().clickable { ui.activity.nexusThemeChanged(key) },
                        verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = theme == key, onClick = { ui.activity.nexusThemeChanged(key) })
                        Text(stringResource(label))
                    }
                }
            }
        }
        item {
            NexusCard {
                Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleLarge)
                languages.forEach { (key, label) ->
                    Row(Modifier.fillMaxWidth().clickable { ui.activity.nexusLanguageChanged(key) },
                        verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = language == key, onClick = { ui.activity.nexusLanguageChanged(key) })
                        Text(stringResource(label))
                    }
                }
            }
        }
        item {
            NexusCard(onClick = { keysOpen = true }) {
                Text(stringResource(R.string.settings_providers), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(7.dp))
                NexusLabel(stringResource(R.string.keys_warning))
            }
        }
        item {
            NexusCard {
                Text(stringResource(R.string.settings_about), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(5.dp))
                NexusLabel(stringResource(R.string.settings_version))
                NexusLabel(stringResource(R.string.settings_privacy))
            }
        }
        item { Spacer(Modifier.height(15.dp)) }
    }
    if (keysOpen) KeysDialog(ui) { keysOpen = false }
}


@Composable
fun VersionsDialog(ui: NexusComposeUi) {
    val labels = remember { ui.activity.nexusVersionLabels().toList() }
    var selected by remember { mutableIntStateOf(-1) }
    AlertDialog(onDismissRequest = { ui.dismissVersions() },
        title = { Text(stringResource(R.string.action_versions)) },
        text = {
            if (selected < 0) {
                LazyColumn(Modifier.heightIn(max = 450.dp)) {
                    items(labels.indices.toList()) { index ->
                        ListItem(headlineContent = { Text(labels[index]) },
                            modifier = Modifier.clickable { selected = index })
                    }
                }
            } else {
                val result = remember(selected) { ui.activity.nexusVersionAnswer(selected) }
                Column(Modifier.heightIn(max = 470.dp).verticalScroll(rememberScrollState())) {
                    NexusMarkdown(result)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (selected >= 0) selected = -1 else ui.dismissVersions() }) {
                Text(stringResource(if (selected < 0) R.string.action_close else R.string.action_back))
            }
        })
}
