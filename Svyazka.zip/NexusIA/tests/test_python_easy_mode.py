"""Contracts for the simplified Python workspace; not a substitute for Android testing."""
from pathlib import Path
import unittest
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'
UI = JAVA / 'ui'
RES = ROOT / 'app/src/main/res'


class EasyPythonWorkspaceTests(unittest.TestCase):
    def test_zip_replacement_and_backup_are_atomic_and_separate(self):
        store = (JAVA / 'PythonProjectStore.java').read_text()
        self.assertIn('replaceZip(long taskId, byte[] body)', store)
        self.assertIn('LinkedHashMap<String, byte[]> replacement = parseFullProjectZip(body)', store)
        self.assertIn('previous.finishWrite(out);', store)
        self.assertIn('write(taskId, replacement);', store)
        self.assertLess(store.index('previous.finishWrite(out);'), store.index('write(taskId, replacement);'))
        self.assertIn('restorePrevious(long taskId)', store)
        self.assertIn('previousFile(taskId).delete();', store)
        self.assertIn('if (!parsed.containsKey("main.py"))', store)

    def test_ui_shows_import_result_and_preserves_confirmation(self):
        code = (UI / 'NexusPythonProjectFiles.kt').read_text()
        self.assertIn('nexusPythonReplaceZip', code)
        self.assertIn('pendingProject = incoming.second', code)
        self.assertIn('finishImport(', code)
        self.assertIn('ws_easy_import_success', code)
        self.assertIn('ws_easy_replace_title', code)
        self.assertIn('nexusPythonRestorePreviousProject', code)

    def test_simple_entry_is_default_advanced_tools_are_hidden(self):
        code = (UI / 'NexusPythonWorkspace.kt').read_text()
        self.assertIn('var toolPanel by remember { mutableStateOf<PythonToolPanel?>(null) }', code)
        self.assertIn('NexusPrimaryButton(text = stringResource(R.string.ws_easy_run)', code)
        self.assertIn('PythonToolPanel.MENU -> Column(', code)
        self.assertIn('PythonToolPanel.FILES -> PythonProjectFileManager(ui)', code)
        self.assertIn('PythonToolPanel.EDITOR -> PythonEditorTool(ui, save, blocks,', code)
        self.assertIn('PythonToolPanel.SETTINGS -> PythonRunSettingsTool(ui, allowedPackage,', code)
        self.assertNotIn('showAdvancedWorkspace', code)
        self.assertIn('ws_easy_tests_summary', code)
        self.assertIn('PythonProjectFiles(ui)', code)

    def test_editor_has_clear_copy_and_download_without_old_buttons(self):
        code = (UI / 'NexusPythonWorkspace.kt').read_text()
        editor = code.split('private fun PythonProjectEditor(', 1)[1].split(
            'private fun PythonRunOutput(', 1)[0]
        self.assertEqual(editor.count('Text(stringResource(R.string.editor_clear)'), 1)
        self.assertEqual(editor.count('Text(stringResource(R.string.action_copy)'), 1)
        self.assertEqual(editor.count('Text(stringResource(R.string.ws_download)'), 1)
        self.assertIn('Modifier.weight(1f)', editor)
        self.assertIn('if (showSearchTools)', editor)
        self.assertIn('minLines = 1', editor)
        self.assertNotIn('ws_undo', code)
        self.assertNotIn('ws_redo', code)
        self.assertNotIn('editor_paste', code)
        self.assertIn('versionCode 17', (ROOT / 'app/build.gradle').read_text())

    def test_drawer_compiler_references_and_extended_confirmation(self):
        code = (UI / 'NexusPythonWorkspace.kt').read_text()
        self.assertIn('import androidx.compose.ui.draw.clip', code)
        self.assertIn('launch(confirmedExtended = true)', code)
        self.assertIn('extended && !confirmedExtended', code)
        referenced = set(re.findall(r'R\.string\.(\w+)', code))
        for locale in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            names = set()
            for resource in (RES / locale).glob('*.xml'):
                root = ET.parse(resource).getroot()
                names.update(x.attrib['name'] for x in root if x.tag == 'string' and 'name' in x.attrib)
            self.assertFalse(referenced - names,
                f'{locale}: unknown resources {referenced - names}')

    def test_matplotlib_can_use_confirmed_extended_mode_and_timeout_is_visible(self):
        code = (UI / 'NexusPythonWorkspace.kt').read_text()
        self.assertIn('RadioButton(selected = allowedPackage == "matplotlib",', code)
        self.assertIn('Checkbox(checked = extended, onCheckedChange = { onExtended(it) })', code)
        self.assertIn('if (report.status.isNotBlank())', code)
        self.assertIn('launch(confirmedExtended = true)', code)
        worker = (ROOT / 'app/src/main/assets/sandbox/worker.mjs').read_text()
        self.assertLess(worker.index("python.runPython('prepare_matplotlib()')"),
                        worker.index("port.postMessage({kind:'execution_start'})"))
        runner = (ROOT / 'app/src/main/assets/sandbox/runner.js').read_text()
        self.assertIn("input.extended === true ? 20000 : 5000", runner)
        self.assertIn('MATPLOTLIB_PREPARATION_TIMEOUT_MS = 120000', runner)

    def test_new_labels_exist_in_all_five_languages(self):
        required = {'ws_easy_choose_project','ws_easy_run','ws_easy_replace_title',
                    'ws_easy_import_success','ws_easy_run_ok','ws_easy_tests_summary',
                    'ws_easy_restore_previous','ws_easy_edit_settings',
                    'ws_easy_tools','ws_easy_tools_title','ws_easy_files_tool',
                    'ws_easy_editor_tool','ws_easy_run_settings_tool'}
        for locale in ('values','values-en','values-ar','values-ja','values-zh-rCN'):
            root = ET.parse(RES / locale / 'workbench.xml').getroot()
            names = {s.attrib['name'] for s in root.findall('string')}
            self.assertTrue(required.issubset(names), locale)


if __name__ == '__main__':
    unittest.main()
