package app.svyazka.mobile.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.R

/** Compose dialogs around the existing Java PythonExecutor/LocalSandbox engine. */
@Composable
fun PythonDialogs(ui: NexusComposeUi) {
    val blocks = ui.pythonCodeBlocks
    if (blocks.isNotEmpty()) {
        var selected by remember(ui.pythonStep, blocks) { mutableIntStateOf(0) }
        var stdin by remember { mutableStateOf("") }
        var matplotlib by remember { mutableStateOf(false) }
        var remote by remember { mutableStateOf(false) }
        AlertDialog(onDismissRequest = { ui.dismissPythonInput() },
            title = { Text(stringResource(R.string.python_run_title)) },
            text = {
                Column(Modifier.heightIn(max = 490.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    if (blocks.size > 1) {
                        blocks.forEachIndexed { index, code ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = selected == index, onClick = { selected = index })
                                Text(stringResource(R.string.python_block, index + 1) + ": " +
                                    code.lineSequence().firstOrNull().orEmpty().take(55),
                                    style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                    NexusLabel(stringResource(R.string.python_input_help))
                    OutlinedTextField(stdin, { if (it.length <= 16_000) stdin = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.python_input_hint)) }, maxLines = 5)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = matplotlib, onCheckedChange = {
                            matplotlib = it; if (it) remote = false
                        })
                        Text(stringResource(R.string.python_package_permission),
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    if (ui.pythonHasPiston) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = remote, onCheckedChange = {
                                remote = it; if (it) matplotlib = false
                            })
                            Text(stringResource(R.string.python_use_piston),
                                style = MaterialTheme.typography.bodyMedium)
                        }
                        if (remote) NexusLabel(stringResource(R.string.python_warning_remote))
                    }
                }
            }, confirmButton = {
                TextButton(onClick = {
                    val code = blocks.getOrNull(selected) ?: return@TextButton
                    ui.activity.nexusExecutePython(ui.pythonStep, code, stdin, remote, matplotlib)
                }) { Text(stringResource(R.string.action_start)) }
            }, dismissButton = {
                TextButton(onClick = { ui.dismissPythonInput() }) {
                    Text(stringResource(R.string.action_cancel))
                }
            })
    }
    if (ui.pythonBusy) {
        AlertDialog(onDismissRequest = { /* Running Python can only be stopped explicitly. */ },
            title = { Text(stringResource(R.string.processing)) },
            text = { Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(26.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(14.dp))
                Text(stringResource(R.string.status_processing))
            } },
            confirmButton = {
                TextButton(onClick = { ui.activity.nexusCancelPython() }) {
                    Text(stringResource(R.string.action_stop))
                }
            })
    }
    val report = ui.pythonReport
    if (report != null) {
        AlertDialog(onDismissRequest = { ui.dismissPythonResult() },
            title = { Text(stringResource(R.string.result_visual)) },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    NexusLabel(report.engine + (report.exitCode?.let { " · $it" } ?: ""))
                    if (report.status.isNotEmpty()) Text(report.status,
                        color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(R.string.python_stdout), style = MaterialTheme.typography.titleMedium)
                    Text(if (report.stdout.isEmpty()) stringResource(R.string.python_no_output) else report.stdout,
                        style = MaterialTheme.typography.bodyMedium)
                    if (report.stderr.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Text(stringResource(R.string.python_stderr), style = MaterialTheme.typography.titleMedium)
                        Text(report.stderr, color = MaterialTheme.colorScheme.error)
                    }
                    if (report.hasVisual) {
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { ui.dismissPythonResult(); ui.openVisual() },
                            modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.action_show_result))
                        }
                    }
                }
            },
            confirmButton = {
                if (report.diagnostic.isNotEmpty()) {
                    TextButton(onClick = { ui.dismissPythonResult(); ui.activity.nexusSendPythonError() }) {
                        Text(stringResource(R.string.python_error_to_review))
                    }
                } else TextButton(onClick = { ui.dismissPythonResult() }) {
                    Text(stringResource(R.string.action_close))
                }
            },
            dismissButton = {
                if (report.diagnostic.isNotEmpty()) TextButton(onClick = { ui.dismissPythonResult() }) {
                    Text(stringResource(R.string.action_close))
                }
            })
    }
    val error = ui.pythonError
    if (error != null) {
        AlertDialog(onDismissRequest = { ui.dismissPythonResult() },
            title = { Text(stringResource(R.string.python_error_title)) },
            text = { Text(error) },
            confirmButton = { TextButton(onClick = { ui.dismissPythonResult() }) {
                Text(stringResource(R.string.action_close))
            } })
    }
}
