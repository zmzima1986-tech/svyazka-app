package app.svyazka.mobile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** New statuses distinguish response completion from the mere presence of text. */
final class AttemptJournal {
    private AttemptJournal() { }

    static String status(ModelClient.Reply reply, String override) {
        if ("CANCELLED".equals(override)) return "CANCELLED";
        if ("TIMEOUT".equals(override)) return "TIMED_OUT";
        if (reply == null) return "CANCELLED";
        switch (reply.finish) {
            case STOP: return "COMPLETED";
            case LENGTH: return "INCOMPLETE";
            case ERROR: return "FAILED";
            default: throw new IllegalArgumentException("Unknown finish");
        }
    }

    static JSONObject normalize(JSONObject old) throws JSONException {
        JSONObject value = new JSONObject(old.toString());
        if (!value.has("status")) {
            String legacy = value.optString("outcome", "ERROR");
            String state;
            switch (legacy) {
                case "STOP": state = "COMPLETED"; break;
                case "LENGTH": state = "INCOMPLETE"; break;
                case "TIMEOUT": state = "TIMED_OUT"; break;
                case "CANCELLED": state = "CANCELLED"; break;
                default: state = "FAILED"; break;
            }
            value.put("status", state);
        }
        if (!value.has("has_text")) value.put("has_text", value.optBoolean("partial", false));
        value.remove("outcome");
        value.remove("partial");
        return value;
    }

    static JSONArray normalizeAll(JSONArray history) throws JSONException {
        JSONArray result = new JSONArray();
        for (int i = 0; i < history.length(); i++) result.put(normalize(history.getJSONObject(i)));
        return result;
    }
}
