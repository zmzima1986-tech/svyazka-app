package app.svyazka.mobile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** No Android dependency: the Java -> Compose presentation contract is immutable and secret-free. */
public final class NexusStateChecks {
    public static void main(String[] args) throws Exception {
        List<NexusState.Stage> stages = new ArrayList<>();
        stages.add(new NexusState.Stage(0, "Architect", "Respond", "model-a", "Model A",
                "Hello", "", false, true, false));
        List<NexusState.Model> models = new ArrayList<>();
        models.add(new NexusState.Model("model-a", "Model A", "Provider", true));
        List<NexusState.Task> tasks = new ArrayList<>();
        tasks.add(new NexusState.Task(5L, "Test", 1000L, 2, true, true, true));
        NexusState state = new NexusState("Test", false, false, false, true, true,
                3, 3, "", "Hello", "Author", "", false, "", stages, models, tasks,
                true, "model-a", "Model A", 2, false, Collections.emptyList());
        stages.clear();
        models.clear();
        tasks.clear();
        assert state.stages.size() == 1;
        assert state.models.size() == 1;
        assert state.tasks.size() == 1;
        assert state.models.get(0).configured;
        assert state.tasks.get(0).completed;
        boolean locked = false;
        try { state.tasks.clear(); }
        catch (UnsupportedOperationException expected) { locked = true; }
        assert locked : "Compose projection must not mutate repository data";
        for (java.lang.reflect.Field f : NexusState.class.getDeclaredFields()) {
            String name = f.getName().toLowerCase(java.util.Locale.ROOT);
            assert !name.contains("secret") && !name.contains("password") && !name.contains("token");
        }
        NexusPythonReport python = new NexusPythonReport("Pyodide", "ok", "", "", "", 0, true);
        assert python.exitCode == 0 && python.hasVisual && python.stdout.equals("ok");
        System.out.println("NexusStateChecks: PASS");
    }
}
