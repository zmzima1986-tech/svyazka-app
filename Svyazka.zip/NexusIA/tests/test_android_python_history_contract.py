"""Static contracts for the Android artifact probe; they do not execute Android."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AndroidArtifactContract(unittest.TestCase):
    def test_android_probe_covers_python_only_artifact_lifecycle(self):
        source = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/PythonHistoryProbe.java').read_text()
        for required in (
            'startActivitySync', 'ui(activity)', 'compose.addPythonFile(FILE)',
            'compose.editPython(SOURCE)', 'nexusPythonFlushPending()',
            'activity.nexusCreateTask()', 'activity.nexusOpenArtifacts()',
            'activity.nexusOpenArtifact(firstProject.get())',
            'activity.nexusArtifactId()', 'compose.getPythonFileList()',
            'activity.nexusDeleteArtifact(first)', 'credentials',
            'hasArtifact(activity, first)', 'hasChat(activity, firstChat)',
        ):
            self.assertIn(required, source)

    def test_artifact_catalog_not_mistaken_for_chat_history(self):
        activity = (ROOT / 'app/src/main/java/app/svyazka/mobile/MainActivity.java').read_text()
        repo = (ROOT / 'app/src/main/java/app/svyazka/mobile/PythonArtifactRepository.java').read_text()
        history = (ROOT / 'app/src/main/java/app/svyazka/mobile/ui/NexusScreens.kt').read_text()
        self.assertIn('private long ensurePythonArtifact() throws IOException', activity)
        self.assertIn('savedPythonArtifact(projectId, path)', activity)
        self.assertIn('artifactRepository.unlinkChat(id)', activity)
        self.assertIn('statement.executeUpdateDelete() == 1', repo)
        self.assertIn('ui.activity.nexusPythonHistoryDiagnostic()', history)

    def test_probe_has_fresh_process_restart_and_tombstone_verification(self):
        fixture = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/UpgradeProbe.java').read_text()
        script = (ROOT / 'scripts/test-android-python-history.py').read_text()
        probe = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/PythonHistoryProbe.java').read_text()
        self.assertIn('PythonHistoryProbe.run(this, step)', fixture)
        for step in ('python_seed', 'python_verify', 'python_deleted'):
            self.assertIn(step, script)
            self.assertIn(step, probe)
        self.assertIn("am', 'force-stop'", script)
        for step in ('python_chat_context_seed', 'python_chat_context_verify'):
            self.assertIn(step, script)
            self.assertIn(step, probe)
        self.assertIn('getDeclaredMethod("questionHistory", long.class, runType)', probe)
        self.assertIn('!sent.contains(otherMarker)', probe)
        self.assertIn('collect.invoke(activity, other, current)', probe)


if __name__ == '__main__':
    unittest.main()
