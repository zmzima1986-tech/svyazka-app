# Third-party notices

## Логотипы провайдеров (Lobe Icons)


Логотипы: [Lobe Icons](https://github.com/lobehub/lobe-icons), статические SVG
из ревизии [`34270bc208d7122778dc00b30bd460f97ea03216`](https://github.com/lobehub/lobe-icons/tree/34270bc208d7122778dc00b30bd460f97ea03216/packages/static-svg/icons).
Использованы оригинальные контуры, растеризованные в прозрачные PNG 128 × 128.
Монохромные знаки имеют светлый вариант в `drawable-night-nodpi`;
остальные находятся в `drawable-nodpi`. Всего 22 PNG, около 90 КБ.
Лицензия также включена в APK как ресурс `R.array.provider_logo_licenses`.

```text
MIT License

Copyright (c) 2023 LobeHub

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Остальные зависимости

См. `app/src/main/assets/licenses/` и `docs/licenses/` для исходных уведомлений и лицензий.
