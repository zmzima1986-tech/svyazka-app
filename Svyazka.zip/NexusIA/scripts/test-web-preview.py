"""Exercise the bundled web workspace in a clean Chromium browser."""
import json
import math
import os
import re
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

ASSETS = Path(__file__).resolve().parents[1] / "app/src/main/assets/web"
ORIGIN = "https://nexus-workspace.invalid/"
DOCUMENT = """<!doctype html><output id="count">0</output><button onclick="return false">x</button>
<script>
const counter = document.getElementById("count");
let value = 0;
setInterval(() => { counter.textContent = String(++value); }, 50);
</script>"""


def main():
    shell = (ASSETS / "shell.html").read_text()
    for name, marker in (("acorn.js", "PARSER"), ("controller.js", "CONTROLLER")):
        shell = shell.replace("/*" + marker + "*/", (ASSETS / name).read_text())
    with sync_playwright() as driver:
        browser = driver.chromium.launch(executable_path=os.environ.get("CHROMIUM_EXECUTABLE"))
        page = browser.new_page()
        page.route("**/*", lambda route: route.fulfill(body=shell, content_type="text/html")
                   if route.request.url == ORIGIN else route.abort())
        page.goto(ORIGIN)

        def inspect(source, language="html"):
            return json.loads(page.evaluate("([code, kind]) => inspectSource(code, kind)", [source, language]))

        assert inspect(DOCUMENT) == {"checked": 2, "external": 0, "issues": []}
        assert inspect("<script>let value = ;</script>")["issues"]
        mixed = '<script type="module">export const x=2;</script><script src="foo.js"></script>'
        assert inspect(mixed) == {"checked": 1, "external": 1, "issues": [], "resources": ["foo.js"]}
        assert inspect("export const a = 1", "javascript")["checked"] == 1
        assert inspect('<button onclick="("></button>')["issues"]
        page.evaluate('source => renderSource(source, "html")', DOCUMENT)
        page.frame_locator("iframe").locator("#count").wait_for()
        frame = page.frames[1]
        until = time.monotonic() + 4
        while frame.evaluate('Number(document.getElementById("count").textContent)') <= 1:
            assert time.monotonic() < until, "Timer did not advance"
            page.wait_for_timeout(50)
        assert frame.evaluate("self.origin") == "null"
        assert frame.evaluate("() => {try {void parent.document; return false} catch {return true}}")
        assert frame.evaluate('async () => {try {await fetch("https://weather.invalid/test"); return false} catch {return true}}')
        assert frame.evaluate('() => {try {localStorage.setItem("test","1"); return false} catch {return true}}')
        def checks(source, features):
            page.evaluate("([s,f])=>startWidgetChecks(s,f)", [source,features])
            until = time.monotonic()+11
            while time.monotonic()<until:
                report = page.evaluate("window.nexusTestResult")
                if report is not None:
                    return {r["id"]: r["status"] for r in report}
                page.wait_for_timeout(100)
            raise AssertionError("No probe report")

        fixtures = ASSETS.parents[4] / "tests/fixtures/recovery"
        for name in ["clock-calendar-weather", "with-bluetooth"]:
            answer = (fixtures / (name+".md")).read_text()
            html = re.search(r"```html[^\n]*\n(.*?)\n```",answer,re.S)[1]
            features=["часы","календарь","погода"]
            if name=="with-bluetooth": features.append("Bluetooth")
            found=checks(html,features)
            print(name,found, flush=True)
            assert all(found.get(k)=="pass" for k in ("clock.tick","calendar.current","calendar.december",
                "calendar.january","calendar.leap","weather.current","weather.leap","weather.offline")),found
            if name=="with-bluetooth": assert found["bluetooth.device"]=="unverified"
        observed = (fixtures / "observed-mixed-clock.md").read_text()
        actual_html = re.search(r"```html[^\n]*\n(.*?)\n```", observed, re.S)[1]
        assert inspect(actual_html)["issues"] == []
        assert checks(actual_html, ["часы"]) == {"clock.tick": "pass"}
        page.evaluate('source => renderSource(source, "html")', actual_html)
        clock = page.frame_locator("iframe").locator("#clock")
        clock.wait_for()
        first = clock.inner_text()
        page.wait_for_timeout(1300)
        assert clock.inner_text() != first and re.fullmatch(r"\d{2}:\d{2}:\d{2}", clock.inner_text())
        assert re.search(r"\d{4}$", page.frame_locator("iframe").locator("#date").inner_text())
        single_clock = """<time data-nexus="clock"></time><script>
            function tick(){document.querySelector('time').textContent=new Date().toTimeString().slice(0,8)}
            setInterval(tick,1000);tick();</script>"""
        assert checks(single_clock,["часы"])=={"clock.tick":"pass"}
        calendar = """<p data-nexus="month"></p><div data-nexus="calendar"></div>
            <button data-nexus="next">Next</button><script>
            let d=new Date();d.setDate(1);
            function draw(){document.querySelector('p').textContent=d.toLocaleString('en',{month:'long',year:'numeric'});
                const grid=document.querySelector('[data-nexus=calendar]');grid.replaceChildren();
                for(let i=1;i<=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();i++){
                    const e=document.createElement('span');e.textContent=i;grid.append(e);}}
            document.querySelector('button').onclick=()=>{d.setMonth(d.getMonth()+1);draw()};draw();</script>"""
        extended=checks(single_clock+calendar,["часы","календарь"])
        assert extended["clock.tick"]=="pass" and extended["calendar.nextyear"]=="pass",extended
        assert checks(calendar.replace("d.setMonth(d.getMonth()+1)","d.setMonth(11)"),["календарь"])["calendar.nextyear"]=="fail"
        assert checks('<div id="clock">08:00:00</div>',["часы"])["clock.tick"]=="fail"
        assert checks('<p>Clock</p>',["часы"])["clock.tick"]=="unverified"
        if os.environ.get("NEXUS_LIVE_WEATHER")=="1":
            from urllib.request import urlopen
            from urllib.parse import urlparse
            live=browser.new_page()
            received=[]
            def fetch_live(route):
                req=route.request
                parts=urlparse(req.url)
                if req.url==ORIGIN:
                    return route.fulfill(body=html,content_type="text/html")
                if (parts.scheme,parts.netloc,parts.path)!=("https","api.open-meteo.com","/v1/forecast"):
                    return route.abort()
                with urlopen(req.url,timeout=15) as response:
                    body=response.read(65536)
                current=json.loads(body)["current_weather"]
                received.append(current)
                route.fulfill(body=body,content_type="application/json",headers={"Access-Control-Allow-Origin":"*"})
            live.route("**/*",fetch_live)
            live.goto(ORIGIN)
            live.locator("#weather strong").wait_for(timeout=20000)
            temperature=live.locator("#weather strong").inner_text()
            assert received and temperature==str(math.floor(float(received[0]["temperature"])+0.5))+"°C",(received,temperature)
            print("External widget, real Open-Meteo response:",received[0]["time"],temperature)
        browser.close()
    print("JavaScript syntax, event handlers, timer and offline frame checks passed")


if __name__ == "__main__":
    main()
