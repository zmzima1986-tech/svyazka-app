package app.svyazka.mobile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.xml.parsers.SAXParserFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/** Bounded document parsing. Archives are inspected in memory, never extracted or executed. */
public final class AttachmentParser {
    public enum Kind { TEXT, DOCX, PDF, ZIP, IMAGE, UNKNOWN }
    public static final int MAX_ENTRIES = 256;
    public static final long MAX_EXPANDED = 32L * 1024 * 1024;
    private static final Set<String> TEXT = new HashSet<>(Arrays.asList(
            "txt", "md", "markdown", "json", "jsonl", "csv", "tsv", "xml", "html", "htm", "yaml", "yml", "log",
            "py", "pyi", "java", "kt", "kts", "js", "jsx", "mjs", "cjs", "ts", "tsx", "css", "scss", "sass",
            "sql", "c", "h", "cc", "cpp", "cxx", "hpp", "cs", "go", "rs", "rb", "swift", "php", "dart",
            "sh", "bash", "zsh", "fish", "ps1", "bat", "cmd", "toml", "ini", "conf", "cfg", "properties", "gradle",
            "env", "r", "lua", "pl", "ex", "exs", "erl", "hs", "vue", "svelte", "tex", "ipynb", "gitignore", "dockerfile"));
    private static final Set<String> ARCHIVES = new HashSet<>(Arrays.asList("zip", "7z", "rar", "gz", "tgz", "bz2", "xz", "tar", "jar", "apk"));
    private AttachmentParser() {}

    public static final class Note {
        public final String name;
        public final AttachmentProblem.Code code; // null means this item was actually read.
        public Note(String name, AttachmentProblem.Code code) { this.name = name; this.code = code; }
    }
    public static final class Result {
        public final String text;
        public final List<Note> notes;
        public final boolean partial;
        public final int processed, total;
        public Result(String text, List<Note> notes, boolean partial, int processed, int total) {
            this.text = text; this.notes = Collections.unmodifiableList(new ArrayList<>(notes));
            this.partial = partial; this.processed = processed; this.total = total;
        }
    }
    public static String extension(String name) {
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        int dot = name.lastIndexOf('.');
        return dot > slash ? name.substring(dot + 1).toLowerCase(Locale.ROOT) : "";
    }
    public static Kind kind(String name, String mime) {
        String ext = extension(name);
        if ("docx".equals(ext) || "application/vnd.openxmlformats-officedocument.wordprocessingml.document".equals(mime)) return Kind.DOCX;
        if ("pdf".equals(ext) || "application/pdf".equals(mime)) return Kind.PDF;
        if ("zip".equals(ext) || "application/zip".equals(mime) || "application/x-zip-compressed".equals(mime)) return Kind.ZIP;
        if (Arrays.asList("jpg", "jpeg", "png", "webp").contains(ext) || InputMaterial.imageMime(mime)) return Kind.IMAGE;
        String base = name.substring(name.lastIndexOf('/') + 1).toLowerCase(Locale.ROOT);
        if (TEXT.contains(ext) || Arrays.asList("readme", "license", "makefile", "dockerfile", ".gitignore", ".env").contains(base)
                || mime.startsWith("text/") || Arrays.asList("application/json", "application/xml", "application/javascript").contains(mime)) return Kind.TEXT;
        return Kind.UNKNOWN;
    }
    public static Result read(File file, String name, String mime) throws IOException {
        if (file.length() > InputMaterial.MAX_FILE_BYTES) throw new AttachmentProblem(AttachmentProblem.Code.FILE_SIZE, name);
        switch (kind(name, mime)) {
            case TEXT:
                if (file.length() > InputMaterial.MAX_TEXT_CHARS * 4L + 4) throw new AttachmentProblem(AttachmentProblem.Code.TEXT_SIZE, name);
                String text;
                try (InputStream input = new FileInputStream(file)) { text = decode(readBounded(input, InputMaterial.MAX_FILE_BYTES)); }
                return new Result(text, Collections.singletonList(new Note(name, null)), false, 1, 1);
            case DOCX: return docx(file, name);
            case ZIP: return archive(file, name);
            default: throw new AttachmentProblem(AttachmentProblem.Code.UNSUPPORTED, name);
        }
    }
    public static byte[] readBounded(InputStream input, long maximum) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        while ((count = input.read(buffer)) != -1) {
            if (Thread.currentThread().isInterrupted()) throw new AttachmentProblem(AttachmentProblem.Code.INTERRUPTED);
            if (output.size() + (long) count > maximum) throw new AttachmentProblem(AttachmentProblem.Code.PACKAGE_SIZE);
            output.write(buffer, 0, count);
        }
        return output.toByteArray();
    }
    public static String decode(byte[] bytes) throws AttachmentProblem {
        Charset charset = StandardCharsets.UTF_8;
        int offset = 0;
        if (bytes.length >= 3 && (bytes[0] & 255) == 239 && (bytes[1] & 255) == 187 && (bytes[2] & 255) == 191) offset = 3;
        else if (bytes.length >= 2 && (bytes[0] & 255) == 255 && (bytes[1] & 255) == 254) { charset = StandardCharsets.UTF_16LE; offset = 2; }
        else if (bytes.length >= 2 && (bytes[0] & 255) == 254 && (bytes[1] & 255) == 255) { charset = StandardCharsets.UTF_16BE; offset = 2; }
        String value;
        try {
            value = charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes, offset, bytes.length - offset)).toString();
        } catch (CharacterCodingException e) { throw new AttachmentProblem(AttachmentProblem.Code.ENCODING); }
        if (value.length() > InputMaterial.MAX_TEXT_CHARS) throw new AttachmentProblem(AttachmentProblem.Code.TEXT_SIZE);
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c == 0 || c < 32 && c != '\n' && c != '\r' && c != '\t' && c != '\f')
                throw new AttachmentProblem(AttachmentProblem.Code.NOT_TEXT);
        }
        return value;
    }
    public static boolean safePath(String path) {
        if (path.isEmpty() || path.length() > 1024 || path.startsWith("/") || path.startsWith("\\")
                || path.matches("^[A-Za-z]:.*") || path.indexOf('\0') >= 0) return false;
        if (path.length() >= 2 && path.charAt(1) == ':') return false;
        for (int i = 0; i < path.length(); i++) if (Character.isISOControl(path.charAt(i))) return false;
        for (String segment : path.replace('\\', '/').split("/")) if (segment.equals("..")) return false;
        return true;
    }
    // Check the central directory before ZipFile can allocate metadata for excessive entries.
    // ZIP64, multi-volume, encrypted entries and symlinks are deliberately not accepted.
    private static int centralDirectory(File file) throws IOException {
        try (RandomAccessFile input = new RandomAccessFile(file, "r")) {
            long length = input.length();
            if (length < 22) throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT);
            int tailLength = (int) Math.min(length, 65557);
            byte[] tail = new byte[tailLength]; input.seek(length - tailLength); input.readFully(tail);
            int end = -1;
            for (int i = tail.length - 22; i >= 0; i--) {
                if (u32(tail, i) == 0x06054b50L && i + 22 + u16(tail, i + 20) == tail.length) { end = i; break; }
            }
            if (end < 0) throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT);
            int count = u16(tail, end + 10);
            long size = u32(tail, end + 12), offset = u32(tail, end + 16);
            if (count > MAX_ENTRIES) throw new AttachmentProblem(AttachmentProblem.Code.ZIP_COUNT);
            if (u16(tail, end + 4) != 0 || u16(tail, end + 6) != 0 || u16(tail, end + 8) != count
                    || size == 0xffffffffL || offset == 0xffffffffL)
                throw new AttachmentProblem(AttachmentProblem.Code.UNSUPPORTED, "ZIP64 / multi-volume ZIP");
            long endPosition = length - tailLength + end;
            if (offset + size != endPosition || offset < 0 || offset > length)
                throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT);
            input.seek(offset);
            int actual = 0;
            byte[] header = new byte[46];
            while (input.getFilePointer() < endPosition) {
                if (++actual > MAX_ENTRIES) throw new AttachmentProblem(AttachmentProblem.Code.ZIP_COUNT);
                input.readFully(header);
                if (u32(header, 0) != 0x02014b50L) throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT);
                if ((u16(header, 8) & 1) != 0) throw new AttachmentProblem(AttachmentProblem.Code.UNSUPPORTED, "Encrypted ZIP");
                if (((u32(header, 38) >>> 16) & 0170000) == 0120000)
                    throw new AttachmentProblem(AttachmentProblem.Code.ZIP_PATH, "Symbolic link");
                long next = input.getFilePointer() + u16(header, 28) + u16(header, 30) + u16(header, 32);
                if (next > endPosition) throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT);
                input.seek(next);
            }
            if (actual != count) throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT);
            return count;
        } catch (AttachmentProblem e) { throw e; }
        catch (IOException e) { throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT); }
    }
    private static int u16(byte[] value, int offset) { return (value[offset] & 255) | (value[offset + 1] & 255) << 8; }
    private static long u32(byte[] value, int offset) { return u16(value, offset) | (long) u16(value, offset + 2) << 16; }

    private static ZipFile checkedZip(File file) throws IOException {
        int entryCount = centralDirectory(file);
        ZipFile zip;
        try { zip = new ZipFile(file); }
        catch (IOException e) { throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT); }
        try {
            if (zip.size() > MAX_ENTRIES) throw new AttachmentProblem(AttachmentProblem.Code.ZIP_COUNT);
            if (zip.size() != entryCount) throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT);
            long expanded = 0;
            Set<String> names = new HashSet<>();
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (!safePath(entry.getName()) || !names.add(entry.getName().replace('\\', '/')))
                    throw new AttachmentProblem(AttachmentProblem.Code.ZIP_PATH, entry.getName());
                long size = entry.getSize(), compressed = entry.getCompressedSize();
                if (size < 0 || compressed < 0 || size > InputMaterial.MAX_FILE_BYTES || (expanded += size) > MAX_EXPANDED)
                    throw new AttachmentProblem(AttachmentProblem.Code.PACKAGE_SIZE, entry.getName());
                if (size > 1024 * 1024 && (compressed == 0 || size / Math.max(1, compressed) > 200))
                    throw new AttachmentProblem(AttachmentProblem.Code.ZIP_RATIO, entry.getName());
            }
            return zip;
        } catch (IOException | RuntimeException e) { zip.close(); throw e; }
    }
    private static byte[] entryBytes(ZipFile zip, ZipEntry entry, long maximum) throws IOException {
        byte[] bytes;
        try (InputStream stream = zip.getInputStream(entry)) { bytes = readBounded(stream, maximum); }
        catch (AttachmentProblem e) { throw e; }
        catch (IOException e) { throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT, entry.getName()); }
        CRC32 crc = new CRC32(); crc.update(bytes);
        if (bytes.length != entry.getSize() || entry.getCrc() != crc.getValue())
            throw new AttachmentProblem(AttachmentProblem.Code.CORRUPT, entry.getName());
        return bytes;
    }
    private static Result archive(File file, String name) throws IOException {
        List<Note> notes = new ArrayList<>();
        JSONArray processed = new JSONArray(), skipped = new JSONArray();
        int total = 0, count = 0, textLength = 0;
        try (ZipFile zip = checkedZip(file)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (entry.isDirectory()) continue;
                total++;
                String path = entry.getName();
                AttachmentProblem.Code skip = null;
                if (ARCHIVES.contains(extension(path))) skip = AttachmentProblem.Code.NESTED_ARCHIVE;
                else if (kind(path, "") != Kind.TEXT) skip = AttachmentProblem.Code.BINARY_ENTRY;
                if (skip != null) {
                    notes.add(new Note(path, skip)); skipped.put(new JSONObject().put("path", path).put("reason", skip.name()));
                    continue;
                }
                if (entry.getSize() > InputMaterial.MAX_TEXT_CHARS * 4L + 4) throw new AttachmentProblem(AttachmentProblem.Code.TEXT_SIZE, path);
                byte[] bytes = entryBytes(zip, entry, InputMaterial.MAX_TEXT_CHARS * 4L + 4);
                String text;
                try { text = decode(bytes); }
                catch (AttachmentProblem e) {
                    if (e.code == AttachmentProblem.Code.TEXT_SIZE) throw e;
                    notes.add(new Note(path, e.code)); skipped.put(new JSONObject().put("path", path).put("reason", e.code.name()));
                    continue;
                }
                textLength += text.length();
                if (textLength > InputMaterial.MAX_TEXT_CHARS) throw new AttachmentProblem(AttachmentProblem.Code.TEXT_SIZE, name);
                processed.put(new JSONObject().put("path", path).put("text", text));
                notes.add(new Note(path, null)); count++;
            }
            String text = count == 0 ? "" : new JSONObject().put("archive", name).put("processed_files", processed)
                    .put("skipped_files", skipped).put("total_files", total).toString();
            return new Result(text, notes, count != total, count, total);
        } catch (JSONException e) { throw new IOException(e); }
    }
    private static boolean word(String uri) {
        return "http://schemas.openxmlformats.org/wordprocessingml/2006/main".equals(uri)
                || "http://purl.oclc.org/ooxml/wordprocessingml/main".equals(uri);
    }
    private static void xml(byte[] bytes, DefaultHandler handler) throws IOException {
        // OOXML supports UTF-8 and UTF-16. Convert first so a DTD cannot hide behind encoding.
        String text = decodeXml(bytes);
        if (text.contains("<!DOCTYPE") || text.contains("<!ENTITY"))
            throw new AttachmentProblem(AttachmentProblem.Code.DOCX_STRUCTURE);
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance(); factory.setNamespaceAware(true);
            org.xml.sax.XMLReader reader = factory.newSAXParser().getXMLReader();
            reader.setEntityResolver((publicId, systemId) -> { throw new SAXException("External entities disabled"); });
            reader.setContentHandler(handler); reader.setErrorHandler(handler);
            reader.parse(new InputSource(new StringReader(text)));
        } catch (Exception e) {
            if (e.getCause() instanceof AttachmentProblem) throw (AttachmentProblem) e.getCause();
            throw new AttachmentProblem(AttachmentProblem.Code.DOCX_STRUCTURE);
        }
    }
    private static String decodeXml(byte[] bytes) throws AttachmentProblem {
        // XML markup itself can be larger than the extracted text limit.
        if (bytes.length > 4 * 1024 * 1024) throw new AttachmentProblem(AttachmentProblem.Code.PACKAGE_SIZE);
        int offset = 0;
        Charset charset = StandardCharsets.UTF_8;
        if (bytes.length >= 2 && (bytes[0] & 255) == 255 && (bytes[1] & 255) == 254) { charset = StandardCharsets.UTF_16LE; offset = 2; }
        else if (bytes.length >= 2 && (bytes[0] & 255) == 254 && (bytes[1] & 255) == 255) { charset = StandardCharsets.UTF_16BE; offset = 2; }
        try { return charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes, offset, bytes.length - offset)).toString().replaceFirst("^\\uFEFF", ""); }
        catch (CharacterCodingException e) { throw new AttachmentProblem(AttachmentProblem.Code.ENCODING); }
    }
    private static Result docx(File file, String name) throws IOException {
        try (ZipFile zip = checkedZip(file)) {
            ZipEntry relationships = zip.getEntry("_rels/.rels"), types = zip.getEntry("[Content_Types].xml");
            if (relationships == null || types == null) throw new AttachmentProblem(AttachmentProblem.Code.DOCX_STRUCTURE, name);
            final String[] main = {null};
            xml(entryBytes(zip, relationships, 1024 * 1024), new DefaultHandler() {
                @Override public void startElement(String uri, String local, String qName, Attributes attrs) throws SAXException {
                    if ("Relationship".equals(local)) {
                        String type = attrs.getValue("Type");
                        if (type != null && type.endsWith("/officeDocument")) {
                            String target = attrs.getValue("Target");
                            if (target == null || "External".equals(attrs.getValue("TargetMode"))) throw new SAXException("External document");
                            if (target.startsWith("/")) target = target.substring(1);
                            if (!safePath(target) || target.contains(":")) throw new SAXException("Invalid target");
                            main[0] = target;
                        }
                    }
                }
            });
            if (main[0] == null || zip.getEntry(main[0]) == null) throw new AttachmentProblem(AttachmentProblem.Code.DOCX_STRUCTURE, name);
            final boolean[] valid = {false};
            xml(entryBytes(zip, types, 1024 * 1024), new DefaultHandler() {
                @Override public void startElement(String uri, String local, String qName, Attributes attrs) {
                    if ("Override".equals(local) && ("/" + main[0]).equals(attrs.getValue("PartName"))
                            && "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml".equals(attrs.getValue("ContentType"))) valid[0] = true;
                }
            });
            if (!valid[0]) throw new AttachmentProblem(AttachmentProblem.Code.DOCX_STRUCTURE, name);
            StringBuilder text = new StringBuilder();
            final boolean[] drawing = {false};
            xml(entryBytes(zip, zip.getEntry(main[0]), 4 * 1024 * 1024), new DefaultHandler() {
                private boolean inText;
                private void append(String value) throws SAXException {
                    if (text.length() + value.length() > InputMaterial.MAX_TEXT_CHARS)
                        throw new SAXException(new AttachmentProblem(AttachmentProblem.Code.TEXT_SIZE, name));
                    text.append(value);
                }
                @Override public void startElement(String uri, String local, String qName, Attributes attrs) throws SAXException {
                    if (!word(uri)) return;
                    if ("t".equals(local)) inText = true;
                    if ("tab".equals(local)) append("\t");
                    if ("br".equals(local) || "cr".equals(local)) append("\n");
                    if ("drawing".equals(local) || "pict".equals(local)) drawing[0] = true;
                }
                @Override public void characters(char[] chars, int start, int length) throws SAXException {
                    if (inText) append(new String(chars, start, length));
                }
                @Override public void endElement(String uri, String local, String qName) throws SAXException {
                    if (!word(uri)) return;
                    if ("t".equals(local)) inText = false;
                    if ("p".equals(local) || "tr".equals(local)) append("\n");
                    if ("tc".equals(local)) append("\t");
                }
            });
            if (text.toString().trim().isEmpty()) throw new AttachmentProblem(AttachmentProblem.Code.NOT_TEXT, name);
            boolean partial = drawing[0];
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                String path = entries.nextElement().getName();
                if (path.startsWith("word/media/") || path.matches("word/(header|footer|footnotes|endnotes|comments).*\\.xml")) partial = true;
            }
            return new Result(text.toString(), Arrays.asList(new Note(main[0], null),
                    new Note(name, AttachmentProblem.Code.DOCX_SCOPE)), partial, 1, 1);
        }
    }
}
