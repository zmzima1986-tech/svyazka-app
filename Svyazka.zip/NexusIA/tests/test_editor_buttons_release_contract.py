"""Checks the actual Python editor source before Android compilation."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/svyazka/mobile/ui/NexusPythonWorkspace.kt'
GRADLE = ROOT / 'app/build.gradle'


class EditorButtonsReleaseContract(unittest.TestCase):
    def setUp(self):
        src = UI.read_text(encoding='utf-8')
        self.editor = src.split('private fun PythonProjectEditor(', 1)[1].split(
            'private fun PythonRunOutput(', 1)[0]
        self.screen = src.split('private fun PythonEditorTool(', 1)[1].split(
            'private fun PythonRunSettingsTool(', 1)[0]

    def test_clear_and_copy_below_editor(self):
        self.assertEqual(self.editor.count('Text(stringResource(R.string.editor_clear)'), 1)
        self.assertEqual(self.editor.count('Text(stringResource(R.string.action_copy)'), 1)
        self.assertIn('clipboard.setPrimaryClip(ClipData.newPlainText(', self.editor)
        self.assertNotIn('R.string.ws_undo', self.editor)
        self.assertNotIn('R.string.ws_redo', self.editor)

    def test_download_fits_one_line(self):
        self.assertEqual(self.editor.count('Text(stringResource(R.string.ws_download)'), 1)
        self.assertIn('Button(onClick = save, modifier = Modifier.fillMaxWidth()', self.editor)
        self.assertIn('maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)', self.editor)
        self.assertNotIn('R.string.action_save_file', self.editor)
        self.assertNotIn('R.string.action_save', self.editor)

    def test_editor_panel_has_no_scrolling(self):
        self.assertIn('Column(Modifier.fillMaxSize()', self.screen)
        self.assertIn('PythonProjectEditor(ui, save, Modifier.weight(1f))', self.screen)
        self.assertIn('Column(modifier.fillMaxSize()', self.editor)
        self.assertIn('modifier = Modifier.fillMaxWidth().weight(1f), enabled = isEditable', self.editor)
        self.assertIn('if (showSearchTools)', self.editor)
        main_panel = self.editor.split('if (showSearchTools)', 1)[0]
        self.assertNotIn('verticalScroll(', main_panel)
        self.assertNotIn('horizontalScroll(', main_panel)

    def test_gradle_refuses_stale_editor(self):
        gradle = GRADLE.read_text(encoding='utf-8')
        self.assertIn('verifyPythonEditorButtons', gradle)
        self.assertIn("tasks.named('preBuild')", gradle)
        self.assertIn('WRONG PYTHON EDITOR:', gradle)
        self.assertIn('Text(stringResource(R.string.action_copy),', gradle)
        self.assertIn('Text(stringResource(R.string.ws_download),', gradle)


if __name__ == '__main__':
    unittest.main()
