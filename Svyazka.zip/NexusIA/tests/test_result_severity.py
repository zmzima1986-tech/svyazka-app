"""Run the real pure-Java UI classifier and check its use by the Compose views."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'
UI = JAVA / 'ui'


class ResultSeverityTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which('javac') and shutil.which('java'), 'JDK not installed')
    def test_java_outcome_matrix(self):
        code = r'''import app.svyazka.mobile.ResultSeverity;
import static app.svyazka.mobile.ResultSeverity.*;
public class StatusChecks {
    static void expect(ResultSeverity actual, ResultSeverity expected) {
        if (actual != expected) throw new AssertionError(actual + " != " + expected);
    }
    static void count(int actual, int expected) {
        if (actual != expected) throw new AssertionError(actual + " != " + expected);
    }
    public static void main(String[] args) {
        expect(verification("RAN", true), SUCCESS);
        expect(verification("PASSED", true), SUCCESS);
        expect(verification("ERROR", true), ERROR);
        expect(verification("LIMITED", true), WARNING);
        expect(verification("STOPPED", true), WARNING);
        expect(verification("NONE", true), NEUTRAL);
        expect(verification("NONE", false), SUCCESS);
        expect(verification("CHECKING", true), NEUTRAL);
        expect(verification("REPAIRING", true), NEUTRAL);
        expect(execution(0, false), SUCCESS);
        expect(execution(0, true), ERROR);
        expect(execution(1, false), ERROR);
        expect(execution(null, false), WARNING);
        expect(execution(null, true), ERROR);
        expect(web("SYNTAX_CHECKED", false, false, false, true), SUCCESS);
        expect(web("SYNTAX_CHECKED", false, true, false, true), ERROR);
        expect(web("SYNTAX_ERROR", true, false, false, false), ERROR);
        expect(web("UNAVAILABLE", false, false, false, false), WARNING);
        expect(web("SYNTAX_CHECKED", false, false, false, false), WARNING);
        expect(web("SYNTAX_CHECKED", false, false, true, true), WARNING);
        String note = "Выполнено assert без ошибок: 10. Независимых контрольных примеров нет.";
        count(selfAssertCount("RAN", note), 10);
        count(selfAssertCount("ERROR", note), -1);
        count(selfAssertCount("RAN", "arbitrary text 10"), -1);
        count(selfAssertCount("RAN", ""), -1);
        count(selfAssertCount("RAN", null), -1);
        expect(executionNotice(0, false, 10, "Тесты: 10/10."), SUCCESS);
        expect(executionNotice(0, false, 0, "No independent tests"), WARNING);
        expect(executionNotice(0, false, 10, "Truncated. Тесты: 10/10."), WARNING);
        expect(executionNotice(0, true, 10, "Тесты: 9/10."), ERROR);
    }
}'''
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'StatusChecks.java'
            path.write_text(code, encoding='utf-8')
            subprocess.run(['javac', '-encoding', 'UTF-8', '-d', tmp,
                            str(JAVA / 'ResultSeverity.java'), str(path)], check=True)
            subprocess.run(['java', '-cp', tmp, 'StatusChecks'], check=True)

    def test_success_and_missing_independent_evidence_are_separate(self):
        shared = (UI / 'NexusStatus.kt').read_text(encoding='utf-8')
        self.assertIn('R.string.verify_self_asserts, count), ResultSeverity.SUCCESS', shared)
        self.assertIn('R.string.verify_no_independent), ResultSeverity.WARNING', shared)
        self.assertIn('ResultSeverity.selfAssertCount(check.status.name, check.diagnostic)', shared)
        logs = (UI / 'NexusDrawers.kt').read_text(encoding='utf-8')
        self.assertIn('VerificationDiagnostic(verification)', logs)
        self.assertNotIn('Text(verification.diagnostic, color = MaterialTheme.colorScheme.error)', logs)
        chat = (UI / 'NexusChat.kt').read_text(encoding='utf-8')
        self.assertIn('VerificationDiagnostic(check)', chat)

    def test_manual_and_web_status_use_shared_mapping(self):
        for name in ('NexusPythonWorkspace.kt', 'NexusLightDesign.kt', 'NexusPythonDialogs.kt'):
            self.assertIn('report.noticeSeverity()', (UI / name).read_text(encoding='utf-8'))
        self.assertIn('ResultSeverity.web(', (JAVA / 'MainActivity.java').read_text(encoding='utf-8'))
        self.assertIn('severity.drawable()', (UI / 'WebWorkspace.kt').read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main()
