package app.svyazka.mobile;

import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import java.io.IOException;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class PythonChatApplyTest {
    @Test public void verifiedBundleRequiresBothHashesAndRestoresEveryFile() throws Exception {
        PythonProjectStore files = new PythonProjectStore(ApplicationProvider.getApplicationContext(), true);
        long id = (System.nanoTime() & Long.MAX_VALUE) | 1;
        try {
            files.putText(id,"main.py","a");
            files.putText(id,"test_main.py","b");
            String before = PythonProjectStore.snapshotSha256(files.snapshotForChat(id));
            java.util.Map<String,String> next = new java.util.LinkedHashMap<>();
            next.put("main.py","aa");
            next.put("test_main.py","bb");
            java.util.Map<String,byte[]> bytes = new java.util.LinkedHashMap<>();
            for (java.util.Map.Entry<String,String> file : next.entrySet())
                bytes.put(file.getKey(),file.getValue().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            String after = PythonProjectStore.snapshotSha256(bytes);
            assertFalse(files.replaceCheckedProject(id,before,next,before));
            files.putText(id,"main.py","manual edit");
            assertFalse(files.replaceCheckedProject(id,before,next,after));
            assertEquals("manual edit",files.text(id,"main.py"));
            files.putText(id,"main.py","a");
            assertTrue(files.replaceCheckedProject(id,before,next,after));
            assertEquals("aa",files.text(id,"main.py"));
            assertEquals("bb",files.text(id,"test_main.py"));
            files.restorePrevious(id);
            assertEquals("a",files.text(id,"main.py"));
            assertEquals("b",files.text(id,"test_main.py"));
        } finally { files.deleteTask(id); }
    }

    @Test public void inputStatusSurvivesReportRestore() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        long id = (System.nanoTime() & Long.MAX_VALUE) | 1;
        PythonLastRunStore store = new PythonLastRunStore(context,true);
        try {
            store.save(id,new SandboxClient.Result("Name?", "", "local", 0, "stdin", "", "", null,null,"snapshot",null,true));
            SandboxClient.Result saved = new PythonLastRunStore(context,true).load(id);
            assertNotNull(saved);
            assertTrue(saved.inputRequired);
            NexusPythonReport shown = new NexusPythonReport(saved.engine,saved.stdout,saved.stderr,saved.status,
                    "",saved.exitCode,false,"[]","[]",saved.snapshotSha256,saved.inputRequired);
            assertNull(shown.exitCode);
            assertTrue(shown.inputRequired);
        } finally { store.deleteTask(id); }
    }

    @Test public void approvedEditStoresNewContentAndRestorablePreviousProject() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore project = new PythonProjectStore(context, true);
        long id = System.nanoTime() & Long.MAX_VALUE;
        if (id == 0) id = 1;
        project.putText(id, "main.py", "print('old')\n");
        project.putText(id, "data.txt", "keep me\n");
        project.replaceTextWithBackup(id, "main.py", "print('new')\n");
        assertEquals("print('new')\n", project.text(id, "main.py"));
        assertEquals("keep me\n", project.text(id, "data.txt"));
        assertTrue(project.hasPrevious(id));
        project.restorePrevious(id);
        assertEquals("print('old')\n", project.text(id, "main.py"));
        assertEquals("keep me\n", project.text(id, "data.txt"));
        project.deleteTask(id);
    }

    @Test public void backupAlsoRestoresProjectsWithNamedEntryOtherThanMain() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore project = new PythonProjectStore(context, true);
        long id = (System.nanoTime() & Long.MAX_VALUE) | 1;
        project.putText(id, "script.py", "print('before')");
        try {
            project.replaceTextWithBackup(id, "script.py", "print('after')");
            assertEquals("print('after')", project.text(id, "script.py"));
            project.restorePrevious(id);
            assertEquals("print('before')", project.text(id, "script.py"));
        } finally { project.deleteTask(id); }
    }

    @Test public void unknownFileDoesNotChangeProjectOrCreateBackup() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore project = new PythonProjectStore(context, true);
        long id = (System.nanoTime() & Long.MAX_VALUE) | 1;
        project.putText(id, "main.py", "print('safe')\n");
        try {
            project.replaceTextWithBackup(id, "src/main.py", "print('new')");
            fail("An absent file cannot be overwritten");
        } catch (IOException expected) {
            assertEquals("print('safe')\n", project.text(id, "main.py"));
            assertFalse(project.hasPrevious(id));
        } finally { project.deleteTask(id); }
    }
    @Test public void incompleteArchivePreservesBothProjectAndUndo() throws Exception {
        Context ctx = ApplicationProvider.getApplicationContext();
        PythonProjectStore project = new PythonProjectStore(ctx, true);
        long id = (System.nanoTime() & Long.MAX_VALUE) | 1;
        try {
            project.putText(id, "main.py", "first");
            project.replaceTextWithBackup(id, "main.py", "second");
            byte[] good = project.exportZip(id);
            byte[] incomplete = java.util.Arrays.copyOf(good, good.length - 1);
            assertThrows(IOException.class, () -> project.replaceZip(id, incomplete));
            assertEquals("second", project.text(id, "main.py"));
            project.restorePrevious(id);
            assertEquals("first", project.text(id, "main.py"));
        } finally { project.deleteTask(id); }
    }

    @Test public void interruptedBackupRenameRemainsRestorable() throws Exception {
        Context ctx = ApplicationProvider.getApplicationContext();
        PythonProjectStore project = new PythonProjectStore(ctx, true);
        long id = (System.nanoTime() & Long.MAX_VALUE) | 1;
        try {
            project.putText(id, "main.py", "old");
            project.replaceTextWithBackup(id, "main.py", "new");
            java.io.File base = new java.io.File(ctx.getFilesDir(), "python-projects/artifact-" + id + ".previous.zip");
            assertTrue(base.renameTo(new java.io.File(base.getPath() + ".bak")));
            assertTrue(project.hasPrevious(id));
            project.restorePrevious(id);
            assertEquals("old", project.text(id, "main.py"));
        } finally { project.deleteTask(id); }
    }
}
