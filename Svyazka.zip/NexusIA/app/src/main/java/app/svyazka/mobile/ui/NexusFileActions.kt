package app.svyazka.mobile.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import app.svyazka.mobile.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/** Files are read/written only after an explicit user action through Android SAF.
 * No storage permission, KeyVault access or changes to Java request execution are needed.
 */
private const val MAX_ATTACHED_BYTES = 72 * 1024
private const val MAX_TASK_CHARS = 90_000 // Safely below Workflow.TASK_LIMIT (100,000).

@Composable
fun rememberAttachFileAction(ui: NexusComposeUi): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val loaded = withContext(Dispatchers.IO) {
                    runCatching { readAttachment(context, uri) }
                }
                loaded.fold(onSuccess = { (name, content) ->
                    val fenceSize = maxOf(3, (Regex("`+").findAll(content).maxOfOrNull { it.value.length } ?: 0) + 1)
                    val fence = "`".repeat(fenceSize)
                    val attachment = "\n\n---\n" +
                        context.getString(R.string.file_attachment_label, name) +
                        "\n" + fence + "\n" + content + "\n" + fence
                    if (ui.draft.length + attachment.length > MAX_TASK_CHARS) {
                        Toast.makeText(context, R.string.file_too_large, Toast.LENGTH_LONG).show()
                    } else {
                        ui.draftChanged(ui.draft + attachment)
                        Toast.makeText(context, R.string.file_attached, Toast.LENGTH_SHORT).show()
                    }
                }, onFailure = {
                    Toast.makeText(context, R.string.file_read_error, Toast.LENGTH_LONG).show()
                })
            }
        }
    }
    return { launcher.launch(arrayOf("*/*")) }
}

private fun readAttachment(context: Context, uri: Uri): Pair<String, String> {
    val resolver = context.contentResolver
    var name = "attachment.txt"
    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0) name = cursor.getString(index) ?: name
        }
    }
    name = name.substringAfterLast('/').substringAfterLast('\\')
        .replace(Regex("[\r\n\t<>]"), "_").take(100).ifBlank { "attachment.txt" }
    val extension = name.substringAfterLast('.', "").lowercase(java.util.Locale.ROOT)
    val knownTextExtensions = setOf("txt", "md", "markdown", "py", "java", "kt", "kts",
        "js", "jsx", "ts", "tsx", "html", "htm", "css", "json", "xml", "yaml", "yml",
        "toml", "gradle", "properties", "sh", "bash", "sql", "c", "h", "cpp", "hpp",
        "cs", "go", "rs", "rb", "swift", "php", "dart", "log", "csv", "ini")
    val mime = resolver.getType(uri).orEmpty()
    if (extension !in knownTextExtensions && !mime.startsWith("text/") &&
        mime !in setOf("application/json", "application/xml", "application/javascript")) {
        throw IllegalArgumentException("Unsupported binary file")
    }
    val bytes = ByteArrayOutputStream()
    val chunk = ByteArray(8192)
    resolver.openInputStream(uri)?.use { stream ->
        while (true) {
            val read = stream.read(chunk)
            if (read < 0) break
            if (bytes.size() + read > MAX_ATTACHED_BYTES) throw IllegalArgumentException("File too large")
            bytes.write(chunk, 0, read)
        }
    } ?: throw IllegalArgumentException("Cannot open attachment")
    val decoder = Charsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)
    val text = try { decoder.decode(ByteBuffer.wrap(bytes.toByteArray())).toString().removePrefix("\uFEFF") }
        catch (_: CharacterCodingException) { throw IllegalArgumentException("Not UTF-8 text") }
    if (text.isEmpty() || text.any { it == '\u0000' || (it.code < 0x20 && it != '\n' && it != '\r' && it != '\t') }) {
        throw IllegalArgumentException("Not a text file")
    }
    return name to text
}

private data class SavePayload(val filename: String, val text: String)

@Composable
fun rememberSaveResultAction(answer: String): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<SavePayload?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val payload = pending
        pending = null
        if (uri != null && payload != null) {
            scope.launch {
                val saved = withContext(Dispatchers.IO) {
                    runCatching {
                        val output = context.contentResolver.openOutputStream(uri, "w")
                            ?: throw IllegalStateException("Cannot open output")
                        output.bufferedWriter(Charsets.UTF_8).use { it.write(payload.text) }
                    }.isSuccess
                }
                Toast.makeText(context, if (saved) R.string.file_saved else R.string.file_save_error,
                    if (saved) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show()
            }
        }
    }
    return {
        if (answer.isNotBlank()) {
            val payload = chooseSavePayload(answer)
            pending = payload
            launcher.launch(payload.filename)
        }
    }
}

/** A single fenced code block is exported as code; a multi-file answer stays intact as Markdown. */
private fun chooseSavePayload(answer: String): SavePayload {
    val fence = Regex("(?m)^\\s*```([a-zA-Z0-9_+.-]*)[^\\n]*\\n([\\s\\S]*?)^\\s*```\\s*$")
    val matches = fence.findAll(answer).toList()
    if (matches.isEmpty()) return SavePayload("result.txt", answer)
    if (matches.size > 1) return SavePayload("result.md", answer)
    val language = matches[0].groupValues[1].lowercase()
    val code = matches[0].groupValues[2].trimEnd('\n', '\r')
    if (code.isBlank()) return SavePayload("result.md", answer)
    val filename = when (language) {
        "python", "py" -> "code.py"
        "javascript", "js" -> "code.js"
        "typescript", "ts" -> "code.ts"
        "html" -> "index.html"
        "css" -> "style.css"
        "kotlin", "kt" -> "Main.kt"
        "java" -> "Main.java"
        "json" -> "data.json"
        "bash", "sh" -> "script.sh"
        "sql" -> "query.sql"
        else -> "result.txt"
    }
    return SavePayload(filename, code + "\n")
}
