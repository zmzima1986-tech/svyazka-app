import { loadPyodide } from './pyodide/pyodide.mjs';

const outputLimit = 24000;
const pythonRunner = `
import sys, traceback

def _run(source):
    namespace = {"__name__": "__main__", "__file__": "main.py"}
    try:
        exec(compile(source, "main.py", "exec"), namespace)
    except SystemExit as error:
        if error.code is None:
            return 0
        if isinstance(error.code, int):
            return error.code % 256
        print(error.code, file=sys.stderr)
        return 1
    except BaseException as error:
        traceback.print_exception(type(error), error, error.__traceback__.tb_next)
        return 1
    return 0

_run
`;

self.addEventListener('message', async (event) => {
    const port = event.ports[0];
    try {
        const python = await loadPyodide({
            jsglobals: Object.create(null),
            // Wheels are fetched only for explicit user-authorized package loading.
            packageBaseUrl: 'https://cdn.jsdelivr.net/pyodide/v314.0.8/full/',
        });
        let verifier;
        if (event.data?.verify === true) {
            const response = await fetch('./verify.py');
            if (!response.ok) throw new Error('Verifier unavailable');
            python.runPython(await response.text());
            verifier = python.globals.get('verify_request');
        }
        const engine = 'На телефоне · Python ' + python.runPython('import sys; sys.version.split()[0]');
        port.onmessage = ({ data }) => {
            if (verifier) {
                try {
                    port.postMessage({kind: 'execution_start'});
                    const notify = (stage, passed, total) => port.postMessage({kind: 'progress', progress: {stage, passed, total}});
                    const report = JSON.parse(verifier(JSON.stringify(data), notify));
                    port.postMessage({kind: 'verified', report});
                } catch (error) {
                    port.postMessage({kind: 'error', error: String(error).slice(0, 500)});
                } finally { verifier.destroy(); }
                return;
            }
            execute(python, data, port).catch((error) => port.postMessage({
                kind: 'error', error: 'Ошибка выполнения: ' + String(error).slice(0, 500),
            }));
        };
        port.postMessage({ kind: 'ready', engine });
    } catch (error) {
        port.postMessage({ kind: 'error', error: 'Ошибка запуска Python: ' + String(error).slice(0, 500) });
    }
}, { once: true });

async function execute(python, { code, stdin, allow_matplotlib }, port) {
    let stdout = '';
    let stderr = '';
    let truncated = false;
    let lastReport = 0;
    const outDecoder = new TextDecoder();
    const errDecoder = new TextDecoder();
    const lines = stdin === '' ? [] : stdin.replace(/\r\n/g, '\n').split('\n');
    if (lines.length && lines[lines.length - 1] === '' && stdin.endsWith('\n')) lines.pop();
    let line = 0;
    python.setStdin({ stdin: () => line < lines.length ? lines[line++] : null });

    function report() {
        const now = performance.now();
        if (now - lastReport < 200) return;
        lastReport = now;
        port.postMessage({ kind: 'output', stdout, stderr });
    }

    function append(value, buffer, decoder) {
        if (value.length >= outputLimit) {
            truncated = true;
            return value;
        }
        const text = value + decoder.decode(buffer, { stream: true });
        if (text.length > outputLimit) truncated = true;
        return text.slice(0, outputLimit);
    }

    python.setStdout({ write: (buffer) => {
        stdout = append(stdout, buffer, outDecoder);
        report();
        return buffer.length;
    } });
    python.setStderr({ write: (buffer) => {
        stderr = append(stderr, buffer, errDecoder);
        report();
        return buffer.length;
    } });

    let runner;
    let exit;
    try {
        if (allow_matplotlib === true) {
            // The package and dependencies are pinned by the bundled Pyodide lockfile.
            // This is requested only after explicit user consent in Android UI.
            await python.loadPackage('matplotlib');
            python.runPython("import matplotlib; matplotlib.use('Agg')");
        }
        // Signals that package loading has finished. The parent now enforces
        // an independent five-second limit on arbitrary Python execution.
        port.postMessage({ kind: 'execution_start' });
        runner = python.runPython(pythonRunner);
        exit = runner(code);
    } catch (error) {
        stderr = (stderr + '\n' + String(error)).slice(0, outputLimit);
        exit = 1;
    } finally {
        if (runner) runner.destroy();
    }
    const visual = captureVisual(python);
    if (!visual.html && /^\s*(?:<!doctype html|<html\b)/i.test(stdout)) {
        visual.html = stdout.slice(0, 24000);
    }
    port.postMessage({
        kind: 'done',
        stdout: (stdout + outDecoder.decode()).slice(0, outputLimit),
        stderr: (stderr + errDecoder.decode()).slice(0, outputLimit),
        code: exit,
        status: truncated ? 'Показано до 24 000 символов каждого потока.' : '',
        image_png: visual.image_png,
        html: visual.html,
    });
}

// Visual artifacts are separate from stdout/stderr and never executed as app instructions.
// This routine only reads files created inside the temporary WASM filesystem.
function captureVisual(python) {
    try {
        return JSON.parse(python.runPython(`
import sys, json, os, base64, io
visual_png = ''
visual_html = ''
try:
    if 'matplotlib.pyplot' in sys.modules:
        pyplot = sys.modules['matplotlib.pyplot']
        figures = pyplot.get_fignums()
        if figures:
            buffer = io.BytesIO()
            pyplot.figure(figures[-1]).savefig(buffer, format='png', dpi=90)
            png = buffer.getvalue()
            if len(png) <= 420_000:
                visual_png = base64.b64encode(png).decode('ascii')
except Exception:
    pass
try:
    for name in ('index.html', 'output.html'):
        if os.path.isfile(name) and os.stat(name).st_size <= 96_000:
            with open(name, 'r', encoding='utf-8', errors='replace') as visual_file:
                visual_html = visual_file.read(96_000)
            break
except Exception:
    pass
json.dumps({'image_png': visual_png, 'html': visual_html})
`));
    } catch (_) {
        return { image_png: '', html: '' };
    }
}
