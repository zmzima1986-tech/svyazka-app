package app.svyazka.mobile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.List;
import java.util.Collections;
import java.util.function.Consumer;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class ModelClient {
    static final int REQUEST_TIMEOUT_MS = 60_000;
    private static final String ROUTER_BASE = "https://openrouter.ai/api/v1/";
    private static final String GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
    private static final String GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/";
    private static final String CONTINUE_PROMPT = "Дополни оборванный ответ с места обрыва. "
            + "Верни только продолжение, сохрани пробелы и переносы для соединения частей. "
            + "Не повторяй начало, не открывай заново уже открытый блок кода.";
    private static final String NO_CONNECTION = "Связь с моделью прервалась. Можно продолжить с этого шага.";

    static final class Problem extends Exception {
        final int status;
        final RequestFailure failure;

        Problem(String message) { this(0, message); }

        Problem(int status, String message) {
            this(RequestFailure.of(status), message);
        }

        Problem(RequestFailure failure, String message) {
            super(message);
            this.failure = failure;
            this.status = failure.status;
        }
    }

    enum Finish { STOP, LENGTH, ERROR }

    static final class Reply {
        final String text;
        final Finish finish;
        final String problem;
        final int status;
        final RequestFailure failure;

        Reply(String text, Finish finish, String problem) {
            this(text, finish, problem, RequestFailure.of(0));
        }

        private Reply(String text, Finish finish, String problem, RequestFailure failure) {
            this.text = text;
            this.finish = finish;
            this.problem = problem;
            this.status = failure.status;
            this.failure = failure;
        }

        static Reply error(String text, String problem) {
            return error(text, problem, 0);
        }

        static Reply error(String text, String problem, int status) {
            return error(text, problem, RequestFailure.of(status));
        }

        static Reply error(String text, String problem, RequestFailure failure) {
            return new Reply(text, Finish.ERROR, problem, failure);
        }

        static Reply rejected(String text, String problem) {
            return error(text, problem, new RequestFailure(0, RequestFailure.Reason.RESPONSE_REJECTED, 0));
        }
    }

    static final class Cancellation {
        private volatile boolean cancelled;
        private volatile HttpURLConnection connection;

        synchronized void attach(HttpURLConnection current) throws IOException {
            if (cancelled || Thread.currentThread().isInterrupted()) {
                current.disconnect();
                throw new IOException("Request cancelled");
            }
            connection = current;
        }

        void cancel() {
            HttpURLConnection current;
            synchronized (this) {
                cancelled = true;
                current = connection;
            }
            if (current != null) current.disconnect();
        }

        synchronized void detach() { connection = null; }
    }

    private interface Decoder<T> {
        T read(BufferedReader source, String contentType) throws IOException, JSONException, Problem;
    }

    ModelCatalog models(Cancellation cancellation) throws IOException, JSONException, Problem {
        return request(ROUTER_BASE + "models", null, null, null, false, cancellation,
                (source, type) -> ModelCatalog.fromOpenRouter(readJson(source)));
    }

    boolean routerDailyQuotaExhausted(String key, Cancellation cancellation)
            throws IOException, JSONException, Problem {
        return request(ROUTER_BASE + "key", "Authorization", "Bearer " + key, null, false, cancellation,
                (source, type) -> routerDailyQuotaExhausted(readJson(source)));
    }

    static boolean routerDailyQuotaExhausted(JSONObject response) {
        JSONObject data = response.optJSONObject("data");
        JSONObject daily = data == null ? null : data.optJSONObject("free_model_daily_requests");
        return daily != null && daily.optInt("limit", 0) > 0 && daily.optInt("remaining", -1) == 0;
    }

    Reply complete(Workflow.Run run, ModelCatalog.Model model, String key,
                   Cancellation cancellation, Consumer<String> progress)
            throws IOException, JSONException, Problem {
        return complete(run, model, key, cancellation, progress, Collections.emptyList());
    }

    Reply complete(Workflow.Run run, ModelCatalog.Model model, String key,
                   Cancellation cancellation, Consumer<String> progress, List<InputMaterial.Image> images)
            throws IOException, JSONException, Problem {
        String missing = run.missingInput();
        if (!missing.isEmpty()) throw new Problem(missing);
        if (model.provider == Workflow.Provider.GEMINI) {
            return request(GEMINI_URL + model.id + ":streamGenerateContent?alt=sse", "x-goog-api-key", key,
                    materialBody(run, model, images), true, cancellation,
                    (source, type) -> type.contains("application/json") ? parseGemini(readJson(source))
                            : parseGeminiStream(source, progress));
        }
        boolean groq = model.provider == Workflow.Provider.GROQ;
        if (!groq && !ModelCatalog.isFreeId(model.id)) {
            throw new Problem("Выбери бесплатную модель OpenRouter.");
        }
        String url = groq ? GROQ_URL : ROUTER_BASE + "chat/completions";
        JSONObject body = materialBody(run, model, images);
        return request(url, "Authorization", "Bearer " + key, body, true, cancellation,
                (source, type) -> type.contains("application/json") ? parseRouterJson(readJson(source))
                        : parseRouterStream(source, progress));
    }

    static JSONObject materialBody(Workflow.Run run, ModelCatalog.Model model, List<InputMaterial.Image> images)
            throws JSONException, AttachmentProblem, Problem {
        InputMaterial.validate(run, model, images);
        JSONObject body = model.provider == Workflow.Provider.GEMINI ? geminiBody(run, model)
                : model.provider == Workflow.Provider.GROQ ? groqBody(run, model) : routerBody(run, model);
        if (!images.isEmpty()) {
            JSONArray content = new JSONArray().put(new JSONObject().put("type", "text").put("text", run.prompt()));
            for (InputMaterial.Image image : images) {
                content.put(new JSONObject().put("type", "text").put("text", "Attached image: " + image.ref.name));
                content.put(new JSONObject().put("type", "image_url").put("image_url", new JSONObject()
                        .put("url", "data:" + image.ref.mime + ";base64," + image.base64)));
            }
            body.getJSONArray("messages").getJSONObject(1).put("content", content);
            long room = model.context - 1024L - InputMaterial.utf8(run.instructions())
                    - InputMaterial.utf8(run.prompt()) - InputMaterial.imageTokens(run.materials);
            if (run.draftMode == Workflow.DraftMode.CONTINUE) room -= InputMaterial.utf8(run.draft.text);
            if (room < 512L) throw new Problem("Изображения и текст превышают доступный контекст модели. "
                    + "Исходные материалы сохранены без усечения.");
            body.put("max_tokens", Math.min(body.getInt("max_tokens"), room));
        }
        if (!run.materials.isEmpty() && InputMaterial.utf8(body.toString()) > InputMaterial.MAX_REQUEST_BYTES)
            throw new AttachmentProblem(AttachmentProblem.Code.HTTP_SIZE);
        return body;
    }

    static JSONObject routerBody(Workflow.Run run, ModelCatalog.Model model) throws JSONException, Problem {
        return chatBody(run, model, false);
    }

    static JSONObject groqBody(Workflow.Run run, ModelCatalog.Model model) throws JSONException, Problem {
        return chatBody(run, model, true);
    }

    private static JSONObject chatBody(Workflow.Run run, ModelCatalog.Model model, boolean groq)
            throws JSONException, Problem {
        String rules = run.instructions();
        String prompt = run.prompt();
        String previous = precedingPart(run, model, rules, prompt);
        JSONArray messages = new JSONArray().put(message("system", rules)).put(message("user", prompt));
        if (!previous.isEmpty()) {
            messages.put(message("assistant", previous)).put(message("user", CONTINUE_PROMPT));
        }
        JSONObject body = new JSONObject().put("model", model.id).put("stream", true)
                .put("messages", messages);
        int outputBudget = budget(run, model, rules, prompt, previous);
        if (groq) {
            return body.put("max_completion_tokens", Math.min(4096, outputBudget))
                    .put("reasoning_effort", "low");
        }
        JSONObject priceLimit = new JSONObject().put("prompt", 0).put("completion", 0).put("request", 0);
        body.put("max_tokens", outputBudget).put("provider", new JSONObject().put("max_price", priceLimit));
        if (model.reasoning) {
            JSONObject reasoning = new JSONObject().put("exclude", true);
            if (ModelCatalog.NEMOTRON.id.equals(model.id)) reasoning.put("effort", "medium");
            body.put("reasoning", reasoning);
        }
        return body;
    }

    private static JSONObject geminiBody(Workflow.Run run, ModelCatalog.Model model) throws JSONException, Problem {
        String rules = run.instructions();
        String prompt = run.prompt();
        String previous = precedingPart(run, model, rules, prompt);
        JSONArray contents = new JSONArray().put(geminiContent("user", prompt));
        if (!previous.isEmpty()) {
            contents.put(geminiContent("model", previous)).put(geminiContent("user", CONTINUE_PROMPT));
        }
        return new JSONObject().put("systemInstruction", geminiContent(null, rules))
                .put("contents", contents).put("generationConfig",
                        new JSONObject().put("maxOutputTokens", budget(run, model, rules, prompt, previous)));
    }

    private static String precedingPart(Workflow.Run run, ModelCatalog.Model model,
                                        String instructions, String prompt) {
        if (run.draftMode != Workflow.DraftMode.CONTINUE) return "";
        // Never silently cut the start of a Python file during continuation.
        // The budget preflight rejects a too-large request with an explicit reason.
        return run.draft.text;
    }

    private static int budget(Workflow.Run run, ModelCatalog.Model model, String instructions,
                              String prompt, String previous) throws Problem {
        int budget = Math.min(run.nextStep().outputBudget, model.maxOutput > 0 ? model.maxOutput : 32_768);
        if (model.context == 0) return budget;
        // UTF-8 size is a conservative estimate; the provider counts the exact tokens.
        long room = model.context - 1024L - bytes(instructions) - bytes(prompt) - bytes(previous);
        if (!previous.isEmpty()) room -= bytes(CONTINUE_PROMPT);
        if (room < 512L) throw new Problem("Запрос слишком велик для контекста выбранной модели. "
                + "Текст и сохранённый черновик не сокращены автоматически. "
                + "Выбери модель с большим окном контекста или сократи исходные материалы.");
        return (int) Math.min(budget, room);
    }

    private static int bytes(String text) {
        return text.getBytes(StandardCharsets.UTF_8).length;
    }

    private static JSONObject geminiContent(String role, String text) throws JSONException {
        JSONObject content = new JSONObject()
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
        if (role != null) content.put("role", role);
        return content;
    }

    private static JSONObject message(String role, String content) throws JSONException {
        return new JSONObject().put("role", role).put("content", content);
    }

    static Reply parseGemini(JSONObject reply) throws JSONException {
        StringBuilder answer = new StringBuilder();
        Reply result = readGeminiEvent(reply, answer);
        return result != null ? result
                : Reply.error(answer.toString(), "Gemini завершил передачу без статуса ответа.");
    }

    static Reply parseGeminiStream(BufferedReader source, Consumer<String> progress) {
        return parseStream(source, progress, ModelClient::readGeminiEvent);
    }

    private static Reply readGeminiEvent(JSONObject reply, StringBuilder answer) throws JSONException {
        JSONObject error = reply.optJSONObject("error");
        if (error != null) return serviceError(answer.toString(), error.optInt("code", 0), error);
        JSONArray candidates = reply.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) {
            JSONObject feedback = reply.optJSONObject("promptFeedback");
            String blockReason = feedback == null ? "" : value(feedback, "blockReason");
            if (!blockReason.isEmpty() && !"BLOCK_REASON_UNSPECIFIED".equals(blockReason)) {
                return Reply.rejected(answer.toString(), "Gemini отклонил запрос. Попробуй уточнить задачу.");
            }
            return null;
        }
        JSONObject candidate = candidates.getJSONObject(0);
        String finish = candidate.optString("finishReason");
        JSONObject content = candidate.optJSONObject("content");
        JSONArray parts = content == null ? null : content.optJSONArray("parts");
        if (parts != null) {
            for (int i = 0; i < parts.length(); i++) {
                JSONObject part = parts.getJSONObject(i);
                if (!part.optBoolean("thought")) answer.append(value(part, "text"));
            }
        }
        if ("MAX_TOKENS".equals(finish)) return new Reply(answer.toString(), Finish.LENGTH, "");
        if ("STOP".equals(finish)) return new Reply(answer.toString(), Finish.STOP, "");
        if (finish.isEmpty() || "FINISH_REASON_UNSPECIFIED".equals(finish)) return null;
        return Reply.rejected(answer.toString(), "Gemini остановил ответ. Попробуй уточнить задачу.");
    }

    private static Reply parseRouterJson(JSONObject reply) {
        return readRouterEvent(reply, new StringBuilder(), "message");
    }

    static Reply parseRouterStream(BufferedReader source) {
        return parseRouterStream(source, text -> {});
    }

    static Reply parseRouterStream(BufferedReader source, Consumer<String> progress) {
        return parseStream(source, progress, (event, answer) -> readRouterEvent(event, answer, "delta"));
    }

    private interface StreamEvent {
        Reply decode(JSONObject event, StringBuilder answer) throws JSONException;
    }

    private static Reply parseStream(BufferedReader source, Consumer<String> progress, StreamEvent decoder) {
        long reported = 0;
        int reportedLength = 0;
        StringBuilder answer = new StringBuilder();
        StringBuilder event = new StringBuilder();
        try {
            String line;
            while ((line = source.readLine()) != null) {
                if (line.startsWith("data:")) {
                    if (event.length() > 0) event.append('\n');
                    int start = line.startsWith("data: ") ? 6 : 5;
                    event.append(line.substring(start));
                } else if (line.isEmpty() && event.length() > 0) {
                    Reply complete = parseEvent(event, answer, decoder);
                    long now = System.nanoTime();
                    if (answer.length() != reportedLength
                            && (reportedLength == 0 || complete != null || now - reported > 750_000_000L)) {
                        progress.accept(answer.toString());
                        reported = now;
                        reportedLength = answer.length();
                    }
                    if (complete != null) return complete;
                    event.setLength(0);
                }
            }
            if (event.length() > 0) {
                Reply complete = parseEvent(event, answer, decoder);
                if (complete != null) return complete;
            }
        } catch (IOException e) {
            return Reply.error(answer.toString(), NO_CONNECTION);
        } catch (JSONException e) {
            return Reply.error(answer.toString(), "Не удалось прочитать часть ответа модели.");
        }
        return Reply.error(answer.toString(), "Провайдер прервал ответ до завершения.");
    }

    private static Reply parseEvent(StringBuilder event, StringBuilder answer, StreamEvent decoder)
            throws JSONException {
        String data = event.toString().trim();
        if (data.isEmpty()) return null;
        if ("[DONE]".equals(data)) {
            return Reply.error(answer.toString(), "Провайдер закончил передачу без статуса ответа.");
        }
        return decoder.decode(new JSONObject(data), answer);
    }

    private static Reply readRouterEvent(JSONObject event, StringBuilder answer, String contentField) {
        JSONArray choices = event.optJSONArray("choices");
        JSONObject choice = choices == null ? null : choices.optJSONObject(0);
        if (choice != null) {
            JSONObject delta = choice.optJSONObject(contentField);
            if (delta != null) answer.append(value(delta, "content"));
        }
        JSONObject error = event.optJSONObject("error");
        if (error == null && choice != null) error = choice.optJSONObject("error");
        if (error != null) {
            int status = error.optInt("code", 0);
            if (status == 0) {
                String code = error.optString("code");
                String type = error.optString("type");
                if ("rate_limit_exceeded".equals(code) || "rate_limit_error".equals(type)) status = 429;
                else if ("service_unavailable".equals(code)) status = 503;
            }
            return serviceError(answer.toString(), status, error);
        }
        String reason = choice == null ? "" : value(choice, "finish_reason");
        switch (reason) {
            case "stop": return new Reply(answer.toString(), Finish.STOP, "");
            case "length": return new Reply(answer.toString(), Finish.LENGTH, "");
            case "content_filter":
                return Reply.rejected("", "Провайдер остановил ответ. Попробуй уточнить задачу.");
            case "error": return Reply.error(answer.toString(), summary(0, null));
            case "":
                return contentField.equals("delta") ? null
                        : Reply.error(answer.toString(), "Провайдер не сообщил, завершён ли ответ.");
            default: return Reply.error(answer.toString(), "Модель не завершила текстовый ответ.");
        }
    }

    private static Reply serviceError(String partial, int status, JSONObject error) {
        RequestFailure failure = RequestFailure.read(status, error, null, System.currentTimeMillis());
        return Reply.error(partial, explain(status, error), failure);
    }

    private static String value(JSONObject item, String field) {
        return item.isNull(field) ? "" : item.optString(field, "");
    }

    private static String explain(int status, JSONObject error) {
        String summary = summary(status, error);
        String header = status > 0 ? summary + "\nКод провайдера: " + status : summary;
        if (error == null) return header;
        String details = error.optString("message", "");
        JSONObject metadata = error.optJSONObject("metadata");
        if (metadata != null) {
            details += "\n" + metadata.optString("provider_name", "")
                    + "\n" + metadata.optString("raw", "");
        }
        details = details.replaceAll("(?:sk-|gsk_)[A-Za-z0-9_-]+", "[ключ скрыт]");
        if (details.length() > 3000) details = details.substring(0, 3000);
        return header + "\n" + details.trim();
    }

    private static String summary(int status, JSONObject error) {
        RequestFailure.Reason reason = RequestFailure.classify(status, error);
        if (reason == RequestFailure.Reason.TOKEN_RATE_LIMIT)
            return "Превышен лимит токенов в минуту (TPM) у провайдера. "
                    + "Это не размер контекстного окна. Подожди сброса лимита или выбери другой сервис.";
        if (reason == RequestFailure.Reason.CONTEXT_LIMIT)
            return "Задача и полученные ответы не помещаются в контекст модели. Выбери модель с большим контекстом.";
        if (status == 413)
            return "Провайдер отклонил размер запроса (HTTP 413), но точный тип ограничения не указан. "
                    + "Проверь детали отказа и лимиты сервиса.";
        switch (status) {
            case 400: return "Провайдер отклонил запрос. Проверь выбранную модель.";
            case 401:
            case 403: return "Проверь ключ и доступ к модели в настройках провайдера.";
            case 402: return "Провайдер отклонил запрос по условиям тарифа.";
            case 404: return "Провайдер не нашёл доступный маршрут для этой модели. Можно выбрать другую.";
            case 408:
            case 504: return "Модель не успела ответить. Можно продолжить с этого шага.";
            case 429: return "Достигнут лимит запросов провайдера. Попробуй продолжить позже.";
            default: return "Сервис модели недоступен. Можно продолжить с этого шага.";
        }
    }

    private static JSONObject readJson(BufferedReader source) throws IOException, JSONException {
        StringBuilder text = new StringBuilder();
        char[] buffer = new char[8192];
        int count;
        while ((count = source.read(buffer)) != -1) text.append(buffer, 0, count);
        return new JSONObject(text.toString());
    }

    private static JSONObject readError(HttpURLConnection connection) {
        InputStream stream = connection.getErrorStream();
        if (stream == null) return null;
        try (BufferedReader input = reader(stream)) {
            return readJson(input).optJSONObject("error");
        } catch (IOException | JSONException e) {
            return null;
        }
    }

    private static BufferedReader reader(InputStream source) {
        return new BufferedReader(new InputStreamReader(source, StandardCharsets.UTF_8));
    }

    private static <T> T request(String url, String authHeader, String authValue, JSONObject body,
                                 boolean stream, Cancellation cancellation, Decoder<T> decoder)
            throws IOException, JSONException, Problem {
        HttpsURLConnection connection = (HttpsURLConnection) new URL(url).openConnection();
        try {
            cancellation.attach(connection);
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(20_000);
            connection.setReadTimeout(body == null ? 20_000 : REQUEST_TIMEOUT_MS);
            connection.setRequestProperty("Accept", stream ? "text/event-stream" : "application/json");
            if (authHeader != null) connection.setRequestProperty(authHeader, authValue);
            if (body != null) {
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setDoOutput(true);
                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(payload.length);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(payload);
                }
            }
            int status = connection.getResponseCode();
            if (status != 200) {
                String retry = connection.getHeaderField("Retry-After");
                JSONObject error = readError(connection);
                RequestFailure failure = RequestFailure.read(status, error, retry, System.currentTimeMillis());
                String detail = explain(status, error);
                if (retry != null) detail += "\nRetry-After: " + retry;
                if (authValue != null) detail = detail.replace(authValue, "[ключ скрыт]")
                        .replace(authValue.replace("Bearer ", ""), "[ключ скрыт]");
                throw new Problem(failure, detail);
            }
            try (BufferedReader source = reader(connection.getInputStream())) {
                String contentType = connection.getContentType();
                return decoder.read(source, contentType == null ? "" : contentType);
            }
        } finally {
            cancellation.detach();
            connection.disconnect();
        }
    }
}
