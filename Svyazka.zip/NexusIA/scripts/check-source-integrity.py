#!/usr/bin/env python3
"""Strict source inventory. Compare first; never rewrite the reference implicitly."""
import argparse
import hashlib
import os
from pathlib import Path, PurePosixPath
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = 'docs/SOURCE_CURRENT_SHA256.txt'
# Ignore only local/generated directories and sensitive configuration, not source assets.
IGNORED_DIRS = {'.git', '.gradle', '.idea', 'build', '__pycache__', '.pytest_cache'}
IGNORED_NAMES = {'local.properties', 'signing.pass', '.env'}
IGNORED_SUFFIXES = {'.pyc', '.jks', '.keystore', '.p12', '.apk', '.aab'}


def excluded(relative):
    path = PurePosixPath(relative)
    return (relative == MANIFEST or any(part in IGNORED_DIRS for part in path.parts)
            or path.name in IGNORED_NAMES or path.name.startswith('.env.')
            or path.suffix.lower() in IGNORED_SUFFIXES)


def inventory(root):
    result = {}
    for folder, dirs, files in os.walk(root, followlinks=False):
        base = Path(folder)
        dirs[:] = sorted(name for name in dirs if name not in IGNORED_DIRS)
        for name in dirs + sorted(files):
            path = base / name
            relative = path.relative_to(root).as_posix()
            if excluded(relative):
                continue
            if path.is_symlink():
                raise ValueError(f'Symlink not allowed: {relative}')
            if path.is_dir():
                continue
            if not path.is_file() or any(ch in relative for ch in '\r\n\\'):
                raise ValueError(f'Unsupported file or name: {relative}')
            with path.open('rb') as stream:
                digest = hashlib.sha256()
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(chunk)
            result[relative] = digest.hexdigest()
    return dict(sorted(result.items()))


def parse_manifest(text):
    result = {}
    for line in text.splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        if not match:
            raise ValueError(f'Malformed manifest line: {line!r}')
        digest, relative = match.groups()
        path = PurePosixPath(relative)
        if (path.is_absolute() or path.as_posix() != relative or '..' in path.parts
                or not path.parts or '\\' in relative or excluded(relative) or relative in result):
            raise ValueError(f'Unsafe, excluded or duplicate manifest path: {relative}')
        result[relative] = digest
    if not result:
        raise ValueError('Empty manifest')
    return result


def differences(expected, actual):
    return ([name for name in sorted(expected.keys() - actual.keys())],
            [name for name in sorted(actual.keys() - expected.keys())],
            [name for name in sorted(expected.keys() & actual.keys()) if expected[name] != actual[name]])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inventory', action='store_true', help='Print a candidate reference; do not write files.')
    args = parser.parse_args()
    try:
        current = inventory(ROOT)
        if args.inventory:
            for name, digest in current.items():
                print(f'{digest}  {name}')
            return 0
        reference = ROOT / MANIFEST
        if reference.is_symlink():
            raise ValueError('Reference manifest must not be a symlink')
        expected = parse_manifest(reference.read_text(encoding='utf-8'))
        missing, extra, changed = differences(expected, current)
        for label, names in [('MISSING', missing), ('EXTRA', extra), ('CHANGED', changed)]:
            for name in names:
                print(f'{label}: {name}')
        print(f'Source integrity: {"FAIL" if missing or extra or changed else "PASS"}; '
              f'expected={len(expected)}, actual={len(current)}, missing={len(missing)}, '
              f'extra={len(extra)}, changed={len(changed)}')
        return int(bool(missing or extra or changed))
    except (OSError, ValueError) as error:
        print(f'Source integrity: ERROR: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
