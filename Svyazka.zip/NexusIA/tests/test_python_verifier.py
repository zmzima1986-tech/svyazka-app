"""Run the same verifier asset as the APK on controlled fixtures."""

import importlib.util
import json
import unittest
from pathlib import Path

source = Path(__file__).resolve().parents[1] / "app/src/main/assets/sandbox/verify.py"
spec = importlib.util.spec_from_file_location("nexus_verify", source)
grader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grader)


class VerificationTests(unittest.TestCase):
    def verify(self, code, status, **inputs):
        if "cases" in inputs:
            inputs["specs"] = [json.dumps(inputs.pop("cases"))]
        result = json.loads(grader.verify_request(json.dumps(dict(code=code, **inputs))))
        self.assertEqual(status, result["status"], result)
        if status == "PASSED":
            self.assertTrue(
                result["ran"] and result["syntax"] and result["total"] == result["passed"] > 0
            )
        return result

    def test_no_oracle(self):
        self.verify("print('PASSED')", "RAN")
        self.verify("def f(x): return -999", "RAN")

    def test_parser_and_compiler(self):
        for code in ["def f(:", "return 1"]:
            self.assertFalse(self.verify(code, "ERROR")["syntax"])

    def test_dependencies_and_environment(self):
        for mod in ["neo4j", "fastapi", "numpy", "os", "js", "socket"]:
            self.assertIn(mod, self.verify("import " + mod, "LIMITED")["diagnostic"])

    def test_missing_input(self):
        self.verify("print(input())", "LIMITED")

    def test_stdio_boundaries(self):
        self.verify(
            "print(int(input())**2)",
            "PASSED",
            cases=[dict(stdin="0\n", stdout="0"), dict(stdin="-2\n", stdout="4\n")],
        )

    def test_printing_success_does_not_certify(self):
        self.verify("print('PASSED')", "ERROR", cases=[dict(stdin="", stdout="4")])

    def test_case_isolation(self):
        self.verify(
            "a=[]\ndef f(x):\n a.append(x)\n return len(a)",
            "PASSED",
            examples="assert f(0) == 1\nassert f(1) == 1",
        )

    def test_contract(self):
        code = "def factorial(n):\n total=1\n for i in range(1,n+1): total*=i\n return total"
        self.assertEqual(5, self.verify(code, "PASSED", examples="nexus-contract: factorial")["total"])
        self.verify(code.replace("total=1", "total=0"), "ERROR", examples="nexus-contract: factorial")
        self.verify("from math import gcd", "PASSED", examples="nexus-contract: gcd")

    def test_wrong_value_includes_real_input(self):
        r = self.verify("def f(x): return x", "ERROR", examples="assert f(1) == 1\nassert f(0) == 2")
        self.assertEqual((1, 2), (r["passed"], r["total"]))
        self.assertIn("Тест 2", r["diagnostic"])
        self.assertIn("получено 0", r["diagnostic"])

    def test_boolean_is_not_number(self):
        self.verify("def f(): return False", "ERROR", cases=[dict(function="f", args=[], expected=0)])
        self.verify("def f(): return [True]", "ERROR", cases=[dict(function="f", args=[], expected=[1])])

    def test_actual_arguments_remain_available(self):
        r = self.verify(
            "def f(vals):\n vals.clear()\n return 0",
            "ERROR",
            cases=[dict(function="f", args=[[1, 2]], expected=3)],
        )
        self.assertIn("[1, 2]", r["diagnostic"])

    def test_imported_module_with_cli(self):
        self.verify(
            "def f(x): return x\nif __name__ == '__main__': print(input())",
            "PASSED",
            examples=">>> f(3)\n3",
        )

    def test_text_attachment(self):
        self.verify(
            "import json\nwith open('data.json') as f:\n print(sum(json.loads(f.read())))",
            "PASSED",
            files={"data.json": "[1,-1]"},
            cases=[dict(stdin="", stdout="0")],
        )
        self.verify("open('data.json','w')", "LIMITED", files={"data.json": "original"})

    def test_runtime_error(self):
        self.assertIn("ZeroDivisionError", self.verify("x=1/0", "ERROR")["diagnostic"])

    def test_placeholders(self):
        for code in ["# comments", "def f():\n pass", "def f():\n ..."]:
            self.assertIn("Incomplete", self.verify(code, "ERROR")["diagnostic"])

    def test_limits(self):
        self.verify("print('x'*20000)", "LIMITED")
        self.verify("x=1\n" * 17000, "LIMITED")
        self.verify("print(0)", "LIMITED", cases=[dict(stdin="", stdout="0")] * 25)

    def test_invalid_test_fixture(self):
        for item in ["{broken", "[]", '[{"bad":true}]']:
            self.verify("print(0)", "LIMITED", specs=[item])
        self.verify("print(0)", "LIMITED", examples="assert f(x) == 0")

    def test_plain_io(self):
        self.verify(
            "print(abs(int(input())))", "PASSED", examples="Input: -3\nOutput: 3\nВвод: 0\nВывод: 0"
        )

    def test_ambiguous_modules(self):
        self.assertTrue(
            self.verify("", "LIMITED", syntax_only=["while True: pass", "x=2"], reason="ambiguous")[
                "syntax"
            ]
        )
        r = self.verify("", "LIMITED", syntax_only=["x=1", "x="], reason="ambiguous")
        self.assertFalse(r["syntax"])
        self.assertIn("Блок 2", r["diagnostic"])

    def test_model_self_test_insufficient(self):
        self.verify("assert True\nprint('all passed')", "RAN")


if __name__ == "__main__":
    unittest.main(verbosity=2)
