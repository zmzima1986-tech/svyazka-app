package app.svyazka.mobile;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
import org.json.JSONException;

final class WorkspaceStore {
    static final String TASK = "draft";
    static final String RUN = "run";
    static final String RESULTS = "results_visible";
    static final String HISTORY = "attempt_log";

    interface Disk {
        boolean write(Map<String, Object> changes);
    }

    static final class State {
        final String task;
        final Workflow.Run run;
        final boolean resultsVisible;
        final String history;

        State(String task, Workflow.Run run, boolean resultsVisible, String history) {
            this.task = task;
            this.run = run;
            this.resultsVisible = run != null && resultsVisible;
            this.history = history;
        }

        Map<String, Object> changes() throws JSONException {
            Map<String, Object> values = new LinkedHashMap<>();
            values.put(TASK, task.isEmpty() ? null : task);
            values.put(RUN, run == null ? null : run.toJson().toString());
            values.put(RESULTS, resultsVisible ? true : null);
            values.put(HISTORY, history.isEmpty() ? null : history);
            return values;
        }
    }

    private final Executor writer;
    private final Disk disk;
    private State current;
    private long owner;
    private long revision;

    // The writer serializes writes in submission order.
    WorkspaceStore(State initial, Executor writer, Disk disk) {
        current = initial;
        this.writer = writer;
        this.disk = disk;
    }

    synchronized long attach() { return ++owner; }

    synchronized State current() { return current; }

    synchronized void save(long session, State value, Consumer<Boolean> done) {
        if (session != owner) return;
        enqueue(value, done, false);
    }

    synchronized void clear(long session, Consumer<Boolean> done) {
        if (session != owner) return;
        State before = current;
        long clearingRevision = revision + 1;
        enqueue(new State("", null, false, ""), saved -> {
            if (!saved) {
                synchronized (this) {
                    // Keep the last known workspace when the disk rejected deletion.
                    if (revision == clearingRevision) current = before;
                }
            }
            done.accept(saved);
        }, true);
    }

    private void enqueue(State value, Consumer<Boolean> done, boolean clear) {
        current = value;
        long sequence = ++revision;
        writer.execute(() -> {
            synchronized (this) {
                if (!clear && sequence != revision) return;
            }
            boolean saved;
            try {
                saved = disk.write(value.changes());
            } catch (Exception e) {
                saved = false;
            }
            done.accept(saved);
        });
    }
}
