package app.svyazka.mobile;

import org.junit.Test;
import static org.junit.Assert.*;

/** Pure checks: never require a provider call or a real device. */
public final class PythonAutoFeedbackTest {
    private static String longText(int length) {
        char[] chars = new char[length];
        java.util.Arrays.fill(chars, 'x');
        return new String(chars);
    }
    @Test public void actualInterpreterFailureProducesOneBoundedDiagnostic() {
        String prompt = PythonAutoFeedback.prompt("Исправь программу", "main.py",
                "raise ValueError('broken')\n", 1,
                "Traceback (most recent call last):\nValueError: broken", "");
        assertTrue(PythonAutoFeedback.isFeedback(prompt));
        assertTrue(prompt.contains("Код завершения Python: 1"));
        assertTrue(prompt.contains("ValueError: broken"));
        assertTrue(prompt.contains("raise ValueError"));
        assertEquals("Исправь программу", TaskHistory.forRepair(prompt));
    }

    @Test public void successAndUnconfirmedRunNeverSendError() {
        assertEquals("", PythonAutoFeedback.prompt("Измени код", "main.py", "print(1)",
                0, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Измени код", "main.py", "print(1)",
                null, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Измени код", "main.py", "print(1)",
                1, "", ""));
    }

    @Test public void environmentLimitIsNotAnAIFix() {
        for (String error : new String[] { "ModuleNotFoundError: numpy",
                "PermissionError: denied", "network is unreachable", "timeout" }) {
            assertEquals(error, "", PythonAutoFeedback.prompt("Исправь код", "main.py",
                    "print(1)", 1, error, ""));
        }
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "main.py",
                "print(1)", 1, "ValueError: bad", "Time limit exceeded"));
    }

    @Test public void neverPassUnknownPathOrTruncatedCode() {
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "unknown.js",
                "print(1)", 1, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "../main.py",
                "print(1)", 1, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "main.py",
                longText(16001), 1, "ValueError", ""));
        assertEquals("", PythonAutoFeedback.prompt("Исправь код", "main.py",
                "print(1)", 1, longText(5001), ""));
    }

    @Test public void preSaveVerificationErrorAlsoReachesAIWithoutFakeExitCode() {
        String prompt = PythonAutoFeedback.verificationPrompt("Измени программу", "main.py",
                "print(unknown)\n", "NameError: name 'unknown' is not defined (строка 1)");
        assertTrue(PythonAutoFeedback.isFeedback(prompt));
        assertTrue(prompt.contains("Ошибка локальной проверки"));
        assertFalse(prompt.contains("Код завершения Python: 1"));
        assertEquals("Измени программу", TaskHistory.forRepair(prompt));
        assertFalse(PythonAutoStage.requested(prompt));
    }

    @Test public void preSaveUnsupportedDependencyDoesNotTriggerModel() {
        assertEquals("", PythonAutoFeedback.verificationPrompt("Измени программу", "main.py",
                "import lost_package", "ModuleNotFoundError: No module named lost_package"));
    }

    @Test public void errorAnswerNeverAutomaticallyEditsProject() {
        String prompt = PythonAutoFeedback.prompt("Исправь код", "main.py",
                "print(unknown)\n", 1, "NameError: unknown", "");
        assertFalse(PythonAutoStage.requested(prompt));
        assertEquals("", PythonAutoFeedback.prompt(prompt, "main.py",
                "print(unknown)", 1, "NameError: unknown", ""));
    }
}
