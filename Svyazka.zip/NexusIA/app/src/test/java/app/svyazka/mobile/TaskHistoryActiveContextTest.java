package app.svyazka.mobile;

import static org.junit.Assert.*;
import org.junit.Test;

/** Offline proof: only explicit newer stdout contracts override historical ones. */
public class TaskHistoryActiveContextTest {
    @Test public void newExpectedOutputReplacesOldWithoutDeletingOtherRequirements() {
        String older = "Измени main.py и сохрани функцию add.\nОжидаемый вывод: «СТАРЫЙ».";
        String updated = TaskHistory.followUp(older, "```python\nprint('СТАРЫЙ')\n```",
                "Ожидаемый вывод: «НОВЫЙ».\nОставь функцию add.");
        String requirements = TaskHistory.forRepair(updated);
        assertTrue(requirements.contains("сохрани функцию add"));
        assertTrue(requirements.contains("Оставь функцию add"));
        assertTrue(requirements.contains("Ожидаемый вывод: «НОВЫЙ»"));
        assertFalse(requirements.contains("Ожидаемый вывод: «СТАРЫЙ»"));
        assertEquals("Ожидаемый вывод: «НОВЫЙ».\nОставь функцию add.",
                TaskHistory.currentUserTestRequest(updated));
        assertTrue(updated.contains("print('СТАРЫЙ')")); // Historical code remains available.
    }

    @Test public void ordinaryAdditiveChangePreservesPriorRequirements() {
        String updated = TaskHistory.followUp(
                "Измени main.py.\nОжидаемый вывод: «СТАРЫЙ».", "```python\nprint('СТАРЫЙ')\n```",
                "Добавь функцию add(15, 25) и выведи сумму.");
        assertTrue(TaskHistory.forRepair(updated).contains("Ожидаемый вывод: «СТАРЫЙ»"));
        assertTrue(TaskHistory.forRepair(updated).contains("Добавь функцию add"));
    }

    @Test public void newerContractAlsoSupersedesAnEarlierFollowUp() {
        String first = TaskHistory.followUp("Создай main.py.\nОжидаемый вывод: СТАРЫЙ",
                "```python\nprint('СТАРЫЙ')\n```", "Ожидаемый вывод: ВТОРОЙ");
        String second = TaskHistory.followUp(first, "```python\nprint('ВТОРОЙ')\n```",
                "Ожидаемый вывод: ТРЕТИЙ");
        String requirements = TaskHistory.forRepair(second);
        assertTrue(requirements.contains("Ожидаемый вывод: ТРЕТИЙ"));
        assertFalse(requirements.contains("Ожидаемый вывод: ВТОРОЙ"));
        assertFalse(requirements.contains("Ожидаемый вывод: СТАРЫЙ"));
    }

    @Test public void ambiguousNewContractsDoNotRemoveOlderRequirements() {
        String updated = TaskHistory.followUp("Ожидаемый вывод: ПРЕЖНИЙ", "print('ПРЕЖНИЙ')",
                "Ожидаемый вывод: НОВЫЙ\nОжидаемый вывод: ЕЩЁ ОДИН");
        assertTrue(TaskHistory.forRepair(updated).contains("Ожидаемый вывод: ПРЕЖНИЙ"));
    }

    @Test public void exampleCodeAndDifferentFilesRemainUntouched() {
        String older = "Сохрани utils.py.\n```text\nОжидаемый вывод: ИЗ ПРИМЕРА\n```"
                + "\nОжидаемый вывод: УСТАРЕВШИЙ";
        String updated = TaskHistory.followUp(older, "```python\nprint('from file')\n```",
                "Ожидаемый вывод: ТЕКУЩИЙ");
        String requirements = TaskHistory.forRepair(updated);
        assertTrue(requirements.contains("Сохрани utils.py"));
        assertTrue(requirements.contains("Ожидаемый вывод: ИЗ ПРИМЕРА"));
        assertFalse(requirements.contains("Ожидаемый вывод: УСТАРЕВШИЙ"));
    }

    @Test public void expectationInsideNewCodeSampleDoesNotOverrideHistory() {
        String updated = TaskHistory.followUp("Ожидаемый вывод: «СТАРЫЙ»",
                "print('СТАРЫЙ')", "Покажи пример:\n```text\nОжидаемый вывод: НОВЫЙ\n```");
        assertTrue(TaskHistory.forRepair(updated).contains("Ожидаемый вывод: «СТАРЫЙ»"));
    }

    @Test public void blankContractCannotSilentlyOverrideExistingExpectation() {
        String updated = TaskHistory.followUp("Ожидаемый вывод: «СТАРЫЙ»",
                "print('СТАРЫЙ')", "Ожидаемый вывод:   ");
        assertTrue(TaskHistory.forRepair(updated).contains("Ожидаемый вывод: «СТАРЫЙ»"));
    }

    @Test public void englishContractOverridesEarlierRussianContract() {
        String updated = TaskHistory.followUp("Ожидаемый вывод: «А»", "print('А')",
                "Expected output: B");
        assertFalse(TaskHistory.forRepair(updated).contains("Ожидаемый вывод: «А»"));
        assertTrue(TaskHistory.forRepair(updated).contains("Expected output: B"));
    }
}
