#!/usr/bin/env python3
"""
Simple console calculator supporting:
    + addition
    - subtraction
    * multiplication
    / division (with protection against division by zero)

Functions are pure and unit‑tested with `assert`.
Running the script without arguments starts an interactive prompt.
"""

from typing import Union

Number = Union[int, float]


def add(a: Number, b: Number) -> float:
    """Return a + b."""
    return float(a + b)


def sub(a: Number, b: Number) -> float:
    """Return a - b."""
    return float(a - b)


def mul(a: Number, b: Number) -> float:
    """Return a * b."""
    return float(a * b)


def div(a: Number, b: Number) -> float:
    """Return a / b. Raises ValueError if b is zero."""
    if b == 0:
        raise ValueError("Division by zero is not allowed.")
    return float(a / b)   # ← исправлен оператор деления


# ---------- automatic tests ----------
def _run_tests() -> None:
    # addition
    assert add(2, 3) == 5.0
    assert add(-1, 5) == 4.0
    # subtraction
    assert sub(10, 4) == 6.0
    assert sub(0, 5) == -5.0
    # multiplication
    assert mul(3, 7) == 21.0
    assert mul(-2, -8) == 16.0
    # division
    assert div(20, 5) == 4.0
    assert div(-9, 3) == -3.0

    # division by zero must raise
    try:
        div(1, 0)
        assert False, "Expected ValueError for division by zero"
    except ValueError:
        pass

    # mixed type handling
    assert add(2, 3.5) == 5.5
    assert mul(2.0, 3) == 6.0

    print("All tests passed.")


# ---------- interactive console ----------
def _interactive() -> None:
    menu = """Simple Calculator
Select operation:
  1) addition (+)
  2) subtraction (-)
  3) multiplication (*)
  4) division (/)
  q) quit
Enter choice: """
    while True:
        try:
            choice = input(menu).strip().lower()
        except EOFError:
            # No interactive input available – exit gracefully
            print("\nNo input available. Exiting interactive mode.")
            break

        if choice == "q":
            print("Goodbye.")
            break
        if choice not in {"1", "2", "3", "4"}:
            print("Invalid choice, try again.\n")
            continue

        try:
            a = float(input("Enter first number: ").strip())
            b = float(input("Enter second number: ").strip())
        except ValueError:
            print("Invalid numeric input, try again.\n")
            continue
        except EOFError:
            print("\nNo input available. Exiting interactive mode.")
            break

        try:
            if choice == "1":
                result = add(a, b)
                op = '+'
            elif choice == "2":
                result = sub(a, b)
                op = '-'
            elif choice == "3":
                result = mul(a, b)
                op = '*'
            else:  # choice == "4"
                result = div(a, b)
                op = '/'
            print(f"{a} {op} {b} = {result}\n")
        except ValueError as e:
            print(f"Error: {e}\n")


if __name__ == "__main__":
    # Run unit tests first; they raise AssertionError on failure.
    _run_tests()
    # Start interactive mode (will exit cleanly if no stdin).
    _interactive()
