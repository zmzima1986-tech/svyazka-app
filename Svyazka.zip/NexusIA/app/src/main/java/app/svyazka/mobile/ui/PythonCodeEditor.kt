package app.svyazka.mobile.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Python editor drawn natively in Compose. No network or WebView is required. */
@Composable
internal fun PythonCodeEditor(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    minLines: Int = 1,
    label: String
) {
    val colors = MaterialTheme.colorScheme
    val dark = colors.surface.luminance() < 0.5f
    val palette = remember(dark) { PythonSyntaxColors(dark) }
    val syntax = remember(palette) { PythonSyntaxTransformation(palette) }
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    val fontSize = 13.sp
    val lineHeight = 19.sp
    val textStyle = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = fontSize,
        lineHeight = lineHeight,
        color = colors.onSurface
    )
    val lineStarts = remember(value.text) {
        buildList {
            add(0)
            value.text.forEachIndexed { i, ch -> if (ch == '\n') add(i + 1) }
        }
    }
    val currentLine = value.text.take(value.selection.start.coerceIn(0, value.text.length))
        .count { it == '\n' }
    val gutterWidth = with(density) { (lineStarts.size.toString().length * 9 + 25).dp }
    var textLayout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val corner = RoundedCornerShape(5.dp)

    BoxWithConstraints(
        modifier.clip(corner)
            .background(colors.surface.copy(alpha = 0.48f))
            .border(1.dp, colors.outline.copy(alpha = 0.55f), corner)
    ) {
        val minContentHeight = (maxHeight - 29.dp).coerceAtLeast(1.dp)
        val gutterHeight = with(density) {
            maxOf(textLayout?.size?.height?.toDp() ?: 0.dp, minContentHeight)
        }
        val activeBackground = if (dark) Color(0xFF2B3D57).copy(alpha = .55f)
            else Color(0xFFDEEAF8).copy(alpha = .70f)
        val gutterText = if (dark) Color(0xFF9AA8BD) else Color(0xFF788495)
        val textSizePx = with(density) { fontSize.toPx() }

        Row(Modifier.fillMaxSize().padding(top = 19.dp, bottom = 8.dp)
            .verticalScroll(scroll)) {
            Canvas(Modifier.width(gutterWidth).height(gutterHeight)) {
                val layout = textLayout?.takeIf { it.layoutInput.text.text == value.text }
                    ?: return@Canvas
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textSize = textSizePx
                    typeface = Typeface.MONOSPACE
                    textAlign = Paint.Align.RIGHT
                }
                val firstVisible = scroll.value - textSizePx
                val lastVisible = scroll.value + scroll.viewportSize + textSizePx
                for ((line, start) in lineStarts.withIndex()) {
                    val visualLine = layout.getLineForOffset(start.coerceIn(0, value.text.length))
                    val baseline = layout.getLineBaseline(visualLine)
                    if (baseline < firstVisible || baseline > lastVisible) continue
                    paint.color = (if (line == currentLine) colors.primary else gutterText).toArgb()
                    drawContext.canvas.nativeCanvas.drawText(
                        (line + 1).toString(), size.width - 9.dp.toPx(), baseline, paint
                    )
                }
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f).heightIn(min = minContentHeight)
                    .padding(end = 7.dp)
                    .drawBehind {
                        val layout = textLayout?.takeIf { it.layoutInput.text.text == value.text }
                            ?: return@drawBehind
                        val offset = value.selection.start.coerceIn(0, value.text.length)
                        val visualLine = layout.getLineForOffset(offset)
                        val top = layout.getLineTop(visualLine)
                        val bottom = layout.getLineBottom(visualLine)
                        drawRect(activeBackground,
                            topLeft = Offset(0f, top),
                            size = Size(size.width, (bottom - top).coerceAtLeast(0f)))
                    },
                textStyle = textStyle,
                minLines = minLines,
                visualTransformation = syntax,
                onTextLayout = { textLayout = it },
                enabled = enabled,
                cursorBrush = SolidColor(colors.primary)
            )
        }
        // The small field label stays fixed while only the code and line numbers scroll.
        Text(label,
            modifier = Modifier.padding(start = gutterWidth + 2.dp, top = 2.dp),
            color = colors.primary,
            style = MaterialTheme.typography.labelSmall)
    }
}

/** Add the previous indentation after Enter; indent one extra level after ':'. */
internal fun pythonAutoIndent(before: TextFieldValue, after: TextFieldValue): TextFieldValue {
    val point = before.selection.start
    if (before.selection.start != before.selection.end ||
        after.text.length != before.text.length + 1 ||
        point !in 0..before.text.length ||
        after.text.getOrNull(point) != '\n' ||
        after.text != before.text.substring(0, point) + "\n" + before.text.substring(point)
    ) return after

    val start = if (point == 0) 0 else before.text.lastIndexOf('\n', point - 1) + 1
    val previous = before.text.substring(start, point)
    val whitespace = previous.takeWhile { it == ' ' || it == '\t' }
    val extra = if (previous.trimEnd().endsWith(":")) {
        if (whitespace.contains('\t')) "\t" else "    "
    } else ""
    val indent = whitespace + extra
    if (indent.isEmpty()) return after
    val newPosition = point + 1 + indent.length
    return after.copy(
        text = after.text.substring(0, point + 1) + indent + after.text.substring(point + 1),
        selection = androidx.compose.ui.text.TextRange(newPosition)
    )
}

private class PythonSyntaxColors(dark: Boolean) {
    val keyword = if (dark) Color(0xFFC792EA) else Color(0xFF7C3AED)
    val definition = if (dark) Color(0xFF82AAFF) else Color(0xFF1D4ED8)
    val string = if (dark) Color(0xFFC3E88D) else Color(0xFF9A5B00)
    val comment = if (dark) Color(0xFF94B68A) else Color(0xFF228044)
    val number = if (dark) Color(0xFFF78C6C) else Color(0xFFBA4C09)
    val builtin = if (dark) Color(0xFF89DDFF) else Color(0xFF087F9E)
    val decorator = if (dark) Color(0xFFFFCB6B) else Color(0xFF9C5700)
}

/** Formatting only: text, offsets, selection and execution source remain unchanged. */
private class PythonSyntaxTransformation(private val color: PythonSyntaxColors) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val src = text.text
        val result = AnnotatedString.Builder(text)
        var position = 0
        var definitionNext = false
        while (position < src.length) {
            val c = src[position]
            when {
                c == '#' -> {
                    val begin = position
                    while (position < src.length && src[position] != '\n') position++
                    result.addStyle(SpanStyle(color = color.comment), begin, position)
                }
                c == '\'' || c == '"' -> {
                    val begin = position
                    val triple = position + 2 < src.length &&
                        src[position + 1] == c && src[position + 2] == c
                    position += if (triple) 3 else 1
                    while (position < src.length) {
                        if (src[position] == '\\') {
                            position = (position + 2).coerceAtMost(src.length)
                        } else if (triple && position + 2 < src.length &&
                            src[position] == c && src[position + 1] == c && src[position + 2] == c) {
                            position += 3
                            break
                        } else if (!triple && src[position] == c) {
                            position++
                            break
                        } else position++
                    }
                    result.addStyle(SpanStyle(color = color.string), begin, position)
                }
                c == '@' && src.substring(src.lastIndexOf('\n', position - 1) + 1, position).isBlank() -> {
                    val begin = position++
                    while (position < src.length &&
                        (src[position].isLetterOrDigit() || src[position] == '_' || src[position] == '.')) position++
                    result.addStyle(SpanStyle(color = color.decorator), begin, position)
                }
                c.isDigit() && (position == 0 || !pythonIdentPart(src[position - 1])) -> {
                    val begin = position++
                    while (position < src.length &&
                        (src[position].isLetterOrDigit() || src[position] == '_' || src[position] == '.')) position++
                    result.addStyle(SpanStyle(color = color.number), begin, position)
                }
                pythonIdentStart(c) -> {
                    val begin = position++
                    while (position < src.length && pythonIdentPart(src[position])) position++
                    val word = src.substring(begin, position)
                    val styled = when {
                        definitionNext -> color.definition
                        word in PYTHON_KEYWORDS -> color.keyword
                        word in PYTHON_BUILTINS -> color.builtin
                        src.indexOfFirstNonSpace(position) == '(' -> color.definition
                        else -> null
                    }
                    if (styled != null) result.addStyle(SpanStyle(color = styled), begin, position)
                    definitionNext = word == "def" || word == "class"
                }
                c == '\n' || c == ':' -> {
                    definitionNext = false
                    position++
                }
                else -> position++
            }
        }
        return TransformedText(result.toAnnotatedString(), OffsetMapping.Identity)
    }
}

private fun pythonIdentStart(c: Char) = c == '_' || c.isLetter()
private fun pythonIdentPart(c: Char) = pythonIdentStart(c) || c.isDigit()
private fun String.indexOfFirstNonSpace(from: Int): Char? {
    var i = from
    while (i < length && (this[i] == ' ' || this[i] == '\t')) i++
    return getOrNull(i)
}

private val PYTHON_KEYWORDS = setOf(
    "False", "None", "True", "and", "as", "assert", "async", "await", "break", "case",
    "class", "continue", "def", "del", "elif", "else", "except", "finally", "for",
    "from", "global", "if", "import", "in", "is", "lambda", "match", "nonlocal", "not",
    "or", "pass", "raise", "return", "try", "while", "with", "yield"
)
private val PYTHON_BUILTINS = setOf(
    "abs", "all", "any", "bool", "bytes", "callable", "chr", "dict", "dir", "divmod",
    "enumerate", "filter", "float", "format", "frozenset", "getattr", "hasattr", "hash",
    "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter", "len",
    "list", "map", "max", "min", "next", "object", "oct", "open", "ord", "pow", "print",
    "property", "range", "repr", "reversed", "round", "set", "setattr", "slice",
    "sorted", "str", "sum", "super", "tuple", "type", "vars", "zip"
)
