package app.svyazka.mobile;

import androidx.activity.ComponentActivity;
import androidx.core.view.OneShotPreDrawListener;
import androidx.core.view.WindowCompat;
import app.svyazka.mobile.ui.NexusComposeUi;
import app.svyazka.mobile.ui.AttachmentMessages;
import app.svyazka.mobile.attachments.AttachmentStore;
import android.content.Context;
import android.app.UiModeManager;
import android.content.res.Configuration;
import java.util.Locale;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.Consumer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MainActivity extends ComponentActivity {
    private static final int BG = 0xff0e1520;
    private static final int SURFACE = 0xff172233;
    private static final int BORDER = 0xff2b3a4c;
    private static final int FG = 0xfff1f5fc;
    private static final int MUTED = 0xffa9b9ce;
    private static final int ACCENT = 0xff8ce5dc;
    private static final int ACCENT_INK = 0xff10232a;
    private static final int ACCENT_DARK = 0xff203a42;
    private static final int WARNING = 0xffffcb9b;
    private static final int DANGER = 0xffff6e72;
    private static final int EXPORT_REQUEST = 71;
    private static final String ACTIVE_TASK = TaskRepository.ACTIVE_ID;
    private static final String ACTIVE_ARTIFACT = "active_python_artifact_id";
    private static final int ANSWER_PREVIEW = 3500;
    private static final long CATALOG_TTL = 6 * 60 * 60 * 1000L;
    private static final String GROQ_RESERVE = "groq_reserve";
    private static final long CHECKPOINT_INTERVAL = 2_500;
    private static WorkspaceStore sharedStore;

    // A cancelled HTTP call may keep its thread blocked briefly; retries must not queue behind it.
    private final ExecutorService worker = RequestExecutor.create();
    private NexusComposeUi nexusUi;
    private NexusLaunchView launchView;
    private View coveredChat;
    private int chatAccessibility;
    private final Runnable finishLaunch = this::dismissLaunch;
    private final Runnable openInitialChat = () -> {
        if (nexusUi == null && !isFinishing() && !isDestroyed()) restoreWorkspaceAndOpenChat();
    };
    private final ExecutorService cancellationWorker = Executors.newFixedThreadPool(2);
    private final ExecutorService catalogWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService sandboxWorker = Executors.newSingleThreadExecutor();
    private final ModelClient client = new ModelClient();
    private final ModelPool.Cooldowns cooldowns = new ModelPool.Cooldowns();
    private final SandboxClient sandboxClient = new SandboxClient();
    private final List<Consumer<String>> catalogListeners = new ArrayList<>();
    private SharedPreferences data;
    private TaskRepository repository;
    private long activeTaskId;
    private long activeArtifactId;
    private PythonArtifactRepository artifactRepository;
    private boolean workExpanded;
    private boolean historyVisible;
    private boolean historyReturnResults;
    private WorkspaceStore store;
    private long storeSession;
    private String taskDraft;
    private Workflow.Mode selectedMode;
    private ModelCatalog.Model quickModel;
    private String attemptHistory;
    private boolean clearing;
    private boolean checkpointPending;
    private CredentialStore vault;
    private ModelCatalog catalog;
    private long catalogTime;
    private ModelClient.Cancellation catalogRequest;
    private List<Workflow.Stage> stages;
    private Workflow.Run run;
    private boolean resultsVisible;
    private boolean active;
    private StagePool stagePool;
    private Attempt attempt;
    private SandboxJob sandboxJob;
    private LocalSandbox automaticPython;
    private long verificationGeneration;
    private ScrollView scroll;
    private LinearLayout content;
    private EditText taskInput;
    private final android.os.Handler progressHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable saveDraft = this::persistRun;
    private final Runnable checkpoint = this::persistRun;
    private TextView liveText;
    private TextView liveStatus;
    private SandboxClient.Result latestVisual;
    private Workflow.Run lastPythonRun;
    private int lastPythonStep;
    private String lastPythonCode = "";
    private String lastPythonStdin = "";
    private String lastPythonDiagnostic = "";

    private static final class StagePool {
        final List<ModelCatalog.Model> models;
        final EnumMap<Workflow.Provider, String> keys;
        final List<String> failures = new ArrayList<>();
        final EnumSet<Workflow.Provider> blockedProviders = EnumSet.noneOf(Workflow.Provider.class);
        int next, dispatched;
        boolean quotaChecked;
        boolean catalogChecked;

        StagePool(List<ModelCatalog.Model> models, EnumMap<Workflow.Provider, String> keys) {
            this.models = models;
            this.keys = keys;
        }

    }

    private static final class Attempt {
        final Workflow.Run input;
        final ModelClient.Cancellation cancellation = new ModelClient.Cancellation();
        final long started = android.os.SystemClock.elapsedRealtime();
        volatile String received = "";
        int checkpointLength;
        boolean timedOut;
        Future<?> future;
        Runnable deadline;

        Attempt(Workflow.Run input) { this.input = input; }
    }

    private static final class SandboxJob {
        final ModelClient.Cancellation cancellation = new ModelClient.Cancellation();
        final AlertDialog progress;
        PythonExecutor local;
        Future<?> future;

        SandboxJob(AlertDialog progress) { this.progress = progress; }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_NexusIA);
        super.onCreate(savedInstanceState);
        data = getSharedPreferences("workspace", MODE_PRIVATE);
        cooldowns.restore(data.getString("route_retry_times","{}"), System.currentTimeMillis());
        // Android 12+ uses the persisted application night mode before Activity
        // creation when drawing its native splash. Migrate existing preferences
        // here, then keep the platform choice updated whenever the user changes it.
        syncPlatformSplashTheme(data.getString("ui_theme", "system"));
        // Android's launch window must use the saved app preference, not the
        // device's light/dark setting once the Activity context is available.
        final boolean launchDark = isUserDarkTheme(getResources().getConfiguration(), nexusThemeChoice());
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                launchDark ? Color.BLACK : Color.WHITE));
        if (Build.VERSION.SDK_INT >= 31) {
            getSplashScreen().setOnExitAnimationListener(android.window.SplashScreenView::remove);
        }
        if (savedInstanceState == null && isTaskRoot()
                && (getIntent().getFlags() & Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) == 0) {
            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
            launchView = new NexusLaunchView(this);
            setContentView(launchView);
            // Decor installation applies theme defaults. Set the transparent bar
            // afterwards so its light contrast layer cannot cover the wave.
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= 28) getWindow().setNavigationBarDividerColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
            OneShotPreDrawListener.add(launchView, () -> progressHandler.post(openInitialChat));
        } else {
            restoreWorkspaceAndOpenChat();
            if (savedInstanceState != null) nexusUi.restoreNavigation(savedInstanceState);
        }
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        if (nexusUi != null) nexusUi.saveNavigation(state);
    }

    public void attachChatContent(View chat) {
        final NexusLaunchView cover = launchView;
        if (cover == null) {
            setContentView(chat);
            return;
        }
        ViewGroup host = findViewById(android.R.id.content);
        coveredChat = chat;
        chatAccessibility = chat.getImportantForAccessibility();
        chat.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
        host.addView(chat, 0, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // Posting from pre-draw lets this chat frame finish before the two-second hold starts.
        OneShotPreDrawListener.add(chat, () -> chat.post(() -> {
            if (launchView == cover) progressHandler.postDelayed(finishLaunch, 2000L);
        }));
    }

    private void dismissLaunch() {
        progressHandler.removeCallbacks(finishLaunch);
        if (launchView == null) return;
        ViewGroup parent = (ViewGroup) launchView.getParent();
        if (parent != null) parent.removeView(launchView);
        launchView = null;
        if (coveredChat != null) {
            coveredChat.setImportantForAccessibility(chatAccessibility);
            coveredChat = null;
        }
    }

    private void leaveLaunch() {
        if (launchView == null) return;
        dismissLaunch();
        // Home can be pressed before even the first frame of a fresh task.
        if (nexusUi == null) {
            progressHandler.removeCallbacks(openInitialChat);
            progressHandler.post(openInitialChat);
        }
    }

    private void restoreWorkspaceAndOpenChat() {
        vault = new KeyVault(getSharedPreferences("credentials", MODE_PRIVATE));
        catalog = restoreCatalog();
        catalogTime = data.getLong("catalog_time", 0);
        stages = restoreStages();
        selectedMode = "QUICK".equals(data.getString("selected_mode", "")) ? Workflow.Mode.QUICK : Workflow.Mode.TEAM;
        quickModel = restoreQuickModel();
        repository = new TaskRepository(this);
        repository.migrateLegacy(data);
        artifactRepository = new PythonArtifactRepository(this);
        migratePythonArtifacts();
        artifactRepository.recoverSavedFiles(pythonProjects());
        long preferred = repository.activeId();
        if (preferred == 0) preferred = data.getLong(ACTIVE_TASK, 0);
        TaskRepository.Entry restored = repository.load(preferred);
        if (restored == null) restored = repository.load(repository.legacyId());
        if (restored == null) {
            long created = repository.create("");
            restored = repository.load(created);
        }
        if (sharedStore == null) {
            WorkspaceStore.State previous = new WorkspaceStore.State(restored.id, restored.task,
                    restoreStoredRun(restored.runJson), restored.resultsVisible, restored.attemptLog);
            SharedPreferences preferences = data;
            TaskRepository taskDatabase = repository;
            sharedStore = new WorkspaceStore(previous, Executors.newSingleThreadExecutor(), changes -> {
                if (!taskDatabase.save(changes)) return false;
                // Legacy mirror is best-effort; the SQLite row is authoritative.
                writeWorkspace(preferences, changes);
                return true;
            });
        }
        store = sharedStore;
        storeSession = store.attach();
        WorkspaceStore.State previous = store.current();
        activeTaskId = previous.taskId;
        activeArtifactId = artifactRepository.forChat(activeTaskId);
        if (activeArtifactId == 0) {
            long savedProject = data.getLong(ACTIVE_ARTIFACT, 0);
            if (artifactRepository.exists(savedProject)) activeArtifactId = savedProject;
        }
        repository.select(activeTaskId);
        data.edit().putLong(ACTIVE_TASK, activeTaskId).commit();
        run = interrupted(previous.run);
        if (run != null) AttachmentStore.get(this).consume(activeTaskId, run.materials);
        taskDraft = previous.task;
        attemptHistory = previous.history;
        resultsVisible = previous.resultsVisible;
        if (resultsVisible) renderRun(false);
        else renderTask();
        refreshModels(false, problem -> {});
    }

    private ModelCatalog restoreCatalog() {
        String saved = data.getString("catalog", "");
        if (!saved.isEmpty()) {
            try {
                return ModelCatalog.fromCache(new JSONArray(saved));
            } catch (JSONException ignored) {
                // A missing or invalid cache can be rebuilt from the public catalog.
            }
        }
        return ModelCatalog.starter();
    }

    private void refreshModels(boolean force, Consumer<String> listener) {
        long age = System.currentTimeMillis() - catalogTime;
        if (!force && catalog.refreshed && age >= 0 && age < CATALOG_TTL) {
            listener.accept("");
            return;
        }
        catalogListeners.add(listener);
        if (catalogRequest != null) return;
        ModelClient.Cancellation stop = new ModelClient.Cancellation();
        catalogRequest = stop;
        catalogWorker.submit(() -> {
            try {
                ModelCatalog updated = client.models(stop);
                String cached = updated.cacheData().toString();
                runOnUiThread(() -> finishCatalog(updated, cached));
            } catch (IOException | JSONException | ModelClient.Problem e) {
                runOnUiThread(() -> finishCatalog(null, null));
            }
        });
    }

    private void finishCatalog(ModelCatalog updated, String cached) {
        if (isDestroyed()) return;
        catalogRequest = null;
        String problem = "";
        if (updated == null) {
            problem = "Каталог не обновился. Показан последний доступный список.";
        } else {
            catalog = updated;
            catalogTime = System.currentTimeMillis();
            data.edit().putString("catalog", cached).putLong("catalog_time", catalogTime).apply();
        }
        List<Consumer<String>> listeners = new ArrayList<>(catalogListeners);
        catalogListeners.clear();
        for (Consumer<String> listener : listeners) listener.accept(problem);
        if (nexusUi != null) nexusUi.render(nexusSnapshot(), null);
    }

    private List<Workflow.Stage> restoreStages() {
        try {
            return Workflow.stagesFromJson(new JSONArray(data.getString("stages", "[]")));
        } catch (JSONException e) {
            return Workflow.defaultStages();
        }
    }

    private ModelCatalog.Model restoreQuickModel() {
        String id = data.getString("quick_model", "");
        if (!id.isEmpty()) {
            try {
                return ModelCatalog.storedModel(id, data.getString("quick_model_label", ""));
            } catch (JSONException ignored) {
                // The architect remains the default when the saved selection is invalid.
            }
        }
        return null;
    }

    private ModelCatalog.Model quickModel() {
        return quickModel == null ? stages.get(0).model : quickModel;
    }

    private Workflow.Run restoreStoredRun(String saved) {
        if (saved == null || saved.isEmpty()) return null;
        try {
            return Workflow.Run.fromJson(new JSONObject(saved));
        } catch (JSONException e) {
            return null;
        }
    }

    private Workflow.Run interrupted(Workflow.Run value) {
        if (value != null && value.verification.busy()) return value.finishVerification(value.verification.stopped(getString(R.string.verify_interrupted)));
        if (value != null && !value.complete() && (value.note.isEmpty() || "Ответ ещё поступает.".equals(value.note))) {
            return value.withNote("Разбор прерван. Можно продолжить с незавершённого шага.");
        }
        return value;
    }

    private static boolean writeWorkspace(SharedPreferences preferences, Map<String, Object> changes) {
        SharedPreferences.Editor edit = preferences.edit();
        for (Map.Entry<String, Object> change : changes.entrySet()) {
            Object value = change.getValue();
            if (value == null) edit.remove(change.getKey());
            else if (value instanceof Boolean) edit.putBoolean(change.getKey(), (Boolean) value);
            else if (value instanceof Long) edit.putLong(change.getKey(), (Long) value);
            else edit.putString(change.getKey(), (String) value);
        }
        return edit.commit();
    }

    private void persistRun() {
        progressHandler.removeCallbacks(saveDraft);
        progressHandler.removeCallbacks(checkpoint);
        checkpointPending = false;
        if (clearing) return;
        Workflow.Run snapshot = run;
        Attempt current = attempt;
        if (current != null && !current.received.isEmpty()) {
            snapshot = current.input.receive(ModelClient.Reply.error(current.received, "Ответ ещё поступает."));
        }
        final long owner = activeTaskId;
        final List<InputMaterial.Ref> sent = snapshot == null ? java.util.Collections.emptyList() : snapshot.materials;
        store.save(storeSession, new WorkspaceStore.State(activeTaskId, taskDraft, snapshot, resultsVisible, attemptHistory),
                saved -> { if (saved && !sent.isEmpty()) AttachmentStore.get(this).consume(owner, sent);
                    if (!saved) runOnUiThread(() -> {
                    if (!isDestroyed() && !clearing) toast("Не удалось сохранить рабочие данные.");
                }); });
    }

    private void scheduleCheckpoint() {
        if (checkpointPending) return;
        checkpointPending = true;
        progressHandler.postDelayed(checkpoint, CHECKPOINT_INTERVAL);
    }

    private void makeScreen() {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        root.setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();

        LinearLayout top = row();
        top.setPadding(dp(20), dp(8), dp(20), dp(8));
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.ic_nia_logo);
        top.addView(mark, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView name = text("Nexus AI", 21, FG, true);
        LinearLayout.LayoutParams nameLayout = weighted();
        nameLayout.leftMargin = dp(10);
        top.addView(name, nameLayout);
        Button models = button("Модели", false, view -> showKeys(""));
        models.setEnabled(!clearing);
        top.addView(models);
        root.addView(top);
        View rule = new View(this);
        rule.setBackgroundColor(BORDER);
        root.addView(rule, new LinearLayout.LayoutParams(-1, dp(1)));

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        content = column();
        content.setPadding(dp(20), dp(22), dp(20), dp(24));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        root.requestFocus();
    }

    private void renderTask() {
        historyVisible = false;
        if (resultsVisible) {
            resultsVisible = false;
            persistRun();
        }
        nexusRender(NexusComposeUi.Page.TASK);
    }

    private void selectMode(Workflow.Mode value) {
        if (active || clearing || selectedMode == value) return;
        selectedMode = value;
        data.edit().putString("selected_mode", value.name()).apply();
        // Changing the next-run mode must not discard the current conversation.
        if (run == null) renderTask();
        else nexusRender(NexusComposeUi.Page.TASK);
    }

    private void addTeamCards() {
        add(content, text("Команда", 19, FG, true), 22);
        for (int i = 0; i < stages.size(); i++) {
            Workflow.Stage stage = stages.get(i);
            LinearLayout item = row();
            item.setPadding(dp(13), dp(10), dp(14), dp(10));
            item.setMinimumHeight(dp(61));
            item.setBackground(ripple(SURFACE, BORDER, 14));
            item.addView(badge(i + 1));
            LinearLayout descriptions = column();
            descriptions.addView(text(stage.role, 16, FG, true));
            add(descriptions, text(stage.model.label + " · " + stage.model.provider.label,
                    13, MUTED, false), 3);
            LinearLayout.LayoutParams descriptionLayout = weighted();
            descriptionLayout.leftMargin = dp(12);
            descriptionLayout.rightMargin = dp(8);
            item.addView(descriptions, descriptionLayout);
            item.addView(text("›", 25, MUTED, false));
            int index = i;
            item.setFocusable(true);
            item.setOnClickListener(view -> editStage(index));
            item.setContentDescription("Шаг " + (i + 1) + ". " + stage.role + ". "
                    + stage.model.label + ". Изменить роль.");
            add(content, item, 8);
        }
    }

    private void renderRun(boolean keepPosition) {
        historyVisible = false;
        if (!resultsVisible) {
            resultsVisible = true;
            persistRun();
        }
        liveStatus = null;
        liveText = null;
        nexusRender(keepPosition ? null : NexusComposeUi.Page.RESULT);
    }

    /** Displays the authoritative finished answer; review details are collapsed by default. */
    private void showFinalAnswer() {
        final int finalStep = run.finalIndex();
        final String answer = run.displayAnswer(finalStep);
        LinearLayout card = column();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(shape(SURFACE, ACCENT, 15));
        add(card, text("Готовый результат", 18, ACCENT, true), 0);
        Workflow.Artifact artifact = run.answerAt(finalStep);
        if (!artifact.warnings.isEmpty()) {
            add(card, selectable("⚠ Проверь продолжение ответа:\n"
                    + String.join("\n", artifact.warnings), 13, WARNING), 8);
        }
        TextView formatted = selectable("", 15, FG);
        formatted.setText(MarkdownText.render(preview(answer)));
        formatted.setLineSpacing(dp(4), 1f);
        add(card, formatted, 12);
        if (answer.length() > ANSWER_PREVIEW) {
            add(card, button("Открыть весь результат", false, view -> showFormattedText("Готовый результат", answer)), 8);
        }
        add(card, button("Копировать результат", false, view -> copyAnswer("Готовый результат", answer)), 10);
        List<String> blocks = PythonInputs.manualBlocks(answer);
        if (!blocks.isEmpty()) {
            Button execute = button("Запустить Python", false,
                    view -> choosePythonBlock(run, finalStep, blocks));
            execute.setEnabled(!active);
            add(card, execute, 8);
        }
        add(content, card, 14);
    }

    private void copyAnswer(String title, String answer) {
        try {
            ClipboardManager clipboard = getSystemService(ClipboardManager.class);
            clipboard.setPrimaryClip(ClipData.newPlainText(title, answer));
            toast("Результат скопирован");
        } catch (RuntimeException e) {
            toast("Не удалось скопировать. Используй экспорт JSON.");
        }
    }

    private void showFormattedText(String title, String value) {
        LinearLayout form = dialogForm();
        TextView answer = selectable("", 15, FG);
        answer.setText(MarkdownText.render(value));
        answer.setLineSpacing(dp(4), 1f);
        add(form, answer, 0);
        new AlertDialog.Builder(this).setTitle(title).setView(dialogArea(form))
                .setNeutralButton("Копировать", (dialog, which) -> copyAnswer(title, value))
                .setPositiveButton("Закрыть", null).show();
    }

    private void askFollowUp() {
        if (active || clearing || run == null || !run.complete()) return;
        LinearLayout form = dialogForm();
        add(form, text("Создадим новую версию. Предыдущий результат останется в истории версий.",
                14, MUTED, false), 0);
        EditText clarification = field("", "Например: добавь экран настроек", 0, 4, false);
        add(form, clarification, 10);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Уточнить результат")
                .setView(dialogArea(form)).setPositiveButton("Отправить", null)
                .setNegativeButton("Отмена", null).show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String clarificationText = clarification.getText().toString().trim();
            if (clarificationText.isEmpty()) { clarification.setError(getString(R.string.field_required)); return; }
            dialog.dismiss();
            nexusFollowUp(clarificationText);
        });
    }

    private void showVersions() {
        List<TaskRepository.Version> versions = repository.versions(activeTaskId);
        if (versions.isEmpty()) {
            toast("Пока нет предыдущих версий.");
            return;
        }
        String[] labels = new String[versions.size()];
        for (int i = 0; i < labels.length; i++) {
            TaskRepository.Version item = versions.get(i);
            labels[i] = "Версия " + item.number + " · " + dateLabel(item.createdAt);
        }
        new AlertDialog.Builder(this).setTitle("Предыдущие версии")
                .setItems(labels, (dialog, index) -> {
                    TaskRepository.Version version = versions.get(index);
                    Workflow.Run snapshot = restoreStoredRun(version.runJson);
                    if (snapshot == null) {
                        toast("Не удалось прочитать сохранённую версию.");
                    } else if (snapshot.complete()) {
                        showFormattedText("Версия " + version.number,
                                snapshot.displayAnswer(snapshot.finalIndex()));
                    } else {
                        showFormattedText("Версия " + version.number,
                                snapshot.draft.text.isEmpty() ? snapshot.task : snapshot.draft.text);
                    }
                }).setNegativeButton("Закрыть", null).show();
    }

    private String dateLabel(long time) {
        return DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date(time));
    }

    private void renderHistory() {
        if (active || clearing) {
            toast("Заверши или останови запрос перед переключением задач.");
            return;
        }
        if (!historyVisible) historyReturnResults = resultsVisible;
        historyVisible = true;
        nexusRender(NexusComposeUi.Page.HISTORY);
    }

    private void returnFromHistory() {
        historyVisible = false;
        if (historyReturnResults && run != null) renderRun(false);
        else renderTask();
    }

    private void openHistoryTask(long id) {
        if (id == activeTaskId) {
            TaskRepository.Entry entry = repository.load(id);
            if (entry != null && !entry.runJson.isEmpty()) renderRun(false);
            else renderTask();
            return;
        }
        persistBeforeSwitch(() -> {
            TaskRepository.Entry entry = repository.load(id);
            if (entry == null) {
                toast("Задача не найдена.");
                renderHistory();
                return;
            }
            enterTask(entry);
        });
    }

    private void enterTask(TaskRepository.Entry entry) {
        Workflow.Run restored = interrupted(restoreStoredRun(entry.runJson));
        boolean showResult = restored != null;
        repository.select(entry.id);
        activeTaskId = entry.id;
        selectArtifact(artifactRepository.forChat(activeTaskId));
        storeSession = store.switchTo(new WorkspaceStore.State(entry.id, entry.task, restored,
                showResult, entry.attemptLog));
        data.edit().putLong(ACTIVE_TASK, entry.id).commit();
        taskDraft = entry.task;
        run = restored;
        if (restored != null) AttachmentStore.get(this).consume(activeTaskId, restored.materials);
        attemptHistory = entry.attemptLog;
        resultsVisible = showResult;
        workExpanded = false;
        historyVisible = false;
        if (showResult) renderRun(false);
        else renderTask();
    }

    /** Await the last durable snapshot before changing the active task or its current cycle. */
    private void persistBeforeSwitch(Runnable next) {
        if (clearing || active || sandboxJob != null) return;
        nexusPythonFlushPending();
        clearing = true;
        progressHandler.removeCallbacks(saveDraft);
        progressHandler.removeCallbacks(checkpoint);
        checkpointPending = false;
        store.save(storeSession,
                new WorkspaceStore.State(activeTaskId, taskDraft, run, resultsVisible, attemptHistory),
                saved -> runOnUiThread(() -> {
                    if (isDestroyed()) return;
                    clearing = false;
                    if (!saved) {
                        toast("Не удалось сохранить текущую задачу. Переключение отменено.");
                        return;
                    }
                    next.run();
                }));
    }

    private void addAnswerCard(LinearLayout panel, int i) {
        Workflow.Stage stage = run.stages.get(i);
        boolean done = run.hasAnswer(i);
        boolean current = !run.complete() && i == run.nextIndex();
        boolean running = active && current;
        boolean hasDraft = current && !run.draft.text.isEmpty();
        boolean finalAnswer = run.complete() && i == run.finalIndex();
        boolean skipped = run.revisionSkipped() && i == Workflow.Step.REVISION.ordinal();
        String status = done ? (finalAnswer ? "Итог" : "Готово")
                : running ? hasDraft ? "Продолжает ответ" : "Готовит ответ"
                : current ? hasDraft ? "Сохранён черновик" : "Ждёт запуска"
                : skipped ? "Пропущен · ревью без замечаний" : "В очереди";
        LinearLayout card = column();
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(shape(SURFACE, finalAnswer ? ACCENT : running ? ACCENT_DARK : BORDER, 15));
        LinearLayout heading = row();
        heading.addView(badge(i + 1));
        LinearLayout description = column();
        description.addView(text(stage.role, 16, FG, true));
        String modelLabel = stage.model.label;
        if (done) modelLabel = contributorLabels(run.answerAt(i), stage.model);
        add(description, text(modelLabel + " · " + status, 13,
                running ? ACCENT : MUTED, false), 3);
        LinearLayout.LayoutParams item = weighted();
        item.leftMargin = dp(10);
        heading.addView(description, item);
        card.addView(heading);
        if (done || hasDraft) {
            String answer = done ? run.displayAnswer(i) : run.draft.text;
            if (hasDraft) {
                add(card, text("Черновик · " + contributorLabels(run.draft, stage.model),
                        13, WARNING, true), 12);
            }
            Workflow.Artifact artifact = done ? run.answerAt(i) : run.draft;
            if (!artifact.warnings.isEmpty()) {
                add(card, text("⚠ Проверь продолжение ответа:\n" + String.join("\n", artifact.warnings),
                        13, WARNING, false), 10);
            }
            TextView response = selectable(preview(answer), 15, FG);
            response.setLineSpacing(dp(4), 1f);
            add(card, response, 14);
            if (answer.length() > ANSWER_PREVIEW) {
                add(card, button("Открыть весь текст", false, view -> showText(stage.role, answer)), 10);
            }
            add(card, button("Копировать ответ", false, view -> {
                try {
                    ClipboardManager clipboard = getSystemService(ClipboardManager.class);
                    clipboard.setPrimaryClip(ClipData.newPlainText(stage.role, answer));
                    toast("Ответ скопирован");
                } catch (RuntimeException e) {
                    toast("Не удалось скопировать. Сохрани разбор в JSON.");
                }
            }), 10);
            List<String> blocks = PythonInputs.manualBlocks(answer);
            if (done && !blocks.isEmpty()) {
                Button execute = button("Запустить код", false, view -> choosePythonBlock(run, i, blocks));
                execute.setEnabled(!active);
                add(card, execute, 10);
            }
        }
        if (running) {
            String waiting = stagePool != null && !stagePool.failures.isEmpty()
                    ? "Пробую резервную модель · попытка " + stagePool.next + " из " + stagePool.models.size()
                    : "Ожидание модели · максимум 60 секунд на попытку";
            liveStatus = text(waiting, 13, ACCENT, false);
            liveText = selectable("", 15, FG);
            add(card, liveStatus, 10);
            add(card, liveText, 10);
        }
        if (current && !active) {
            add(card, button("Сменить модель шага", false, view -> chooseModel(stage.model, model -> {
                run = run.withModel(model);
                persistRun();
                renderRun(true);
            })), 10);
        }
        add(panel, card, 10);
    }

    private String contributorLabels(Workflow.Artifact artifact, ModelCatalog.Model fallback) {
        List<String> names = new ArrayList<>();
        for (String id : artifact.models) {
            try {
                names.add(catalog.details(ModelCatalog.storedModel(id, "")).label);
            } catch (JSONException e) {
                names.add(id);
            }
        }
        return names.isEmpty() ? fallback.label : String.join(" + ", names);
    }

    private void choosePythonBlock(Workflow.Run source, int index, List<String> blocks) {
        if (blocks.size() == 1) {
            showSandboxInput(source, index, blocks.get(0), "", false);
            return;
        }
        String[] labels = new String[blocks.size()];
        for (int i = 0; i < labels.length; i++) {
            String firstLine = blocks.get(i).trim().split("\\R", 2)[0];
            labels[i] = "Блок " + (i + 1) + " · "
                    + (firstLine.length() > 70 ? firstLine.substring(0, 70) + "…" : firstLine);
        }
        new AlertDialog.Builder(this).setTitle("Выбрать блок Python").setItems(labels,
                (dialog, which) -> showSandboxInput(source, index, blocks.get(which), "", false))
                .setNegativeButton("Отмена", null).show();
    }

    private void showSandboxInput(Workflow.Run source, int index, String code, String previousInput,
                                  boolean usePiston) {
        LinearLayout form = dialogForm();
        add(form, text("Введи данные для input(), по одному ответу на строку. "
                + "Пустое поле означает конец ввода.", 14, MUTED, false), 0);
        EditText stdin = field(previousInput, "Ввод программы (stdin)", 0, 3, false);
        add(form, stdin, 8);
        String pistonKey = readPistonForEdit();
        CheckBox packages = new CheckBox(this);
        packages.setText("Разрешить загрузку Matplotlib и зависимостей с CDN Pyodide "
                + "(только для локального Python, нужен интернет)");
        packages.setChecked(false);
        add(form, packages, 8);
        CheckBox remote = new CheckBox(this);
        if (!pistonKey.isEmpty()) {
            remote.setText("Piston · Python " + SandboxClient.PISTON_VERSION + "\nКод и ввод отправятся в Piston.");
            remote.setChecked(usePiston);
            add(form, remote, 8);
        }
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Запустить код")
                .setView(dialogArea(form)).setPositiveButton("Запустить", null)
                .setNegativeButton("Отмена", null).show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String input = stdin.getText().toString();
            try {
                SandboxClient.validate(code, input);
            } catch (IllegalArgumentException e) {
                stdin.setError(e.getMessage());
                return;
            }
            dialog.dismiss();
            runSandbox(source, index, code, input, remote.isChecked() ? pistonKey : "",
                    packages.isChecked() && !remote.isChecked());
        });
    }

    private void runSandbox(Workflow.Run source, int index, String code, String stdin,
                            String pistonKey, boolean loadMatplotlib) {
        runSandbox(source, index, code, stdin, pistonKey, loadMatplotlib,
                null, "main.py", "", false);
    }

    private void runSandbox(Workflow.Run source, int index, String code, String stdin,
                            String pistonKey, boolean loadMatplotlib, JSONObject projectFiles,
                            String entryFile, String allowedPackage, boolean extended) {
        if (active || clearing || source != run || sandboxJob != null) return;
        boolean remote = !pistonKey.isEmpty();
        boolean compose = nexusUi != null;
        AlertDialog progress = compose ? null : new AlertDialog.Builder(this)
                .setTitle("Запускаю Python")
                .setMessage(remote ? "В песочнице Piston…"
                        : loadMatplotlib ? "Загружаю Matplotlib…" : "На телефоне…")
                .setNegativeButton("Остановить", null).show();
        SandboxJob job = new SandboxJob(progress);
        sandboxJob = job;
        lastPythonRun = source;
        lastPythonStep = index;
        lastPythonCode = code;
        lastPythonStdin = stdin;
        lastPythonDiagnostic = "";
        if (compose) nexusUi.pythonStarted();
        if (progress != null) progress.setOnDismissListener(dialog -> {
            if (sandboxJob == job) cancelSandbox();
        });
        Consumer<SandboxClient.Result> result = output -> {
            if (sandboxJob != job || isDestroyed()) return;
            sandboxJob = null;
            if (progress != null) progress.dismiss();
            if (compose) {
                String diagnostic = output.diagnostic();
                lastPythonDiagnostic = PythonVerification.environmentalDiagnostic(diagnostic) || index < 0
                        || source == null ? "" : diagnostic;
                if (projectFiles != null) {
                    final long resultProject = activeArtifactId;
                    sandboxWorker.submit(() -> {
                        synchronized (pythonReportLock) {
                            if (!deletedPythonReportProjects.contains(resultProject)) {
                                try { new PythonLastRunStore(getApplicationContext(), true).save(resultProject, output); }
                                catch (IOException ignored) { /* Still visible in the current UI. */ }
                            }
                        }
                    });
                }
                latestVisual = (!output.pngBase64.isEmpty() || !output.html.isEmpty()) ? output : null;
                if (latestVisual != null) nexusUi.cacheVisual(latestVisual.pngBase64, latestVisual.html);
                nexusUi.onVisualAvailable(latestVisual != null);
                nexusUi.pythonFinished(new NexusPythonReport(output.engine, output.stdout,
                        output.stderr, output.status, lastPythonDiagnostic,
                        output.exitCode, latestVisual != null,
                        output.artifacts.toString(), output.tests.toString(), output.snapshotSha256));
            } else showSandboxResult(source, index, code, stdin, remote, output);
        };
        Consumer<String> problem = message -> {
            if (sandboxJob != job || isDestroyed()) return;
            sandboxJob = null;
            if (progress != null) progress.dismiss();
            if (compose) nexusUi.pythonFailed(message);
            else new AlertDialog.Builder(this).setTitle("Запуск недоступен").setMessage(message)
                    .setNegativeButton("Закрыть", null)
                    .setPositiveButton("Повторить", (dialog, which) ->
                            showSandboxInput(source, index, code, stdin, false)).show();
        };
        if (remote) {
            job.future = sandboxWorker.submit(() -> {
                try {
                    SandboxClient.Result output = sandboxClient.execute(code, stdin, pistonKey, job.cancellation);
                    runOnUiThread(() -> result.accept(output));
                } catch (IOException e) {
                    String message = e.getMessage();
                    if (message == null || !message.startsWith("Piston"))
                        message = "Нет ответа от Piston. Можно повторить запуск на телефоне.";
                    String safe = message;
                    runOnUiThread(() -> problem.accept(safe));
                } catch (JSONException e) {
                    runOnUiThread(() -> problem.accept("Piston вернул неполный результат запуска."));
                }
            });
        } else {
            job.local = new AndroidPythonExecutor(this, result, problem);
            if (projectFiles == null) job.local.execute(code, stdin, loadMatplotlib);
            else job.local.executeProject(code, stdin, projectFiles, entryFile, allowedPackage, extended);
        }
    }

    private void showSandboxResult(Workflow.Run source, int index, String code, String stdin,
                                   boolean usedPiston, SandboxClient.Result result) {
        latestVisual = (!result.pngBase64.isEmpty() || !result.html.isEmpty()) ? result : null;
        if (nexusUi != null) {
            if (latestVisual != null) nexusUi.cacheVisual(latestVisual.pngBase64, latestVisual.html);
            nexusUi.onVisualAvailable(latestVisual != null);
        }
        LinearLayout form = dialogForm();
        String header = result.engine;
        if (result.exitCode != null) header += " · код завершения " + result.exitCode;
        add(form, text(header, 14, MUTED, true), 0);
        if (!result.status.isEmpty()) add(form, selectable(result.status, 14, WARNING), 8);
        add(form, text("Вывод (stdout)", 14, MUTED, true), 12);
        add(form, consoleText(result.stdout.isEmpty() ? "Нет вывода." : result.stdout, FG), 6);
        if (!result.stderr.isEmpty()) {
            add(form, text("Ошибки (stderr)", 14, MUTED, true), 12);
            add(form, consoleText(result.stderr, WARNING), 6);
        }
        if (!result.pngBase64.isEmpty() || !result.html.isEmpty()) {
            add(form, button("Показать результат", true, view -> showVisualResult(result)), 12);
        }
        AlertDialog.Builder dialog = new AlertDialog.Builder(this).setTitle("Результат запуска")
                .setView(dialogArea(form)).setNegativeButton("Закрыть", null)
                .setNeutralButton("Повторить", (which, button) ->
                        showSandboxInput(source, index, code, stdin, usedPiston));
        String error = result.diagnostic();
        if (!error.isEmpty() && !PythonVerification.environmentalDiagnostic(error)) {
            add(form, text("Ревьюер получит код, ввод и сообщение об ошибке.", 13, MUTED, false), 12);
            dialog.setPositiveButton("Отправить ошибку Ревьюеру", (window, button) -> {
                if (active || run != source || !run.hasAnswer(index)) return;
                boolean wasComplete = run.complete();
                run = run.addRepair(new Workflow.RepairInput(index, code, stdin, error));
                persistRun();
                if (wasComplete) resumeRun();
                if (!active) {
                    if (!wasComplete) toast("Шаг исправления добавлен после текущих шагов.");
                    renderRun(true);
                }
            });
        }
        dialog.show();
    }

    /** Untrusted Python output: no keys, JS bridge, navigation, network, or file access. */
    private void showVisualResult(SandboxClient.Result result) {
        latestVisual = result;
        if (nexusUi != null) nexusUi.showVisual(result.pngBase64, result.html);
    }


    // The Java request/workflow/crypto/database implementation remains authoritative.
    // Compose receives a read-only snapshot without API keys or WebView internals.
    private void nexusRender(NexusComposeUi.Page page) {
        if (nexusUi == null) {
            nexusUi = new NexusComposeUi(this);
            nexusUi.mount();
        }
        nexusUi.render(nexusSnapshot(), page);
    }

    public PythonVerification nexusVerification() { return run == null ? PythonVerification.NONE : run.verification; }
    public int nexusFinalStep() { return run != null && run.complete() ? run.finalIndex() : -1; }

    public List<NexusState.Stage> nexusConfiguredStages() {
        List<NexusState.Stage> configured = new ArrayList<>();
        for (int i = 0; i < stages.size(); i++) {
            Workflow.Stage stage = stages.get(i);
            configured.add(new NexusState.Stage(i, stage.role, stage.instruction, stage.selected.id,
                    stage.selected.label, "", "", false, false, false));
        }
        return configured;
    }

    public boolean nexusAllowFallback() { return data.getBoolean("allow_fallback", true); }

    public boolean nexusSetFallback(boolean allow) {
        return data.edit().putBoolean("allow_fallback", allow).commit();
    }

    public boolean nexusPartsAvailable() {
        return !active && run != null && !run.complete() && !run.nextStage().numberedParts
                && (run.note.contains(getString(R.string.budget_short)) || run.draftMode == Workflow.DraftMode.CONTINUE);
    }

    public void nexusResumeInParts() {
        if (!nexusPartsAvailable()) return;
        run = run.permitParts();
        persistRun();
        resumeRun();
    }

    public void nexusChangePausedModel(String id) {
        if (active || clearing || run == null || run.complete()) return;
        ModelCatalog.Model replacement = nexusFindModel(id);
        if (replacement == null || !catalog.available(replacement)) { toast(getString(R.string.route_missing)); return; }
        run = run.withModel(replacement);
        persistRun();
        renderRun(false);
    }

    public NexusState nexusSnapshot() {
        List<NexusState.Stage> stageViews = new ArrayList<>();
        List<Workflow.Stage> visible = run != null ? run.stages : stages;
        for (int i = 0; i < visible.size(); i++) {
            Workflow.Stage stage = visible.get(i);
            boolean done = run != null && run.hasAnswer(i);
            boolean current = run != null && !run.complete() && i == run.nextIndex();
            String answer = done ? run.displayAnswer(i)
                    : current ? run.draft.text : "";
            String warnings = "";
            if (run != null && done) warnings = String.join("\n", run.answerAt(i).warnings);
            if (run != null && current && !done) warnings = String.join("\n", run.draft.warnings);
            String modelLabel = done ? contributorLabels(run.answerAt(i), stage.model) : stage.model.label;
            if (!stage.selected.id.equals(stage.model.id) || done && run.answerAt(i).models.size() > 1)
                modelLabel = getString(R.string.route_actual, stage.selected.label, modelLabel)
                        + (stage.routeReason.isEmpty() ? "" : " · " + stage.routeReason);
            stageViews.add(new NexusState.Stage(i, stage.role, stage.instruction,
                    stage.selected.id, modelLabel, answer, warnings,
                    !PythonInputs.manualBlocks(answer).isEmpty(), done, current));
        }
        List<NexusState.Model> modelViews = new ArrayList<>();
        EnumMap<Workflow.Provider, Boolean> connected = new EnumMap<>(Workflow.Provider.class);
        for (Workflow.Provider provider : Workflow.Provider.values())
            connected.put(provider, !readForEdit(provider).isEmpty());
        for (ModelCatalog.Model model : catalog.choices()) {
            modelViews.add(new NexusState.Model(model.id, model.label, model.provider.label,
                    Boolean.TRUE.equals(connected.get(model.provider)), model.imageInput, model.context));
        }
        List<NexusState.Task> taskViews = new ArrayList<>();
        for (TaskRepository.Entry entry : repository.list()) {
            boolean selected = entry.id == activeTaskId;
            Workflow.Run saved = selected ? run : interrupted(restoreStoredRun(entry.runJson));
            taskViews.add(new NexusState.Task(entry.id, entry.title, entry.updatedAt, entry.versions,
                    saved != null && saved.complete(), saved != null, selected,
                    saved == null ? PythonVerification.Status.NONE : saved.verification.status,
                    entry.pinned, entry.task.trim().isEmpty() && saved == null ? "" :
                            TaskHistory.title(PythonInputs.withoutMaterials(saved == null ? entry.task : TaskHistory.displayTask(saved.task)))));
        }
        boolean complete = run != null && run.complete();
        int finalStep = complete ? run.finalIndex() : -1;
        String finalText = finalStep >= 0 ? run.displayAnswer(finalStep) : "";
        String warning = finalStep >= 0
                ? String.join("\n", run.answerAt(finalStep).warnings) : "";
        return new NexusState(taskDraft == null ? "" : taskDraft,
                selectedMode == Workflow.Mode.QUICK, active, clearing,
                run != null, complete, run == null ? 0 : run.answers.size(),
                run == null ? (selectedMode == Workflow.Mode.QUICK ? 1 : 3) : run.stages.size(),
                run == null ? "" : run.note, finalText,
                finalStep >= 0 ? run.stages.get(finalStep).role : "", warning,
                !PythonInputs.manualBlocks(finalText).isEmpty(), attemptHistory == null ? "" : attemptHistory,
                stageViews, modelViews, taskViews, data.getBoolean(GROQ_RESERVE, false),
                quickModel().id, quickModel().label,
                repository.versions(activeTaskId).size(), latestVisual != null, nexusExchanges());
    }

    /** Project real saved run versions into a readable conversation without modifying SQLite. */
    private List<NexusState.Exchange> nexusExchanges() {
        List<NexusState.Exchange> messages = new ArrayList<>();
        List<TaskRepository.Version> versions = repository.versions(activeTaskId);
        String previousOriginal = "";
        // Oldest first. Keep the latest 40 versions in the chat; all remain in Versions.
        for (int i = Math.min(versions.size() - 1, 39); i >= 0; i--) {
            Workflow.Run archived = restoreStoredRun(versions.get(i).runJson);
            if (archived != null) {
                previousOriginal = appendNexusExchange(messages, archived, previousOriginal);
            }
        }
        if (run != null) appendNexusExchange(messages, run, previousOriginal);
        return messages;
    }

    private String appendNexusExchange(List<NexusState.Exchange> messages,
                                       Workflow.Run archived, String previousOriginal) {
        String fullPrompt = PythonInputs.withoutMaterials(archived.userTestTask()).trim();
        String prompt;
        if (!previousOriginal.isEmpty() && fullPrompt.startsWith(previousOriginal + "\n\n")) {
            prompt = fullPrompt.substring(previousOriginal.length() + 2).trim();
        } else if (messages.isEmpty() && taskDraft != null && !taskDraft.trim().isEmpty()) {
            // The original user draft, not the expanded prompt with attachment contents.
            prompt = taskDraft.trim();
        } else {
            // A compiled workflow prompt is not a user message. If the original
            // user wording is unavailable, show only the real saved answer.
            prompt = fullPrompt;
        }
        String answer = archived.complete() ? archived.displayAnswer(archived.finalIndex()) : "";
        messages.add(new NexusState.Exchange(prompt, answer, archived.complete()));
        return fullPrompt.isEmpty() ? previousOriginal : fullPrompt;
    }

    /** Include every saved version, regardless of the main chat display limit. Called off the UI thread. */
    public List<NexusState.SearchMessage> nexusSearchMessages(long onlyTask) {
        List<NexusState.SearchMessage> rows = new ArrayList<>();
        List<TaskRepository.Entry> tasks = onlyTask == 0 ? repository.list() :
                java.util.Collections.singletonList(repository.load(onlyTask));
        for (TaskRepository.Entry entry : tasks) {
            if (entry == null) continue;
            List<TaskRepository.Version> versions = repository.versions(entry.id);
            for (int i = versions.size() - 1; i >= 0; i--)
                addSearchVersion(rows, entry, versions.get(i).runJson);
            if (entry.runJson.isEmpty()) rows.add(new NexusState.SearchMessage(entry.id, entry.title, entry.task, true));
            else addSearchVersion(rows, entry, entry.runJson);
        }
        return rows;
    }
    private void addSearchVersion(List<NexusState.SearchMessage> rows, TaskRepository.Entry entry, String json) {
        Workflow.Run saved = restoreStoredRun(json);
        if (saved == null) return;
        String question = PythonInputs.withoutMaterials(TaskHistory.displayTask(saved.task));
        rows.add(new NexusState.SearchMessage(entry.id, entry.title, question, true));
        if (saved.complete()) rows.add(new NexusState.SearchMessage(entry.id, entry.title,
                saved.displayAnswer(saved.finalIndex()), false));
    }

    public void nexusDraftChanged(String draft) {
        if (clearing) return;
        taskDraft = draft;
        progressHandler.removeCallbacks(saveDraft);
        progressHandler.postDelayed(saveDraft, 600);
    }

    public void nexusModeChanged(boolean quick) {
        selectMode(quick ? Workflow.Mode.QUICK : Workflow.Mode.TEAM);
    }

    public String nexusBuffer(String name) {
        return getSharedPreferences("chat_drafts", MODE_PRIVATE).getString(activeTaskId + "/" + name, "");
    }
    public void nexusBuffer(String name, String value) {
        SharedPreferences.Editor edit = getSharedPreferences("chat_drafts", MODE_PRIVATE).edit();
        String key = activeTaskId + "/" + name;
        if (value.isEmpty()) edit.remove(key); else edit.putString(key, value);
        edit.apply();
    }
    public long nexusTaskId() { return activeTaskId; }
    public void nexusStart() { startRun(); }
    public void nexusStop() { if (active) stopRun(); }
    public void nexusResume() { resumeRun(); }
    public void nexusOpenTaskEditor() { renderTask(); }
    public void nexusOpenResults() { if (run != null) renderRun(false); }
    public void nexusOpenHistory() { renderHistory(); }

    /** The file store, not a possibly stale Compose editor, owns Python chat data. */
    public boolean nexusHasSavedPythonFiles() {
        if (activeArtifactId <= 0) return false;
        try { return pythonProjects().paths(activeArtifactId).length > 0; }
        catch (IOException e) { return true; } // Never reuse a workspace whose files cannot be checked.
    }

    public void nexusCreateTask() {
        if (clearing) return;
        if (active) stopRun();
        if (sandboxJob != null) { cancelSandbox(); if (nexusUi != null) nexusUi.pythonCancelled(); }
        if (run == null && taskDraft.trim().isEmpty() && nexusUi != null
                && !nexusUi.hasDraftContent() && !nexusHasSavedPythonFiles()
                && !repository.hasExplicitlySavedChat(activeTaskId)) {
            renderTask(); return;
        }
        persistBeforeSwitch(() -> {
            try {
                long id = repository.create("");
                TaskRepository.Entry entry = repository.load(id);
                if (entry == null) throw new IllegalStateException("Task not saved");
                enterTask(entry);
            } catch (RuntimeException e) { toast(getString(R.string.error_new_task)); }
        });
    }

    public void nexusOpenTask(long id) {
        if (id != activeTaskId && (active || sandboxJob != null)) {
            toast(getString(R.string.finish_before_switch)); return;
        }
        openHistoryTask(id);
    }

    public void nexusPinTask(long id, boolean pinned) {
        if (repository.pin(id, pinned)) nexusRender(null);
    }
    public void nexusRenameTask(long id, String name) {
        if (repository.rename(id, name)) nexusRender(null);
    }

    private void removeTaskFiles(long id) {
        AttachmentStore.get(this).deleteTask(id);
        // Chat deletion must not delete an independent Python artifact.
        artifactRepository.unlinkChat(id);
        new PythonProjectStore(this).deleteTask(id); // Old pre-migration chat copies only.
        synchronized (pythonReportLock) {
            deletedPythonReportChats.add(id);
            new PythonLastRunStore(this).deleteTask(id);
        }
        SharedPreferences prefs = getSharedPreferences("chat_drafts", MODE_PRIVATE);
        SharedPreferences.Editor edit = prefs.edit();
        for (String key : prefs.getAll().keySet()) if (key.startsWith(id + "/")) edit.remove(key);
        edit.apply();
    }

    public void nexusDeleteTask(long id) {
        if (active || clearing || sandboxJob != null) return;
        nexusPythonFlushPending();
        TaskRepository.Entry entry = repository.load(id);
        if (entry == null) return;
        if (id != activeTaskId) {
            if (repository.delete(id)) { removeTaskFiles(id); renderHistory(); }
            else toast(getString(R.string.error_delete_task));
            return;
        }
        persistBeforeSwitch(() -> {
            long replacement = repository.create("");
            if (replacement > 0 && repository.delete(id)) { removeTaskFiles(id); enterTask(repository.load(replacement)); }
            else toast(getString(R.string.error_delete_task));
        });
    }

    private ModelCatalog.Model nexusFindModel(String id) {
        for (ModelCatalog.Model model : catalog.choices()) if (model.id.equals(id)) return model;
        return null;
    }

    public void nexusChooseQuickModel(String id) {
        ModelCatalog.Model model = nexusFindModel(id);
        if (model == null || active || clearing) return;
        quickModel = model;
        data.edit().putString("quick_model", model.id)
                .putString("quick_model_label", model.label).apply();
        if (run == null) renderTask();
        else nexusRender(NexusComposeUi.Page.TASK);
    }

    public boolean nexusUpdateStage(int index, String role, String instruction, String modelId) {
        if (clearing || index < 0 || index >= stages.size()
                || role.trim().isEmpty() || role.trim().length() > 42
                || instruction.trim().isEmpty() || instruction.trim().length() > 1600) return false;
        ModelCatalog.Model model = nexusFindModel(modelId);
        if (model == null || !catalog.available(model)) { toast(getString(R.string.route_missing)); return false; }
        List<Workflow.Stage> updated = new ArrayList<>(stages);
        updated.set(index, new Workflow.Stage(role.trim(), instruction.trim(), model));
        try {
            if (!data.edit().putString("stages", Workflow.stagesToJson(updated).toString()).commit()) {
                toast(getString(R.string.role_save_error)); return false;
            }
            stages = updated;
            if (run == null) renderTask();
            else nexusRender(NexusComposeUi.Page.TASK);
            return true;
        } catch (JSONException e) { return false; }
    }

    public void nexusRefreshModels() {
        refreshModels(true, problem -> {
            if (!problem.isEmpty()) toast(problem);
            if (nexusUi != null) nexusUi.render(nexusSnapshot(), null);
        });
    }

    /** Secret values are only requested for the editing dialog, never put into NexusState. */
    public String[] nexusKeysForEditing() {
        return new String[] {readForEdit(Workflow.Provider.OPENROUTER),
                readForEdit(Workflow.Provider.GROQ), readForEdit(Workflow.Provider.GEMINI),
                readPistonForEdit()};
    }

    public boolean nexusSaveKeys(String router, String groq, String gemini,
                                 String piston, boolean reserve) {
        if (!validKey(router) || !validKey(groq) || !validKey(gemini) || !validKey(piston)) return false;
        try {
            vault.save(router.trim(), gemini.trim(), groq.trim(), piston.trim());
            data.edit().putBoolean(GROQ_RESERVE, reserve && !groq.trim().isEmpty()).apply();
            if (nexusUi != null) nexusUi.render(nexusSnapshot(), null);
            return true;
        } catch (GeneralSecurityException | IOException e) { return false; }
    }

    public void nexusRunPython(int step) {
        if (active || clearing || run == null || !run.hasAnswer(step)) return;
        List<String> blocks = PythonInputs.manualBlocks(run.displayAnswer(step));
        if (blocks.isEmpty()) return;
        if (nexusUi != null) nexusUi.requestPython(step, blocks.toArray(new String[0]),
                !readPistonForEdit().isEmpty());
        else choosePythonBlock(run, step, blocks);
    }

    public boolean nexusExecutePython(int step, String code, String stdin,
                                      boolean remote, boolean loadMatplotlib) {
        if (clearing || active || sandboxJob != null) return false;
        if (step >= 0 && (run == null || !run.hasAnswer(step))) return false;
        try { SandboxClient.validate(code, stdin); }
        catch (IllegalArgumentException e) { toast(e.getMessage()); return false; }
        String pistonKey = remote ? readPistonForEdit() : "";
        if (remote && pistonKey.isEmpty()) return false;
        runSandbox(run, step, code, stdin, pistonKey, loadMatplotlib && !remote);
        return true;
    }

    // Mini-projects have independent persistent artifact IDs, not chat IDs.
    private final android.os.Handler pythonSaveHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable pendingPythonSave;
    private PythonProjectStore pythonProjectStore;
    private final Object pythonReportLock = new Object();
    private final java.util.Set<Long> deletedPythonReportChats = new java.util.HashSet<>();
    private final java.util.Set<Long> deletedPythonReportProjects = new java.util.HashSet<>();
    private PythonProjectStore pythonProjects() {
        if (pythonProjectStore == null) pythonProjectStore = new PythonProjectStore(this, true);
        return pythonProjectStore;
    }

    /** Non-destructive upgrade. Copy every saved legacy project into an independent artifact.
     * Repeated launches retry interrupted copies; a deleted artifact's tombstone blocks reimport.
     * Even a legacy file whose chat row is missing remains recoverable under Artifacts. */
    private void migratePythonArtifacts() {
        PythonProjectStore legacy = new PythonProjectStore(this);
        PythonLastRunStore legacyRuns = new PythonLastRunStore(this);
        PythonLastRunStore artifactRuns = new PythonLastRunStore(this, true);
        for (long chatId : legacy.savedTaskIds()) {
            try {
                String[] names = legacy.paths(chatId);
                if (names.length == 0) continue;
                String title = "Python · " + names[0];
                for (String name : names) {
                    if (!"main.py".equals(name)) { title = "Python · " + name; break; }
                }
                long projectId = artifactRepository.registerLegacy(chatId,
                        repository.load(chatId) != null, title);
                if (projectId <= 0) continue; // Previously deleted by the user.
                if (pythonProjects().paths(projectId).length == 0) {
                    legacy.copyTo(chatId, pythonProjects(), projectId);
                    if (!artifactRepository.touch(projectId, names[0]))
                        throw new IOException("Artifact catalog row is missing");
                }
                SandboxClient.Result report = legacyRuns.load(chatId);
                if (report != null && artifactRuns.load(projectId) == null)
                    artifactRuns.save(projectId, report);
            } catch (IOException | RuntimeException error) {
                android.util.Log.w("NexusArtifacts", "Legacy Python project migration failed for chat " + chatId, error);
                // Original chat-<id>.json is NEVER deleted on migration failure.
            }
        }
    }

    private void selectArtifact(long id) {
        activeArtifactId = id;
        if (!data.edit().putLong(ACTIVE_ARTIFACT, id).commit())
            toast("Не удалось запомнить выбранный проект. Он останется в Артефактах.");
    }

    public long nexusArtifactId() { return activeArtifactId; }
    public long nexusChatProjectId() { return artifactRepository.forChat(activeTaskId); }

    /** Persist only the chat snapshot; do not create or modify a Python project. */
    public void nexusSaveChat() {
        if (clearing || active || sandboxJob != null) {
            toast("Сначала заверши текущую операцию."); return;
        }
        nexusPythonFlushPending();
        long chatId = activeTaskId;
        persistBeforeSwitch(() -> {
            try {
                boolean saved = repository.markSavedChat(chatId);
                if (saved) nexusRender(null);
                toast(saved ? "Чат сохранён в истории." : "Не удалось сохранить чат.");
            } catch (RuntimeException error) {
                toast("Не удалось сохранить чат: " + error.getMessage());
            }
        });
    }

    /** Explicit save confirms the actual editor bytes reached the artifact file store. */
    public void nexusSaveArtifact(String path, String code) {
        if (clearing || active || sandboxJob != null) {
            toast("Сначала заверши текущую операцию."); return;
        }
        nexusPythonFlushPending();
        try {
            long id = ensurePythonArtifact();
            pythonProjects().putText(id, path, code);
            savedPythonArtifact(id, path);
            if (nexusUi != null) nexusUi.pythonFileSaved(activeTaskId, path);
            toast("Артефакт сохранён отдельно от чата.");
        } catch (IOException | RuntimeException error) {
            toast("Не удалось сохранить артефакт: " + error.getMessage());
        }
    }

    /** Link the active artifact to the current chat without copying files. */
    public void nexusAttachArtifactToChat() {
        if (clearing || active || sandboxJob != null) {
            toast("Сначала заверши текущую операцию."); return;
        }
        nexusPythonFlushPending();
        if (activeArtifactId <= 0 || !artifactRepository.exists(activeArtifactId)
                || repository.load(activeTaskId) == null) {
            toast("Сначала открой сохранённый проект."); return;
        }
        try {
            if (!artifactRepository.attachChat(activeTaskId, activeArtifactId)) {
                toast("Не удалось связать чат с проектом."); return;
            }
            nexusRender(NexusComposeUi.Page.TASK);
        } catch (RuntimeException error) {
            toast("Не удалось связать чат с проектом: " + error.getMessage());
        }
    }

    /** Start a separate chat for this project, preserving the original chat and all code. */
    public void nexusNewChatForArtifact() {
        if (clearing || active || sandboxJob != null) return;
        nexusPythonFlushPending();
        final long project = activeArtifactId;
        if (!artifactRepository.exists(project)) {
            toast("Сначала открой сохранённый проект."); return;
        }
        persistBeforeSwitch(() -> {
            long created = 0;
            try {
                created = repository.create("");
                TaskRepository.Entry entry = repository.load(created);
                if (entry == null || !artifactRepository.attachChat(created, project))
                    throw new IllegalStateException("Не удалось подключить проект.");
                enterTask(entry);
            } catch (RuntimeException error) {
                if (created > 0) {
                    artifactRepository.unlinkChat(created);
                    repository.delete(created);
                }
                toast("Не удалось создать чат для проекта: " + error.getMessage());
            }
        });
    }

    public void nexusDetachArtifactFromChat() {
        if (clearing || active || sandboxJob != null) return;
        nexusPythonFlushPending();
        if (artifactRepository.forChat(activeTaskId) != activeArtifactId || activeArtifactId <= 0) return;
        try {
            artifactRepository.unlinkChat(activeTaskId);
            nexusRender(null);
            toast("Чат отвязан. Файлы проекта сохранены.");
        } catch (RuntimeException error) {
            toast("Не удалось отвязать чат: " + error.getMessage());
        }
    }
    public java.util.List<NexusArtifact> nexusArtifacts() {
        return artifactRepository == null ? new ArrayList<>() : artifactRepository.list(pythonProjects());
    }
    public void nexusOpenArtifacts() {
        if (active || clearing || sandboxJob != null) {
            toast("Заверши выполнение перед переключением проектов."); return;
        }
        nexusPythonFlushPending();
        nexusRender(null);
        if (nexusUi != null) nexusUi.selectPage(NexusComposeUi.Page.ARTIFACTS);
    }
    public void nexusOpenArtifact(long id) {
        if (active || clearing || sandboxJob != null) {
            toast("Заверши выполнение перед переключением проектов."); return;
        }
        nexusPythonFlushPending();
        if (!artifactRepository.exists(id)) { toast("Проект не найден."); return; }
        selectArtifact(id);
        nexusRender(null);
        if (nexusUi != null) nexusUi.selectPage(NexusComposeUi.Page.PROJECT);
    }
    public void nexusCreateArtifact() {
        if (active || clearing || sandboxJob != null) return;
        nexusPythonFlushPending();
        long old = activeArtifactId;
        try {
            long id = artifactRepository.createUnlinked();
            pythonProjects().putText(id, "main.py", "");
            if (!artifactRepository.touch(id, "main.py"))
                throw new IOException("Не удалось зарегистрировать проект.");
            selectArtifact(id);
            nexusRender(null);
            if (nexusUi != null) nexusUi.selectPage(NexusComposeUi.Page.PROJECT);
        } catch (IOException | RuntimeException error) {
            selectArtifact(old);
            toast("Не удалось создать проект: " + error.getMessage());
        }
    }
    public void nexusRenameArtifact(long id, String title) {
        if (!artifactRepository.rename(id, title)) toast("Не удалось переименовать проект.");
        if (nexusUi != null) nexusUi.refreshArtifacts();
    }
    public void nexusDeleteArtifact(long id) {
        if (active || clearing || sandboxJob != null) return;
        nexusPythonFlushPending();
        if (!artifactRepository.delete(id)) { toast("Не удалось удалить проект."); return; }
        pythonProjects().deleteTask(id);
        synchronized (pythonReportLock) {
            deletedPythonReportProjects.add(id);
            new PythonLastRunStore(this, true).deleteTask(id);
        }
        if (activeArtifactId == id) selectArtifact(0);
        nexusRender(null);
        if (nexusUi != null) nexusUi.selectPage(NexusComposeUi.Page.ARTIFACTS);
    }

    /** Allocate a project without requiring a message, model, or a title in chat history. */
    private long ensurePythonArtifact() throws IOException {
        try {
            if (activeArtifactId > 0) {
                if (!artifactRepository.exists(activeArtifactId))
                    throw new IOException("Проект удалён или недоступен.");
                return activeArtifactId;
            }
            long created = artifactRepository.createUnlinked();
            selectArtifact(created);
            return created;
        } catch (android.database.SQLException e) {
            throw new IOException("Не удалось создать запись артефакта.", e);
        }
    }

    private void savedPythonArtifact(long id, String path) throws IOException {
        try {
            if (!artifactRepository.touch(id, path))
                throw new IOException("Файл сохранён, но запись проекта отсутствует.");
        } catch (android.database.SQLException error) {
            throw new IOException("Файл сохранён, но каталог проектов недоступен.", error);
        }
        if (nexusUi != null) nexusUi.projectCreated(id);
    }

    /** Identifiers only: no code, API keys, messages, or file contents are exposed. */
    public String nexusPythonHistoryDiagnostic() {
        StringBuilder report = new StringBuilder("Nexus AI 0.7.0 · Python chat history\n")
                .append("Activity chat ID: ").append(activeTaskId).append('\n');
        try {
            report.append("Compose chat ID: ").append(nexusUi == null ? "none" : nexusUi.getTaskId())
                    .append("\nSQLite selected chat ID: ").append(repository.activeId())
                    .append("\nPreferences chat ID: ").append(data.getLong(ACTIVE_TASK, 0))
                    .append("\nWorkspace chat ID: ").append(store == null ? 0 : store.current().taskId)
                    .append("\nActive artifact ID: ").append(activeArtifactId)
                    .append('\n');
            long[] projectIds = pythonProjects().savedTaskIds();
            try {
                report.append("Current Python file count: ")
                        .append(activeArtifactId <= 0 ? 0 : pythonProjects().paths(activeArtifactId).length).append('\n');
            } catch (IOException error) {
                report.append("Current Python files: unreadable\n");
            }
            List<TaskRepository.Entry> listed = repository.list();
            report.append("History entries: ").append(listed.size())
                    .append("\nArtifact catalog entries: ").append(nexusArtifacts().size())
                    .append("\nSaved Python project IDs: ").append(projectIds.length).append('\n');
            TaskRepository.Entry activeRow = repository.load(activeTaskId);
            report.append("Active SQLite row: ").append(activeRow == null ? "MISSING" : "present")
                    .append('\n');
            for (int i = 0; i < projectIds.length && i < 30; i++) {
                long id = projectIds[i];
                boolean visible = false;
                for (NexusArtifact candidate : nexusArtifacts())
                    if (candidate.id == id) { visible = true; break; }
                report.append("Artifact ").append(id)
                        .append(": catalog=").append(artifactRepository.exists(id))
                        .append(", artifactsScreen=").append(visible).append('\n');
            }
            if (projectIds.length > 30) report.append("More projects omitted: ")
                    .append(projectIds.length - 30).append('\n');
        } catch (RuntimeException error) {
            report.append("Diagnostic error: ").append(error.getClass().getSimpleName());
        }
        return report.toString();
    }

    public void nexusPythonStageFile(long taskId, String path, String text) {
        if (pendingPythonSave != null) pythonSaveHandler.removeCallbacks(pendingPythonSave);
        pendingPythonSave = () -> {
            pendingPythonSave = null;
            try {
                if (taskId != activeTaskId) return; // Stale Compose editor.
                long projectId = ensurePythonArtifact();
                pythonProjects().putText(projectId, path, text);
                savedPythonArtifact(projectId, path);
                if (nexusUi != null) nexusUi.pythonFileSaved(taskId, path);
            } catch (IOException error) { toast("Не удалось сохранить файл Python: " + error.getMessage()); }
        };
        pythonSaveHandler.postDelayed(pendingPythonSave, 650);
    }

    public void nexusPythonFlushPending() {
        if (pendingPythonSave != null) {
            pythonSaveHandler.removeCallbacks(pendingPythonSave);
            Runnable save = pendingPythonSave;
            pendingPythonSave = null;
            save.run();
        }
    }

    public NexusPythonReport nexusPythonRestoredReport() {
        SandboxClient.Result saved = new PythonLastRunStore(this, true).load(activeArtifactId);
        if (saved == null) return null;
        return new NexusPythonReport(saved.engine, saved.stdout, saved.stderr, saved.status,
                "", saved.exitCode, !saved.pngBase64.isEmpty() || !saved.html.isEmpty(),
                saved.artifacts.toString(), saved.tests.toString(), saved.snapshotSha256);
    }

    public String[] nexusPythonRestoredVisual() {
        SandboxClient.Result saved = new PythonLastRunStore(this, true).load(activeArtifactId);
        return saved == null ? new String[]{"", ""} : new String[]{saved.pngBase64, saved.html};
    }

    public String[] nexusPythonPaths() {
        if (activeArtifactId <= 0) return new String[0];
        try { return pythonProjects().paths(activeArtifactId); }
        catch (IOException e) { toast(e.getMessage()); return new String[0]; }
    }

    public String nexusPythonRead(String path) {
        if (activeArtifactId <= 0) return "";
        try { return pythonProjects().text(activeArtifactId, path); }
        catch (IOException e) { toast(e.getMessage()); return ""; }
    }

    public byte[] nexusPythonBytes(String path) {
        if (activeArtifactId <= 0) return null;
        try { return pythonProjects().bytes(activeArtifactId, path); }
        catch (IOException e) { toast(e.getMessage()); return null; }
    }

    public String nexusPythonPut(String path, byte[] bytes) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().put(projectId, path, bytes);
            savedPythonArtifact(projectId, path);
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public String nexusPythonRemove(String path) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().remove(projectId, path);
            savedPythonArtifact(projectId, "main.py");
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public String nexusPythonRename(String from, String to) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().rename(projectId, from, to);
            savedPythonArtifact(projectId, to);
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public String nexusPythonImportZip(byte[] body) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().importZip(projectId, body);
            savedPythonArtifact(projectId, "main.py");
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public String nexusPythonReplaceZip(byte[] body) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().replaceZip(projectId, body);
            savedPythonArtifact(projectId, "main.py");
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public boolean nexusPythonHasPreviousProject() {
        return activeArtifactId > 0 && pythonProjects().hasPrevious(activeArtifactId);
    }

    public String nexusPythonRestorePreviousProject() {
        if (sandboxJob != null) return "Завершите Python перед восстановлением проекта.";
        nexusPythonFlushPending();
        try {
            if (activeArtifactId <= 0) throw new IOException("Нет проекта для восстановления.");
            pythonProjects().restorePrevious(activeArtifactId);
            savedPythonArtifact(activeArtifactId, "main.py");
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public byte[] nexusPythonExportZip() {
        nexusPythonFlushPending();
        if (activeArtifactId <= 0) { toast("Сначала сохрани проект."); return null; }
        try { return pythonProjects().exportZip(activeArtifactId); }
        catch (IOException e) { toast(e.getMessage()); return null; }
    }

    public boolean nexusExecutePythonProject(String entry, String code, String stdin,
                                              String allowedPackage, boolean extended) {
        if (clearing || active || sandboxJob != null || !PythonProjectStore.validPath(entry)
                || !entry.endsWith(".py")) return false;
        try { SandboxClient.validate(code, stdin); }
        catch (IllegalArgumentException e) { toast(e.getMessage()); return false; }
        try {
            nexusPythonFlushPending();
            long projectId = ensurePythonArtifact();
            pythonProjects().putText(projectId, entry, code);
            savedPythonArtifact(projectId, entry);
            JSONObject snapshot = pythonProjects().snapshot(projectId);
            runSandbox(run, -1, code, stdin, "", !allowedPackage.isEmpty(),
                    snapshot, entry, allowedPackage, extended);
            return true;
        } catch (IOException e) { toast("Не удалось открыть проект: " + e.getMessage()); return false; }
    }

        public boolean nexusHasPiston() { return !readPistonForEdit().isEmpty(); }

    public void nexusCancelPython() { cancelSandbox(); }

    public void nexusSendPythonError() {
        if (active || clearing || lastPythonRun != run || run == null
                || !run.hasAnswer(lastPythonStep) || lastPythonDiagnostic.isEmpty()
                || PythonVerification.environmentalDiagnostic(lastPythonDiagnostic)) return;
        boolean complete = run.complete();
        run = run.addRepair(new Workflow.RepairInput(lastPythonStep,
                lastPythonCode, lastPythonStdin, lastPythonDiagnostic));
        persistRun();
        if (complete) resumeRun();
        else renderRun(true);
    }

    public void nexusExport() { if (run != null && !active) chooseExport(); }
    public void nexusOpenVersions() {
        if (nexusUi != null) nexusUi.requestVersions();
        else showVersions();
    }
    public String[] nexusVersionLabels() {
        List<TaskRepository.Version> versions = repository.versions(activeTaskId);
        String[] titles = new String[versions.size()];
        for (int i = 0; i < versions.size(); i++)
            titles[i] = "#" + versions.get(i).number + " · " + dateLabel(versions.get(i).createdAt);
        return titles;
    }
    public String nexusVersionAnswer(int index) {
        List<TaskRepository.Version> versions = repository.versions(activeTaskId);
        if (index < 0 || index >= versions.size()) return "";
        Workflow.Run snapshot = restoreStoredRun(versions.get(index).runJson);
        if (snapshot == null) return "";
        return snapshot.complete() ? snapshot.displayAnswer(snapshot.finalIndex()) :
                snapshot.draft.text.isEmpty() ? snapshot.task : snapshot.draft.text;
    }

    private boolean askPythonTarget(String text, String earlier, Consumer<String> submit) {
        if (!PythonInputs.asksPythonPort(text) || !PythonInputs.target(text).isEmpty()
                || !PythonInputs.target(earlier).isEmpty()) return false;
        String[] labels = {getString(R.string.target_desktop), getString(R.string.target_console), getString(R.string.target_android)};
        String[] ids = {"desktop", "console", "android"};
        new AlertDialog.Builder(this).setTitle(R.string.target_question).setItems(labels, (dialog, index) ->
                submit.accept(text + "\n" + labels[index] + " [" + ids[index] + "]"))
                .setNegativeButton(R.string.action_cancel, null).show();
        return true;
    }

    public void nexusFollowUp(String clarification) {
        if (active || clearing || run == null || !run.complete()) return;
        final Workflow.Run previous = run;
        if (askPythonTarget(clarification, TaskHistory.forRepair(previous.task), this::nexusFollowUp)) return;
        submitFollowUp(previous, clarification, previous.displayAnswer(previous.finalIndex()), false);
    }

    public boolean nexusHasSourcePlan() {
        return !nexusBuffer("source_plan").isEmpty() && (run != null && !run.complete() && !active
                || !nexusBuffer("plan_visible").isEmpty());
    }

    private void saveSourcePlan(String intent, String original) {
        try {
            String digest = InputMaterial.sha256(original.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            nexusBuffer("source_plan", new JSONObject().put("change", intent).put("sha256", digest).toString());
        } catch (JSONException invalid) { throw new IllegalStateException(invalid); }
    }

    public void nexusOpenSourcePlan() {
        if (active || clearing || run == null) return;
        try {
            nexusBuffer("plan_visible","1");
            JSONObject plan = new JSONObject(nexusBuffer("source_plan"));
            String intent = plan.getString("change");
            String expected = plan.getString("sha256");
            List<Workflow.Run> versions = new ArrayList<>();
            versions.add(run);
            for (TaskRepository.Version saved : repository.versions(activeTaskId)) {
                Workflow.Run archived = restoreStoredRun(saved.runJson);
                if (archived != null) versions.add(archived);
            }
            for (Workflow.Run version : versions) {
                if (!version.complete()) continue;
                String answer = version.displayAnswer(version.finalIndex());
                String source = PythonInputs.singleSourceOrAnswer(answer);
                if (!expected.equals(InputMaterial.sha256(source.getBytes(java.nio.charset.StandardCharsets.UTF_8)))) continue;
                List<String> sections = TaskHistory.sections(source);
                String[] labels = new String[sections.size()];
                for (int i=0, offset=0; i<labels.length; i++) {
                    int end = offset + sections.get(i).length();
                    labels[i] = getString(R.string.source_range, i+1, labels.length, offset+1, end);
                    offset = end;
                }
                new AlertDialog.Builder(this).setTitle(R.string.source_plan).setItems(labels, (dialog,index) ->
                        submitFollowUp(version, intent + "\n" + labels[index] + ". Разбери только указанную часть. "
                                + "Остальные части и программа целиком не проверены.", sections.get(index), true))
                        .setNegativeButton(R.string.action_cancel,null).show();
                return;
            }
            toast(getString(R.string.error_save_version));
        } catch (JSONException invalid) { toast(getString(R.string.error_save_version)); }
    }

    private void submitFollowUp(Workflow.Run previous, String clarification, String source, boolean scoped) {
        final Workflow.Run versionToSave = run;
        String prompt;
        final AttachmentStore.Prepared materials;
        try {
            materials = prepareMessage(clarification);
            prompt = TaskHistory.followUp(PythonInputs.withoutMaterials(TaskHistory.forRepair(previous.task)),
                    source, materials.getTask());
        } catch (AttachmentProblem e) {
            toast(AttachmentMessages.format(this, e.code, e.detail)); return;
        } catch (IllegalArgumentException e) {
            if (!scoped && source.length() > 6000) {
                saveSourcePlan(clarification, PythonInputs.singleSourceOrAnswer(source));
                nexusRender(null);
                nexusOpenSourcePlan();
            } else toast(e.getMessage());
            return;
        }
        Workflow.Run next = (selectedMode == Workflow.Mode.QUICK
                ? Workflow.Run.quick(prompt, quickModel(), stages.get(Workflow.Step.REVIEW.ordinal())).withMaterials(materials.getRefs())
                : new Workflow.Run(prompt, stages).withMaterials(materials.getRefs()))
                .withUserTestTask(previous.userTestTask() + "\n\n" + materials.getTask());
        if (modelsFor(next).models.isEmpty()) {
            toast(getString(R.string.error_no_models));
            return;
        }
        persistBeforeSwitch(() -> {
            try {
                if (!repository.preserveVersion(activeTaskId, versionToSave.toJson().toString())) {
                    toast(getString(R.string.error_save_version));
                    return;
                }
            } catch (JSONException | RuntimeException e) {
                toast(getString(R.string.error_save_version));
                return;
            }
            workExpanded = false;
            if (!scoped) {
                nexusBuffer("plan_visible", "");
                if (source.length() > 6000) saveSourcePlan(clarification, PythonInputs.singleSourceOrAnswer(source));
                else nexusBuffer("source_plan", "");
            }
            begin(next.withFallbackPolicy(nexusAllowFallback()));
        });
    }

    private static boolean isUserDarkTheme(Configuration configuration, String preference) {
        if ("dark".equals(preference)) return true;
        if ("light".equals(preference)) return false;
        return (configuration.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }
    /** Keep Android 12+ native splash colors aligned with the user's app theme. */
    private void syncPlatformSplashTheme(String preference) {
        if (Build.VERSION.SDK_INT < 31) return;
        UiModeManager manager = getSystemService(UiModeManager.class);
        if (manager == null) return;
        final int mode;
        if ("dark".equals(preference)) mode = UiModeManager.MODE_NIGHT_YES;
        else if ("light".equals(preference)) mode = UiModeManager.MODE_NIGHT_NO;
        else {
            // For application-local mode, AUTO clears a package-specific night
            // override and restores the normal system-selected day/night mode.
            mode = UiModeManager.MODE_NIGHT_AUTO;
        }
        // Avoid repeated configuration changes when Android recreates Activity.
        if (data.getInt("splash_platform_night_mode", -1) == mode) return;
        if (!data.edit().putInt("splash_platform_night_mode", mode).commit()) return;
        try {
            manager.setApplicationNightMode(mode);
        } catch (RuntimeException ignored) {
            data.edit().remove("splash_platform_night_mode").apply();
            // A vendor ROM may reject this per-app API; Compose still applies
            // the saved preference and the UI remains usable.
        }
    }

    public String nexusThemeChoice() { return data.getString("ui_theme", "system"); }
    public String nexusLanguageChoice() { return data.getString("ui_language", "system"); }
    public void nexusThemeChanged(String theme) {
        if (!theme.equals("light") && !theme.equals("dark") && !theme.equals("system")) return;
        data.edit().putString("ui_theme", theme).apply();
        if (nexusUi != null) nexusUi.onThemeChanged(theme);
        // Changing the platform night mode can recreate Activity. Never risk
        // cancelling an active AI request or Python execution for a splash color.
        if (!active && sandboxJob == null && automaticPython == null)
            syncPlatformSplashTheme(theme);
    }
    public void nexusLanguageChanged(String language) {
        if (active || clearing) { toast(getString(R.string.error_change_language_active)); return; }
        if (!language.equals("system") && !language.equals("ru") && !language.equals("en")
                && !language.equals("zh-CN") && !language.equals("ar") && !language.equals("ja")) return;
        if (language.equals(nexusLanguageChoice())) return;
        if (data.edit().putString("ui_language", language).commit()) recreate();
    }

    @Override protected void attachBaseContext(Context base) {
        SharedPreferences preferences = base.getSharedPreferences("workspace", Context.MODE_PRIVATE);
        String language = preferences.getString("ui_language", "system");
        String appearance = preferences.getString("ui_theme", "system");
        boolean customLanguage = language != null && !"system".equals(language);
        boolean customTheme = "light".equals(appearance) || "dark".equals(appearance);
        if (!customLanguage && !customTheme) { super.attachBaseContext(base); return; }
        Configuration configuration = new Configuration(base.getResources().getConfiguration());
        if (customLanguage) {
            Locale locale = Locale.forLanguageTag(language);
            configuration.setLocale(locale);
            configuration.setLayoutDirection(locale);
        }
        if (customTheme) {
            configuration.uiMode = (configuration.uiMode & ~Configuration.UI_MODE_NIGHT_MASK)
                    | ("dark".equals(appearance)
                    ? Configuration.UI_MODE_NIGHT_YES : Configuration.UI_MODE_NIGHT_NO);
        }
        super.attachBaseContext(base.createConfigurationContext(configuration));
    }

    private TextView consoleText(String value, int color) {
        TextView output = selectable(value, 14, color);
        output.setTypeface(Typeface.MONOSPACE);
        return output;
    }

    private void cancelSandbox() {
        SandboxJob job = sandboxJob;
        if (job == null) return;
        sandboxJob = null;
        if (job.local != null) job.local.cancel();
        if (job.future != null) {
            job.future.cancel(true);
            new Thread(job.cancellation::cancel, "cancel-sandbox").start();
        }
        if (job.progress != null) job.progress.dismiss();
        if (nexusUi != null) nexusUi.pythonCancelled();
    }

    private String preview(String text) {
        if (text.length() <= ANSWER_PREVIEW) return text;
        int end = Character.isLowSurrogate(text.charAt(ANSWER_PREVIEW))
                ? ANSWER_PREVIEW - 1 : ANSWER_PREVIEW;
        return text.substring(0, end) + "…";
    }

    private void showText(String title, String value) {
        LinearLayout form = dialogForm();
        TextView answer = selectable(value, 15, FG);
        answer.setLineSpacing(dp(4), 1f);
        add(form, answer, 0);
        ScrollView area = new ScrollView(this);
        area.addView(form);
        new AlertDialog.Builder(this).setTitle(title).setView(area)
                .setPositiveButton("Закрыть", null).show();
    }

    private AttachmentStore.Prepared prepareMessage(String task) throws AttachmentProblem {
        AttachmentStore.Prepared materials = AttachmentStore.get(this).prepare(activeTaskId, task,
                run == null ? java.util.Collections.emptyList() : run.materials);
        boolean hasImages = false;
        for (InputMaterial.Ref ref : materials.getRefs()) if (ref.isImage()) hasImages = true;
        if (hasImages) {
            List<ModelCatalog.Model> selected = new ArrayList<>();
            if (selectedMode == Workflow.Mode.QUICK) selected.add(quickModel());
            else for (Workflow.Stage stage : stages) selected.add(stage.model);
            for (ModelCatalog.Model chosen : selected) {
                ModelCatalog.Model details = catalog.details(chosen);
                if (details.provider != Workflow.Provider.OPENROUTER || !details.imageInput)
                    throw new AttachmentProblem(AttachmentProblem.Code.MODEL_IMAGES, details.label);
            }
        }
        return materials;
    }

    private void startRun() {
        if (active || clearing) return;
        startRun(taskDraft.trim());
    }

    private void startRun(String task) {
        if (askPythonTarget(task, "", this::startRun)) return;
        if (task.isEmpty()) {
            toast(getString(R.string.error_empty_task));
            return;
        }
        if (task.length() > Workflow.TASK_LIMIT) {
            toast(getString(R.string.error_task_too_long));
            return;
        }
        AttachmentStore.Prepared materials;
        try {
            materials = prepareMessage(task);
        } catch (AttachmentProblem e) {
            toast(AttachmentMessages.format(this, e.code, e.detail));
            return;
        }
        InputMethodManager keyboard = getSystemService(InputMethodManager.class);
        if (keyboard != null && getWindow().getDecorView().getWindowToken() != null)
            keyboard.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
        Workflow.Run next = selectedMode == Workflow.Mode.QUICK
                ? Workflow.Run.quick(materials.getTask(), quickModel(), stages.get(Workflow.Step.REVIEW.ordinal())).withMaterials(materials.getRefs())
                : new Workflow.Run(materials.getTask(), stages).withMaterials(materials.getRefs());
        if (run == null) {
            begin(next.withFallbackPolicy(nexusAllowFallback()));
        } else {
            // Starting again never silently overwrites a completed (or partial) run.
            Workflow.Run previous = run;
            persistBeforeSwitch(() -> {
                try {
                    if (!repository.preserveVersion(activeTaskId, previous.toJson().toString())) {
                        toast("Не удалось сохранить предыдущий разбор.");
                        return;
                    }
                } catch (JSONException | RuntimeException e) {
                    toast("Не удалось сохранить предыдущую версию.");
                    return;
                }
                workExpanded = false;
                begin(next.withFallbackPolicy(nexusAllowFallback()));
            });
        }
    }

    private void resumeRun() {
        if (active || clearing || run == null || run.complete()) return;
        begin(run);
    }

    private StagePool modelsFor(Workflow.Run input) {
        EnumMap<Workflow.Provider, String> keys = new EnumMap<>(Workflow.Provider.class);
        for (Workflow.Provider provider : Workflow.Provider.values()) keys.put(provider, readForEdit(provider));
        List<ModelCatalog.Model> models = ModelPool.candidates(catalog, input.nextStep(), input.nextStage().selected,
                !keys.get(Workflow.Provider.OPENROUTER).isEmpty(), !keys.get(Workflow.Provider.GROQ).isEmpty(),
                data.getBoolean(GROQ_RESERVE, false), !keys.get(Workflow.Provider.GEMINI).isEmpty());
        Workflow.Stage stage = input.nextStage();
        if (!stage.allowFallback) models.removeIf(item -> !item.id.equals(stage.selected.id));
        StagePool pool = new StagePool(models, keys);
        if (!catalog.available(stage.selected)) pool.failures.add(getString(R.string.route_missing));
        else if (keys.get(stage.selected.provider).isEmpty()) pool.failures.add(keyMessage(stage));
        return pool;
    }

    private String keyMessage(Workflow.Stage stage) {
        return "Для шага «" + stage.role + "» нужен ключ " + stage.selected.provider.label + ".";
    }

    private void begin(Workflow.Run input) {
        StagePool pool = modelsFor(input);
        if (pool.models.isEmpty()) {
            if (!catalog.available(input.nextStage().selected)) toast(getString(R.string.route_missing));
            else showKeys(keyMessage(input.nextStage()) + " Подключи доступную модель для этого шага.");
            return;
        }
        try {
            AttachmentStore.get(this).retain(activeTaskId, input.materials);
        } catch (IOException e) {
            toast(AttachmentMessages.format(this, AttachmentProblem.Code.IO, ""));
            return;
        }
        if (input != run) attemptHistory = "";
        stagePool = pool;
        if (input.nextIndex() == 0 && input.draft.text.isEmpty()) {
            String goals = TaskHistory.forRepair(input.task);
            String target = PythonInputs.target(goals);
            if (target.equals("android") || target.equals("desktop")) toast(getString(R.string.widget_external));
            else if (PythonInputs.defaultWidget(goals)) toast(getString(R.string.widget_format));
        }
        active = true;
        run = input.withNote("");
        resultsVisible = true;
        requestNextModel(false);
    }

    private void requestNextModel(boolean keepPosition) {
        String missing = run.missingInput();
        if (!missing.isEmpty()) {
            pause(missing);
            return;
        }
        int next = availableCandidate();
        if (next < 0) {
            pause(exhaustedNote(""));
            return;
        }
        if (run.verification.status == PythonVerification.Status.REPAIRING) {
            if (run.verification.requests >= PythonVerification.MAX_REQUESTS) {
                pause(getString(R.string.verify_budget));
                return;
            }
            run = run.withVerification(run.verification.dispatch());
        }
        ModelCatalog.Model model = stagePool.models.get(next);
        stagePool.next = next + 1;
        stagePool.dispatched++;
        String key = stagePool.keys.get(model.provider);
        StagePool pool = stagePool;
        String reason = "";
        if (!model.id.equals(run.nextStage().selected.id)) {
            reason = pool.failures.isEmpty() ? getString(R.string.route_busy) : pool.failures.get(pool.failures.size()-1);
        }
        run = run.withExecutor(model, reason);
        Attempt current = new Attempt(run);
        attempt = current;
        persistRun();
        renderRun(keepPosition);
        current.deadline = () -> {
            if (attempt != current || clearing) return;
            current.timedOut = true;
            // Invalidate the old HTTP call before beginning a fallback; its late
            // callback is ignored because receive() clears the current attempt.
            if (current.future != null) current.future.cancel(true);
            disconnect(current.cancellation);
            receive(current, ModelClient.Reply.error(current.received,
                    "Превышено время ожидания модели. Получено символов: " + current.received.length(), 408));
        };
        progressHandler.postDelayed(current.deadline, ModelClient.REQUEST_TIMEOUT_MS);
        try {
            current.future = worker.submit(() -> {
                ModelClient.Reply reply;
                try {
                    reply = client.complete(current.input, model, key, current.cancellation, text -> {
                        current.received = text;
                        runOnUiThread(() -> {
                            if (attempt != current || isDestroyed() || clearing) return;
                            if (text.length() > current.checkpointLength) {
                                current.checkpointLength = text.length();
                                long remaining = 4L * ModelClient.REQUEST_TIMEOUT_MS - (android.os.SystemClock.elapsedRealtime() - current.started);
                                progressHandler.removeCallbacks(current.deadline);
                                progressHandler.postDelayed(current.deadline, Math.max(0, Math.min(remaining, ModelClient.REQUEST_TIMEOUT_MS)));
                            }
                            scheduleCheckpoint();
                            if (nexusUi != null) nexusUi.onStreaming(text);
                            if (liveText != null) {
                                int start = Math.max(0, text.length() - 3500);
                                liveText.setText(text.substring(start));
                            }
                            if (liveStatus != null) liveStatus.setText("Получено " + text.length() + " символов");
                        });
                    }, AttachmentStore.get(this).images(activeTaskId, current.input.materials));
                } catch (AttachmentProblem e) {
                    reply = ModelClient.Reply.error("", AttachmentMessages.format(this, e.code, e.detail), 400);
                } catch (ModelClient.Problem e) {
                    reply = ModelClient.Reply.error("", e.getMessage(), e.failure);
                } catch (IOException e) {
                    reply = ModelClient.Reply.error("", "Нет ответа по сети. Проверь соединение.");
                } catch (JSONException e) {
                    reply = ModelClient.Reply.error("", "Не удалось прочитать ответ модели.");
                }
                ModelClient.Reply finished = verifyRouterFailure(reply, model, key, current, pool);
                runOnUiThread(() -> receive(current, finished));
            });
        } catch (RejectedExecutionException busy) {
            progressHandler.removeCallbacks(current.deadline);
            attempt = null;
            pause("Сетевые потоки заняты отменяемыми запросами. "
                    + "Подожди освобождения соединений и нажми «Продолжить разбор».");
        }
    }

    private void disconnect(ModelClient.Cancellation cancellation) {
        try {
            cancellationWorker.execute(cancellation::cancel);
        } catch (RejectedExecutionException closed) {
            // Activity is closing. Cancellation is already signalled by future.cancel().
        }
    }

    private ModelClient.Reply verifyRouterFailure(ModelClient.Reply reply, ModelCatalog.Model model,
                                                 String key, Attempt current, StagePool pool) {
        if (model.provider != Workflow.Provider.OPENROUTER
                || reply.failure.reason != RequestFailure.Reason.UNKNOWN) return reply;
        try {
            if (reply.status == 429 && !pool.quotaChecked) {
                pool.quotaChecked = true;
                if (client.routerDailyQuotaExhausted(key, current.cancellation)) {
                    return ModelClient.Reply.error(reply.text,
                            "По данным OpenRouter, дневная квота моделей :free исчерпана.",
                            reply.failure.dailyQuota(System.currentTimeMillis()));
                }
            }
            if (reply.status == 404 && !pool.catalogChecked) {
                pool.catalogChecked = true;
                ModelCatalog updated = client.models(current.cancellation);
                if (updated.routerCount() > 0 && !updated.available(model)) {
                    return ModelClient.Reply.error(reply.text, "Этой модели больше нет в бесплатном каталоге.",
                            reply.failure.unavailable());
                }
            }
        } catch (IOException | JSONException | ModelClient.Problem ignored) {
            // Keep the actual provider error when the diagnostic query fails.
        }
        return reply;
    }

    private void receive(Attempt current, ModelClient.Reply reply) {
        if (attempt != current || isDestroyed()) return;
        progressHandler.removeCallbacks(current.deadline);
        attempt = null;
        if (reply.finish == ModelClient.Finish.ERROR && reply.text.isEmpty() && !current.received.isEmpty()) {
            reply = ModelClient.Reply.error(current.received, reply.problem, reply.failure);
        }
        run = current.input.receive(reply);
        if (ModelPool.shouldTryNext(reply)) {
            ModelCatalog.Model attempted = current.input.nextStage().model;
            long now = System.currentTimeMillis();
            cooldowns.record(attempted, reply.failure, now);
            data.edit().putString("route_retry_times",cooldowns.snapshot(now)).apply();
            if (reply.failure.reason == RequestFailure.Reason.TOKEN_RATE_LIMIT || reply.failure.reason == RequestFailure.Reason.DAILY_QUOTA)
                stagePool.blockedProviders.add(attempted.provider);
            stagePool.failures.add(attempted.label + " · " + (current.timedOut ? getString(R.string.local_timeout) : reply.status == 0 ? getString(R.string.transport_error)
                    : "HTTP " + reply.status + " · " + reply.failure.reason.name()));
            int next = availableCandidate();
            boolean retry = next >= 0 && !(run.verification.status == PythonVerification.Status.REPAIRING
                    && run.verification.requests >= PythonVerification.MAX_REQUESTS);
            recordAttempt(current, reply, retry ? stagePool.models.get(next) : null,
                    current.timedOut ? "TIMEOUT" : "");
            if (retry) {
                requestNextModel(true);
                return;
            }
            pause(next >= 0 ? getString(R.string.verify_budget) + "\n" + reply.problem : exhaustedNote(reply.problem));
            return;
        }
        recordAttempt(current, reply, null, current.timedOut ? "TIMEOUT" : "");
        if (!run.complete() && run.note.isEmpty() && run.nextStep() == Workflow.Step.REVIEW
                && (startWebCheck(current.input.nextIndex()) || startPythonPreReview(current.input.nextIndex()))) return;
        if (!run.complete() && run.note.isEmpty()) {
            stagePool = modelsFor(run);
            if (!stagePool.models.isEmpty()) requestNextModel(true);
            else pause(keyMessage(run.nextStage()));
            return;
        }
        if (!run.complete() && run.verification.status == PythonVerification.Status.REPAIRING) {
            pause(run.note);
            return;
        }
        if (run.complete() && startWebCheck(current.input.nextIndex())) return;
        if (run.complete() && (run.mode == Workflow.Mode.QUICK || current.input.nextStep() == Workflow.Step.REVISION || current.input.nextStep() == Workflow.Step.REPAIR)
                && startVerification(current.input.nextIndex())) return;
        finishRunUi();
    }

    private boolean startPythonPreReview(int index) {
        Workflow.Run owner = run;
        PythonInputs.Candidate file = PythonInputs.candidate(owner.displayAnswer(index));
        if (file == null) return false;
        final long taskId=activeTaskId;
        Consumer<JSONObject> finish = report -> {
            if (run!=owner || !active || clearing || isDestroyed() || activeTaskId!=taskId) return;
            automaticPython=null;
            try {
                report.put("language","python").put("sha256", InputMaterial.sha256(file.code.getBytes(StandardCharsets.UTF_8)));
                run=owner.withWebCheck(index,report);
            } catch (JSONException malformed) { run=owner; }
            continueAfterCheck();
        };
        Consumer<String> limited = reason -> {
            try { finish.accept(new JSONObject().put("status","LIMITED").put("diagnostic",reason)); }
            catch (JSONException invalid) { throw new IllegalStateException(invalid); }
        };
        try {
            JSONObject request=PythonInputs.request(owner,file.code);
            if (file.ambiguous || !file.issue.isEmpty() || InputMaterial.utf8(file.code)>64_000) {
                limited.accept(file.issue.isEmpty() ? getString(R.string.verify_source_limit) : file.issue);
            } else {
                persistRun();
                automaticPython = new LocalSandbox(null, limited::accept);
                automaticPython.verify(this,request,progress -> {},finish::accept);
            }
        } catch (JSONException | RuntimeException unavailable) { limited.accept(getString(R.string.verify_protocol)); }
        return true;
    }

    private void continueAfterCheck() {
        if (run.complete()) finishRunUi();
        else {
            persistRun();
            stagePool=modelsFor(run);
            if (stagePool.models.isEmpty()) pause(keyMessage(run.nextStage()));
            else requestNextModel(true);
        }
    }

    private android.webkit.WebView checkingWeb;
    private Runnable webDeadline;

    private boolean startWebCheck(int index) {
        Workflow.Run owner = run;
        String answer = owner.displayAnswer(index);
        String html = PythonInputs.webSource(answer, "html");
        String kind = html.isEmpty() ? "javascript" : "html";
        String source = html.isEmpty() ? PythonInputs.webSource(answer, kind) : html;
        String goals = TaskHistory.forRepair(owner.task);
        boolean missingHtml = source.isEmpty() && PythonInputs.defaultWidget(goals) && !PythonInputs.hasNamedFiles(answer);
        if (source.isEmpty() && !missingHtml) return false;
        if (PythonInputs.asksPythonPort(goals) && PythonInputs.candidate(answer)!=null) return false;
        JSONArray required = PythonInputs.requiredFeatures(goals);
        persistRun();
        final long taskId = activeTaskId;
        Consumer<JSONObject> finish = result -> {
            if (run != owner || activeTaskId != taskId || isDestroyed() || clearing) return;
            releaseWebCheck();
            try {
                JSONObject check = result == null ? new JSONObject().put("status","UNAVAILABLE") : result;
                if (result != null && !"UNAVAILABLE".equals(check.optString("status")))
                    check.put("status", result.getJSONArray("issues").length()==0 ? "SYNTAX_CHECKED" : "SYNTAX_ERROR");
                JSONArray tests = check.optJSONArray("tests");
                boolean observed = false;
                if (tests != null) for (int i=0;i<tests.length();i++) {
                    JSONObject t=tests.optJSONObject(i);
                    if (t!=null && ("pass".equals(t.optString("status")) || "fail".equals(t.optString("status")))) observed=true;
                }
                check.put("language",missingHtml ? "html" : kind).put("functional_tests",observed)
                        .put("sha256", InputMaterial.sha256(source.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
                run = owner.withWebCheck(index, check);
                if (run.complete() && kind.equals("html") && Workflow.Run.failedWeb(check)
                        && run.repairs.stream().noneMatch(r -> r.language.equals("html"))) {
                    run=run.addRepair(new Workflow.RepairInput(index,source,"",check.toString(),"html"));
                }
            } catch (JSONException ignored) { run = owner; }
            continueAfterCheck();
        };
        if (missingHtml) {
            try { finish.accept(new JSONObject().put("issues",new JSONArray().put(getString(R.string.widget_missing)))); }
            catch (JSONException unexpected) { finish.accept(null); }
            return true;
        }
        try {
            checkingWeb = app.svyazka.mobile.ui.WebWorkspaceKt.inspectWebFile(this,source,kind,required,
                    parsed -> progressHandler.post(() -> finish.accept(parsed)));
            checkingWeb.setFocusable(false);
            checkingWeb.setImportantForAccessibility(android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            android.widget.FrameLayout content=findViewById(android.R.id.content);
            content.addView(checkingWeb,0,new android.widget.FrameLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
            webDeadline = () -> finish.accept(null);
            progressHandler.postDelayed(webDeadline, 12_000);
        } catch (RuntimeException unavailable) { finish.accept(null); }
        return true;
    }

    private void releaseWebCheck() {
        if (webDeadline != null) progressHandler.removeCallbacks(webDeadline);
        webDeadline = null;
        android.webkit.WebView view = checkingWeb;
        checkingWeb = null;
        if (view != null) {
            if (view.getParent() instanceof android.view.ViewGroup)
                ((android.view.ViewGroup)view.getParent()).removeView(view);
            view.stopLoading();
            view.destroy();
        }
    }

    public String nexusWebStatus() {
        if (run == null || !run.complete()) return "";
        JSONObject check = run.answerAt(run.finalIndex()).webCheck;
        if (check == null) return "";
        if (!"SYNTAX_CHECKED".equals(check.optString("status"))) {
            JSONArray issues = check.optJSONArray("issues");
            return issues != null && issues.length()>0 ? issues.optString(0) : getString(R.string.web_check_error);
        }
        String status = getString(R.string.web_counts, check.optInt("checked"), check.optInt("external"));
        JSONArray tests=check.optJSONArray("tests");
        if (tests!=null) for (int i=0;i<tests.length();i++) {
            JSONObject t=tests.optJSONObject(i);
            if (t==null) continue;
            String id=t.optString("id");
            String[] ids={"clock.tick","calendar.current","calendar.december","calendar.january","calendar.leap","weather.current","weather.leap","weather.offline","bluetooth.device","calendar.nextyear"};
            String[] names=getResources().getStringArray(R.array.widget_tests);
            int n=java.util.Arrays.asList(ids).indexOf(id);
            int outcome="pass".equals(t.optString("status")) ? R.string.widget_pass : "fail".equals(t.optString("status")) ? R.string.widget_fail : R.string.widget_unverified;
            status+="\n"+(n<0 ? id : names[n])+" · "+getString(outcome);
        }
        if (run.finalIndex()!=run.nextIndex()-1 && !run.revisionSkipped()) status+="\n"+getString(R.string.widget_prior);
        if (check.optBoolean("network")) status += "\n" + getString(R.string.web_offline);
        if (check.optBoolean("bluetooth")) status += "\n" + getString(R.string.web_ble);
        return status;
    }

    private void finishRunUi() {
        active = false;
        stagePool = null;
        persistRun();
        renderRun(true);
    }

    private boolean startVerification(int index) {
        PythonVerification previous = run.verification;
        PythonInputs.Candidate candidate = PythonInputs.candidate(run.displayAnswer(index));
        if (candidate == null || candidate.ambiguous && previous.status == PythonVerification.Status.REPAIRING) {
            if (previous.status == PythonVerification.Status.NONE && candidate == null) return false;
            finishVerification(previous.stopped(getString(R.string.verify_no_code)));
            return true;
        }
        String fingerprintInput = candidate.issue + "\n" + candidate.code;
        if (previous.status == PythonVerification.Status.REPAIRING && previous.seenCode(fingerprintInput)) {
            finishVerification(previous.stopped(getString(R.string.verify_no_change) + "\n" + previous.diagnostic));
            return true;
        }
        run = run.withVerification(previous.start(index, fingerprintInput));
        active = true;
        stagePool = null;
        persistRun();
        renderRun(true);
        long generation = ++verificationGeneration;
        try {
            if (InputMaterial.utf8(candidate.code) > 64000) {
                finishVerification(run.verification.limited(getString(R.string.verify_source_limit)));
            } else if (!candidate.ambiguous && !candidate.issue.isEmpty()) {
                acceptVerification(new JSONObject().put("status", "ERROR").put("syntax", false).put("ran", false)
                        .put("passed", 0).put("total", 0).put("diagnostic", candidate.issue).put("signature","incomplete-fence").put("category","SYNTAX_ERROR"), candidate.code);
            } else {
                JSONObject request = candidate.ambiguous
                        ? new JSONObject().put("mode","verify").put("code","").put("syntax_only",new JSONArray(candidate.parts)).put("reason",candidate.issue)
                        : PythonInputs.request(run, candidate.code);
                automaticPython = new LocalSandbox(null, reason -> {
                    if (verificationCurrent(generation)) finishVerification(run.verification.limited(reason));
                });
                automaticPython.verify(this, request, event -> {
                    if (!verificationCurrent(generation)) return;
                    String phase = event.optString("stage");
                    int count = event.optInt("passed", -1), total = event.optInt("total", -1);
                    if (!(phase.equals("syntax") || phase.equals("executed")) || count < 0 || count > total || total > 24) {
                        finishVerification(run.verification.limited(getString(R.string.verify_protocol)));
                        return;
                    }
                    run = run.withVerification(run.verification.progress(true, phase.equals("executed"), count, total));
                    if (nexusUi != null) nexusUi.updateVerification();
                }, report -> {
                    if (!verificationCurrent(generation)) return;
                    try { acceptVerification(report, candidate.code); }
                    catch (JSONException e) { finishVerification(run.verification.limited(getString(R.string.verify_protocol))); }
                });
            }
        } catch (JSONException | RuntimeException e) {
            finishVerification(run.verification.limited(getString(R.string.verify_protocol) + " " + e.getMessage()));
        }
        return true;
    }

    private boolean verificationCurrent(long generation) {
        return generation == verificationGeneration && active && !isDestroyed() && run != null
                && run.verification.status == PythonVerification.Status.CHECKING;
    }

    private void acceptVerification(JSONObject report, String code) throws JSONException {
        automaticPython = null;
        PythonVerification check = run.verification.report(report);
        if ("REQUIREMENTS_CHANGED".equals(check.category()) && !run.repairs.isEmpty()) {
            int before = run.repairs.get(run.repairs.size() - 1).sourceIndex;
            finishVerification(check.keepPrevious(before, check.diagnostic));
            return;
        }
        if (check.status != PythonVerification.Status.ERROR || run.mode == Workflow.Mode.QUICK) {
            finishVerification(check);
            return;
        }
        run = run.addRepair(new Workflow.RepairInput(check.source, code, "", check.diagnostic)).withVerification(check.repair());
        stagePool = modelsFor(run);
        if (stagePool.models.isEmpty()) pause(keyMessage(run.nextStage()));
        else requestNextModel(true);
    }

    private void finishVerification(PythonVerification value) {
        verificationGeneration++;
        if (automaticPython != null) automaticPython.close();
        automaticPython = null;
        run = run.finishVerification(value);
        finishRunUi();
    }

    private int availableCandidate() {
        if (stagePool.dispatched >= ModelPool.MAX_ATTEMPTS) return -1;
        int candidate = cooldowns.next(stagePool.models, stagePool.next, System.currentTimeMillis());
        // Skip providers that already reported an exact per-minute token limit;
        // other providers remain eligible for their normal bounded fallback.
        while (candidate >= 0) {
            ModelCatalog.Model model = stagePool.models.get(candidate);
            try {
                Workflow.Run routed = run.withExecutor(model, "");
                long estimate = ModelClient.estimatedInput(routed);
                int output = ModelClient.requestedOutput(routed, model, estimate);
                if (output < routed.minimumOutput()) {
                    String detail = model.label + " · " + getString(R.string.budget_short);
                    if (!stagePool.failures.contains(detail)) stagePool.failures.add(detail);
                    candidate = cooldowns.next(stagePool.models, candidate + 1, System.currentTimeMillis());
                    continue;
                }
            } catch (JSONException invalid) { return -1; }
            if (!stagePool.blockedProviders.contains(model.provider)
                    && (!run.hasImages() || model.provider == Workflow.Provider.OPENROUTER
                    && model.imageInput)) return candidate;
            if (run.hasImages() && !stagePool.blockedProviders.contains(model.provider)) {
                String skipped = AttachmentMessages.format(this, AttachmentProblem.Code.MODEL_IMAGES, model.label);
                if (!stagePool.failures.contains(skipped)) stagePool.failures.add(skipped);
            }
            candidate = cooldowns.next(stagePool.models, candidate + 1, System.currentTimeMillis());
        }
        return -1;
    }

    private String exhaustedNote(String reason) {
        long retry = cooldowns.firstRetry(stagePool.models, System.currentTimeMillis());
        String message = reason.isEmpty() ? (stagePool.failures.isEmpty() ? getString(R.string.route_busy)
                : stagePool.failures.get(stagePool.failures.size()-1)) : reason;
        if (retry > 0) message += "\n" + DateFormat.getDateTimeInstance().format(new Date(retry));
        message += "\n" + getString(run.draft.text.isEmpty() ? R.string.kept_task : R.string.kept_draft);
        message += "\n" + getString(R.string.retry_or_change);
        return message;
    }

    private void recordAttempt(Attempt current, ModelClient.Reply reply, ModelCatalog.Model next, String outcome) {
        if (clearing) return;
        try {
            JSONArray previous = attemptHistory.isEmpty() ? new JSONArray() : new JSONArray(attemptHistory);
            JSONArray journal = new JSONArray();
            for (int i = Math.max(0, previous.length() - 39); i < previous.length(); i++) journal.put(previous.get(i));
            ModelCatalog.Model model = current.input.nextStage().model;
            long inputEstimate = ModelClient.estimatedInput(current.input);
            JSONObject entry = new JSONObject().put("time", System.currentTimeMillis())
                    .put("step", current.input.nextIndex() + 1).put("provider", model.provider.label)
                    .put("selected_model", current.input.nextStage().selected.id)
                    .put("reserve", !model.id.equals(current.input.nextStage().selected.id))
                    .put("model", model.id).put("ms", android.os.SystemClock.elapsedRealtime() - current.started)
                    .put("estimated_input_tokens", inputEstimate)
                    .put("safety_margin_tokens", 1024).put("provider_token_limit", JSONObject.NULL)
                    .put("model_context", model.context == 0 ? JSONObject.NULL : model.context).put("output_limit", ModelClient.requestedOutput(current.input, model, inputEstimate))
                    .put("status", AttemptJournal.status(reply, outcome))
                    .put("has_text", !current.received.isEmpty() || (reply != null && !reply.text.isEmpty()));
            if (reply != null) {
                if (reply.status > 0 && !current.timedOut) entry.put("code", reply.status);
                else entry.put("transport", current.timedOut ? "LOCAL_TIMEOUT" : "NO_HTTP_STATUS");
                entry.put("reason", reply.failure.reason.name());
                if (reply.failure.retryAt > 0) entry.put("retry_at", reply.failure.retryAt);
            }
            if (next != null) entry.put("next_model", next.id);
            journal.put(entry);
            attemptHistory = journal.toString();
        } catch (JSONException ignored) {
            // A malformed diagnostic entry must not stop generation.
        }
    }

    private void showAttemptHistory() {
        try {
            showText("Журнал запросов", AttemptJournal.normalizeAll(new JSONArray(attemptHistory)).toString(2));
        } catch (JSONException e) {
            toast("Не удалось прочитать журнал запросов.");
        }
    }

    private void pause(String message) {
        active = false;
        stagePool = null;
        if (run.verification.busy()) {
            finishVerification(run.verification.stopped(message + "\n" + run.verification.diagnostic));
            return;
        }
        run = run.withNote(message);
        persistRun();
        renderRun(true);
    }

    private void stopRun() {
        cancelRequest();
        pause("Разбор остановлен. Полученные шаги и сохранённый черновик доступны.");
    }

    private void cancelRequest() {
        releaseWebCheck();
        Attempt current = attempt;
        attempt = null;
        stagePool = null;
        active = false;
        verificationGeneration++;
        if (automaticPython != null) automaticPython.close();
        automaticPython = null;
        if (current == null) {
            if (run != null && run.verification.busy()) { run = interrupted(run); persistRun(); }
            return;
        }
        progressHandler.removeCallbacks(current.deadline);
        recordAttempt(current, null, null, "CANCELLED");
        String partial = current.received;
        if (!partial.isEmpty()) {
            run = current.input.receive(ModelClient.Reply.error(partial, "Ответ прерван."));
        }
        if (run.verification.busy()) run = interrupted(run);
        persistRun();
        if (current.future != null) current.future.cancel(true);
        disconnect(current.cancellation);
    }

    private void editStage(int index) {
        Workflow.Stage current = stages.get(index);
        LinearLayout form = dialogForm();
        form.addView(text("Название роли", 14, MUTED, true));
        EditText title = field(current.role, "", 42, 1, false);
        add(form, title, 6);
        add(form, text("Что должен сделать ИИ", 14, MUTED, true), 14);
        EditText instructions = field(current.instruction, "", 1600, 3, false);
        add(form, instructions, 6);
        add(form, text("Модель", 14, MUTED, true), 14);
        ModelCatalog.Model[] selection = {current.model};
        Button choose = button(current.model.label + "  ▾", false, null);
        choose.setOnClickListener(view -> chooseModel(selection[0], model -> {
            selection[0] = model;
            choose.setText(model.label + "  ▾");
        }));
        add(form, choose, 6);
        AlertDialog dialog = dialog("Шаг " + (index + 1), form);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String role = title.getText().toString().trim();
            String instruction = instructions.getText().toString().trim();
            if (role.isEmpty()) {
                title.setError("Назови роль.");
                return;
            }
            if (instruction.isEmpty()) {
                instructions.setError("Добавь задание для этой роли.");
                return;
            }
            List<Workflow.Stage> updated = new ArrayList<>(stages);
            updated.set(index, new Workflow.Stage(role, instruction, selection[0]));
            try {
                data.edit().putString("stages", Workflow.stagesToJson(updated).toString()).apply();
                stages = updated;
                dialog.dismiss();
                renderTask();
            } catch (JSONException e) {
                toast("Не удалось сохранить роль.");
            }
        });
    }

    private void chooseModel(ModelCatalog.Model selected, Consumer<ModelCatalog.Model> onChoice) {
        List<ModelCatalog.Model> choices = catalog.choices();
        String[] labels = new String[choices.size()];
        int checked = -1;
        for (int i = 0; i < choices.size(); i++) {
            ModelCatalog.Model model = choices.get(i);
            labels[i] = model.label + " · " + model.provider.label;
            if (model.id.equals(selected.id)) checked = i;
        }
        AlertDialog picker = new AlertDialog.Builder(this).setTitle("Выбрать модель")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    dialog.dismiss();
                    onChoice.accept(choices.get(which));
                })
                .setNegativeButton("Отмена", null).setNeutralButton("Обновить", null).show();
        Button refresh = picker.getButton(AlertDialog.BUTTON_NEUTRAL);
        refresh.setOnClickListener(view -> {
            refresh.setEnabled(false);
            refresh.setText("Обновление…");
            refreshModels(true, problem -> {
                if (!picker.isShowing()) return;
                if (problem.isEmpty()) {
                    picker.dismiss();
                    chooseModel(selected, onChoice);
                } else {
                    refresh.setEnabled(true);
                    refresh.setText("Обновить");
                    toast(problem);
                }
            });
        });
    }

    private void showKeys(String message) {
        if (nexusUi != null) { nexusUi.requestKeys(); return; }
        LinearLayout form = dialogForm();
        if (!message.isEmpty()) add(form, text(message, 14, WARNING, false), 0);
        add(form, text("Команде по умолчанию нужен один ключ OpenRouter.", 15, FG, false),
                message.isEmpty() ? 0 : 10);
        add(form, text("OpenRouter", 14, MUTED, true), 14);
        EditText router = field(readForEdit(Workflow.Provider.OPENROUTER),
                "Вставь ключ OpenRouter", 512, 1, true);
        add(form, router, 5);
        add(form, button("Получить ключ OpenRouter", false,
                view -> openLink("https://openrouter.ai/settings/keys")), 6);
        TextView catalogStatus = text(catalogLabel(), 13, MUTED, false);
        add(form, catalogStatus, 11);
        Button refresh = button("Обновить бесплатные модели", false, null);
        refresh.setOnClickListener(view -> {
            refresh.setEnabled(false);
            catalogStatus.setText("Обновляю список OpenRouter…");
            refreshModels(true, problem -> {
                refresh.setEnabled(true);
                catalogStatus.setText(problem.isEmpty() ? catalogLabel() : problem);
            });
        });
        add(form, refresh, 5);
        add(form, text("Groq · Free Plan", 14, MUTED, true), 14);
        EditText groq = field(readForEdit(Workflow.Provider.GROQ),
                "Вставь ключ Groq", 512, 1, true);
        add(form, groq, 5);
        add(form, button("Получить ключ Groq", false,
                view -> openLink("https://console.groq.com/keys")), 6);
        CheckBox groqReserve = new CheckBox(this);
        groqReserve.setText("Использовать Groq Free в резерве");
        groqReserve.setChecked(data.getBoolean(GROQ_RESERVE, false));
        add(form, groqReserve, 5);
        add(form, text("Google Gemini · по желанию", 14, MUTED, true), 14);
        EditText gemini = field(readForEdit(Workflow.Provider.GEMINI),
                "Вставь ключ Gemini", 512, 1, true);
        add(form, gemini, 5);
        add(form, button("Получить ключ Gemini", false,
                view -> openLink("https://aistudio.google.com/api-keys")), 6);
        add(form, text("Для бесплатной работы Gemini нужен проект Google на Free Tier.",
                13, MUTED, false), 8);
        add(form, text("Песочница Piston · по желанию", 14, MUTED, true), 14);
        EditText piston = field(readPistonForEdit(), "Токен Piston", 512, 1, true);
        add(form, piston, 5);
        add(form, text("Для запуска Python на телефоне токен не нужен.", 13, MUTED, false), 6);
        add(form, text("Очисти поле, чтобы удалить сохранённый ключ.", 13, MUTED, false), 10);
        AlertDialog dialog = dialog("Подключение моделей", form);
        refreshModels(false, problem -> {
            if (dialog.isShowing()) catalogStatus.setText(problem.isEmpty() ? catalogLabel() : problem);
        });
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String routerValue = router.getText().toString().trim();
            String geminiValue = gemini.getText().toString().trim();
            String groqValue = groq.getText().toString().trim();
            String pistonValue = piston.getText().toString().trim();
            if (!validKey(routerValue)) {
                router.setError("Вставь ключ целиком, без пробелов.");
                return;
            }
            if (!validKey(geminiValue)) {
                gemini.setError("Вставь ключ целиком, без пробелов.");
                return;
            }
            if (!validKey(groqValue)) {
                groq.setError("Вставь ключ целиком, без пробелов.");
                return;
            }
            if (!validKey(pistonValue)) {
                piston.setError("Вставь токен целиком, без пробелов.");
                return;
            }
            try {
                vault.save(routerValue, geminiValue, groqValue, pistonValue);
                data.edit().putBoolean(GROQ_RESERVE, groqReserve.isChecked() && !groqValue.isEmpty()).apply();
                dialog.dismiss();
                toast("Настройки сохранены");
            } catch (GeneralSecurityException | IOException e) {
                toast("Не удалось сохранить ключи на телефоне.");
            }
        });
    }

    private String catalogLabel() {
        return catalog.refreshed ? "Бесплатных моделей OpenRouter: " + catalog.routerCount()
                : "Встроенный список бесплатных моделей OpenRouter";
    }

    private String readForEdit(Workflow.Provider provider) {
        try {
            return vault.read(provider);
        } catch (GeneralSecurityException | IOException e) {
            return "";
        }
    }

    private String readPistonForEdit() {
        try {
            return vault.readPiston();
        } catch (GeneralSecurityException | IOException e) {
            return "";
        }
    }

    private boolean validKey(String s) {
        return s.isEmpty() || s.length() >= 8 && s.matches("[\\x21-\\x7e]+");
    }

    private void openLink(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (android.content.ActivityNotFoundException e) {
            toast("На устройстве нет приложения для открытия ссылки.");
        }
    }

    private void chooseExport() {
        Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                .putExtra(Intent.EXTRA_TITLE, "nexus-ia-result.json");
        try {
            startActivityForResult(create, EXPORT_REQUEST);
        } catch (android.content.ActivityNotFoundException e) {
            toast("Не удалось открыть окно сохранения.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (requestCode != EXPORT_REQUEST || resultCode != RESULT_OK
                || result == null || result.getData() == null || run == null) return;
        try (OutputStream output = getContentResolver().openOutputStream(result.getData(), "w")) {
            if (output == null) throw new IOException("Output missing");
            output.write(run.toJson().toString(2).getBytes(StandardCharsets.UTF_8));
            toast("Разбор сохранён");
        } catch (IOException | JSONException e) {
            toast("Не удалось сохранить файл.");
        }
    }

    @Override public void onBackPressed() {
        if (clearing) return;
        if (nexusUi != null && nexusUi.navigateBack()) return;
        if (historyVisible) {
            returnFromHistory();
        } else if (!resultsVisible) {
            super.onBackPressed();
        } else if (active) {
            new AlertDialog.Builder(this).setMessage("Остановить текущий разбор?")
                    .setNegativeButton("Продолжить", null)
                    .setPositiveButton("Остановить", (dialog, which) -> stopRun()).show();
        } else {
            renderTask();
        }
    }

    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        leaveLaunch();
    }

    @Override protected void onStop() {
        nexusPythonFlushPending();
        leaveLaunch();
        if (store != null) persistRun();
        super.onStop();
    }

    @Override protected void onDestroy() {
        releaseWebCheck();
        progressHandler.removeCallbacks(openInitialChat);
        dismissLaunch();
        cancelRequest();
        cancelSandbox();
        sandboxWorker.shutdownNow();
        worker.shutdownNow();
        if (catalogRequest != null) {
            ModelClient.Cancellation stop = catalogRequest;
            disconnect(stop);
        }
        catalogWorker.shutdownNow();
        cancellationWorker.shutdown();
        catalogListeners.clear();
        super.onDestroy();
    }

    private AlertDialog dialog(String title, LinearLayout form) {
        ScrollView area = dialogArea(form);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title).setView(area).setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", null).create();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.show();
        area.requestFocus();
        return dialog;
    }

    private ScrollView dialogArea(LinearLayout form) {
        ScrollView area = new ScrollView(this);
        area.addView(form);
        area.setFocusableInTouchMode(true);
        return area;
    }

    private LinearLayout dialogForm() {
        LinearLayout panel = column();
        panel.setPadding(dp(20), dp(12), dp(20), dp(6));
        return panel;
    }

    private EditText field(String value, String hint, int limit, int lines, boolean protectedText) {
        EditText field = new EditText(this);
        field.setTextColor(FG);
        field.setHintTextColor(MUTED);
        field.setTextSize(16);
        field.setHint(hint);
        field.setPadding(dp(13), dp(11), dp(13), dp(11));
        field.setBackground(shape(SURFACE, BORDER, 13));
        field.setInputType(InputType.TYPE_CLASS_TEXT | (protectedText
                ? InputType.TYPE_TEXT_VARIATION_PASSWORD
                : lines > 1 ? InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES : 0));
        if (limit > 0) field.setFilters(new InputFilter[] { new InputFilter.LengthFilter(limit) });
        if (lines > 1) {
            field.setMinLines(lines);
            field.setMaxLines(lines + 2);
            field.setGravity(Gravity.TOP | Gravity.START);
        } else {
            field.setSingleLine(true);
            if (protectedText) field.setInputType(InputType.TYPE_CLASS_TEXT
                    | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        field.setText(value);
        return field;
    }

    private TextView badge(int number) {
        TextView view = text(String.valueOf(number), 15, ACCENT, true);
        view.setGravity(Gravity.CENTER);
        view.setBackground(shape(ACCENT_DARK, Color.TRANSPARENT, 10));
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(34)));
        return view;
    }

    private TextView selectable(String value, int size, int color) {
        TextView view = text(value, size, color, false);
        view.setTextIsSelectable(true);
        return view;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return view;
    }

    private Button button(String title, boolean primary, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(primary ? 16 : 14);
        b.setTextColor(primary ? ACCENT_INK : FG);
        b.setAllCaps(false);
        b.setLetterSpacing(0f);
        b.setMinWidth(0);
        b.setMinHeight(dp(primary ? 52 : 44));
        b.setMinimumWidth(0);
        b.setMinimumHeight(dp(primary ? 52 : 44));
        b.setPadding(dp(13), dp(6), dp(13), dp(6));
        b.setStateListAnimator(null);
        b.setBackground(ripple(primary ? ACCENT : SURFACE,
                primary ? Color.TRANSPARENT : BORDER, 12));
        b.setBackgroundTintList(null);
        b.setOnClickListener(action);
        return b;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private void add(LinearLayout layout, View child, int top) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(top);
        layout.addView(child, params);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, -2, 1f);
    }

    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }

    private RippleDrawable ripple(int fill, int stroke, int radius) {
        return new RippleDrawable(ColorStateList.valueOf(0x2f8ce5dc),
                shape(fill, stroke, radius), shape(Color.WHITE, Color.TRANSPARENT, radius));
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
