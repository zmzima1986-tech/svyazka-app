package app.svyazka.mobile.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Typography as MaterialTypography
import androidx.compose.ui.text.TextStyle

val NexusCyan = Color(0xFF22E3FF)
val NexusBlue = Color(0xFF3B82F6)
val NexusIndigo = Color(0xFF6366F1)
val NexusNavy = Color(0xFF0A0A0A)
val NexusSurface = Color(0xFF1A1A1A)
val NexusLightBackground = Color(0xFFF0F4F8)
val NexusLightText = Color(0xFF1A1A1A)

private val DarkPalette = darkColorScheme(
    primary = NexusCyan,
    onPrimary = Color(0xFF06161A),
    primaryContainer = Color(0xFF173439),
    onPrimaryContainer = Color(0xFFEDEFF2),
    secondary = NexusBlue,
    secondaryContainer = Color(0xFF14353B),
    onSecondaryContainer = NexusCyan,
    background = NexusNavy,
    onBackground = Color(0xFFEDEFF2),
    surface = NexusSurface,
    onSurface = Color(0xFFEDEFF2),
    surfaceVariant = Color(0xFF242424),
    onSurfaceVariant = Color(0xFFAEAFB6),
    outline = Color(0xFF45474C),
    error = Color(0xFFFF8992)
)

private val LightPalette = lightColorScheme(
    primary = NexusBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8F8FF),
    onPrimaryContainer = NexusLightText,
    secondary = NexusCyan,
    secondaryContainer = Color(0xFFD7F5FA),
    onSecondaryContainer = Color(0xFF0B596C),
    background = NexusLightBackground,
    onBackground = NexusLightText,
    surface = Color.White,
    onSurface = NexusLightText,
    surfaceVariant = Color(0xFFE7EEF5),
    onSurfaceVariant = Color(0xFF4C6075),
    outline = Color(0xFFC4D1DF),
    error = Color(0xFFBF2533)
)

private val NexusTypography = MaterialTypography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 29.sp, lineHeight = 35.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 23.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp)
)

@Composable
fun NexusTheme(preference: String, content: @Composable () -> Unit) {
    val dark = when (preference) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkPalette else LightPalette,
        typography = NexusTypography, content = content)
}
