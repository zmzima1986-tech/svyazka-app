package app.svyazka.mobile;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import androidx.compose.ui.platform.ComposeView;
import androidx.core.view.OneShotPreDrawListener;
import androidx.test.core.app.ApplicationProvider;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.LooperMode;
import java.time.Duration;

import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = {30, 35})
@LooperMode(LooperMode.Mode.PAUSED)
public final class LaunchLifecycleTest {
    private ActivityController<MainActivity> controller;
    private ViewGroup content;

    private void open(Bundle state, int flags) {
        Context app = ApplicationProvider.getApplicationContext();
        Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClass(app, MainActivity.class).addFlags(flags);
        controller = Robolectric.buildActivity(MainActivity.class, launcher);
        shadowOf(controller.get()).setIsTaskRoot(true);
        controller.create(state).start().resume();
        content = controller.get().findViewById(android.R.id.content);
    }

    @After public void close() {
        if (controller != null) controller.pause().stop().destroy();
        controller = null;
    }

    private void frame() {
        content.getViewTreeObserver().dispatchOnPreDraw();
        shadowOf(Looper.getMainLooper()).idle();
    }

    private boolean hasCover() {
        return content.getChildCount() > 0 && content.getChildAt(content.getChildCount()-1) instanceof NexusLaunchView;
    }

    @Test public void twoSecondsStartOnlyAfterTheChatFrame() {
        open(null, Intent.FLAG_ACTIVITY_NEW_TASK);
        assertTrue(hasCover());
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(3));
        assertTrue(hasCover());
        // visible() performs several traversals. Timestamp the chat's own first frame.
        long[] readyAt = {-1L};
        content.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
            @Override public void onChildViewAdded(View parent, View child) {
                if (child instanceof ComposeView) {
                    OneShotPreDrawListener.add(child, () -> child.post(() -> readyAt[0] = SystemClock.uptimeMillis()));
                }
            }
            @Override public void onChildViewRemoved(View parent, View child) {}
        });
        controller.visible();
        frame();
        assertTrue(content.getChildAt(0) instanceof ComposeView);
        assertTrue(hasCover());
        assertTrue(readyAt[0] >= 0);
        long elapsed = SystemClock.uptimeMillis() - readyAt[0];
        assertTrue(elapsed < 1999);
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(1999 - elapsed));
        assertTrue(hasCover());
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(1));
        assertFalse(hasCover());
        assertEquals(1, content.getChildCount());
        assertTrue(content.getChildAt(0) instanceof ComposeView);
    }

    @Test public void homeWhileCountingDownReturnsDirectlyToChat() {
        open(null, Intent.FLAG_ACTIVITY_NEW_TASK);
        controller.visible();
        frame();
        View chat = content.getChildAt(0);
        assertTrue(chat instanceof ComposeView);
        assertTrue(hasCover());
        controller.userLeaving().pause().stop();
        controller.restart().start().resume().visible();
        assertFalse(hasCover());
        assertSame(chat, content.getChildAt(0));
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(3));
        assertEquals(1, content.getChildCount());
    }

    @Test public void homeDuringLaunchReturnsToChatAndFreshTaskShowsTheCoverAgain() {
        open(null, Intent.FLAG_ACTIVITY_NEW_TASK);
        assertTrue(hasCover());
        controller.userLeaving().pause().stop();
        controller.restart().start().resume().visible();
        frame();
        assertFalse(hasCover());
        assertTrue(content.getChildAt(0) instanceof ComposeView);
        close();
        open(null, Intent.FLAG_ACTIVITY_NEW_TASK);
        assertTrue(hasCover());
    }

    @Test public void restorationAndRecentsDoNotStartAnotherTimer() {
        open(new Bundle(), Intent.FLAG_ACTIVITY_NEW_TASK);
        assertFalse(hasCover());
        assertTrue(content.getChildAt(0) instanceof ComposeView);
        close();
        open(null, Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY);
        assertFalse(hasCover());
        assertTrue(content.getChildAt(0) instanceof ComposeView);
    }
}
