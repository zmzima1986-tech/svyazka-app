"""Trusted grading harness. Only the candidate namespace is visible to submitted code."""

import ast
import builtins
import collections
import copy
import io
import json
import math
import re
import reprlib
import traceback
import types

MAX_SOURCE = 64_000
MAX_TESTS = 24
MAX_OUTPUT = 16_384


class Unavailable(Exception):
    """The environment or test contract cannot support the requested check."""


class Incomplete(Exception):
    pass


class WrongAnswer(Exception):
    pass


NODES = set(
    """
Module Expr Constant Name Load Store Del Assign AnnAssign AugAssign Delete NamedExpr FunctionDef
arguments arg Return Lambda If IfExp For While Break Continue Pass Assert Raise BinOp UnaryOp BoolOp
Compare Call keyword Attribute Subscript Slice Starred List Tuple Set Dict ListComp SetComp DictComp
GeneratorExp comprehension Add Sub Mult Div FloorDiv Mod Pow MatMult LShift RShift BitOr BitXor BitAnd
Invert Not UAdd USub And Or Eq NotEq Lt LtE Gt GtE Is IsNot In NotIn JoinedStr FormattedValue
Import ImportFrom alias With withitem Try ExceptHandler
""".split()
)
METHODS = set(
    """
append extend insert pop remove reverse sort index count clear copy get keys values items update
setdefault popitem add discard union intersection difference issubset issuperset join split rsplit
splitlines strip lstrip rstrip lower upper casefold capitalize title startswith endswith find rfind
replace partition rpartition isdigit isnumeric isalpha isalnum isspace islower isupper zfill
removeprefix removesuffix read readline readlines most_common appendleft popleft extendleft rotate
""".split()
)
SAFE = {
    name: getattr(builtins, name)
    for name in """
abs all any bin bool bytes bytearray chr dict divmod enumerate filter float frozenset int isinstance
hex len list map max min oct ord pow range reversed round set slice sorted str sum tuple zip
ArithmeticError AssertionError IndexError KeyError NotImplementedError RuntimeError TypeError ValueError ZeroDivisionError
""".split()
}


def json_load(s, **options):
    if options:
        raise Unavailable("Параметры пользовательского декодера JSON недоступны.")
    return json.loads(s)


def json_dump(value, **options):
    if options.keys() - {"ensure_ascii", "indent", "sort_keys", "separators", "allow_nan", "skipkeys"}:
        raise Unavailable("Параметры пользовательского кодировщика JSON недоступны.")
    return json.dumps(value, **options)


MODULES = {
    "math": {k: getattr(math, k) for k in dir(math) if not k.startswith("_")},
    "collections": {k: getattr(collections, k) for k in ("deque", "Counter", "defaultdict")},
    "json": {"loads": json_load, "dumps": json_dump},
}
METHODS.update(k for module in MODULES.values() for k in module)


def import_safe(name, globals=None, locals=None, fromlist=(), level=0):
    if level or name not in MODULES:
        raise Unavailable("Модуль недоступен в автоматической песочнице: " + name)
    return types.SimpleNamespace(**MODULES[name])


def validate(tree):
    nodes = list(ast.walk(tree))
    if len(nodes) > 6000:
        raise Unavailable("Превышен лимит сложности кода.")
    if not tree.body or all(
        isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str)
        for n in tree.body
    ):
        raise Incomplete("В блоке нет исполняемых инструкций.")
    for n in nodes:
        if type(n).__name__ not in NODES:
            raise Unavailable("Конструкция недоступна в автоматическом режиме: " + type(n).__name__)
        if (
            isinstance(n, (ast.Expr, ast.Return))
            and isinstance(n.value, ast.Constant)
            and n.value.value is Ellipsis
        ):
            raise Incomplete("В коде оставлено троеточие, строка " + str(n.lineno))
        if isinstance(n, ast.Name):
            if n.id.startswith("__") and not (n.id == "__name__" and isinstance(n.ctx, ast.Load)):
                raise Unavailable("Служебное имя недоступно: " + n.id)
            if (
                isinstance(n.ctx, ast.Load)
                and n.id in vars(builtins)
                and n.id not in SAFE
                and n.id not in {"__name__", "open", "print", "input"}
            ):
                raise Unavailable("Встроенная операция недоступна: " + n.id)
        if isinstance(n, ast.Attribute) and (not isinstance(n.ctx, ast.Load) or n.attr not in METHODS):
            raise Unavailable("Метод или атрибут недоступен: " + n.attr)
        if isinstance(n, ast.FunctionDef):
            if n.decorator_list or n.name.startswith("__") or getattr(n, "type_params", []):
                raise Unavailable("Эта форма объявления функции недоступна.")
            body = n.body[1:] if ast.get_docstring(n) is not None else n.body
            if not body or all(isinstance(s, ast.Pass) for s in body):
                raise Incomplete("Пустая реализация функции " + n.name)
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                mod = a.name if isinstance(n, ast.Import) else (n.module or "")
                if mod not in MODULES or getattr(n, "level", 0):
                    raise Unavailable("Модуль недоступен в автоматической песочнице: " + mod)
                if isinstance(n, ast.ImportFrom) and a.name not in MODULES[mod]:
                    raise Unavailable("Импорт недоступен: " + mod + "." + a.name)
                if (a.asname or a.name).startswith("__"):
                    raise Unavailable("Служебный псевдоним недоступен.")
        if isinstance(n, ast.ExceptHandler):
            types_seen = n.type.elts if isinstance(n.type, ast.Tuple) else [n.type]
            if any(
                not isinstance(t, ast.Name)
                or t.id not in SAFE
                or not isinstance(SAFE[t.id], type)
                or not issubclass(SAFE[t.id], Exception)
                for t in types_seen
            ):
                raise Unavailable("Этот обработчик исключений недоступен для автоматической проверки.")


def reference_cases(req):
    cases = []
    for manifest in req.get("specs", []):
        try:
            values = json.loads(manifest)
        except (ValueError, RecursionError) as e:
            raise Unavailable("Некорректный JSON тестов: " + str(e)) from e
        if not isinstance(values, list) or not values:
            raise Unavailable("nexus-tests должен содержать непустой массив.")
        cases.extend(values)
    source = req.get("examples", "")
    lines = source.splitlines()
    assertions = [s.strip() for s in lines if s.strip().startswith("assert ")]
    for i, line in enumerate(lines):
        if line.strip().startswith(">>> "):
            if i + 1 >= len(lines) or not lines[i + 1].strip():
                raise Unavailable("У примера >>> нет ожидаемого результата.")
            assertions.append("assert " + line.strip()[4:] + " == " + lines[i + 1].strip())
    for text in assertions:
        try:
            stmt = ast.parse(text).body[0]
            expr = stmt.test
            if not (
                isinstance(stmt, ast.Assert)
                and isinstance(expr, ast.Compare)
                and len(expr.ops) == 1
                and isinstance(expr.ops[0], ast.Eq)
                and isinstance(expr.left, ast.Call)
                and isinstance(expr.left.func, ast.Name)
                and not expr.left.keywords
            ):
                raise ValueError
            case = dict(
                function=expr.left.func.id,
                args=[ast.literal_eval(a) for a in expr.left.args],
                expected=ast.literal_eval(expr.comparators[0]),
            )
            if json.loads(json.dumps(case, allow_nan=False)) != case:
                raise ValueError
            cases.append(case)
        except (ValueError, TypeError, AttributeError, SyntaxError, RecursionError, IndexError) as e:
            raise Unavailable(
                "Нужен assert с вызовом функции и ожидаемым литералом либо nexus-tests.json."
            ) from e
    for m in re.finditer(
        r"(?im)^[ \t]*(?:ввод|input)[ \t]*:[ \t]*([^\n]+)\n[ \t]*(?:вывод|output)[ \t]*:[ \t]*([^\n]+)",
        source,
    ):
        cases.append(dict(stdin=m[1].strip() + "\n", stdout=m[2].strip()))
    for name in re.findall(r"(?im)^[ \t]*nexus-contract:[ \t]*(\S+)[ \t]*$", source):
        contracts = {
            "factorial": [([0], 1), ([1], 1), ([2], 2), ([5], 120), ([8], 40320)],
            "gcd": [([0, 0], 0), ([0, 7], 7), ([-12, 18], 6), ([17, 4], 1), ([36, 24], 12)],
        }
        if name not in contracts:
            raise Unavailable("Неизвестный контрольный контракт: " + name)
        cases.extend(dict(function=name, args=args, expected=v) for args, v in contracts[name])
    if len(cases) > MAX_TESTS:
        raise Unavailable("Максимум 24 теста.")
    for case in cases:
        if not isinstance(case, dict):
            raise Unavailable("Некорректный контрольный пример.")
        if set(case) == {"function", "args", "expected"}:
            if not (
                isinstance(case["function"], str)
                and case["function"].isidentifier()
                and not case["function"].startswith("__")
                and isinstance(case["args"], list)
            ):
                raise Unavailable("Тесту нужны имя функции и массив аргументов.")
        elif set(case) != {"stdin", "stdout"} or not all(isinstance(s, str) for s in case.values()):
            raise Unavailable("Укажите function/args/expected либо stdin/stdout.")
    return cases


class Output(io.StringIO):
    def write(self, text):
        if self.tell() + len(text) > MAX_OUTPUT:
            raise Unavailable("Вывод превысил 16 384 символа.")
        return super().write(text)


def matches(a, b):
    if type(a) is not type(b):
        return type(a) in (int, float) and type(b) in (int, float) and a == b
    if isinstance(b, list):
        return len(a) == len(b) and all(matches(x, y) for x, y in zip(a, b))
    if isinstance(b, dict):
        return a.keys() == b.keys() and all(matches(a[k], v) for k, v in b.items())
    return a == b


def execute(program, files, case):
    out, inp = Output(), io.StringIO(case.get("stdin", "") if case else "")

    def read(prompt=""):
        out.write(str(prompt))
        s = inp.readline()
        if not s:
            raise Unavailable("Для input() нужен контрольный пример со stdin.")
        return s.removesuffix("\n").removesuffix("\r")

    def emit(*args, sep=" ", end="\n", flush=False):
        builtins.print(*args, sep=sep, end=end, file=out)

    def open_read(name, mode="r", encoding="utf-8"):
        if (
            not isinstance(name, str)
            or name not in files
            or mode not in ("r", "rt")
            or encoding not in (None, "utf-8", "utf8")
        ):
            raise Unavailable("Доступно чтение только приложенных текстовых файлов по имени.")
        return io.StringIO(files[name])

    env = {
        "__builtins__": dict(SAFE, __import__=import_safe, input=read, print=emit, open=open_read),
        "__name__": "nexus_candidate" if case and "function" in case else "__main__",
    }
    exec(program, env)
    if case is None:
        return
    if "stdin" in case:
        actual = out.getvalue().replace("\r\n", "\n").removesuffix("\n")
        expected = case["stdout"].replace("\r\n", "\n").removesuffix("\n")
    else:
        fn = env.get(case["function"])
        if not callable(fn):
            raise WrongAnswer("В решении отсутствует функция " + case["function"])
        actual, expected = fn(*copy.deepcopy(case["args"])), case["expected"]
    if not matches(actual, expected):
        raise WrongAnswer("ожидалось " + reprlib.repr(expected) + ", получено " + reprlib.repr(actual))


def verify_request(payload, notify=lambda stage, passed, total: None):
    req = json.loads(payload)
    syntax = ran = False
    passed = total = number = 0
    phase = "compile"

    def report(status, reason="", signature=""):
        return json.dumps(
            dict(
                status=status,
                syntax=syntax,
                ran=ran,
                passed=passed,
                total=total,
                diagnostic=reason[:2400],
                signature=signature[:500],
            ),
            ensure_ascii=False,
        )

    try:
        if "syntax_only" in req:
            parts = req["syntax_only"]
            if not parts or sum(len(s.encode("utf-8")) for s in parts) > MAX_SOURCE:
                raise Unavailable("Материал пуст или превышает лимит 64 000 байт.")
            for i, part in enumerate(parts, 1):
                if not part.strip():
                    raise Unavailable("Блок Python пуст.")
                try:
                    compile(part, "block-" + str(i) + ".py", "exec", dont_inherit=True)
                except SyntaxError as e:
                    raise Unavailable(
                        "Блок " + str(i) + ", строка " + str(e.lineno) + ": " + e.msg
                    ) from e
            syntax = True
            return report("LIMITED", req["reason"])
        code = req["code"]
        if len(code.encode("utf-8")) > MAX_SOURCE:
            raise Unavailable("Код превышает 64 000 байт.")
        tree = ast.parse(code, "main.py")
        program = compile(tree, "main.py", "exec", dont_inherit=True)
        syntax = True
        notify("syntax", 0, 0)
        phase = "policy"
        validate(tree)
        cases = reference_cases(req)
        total = len(cases)
        phase = "execute"
        if total:
            notify("syntax", 0, total)
        for number, case in enumerate(cases or [None], 1):
            execute(program, req.get("files", {}), case)
            ran = True
            if case is not None:
                passed += 1
            notify("executed", passed, total)
        return report("PASSED" if total else "RAN")
    except (Unavailable, MemoryError, RecursionError) as e:
        return report("LIMITED", str(e) or type(e).__name__)
    except Exception as e:
        frames = [f for f in traceback.extract_tb(e.__traceback__) if f.filename == "main.py"]
        if not frames and not isinstance(e, (WrongAnswer, Incomplete, SyntaxError)):
            return report("LIMITED", "Ошибка механизма проверки: " + type(e).__name__ + ": " + str(e))
        line = e.lineno if isinstance(e, SyntaxError) else frames[-1].lineno if frames else None
        if isinstance(e, WrongAnswer):
            ran = True
        reason = e.msg if isinstance(e, SyntaxError) else str(e)
        label = (
            ("Тест " + str(number) + " " + reprlib.repr(cases[number - 1]) + ". ")
            if total and number
            else ""
        )
        label += type(e).__name__ + ": " + reason + (" (строка " + str(line) + ")" if line else "")
        signature = "/".join(
            (
                phase,
                type(e).__name__,
                str(number),
                "" if isinstance(e, (WrongAnswer, Incomplete)) else reason,
            )
        )
        return report("ERROR", label, signature)
