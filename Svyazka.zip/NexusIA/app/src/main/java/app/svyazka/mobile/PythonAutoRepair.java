package app.svyazka.mobile;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A bounded Python repair cycle stored in the existing task prompt, not in a second DB.
 * The metadata is generated locally. Neither source code nor model prose is trusted
 * as a command to replace a file or to dispatch another paid request.
 */
final class PythonAutoRepair {
    static final int MAX_ATTEMPTS = 3;
    private static final String TAG = "NEXUS_PYTHON_REPAIR_V1";
    private static final Pattern HEADER = Pattern.compile("^" + Pattern.quote(PythonAutoFeedback.MARKER)
            + "\\n\\[" + TAG + " attempt=([1-3]) path=([A-Za-z0-9_./-]+\\.py)"
            + " base=([0-9a-f]{64}) codes=([0-9a-f,]+) errors=([0-9a-f,]+)\\]\\n");
    private static final Pattern SHA_LIST = Pattern.compile("[0-9a-f]{64}(?:,[0-9a-f]{64}){0,3}");

    static final class State {
        final int attempt;
        final String path, baseHash;
        final List<String> triedCodes, errors;

        private State(int attempt, String path, String baseHash,
                      List<String> triedCodes, List<String> errors) {
            this.attempt = attempt;
            this.path = path;
            this.baseHash = baseHash;
            this.triedCodes = Collections.unmodifiableList(new ArrayList<>(triedCodes));
            this.errors = Collections.unmodifiableList(new ArrayList<>(errors));
        }

        boolean canContinue() { return attempt < MAX_ATTEMPTS; }
        boolean alreadyTried(String code) { return triedCodes.contains(sha(code)); }
        boolean unchangedProject(String savedCode) { return baseHash.equals(sha(savedCode)); }
    }

    private PythonAutoRepair() { }

    static String sha(String text) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256")
                    .digest((text == null ? "" : text).getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder(64);
            for (byte item : bytes) hex.append(String.format(Locale.ROOT, "%02x", item & 255));
            return hex.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(impossible);
        }
    }

    static String errorSignature(String diagnostic) {
        if (diagnostic == null) return sha("");
        String last = "";
        for (String line : diagnostic.split("\\R")) {
            String trimmed = line.trim();
            if (trimmed.matches("(?i).*?(?:Error|Exception)[: ].*")) last = trimmed;
        }
        if (last.isEmpty()) last = diagnostic.trim();
        return sha(last.toLowerCase(Locale.ROOT)
                .replaceAll("\\d+", "#")
                .replaceAll("\\s+", " "));
    }

    /** Only the fixed, locally generated file field from a stage-3 diagnostic. */
    static String pathInFeedback(String prompt) {
        if (!PythonAutoFeedback.isFeedback(prompt)) return "";
        int diagnostic = prompt.indexOf("\n" + PythonAutoFeedback.DIAGNOSTIC_LABEL);
        if (diagnostic < 0) return "";
        int begin = prompt.lastIndexOf("\n" + PythonAutoFeedback.FILE_LABEL, diagnostic);
        if (begin < 0) return "";
        begin += 1 + PythonAutoFeedback.FILE_LABEL.length();
        int end = prompt.indexOf('\n', begin);
        if (end < 0 || end > diagnostic) return "";
        String path = prompt.substring(begin, end);
        return PythonProjectStore.validPath(path) && path.endsWith(".py") ? path : "";
    }

    /** The first diagnosed error is not a repair attempt. Attempts count AI fixes. */
    static String first(String feedback, String path, String failedCode,
                        String diagnostic, String savedCode) {
        if (!PythonAutoFeedback.isFeedback(feedback) || parse(feedback) != null
                || path == null || !path.equals(pathInFeedback(feedback))
                || failedCode == null || failedCode.trim().isEmpty()
                || diagnostic == null || diagnostic.trim().isEmpty()) return "";
        return header(new State(1, path, sha(savedCode),
                Collections.singletonList(sha(failedCode)),
                Collections.singletonList(errorSignature(diagnostic))))
                + feedback.substring(PythonAutoFeedback.MARKER.length() + 1);
    }

    static State parse(String prompt) {
        if (prompt == null) return null;
        Matcher match = HEADER.matcher(prompt);
        if (!match.find()) return null;
        String path = match.group(2), codes = match.group(4), errors = match.group(5);
        if (!PythonProjectStore.validPath(path) || !SHA_LIST.matcher(codes).matches()
                || !SHA_LIST.matcher(errors).matches()) return null;
        List<String> tried = java.util.Arrays.asList(codes.split(","));
        List<String> signatures = java.util.Arrays.asList(errors.split(","));
        int attempt = Integer.parseInt(match.group(1));
        if (tried.size() != attempt || signatures.size() != attempt) return null;
        return new State(attempt, path, match.group(3), tried, signatures);
    }

    /** Blank means stop: budget exhausted, unchanged source, wrong target or repeated error. */
    static String next(State state, String feedback, String path, String failedCode,
                       String diagnostic, String savedCode) {
        if (state == null || !state.canContinue() || !state.path.equals(path)
                || !state.path.equals(pathInFeedback(feedback))
                || !state.unchangedProject(savedCode)
                || failedCode == null || failedCode.trim().isEmpty()
                || diagnostic == null || diagnostic.trim().isEmpty()
                || state.alreadyTried(failedCode)
                || state.errors.contains(errorSignature(diagnostic))) return "";
        List<String> tried = new ArrayList<>(state.triedCodes);
        tried.add(sha(failedCode));
        List<String> errors = new ArrayList<>(state.errors);
        errors.add(errorSignature(diagnostic));
        State next = new State(state.attempt + 1, path, state.baseHash, tried, errors);
        return header(next) + feedback.substring(PythonAutoFeedback.MARKER.length() + 1);
    }

    private static String header(State state) {
        return PythonAutoFeedback.MARKER + "\n[" + TAG + " attempt=" + state.attempt
                + " path=" + state.path + " base=" + state.baseHash
                + " codes=" + String.join(",", state.triedCodes)
                + " errors=" + String.join(",", state.errors) + "]\n";
    }
}
