package app.svyazka.mobile.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.PythonVerification
import app.svyazka.mobile.NexusState
import app.svyazka.mobile.R
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private fun copyText(context: Context, label: String, value: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    manager.setPrimaryClip(ClipData.newPlainText(label, value))
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskScreen(ui: NexusComposeUi) {
    val state = ui.snapshot
    var modelPicker by remember { mutableStateOf(false) }
    var editing by remember { mutableIntStateOf(-1) }
    val context = LocalContext.current
    val attachFile = rememberAttachFileAction(ui)
    val taskFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val clearDescription = stringResource(R.string.action_clear_task_text)
    val taskLabel = stringResource(R.string.task_hint)
    val separateTaskLabel = LocalDensity.current.fontScale >= 1.4f
    val attachments = rememberAttachmentTask(ui)
    LazyColumn(modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            NexusCard(highlighted = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.hero_title),
                            style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        NexusLabel(stringResource(R.string.hero_body))
                    }
                    Spacer(Modifier.width(5.dp))
                    NexusAiStack(Modifier.size(98.dp))
                }
            }
        }
        item {
            Text(stringResource(R.string.task_title), style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(12.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(selected = state.quick, onClick = { ui.activity.nexusModeChanged(true) },
                    label = { Text(stringResource(R.string.quick_mode)) })
                FilterChip(selected = !state.quick, onClick = { ui.activity.nexusModeChanged(false) },
                    label = { Text(stringResource(R.string.team_mode)) })
            }
        }
        if (!attachments.loaded || attachments.busy || attachments.items.isNotEmpty() || attachments.notice != null) {
            item { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { AttachmentSummary(attachments) } }
        }
        items(attachments.items, key = { "attachment-${it.id}" }) { item -> AttachmentCard(ui, item) }
        item {
            if (separateTaskLabel) {
                Text(taskLabel, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
            }
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) {
                    OutlinedTextField(value = ui.draft, onValueChange = { ui.draftChanged(it) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp).focusRequester(taskFocus)
                            .semantics { contentDescription = taskLabel },
                        enabled = !state.active && !state.clearing,
                        label = if (separateTaskLabel) null else { { Text(taskLabel) } },
                        placeholder = { Text(stringResource(R.string.task_placeholder)) },
                        trailingIcon = if (ui.draft.isNotEmpty()) { { Spacer(Modifier.width(48.dp)) } } else null,
                        minLines = 4, maxLines = 12, shape = RoundedCornerShape(20.dp))
                    if (ui.draft.isNotEmpty()) {
                        IconButton(onClick = {
                            ui.draftChanged("")
                            taskFocus.requestFocus()
                            keyboard?.show()
                        }, enabled = !state.active && !state.clearing,
                            modifier = Modifier.align(Alignment.TopEnd).padding(top = 4.dp)
                                .size(48.dp).semantics { contentDescription = clearDescription }) {
                            Icon(Icons.Outlined.Close, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                IconButton(onClick = attachFile,
                    enabled = !state.active && !state.clearing,
                    modifier = Modifier.size(56.dp)) {
                    NexusGlyph(R.drawable.ic_nia_attach, stringResource(R.string.action_attach_file),
                        Modifier.size(41.dp))
                }
            }
            Spacer(Modifier.height(5.dp))
            NexusLabel(stringResource(R.string.file_attachment_hint))
        }
        if (state.quick) {
            item {
                NexusCard(onClick = { modelPicker = true }) {
                    NexusLabel(stringResource(R.string.select_model))
                    Text(state.quickModelLabel, style = MaterialTheme.typography.titleMedium)
                }
            }
        } else {
            item {
                NexusCard(highlighted = true) {
                    Text(stringResource(R.string.team_title), style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ui.activity.nexusConfiguredStages().forEach { stage ->
                            key(stage.index) {
                                Surface(onClick = { editing = stage.index },
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (MaterialTheme.colorScheme.background == NexusNavy)
                                        Color.Transparent else Color(0xFFF6F8FB),
                                    contentColor = MaterialTheme.colorScheme.onSurface,
                                    tonalElevation = 0.dp) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically) {
                                        StatusPill("${stage.index + 1}")
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(roleTitle(stage.role, stage.index), style = MaterialTheme.typography.titleMedium)
                                            roleSubtitle(stage.role, stage.index)?.let { subtitle ->
                                                Text(subtitle, style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            NexusLabel(stage.modelLabel, MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        NexusGlyph(R.drawable.ic_nia_chevron_down,
                                            stringResource(R.string.action_edit), Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            NexusPrimaryButton(text = stringResource(R.string.action_start),
                onClick = { ui.activity.nexusStart() },
                enabled = !state.active && !state.clearing && ui.draft.isNotBlank() && attachments.loaded && !attachments.busy
                    && attachments.items.none { it.status == app.svyazka.mobile.attachments.AttachmentStore.Status.ADDING
                        || it.status == app.svyazka.mobile.attachments.AttachmentStore.Status.PROCESSING },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { NexusGlyph(R.drawable.ic_nia_play, null, Modifier.size(21.dp)) })
            if (state.hasRun) {
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { ui.activity.nexusOpenResults() },
                    modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.result_title))
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
    if (modelPicker) ModelPicker(ui, state.quickModelId, { modelPicker = false }) { id ->
        ui.activity.nexusChooseQuickModel(id)
        modelPicker = false
    }
    if (editing >= 0) {
        val stage = ui.activity.nexusConfiguredStages().firstOrNull { it.index == editing }
        if (stage == null) editing = -1 else RoleEditor(ui, stage, { editing = -1 })
    }
}

@Composable
internal fun RoleEditor(ui: NexusComposeUi, stage: NexusState.Stage, dismiss: () -> Unit) {
    val initialRole = roleTitle(stage.role, stage.index)
    var role by remember(stage.index) { mutableStateOf(initialRole) }
    var instructions by remember(stage.index) { mutableStateOf(stage.instruction) }
    var model by remember(stage.index) { mutableStateOf(stage.modelId) }
    var picker by remember { mutableStateOf(false) }
    val context = LocalContext.current
    AlertDialog(onDismissRequest = dismiss,
        title = { Text(stringResource(R.string.edit_role)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(role, { if (it.length <= 42) role = it },
                    label = { Text(stringResource(R.string.role_name)) }, singleLine = true)
                OutlinedTextField(instructions, { if (it.length <= 1600) instructions = it },
                    label = { Text(stringResource(R.string.role_instructions)) }, maxLines = 6)
                val label = ui.snapshot.models.firstOrNull { it.id == model }?.label ?: stage.modelLabel
                OutlinedButton(onClick = { picker = true }) { Text(label, maxLines = 2) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (ui.activity.nexusUpdateStage(stage.index, if (role == initialRole) stage.role else role, instructions, model)) dismiss()
            }, enabled = role.isNotBlank() && instructions.isNotBlank()) { Text(stringResource(R.string.save_model_role)) }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text(stringResource(R.string.action_cancel)) } })
    if (picker) ModelPicker(ui, model, { picker = false }) { selected -> model = selected; picker = false }
}

@Composable
internal fun ModelPicker(ui: NexusComposeUi, selected: String,
                        dismiss: () -> Unit, choose: (String) -> Unit) {
    var search by remember { mutableStateOf("") }
    val choices = ui.snapshot.models.filter { it.label.contains(search, ignoreCase = true) ||
            it.provider.contains(search, ignoreCase = true) }
    AlertDialog(onDismissRequest = dismiss,
        title = { Text(stringResource(R.string.select_model)) },
        text = {
            Column {
                OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.models_title)) },
                    singleLine = true)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(choices, key = { it.id }) { model ->
                        Row(Modifier.fillMaxWidth().clickable { choose(model.id) }.padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selected == model.id,
                                onClick = { choose(model.id) })
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(model.label, style = MaterialTheme.typography.bodyMedium)
                                NexusLabel(model.provider)
                                if (model.imageInput) Text(stringResource(R.string.attachment_vision_capable),
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }, confirmButton = {
            TextButton(onClick = dismiss) { Text(stringResource(R.string.action_close)) }
        })
}

@Composable
fun ResultScreen(ui: NexusComposeUi) {
    val state = ui.snapshot
    val check = ui.verification
    val checkedPython = check.status != PythonVerification.Status.NONE
    var expanded by remember(state.task) { mutableStateOf(false) }
    var fullAnswer by remember(state.result) { mutableStateOf(false) }
    var followUp by remember { mutableStateOf(false) }
    var journal by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val saveFile = rememberSaveResultAction(state.result)
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(stringResource(R.string.result_title), style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(5.dp))
            NexusLabel(state.task.take(220))
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (state.active) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
                else NexusGlyph(if (state.complete && ((!state.resultHasPython && !checkedPython) || check.status == PythonVerification.Status.PASSED)) R.drawable.ic_nia_success else R.drawable.ic_nia_task,
                    null, Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Text(stringResource(R.string.result_progress, state.finished, state.total),
                    style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.weight(1f))
                if (state.active) IconButton(onClick = { ui.activity.nexusStop() }) {
                    NexusGlyph(R.drawable.ic_nia_stop, stringResource(R.string.action_stop), Modifier.size(30.dp))
                }
            }
            if (state.note.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                NexusCard { Text(state.note, color = MaterialTheme.colorScheme.error) }
            }
        }
        if (checkedPython) item { VerificationCard(check) }
        if (state.complete && !state.active) {
            item {
                NexusCard(highlighted = true) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(if (state.resultHasPython || checkedPython)
                            R.string.verify_last_answer else R.string.result_ready),
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.weight(1f))
                        if ((!state.resultHasPython && !checkedPython) || check.status == PythonVerification.Status.PASSED)
                            StatusPill(stringResource(R.string.status_complete), success = true)
                    }
                    Spacer(Modifier.height(14.dp))
                    if (state.resultWarnings.isNotBlank()) {
                        Text("⚠ " + stringResource(R.string.warning_integrity) + "\n" + state.resultWarnings,
                            color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(12.dp))
                    }
                    val displayed = if (fullAnswer) state.result else state.result.take(9000)
                    NexusMarkdown(displayed)
                    if (state.result.length > 9000 && !fullAnswer) {
                        TextButton(onClick = { fullAnswer = true }) {
                            Text(stringResource(R.string.action_show_result))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        NexusPrimaryButton(text = stringResource(R.string.action_copy),
                            onClick = {
                                copyText(context, state.resultRole, state.result)
                                Toast.makeText(context, R.string.status_copied, Toast.LENGTH_SHORT).show()
                            }, modifier = Modifier.weight(1f),
                            leadingIcon = { NexusGlyph(R.drawable.ic_nia_copy, null, Modifier.size(21.dp)) })
                        OutlinedIconButton(onClick = saveFile,
                            modifier = Modifier.size(55.dp),
                            border = BorderStroke(1.dp, NexusCyan.copy(alpha = .46f))) {
                            NexusGlyph(R.drawable.ic_nia_download, stringResource(R.string.action_save_file),
                                Modifier.size(27.dp))
                        }
                    }
                    if (state.resultHasPython) {
                        OutlinedButton(onClick = { ui.activity.nexusRunPython(ui.activity.nexusFinalStep()) },
                            modifier = Modifier.fillMaxWidth()) {
                            NexusGlyph(R.drawable.ic_nia_code, null, Modifier.size(22.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.action_python))
                        }
                    }
                    if (state.visualAvailable) {
                        OutlinedButton(onClick = { ui.openVisual() }, modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.action_show_result))
                        }
                    }
                }
            }
            item {
                NexusCard(onClick = { expanded = !expanded }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        NexusGlyph(R.drawable.ic_nia_work, null, Modifier.size(24.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(stringResource(R.string.work_title), style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f))
                        NexusGlyph(if (expanded) R.drawable.ic_nia_chevron_up else R.drawable.ic_nia_chevron_down,
                            stringResource(R.string.work_title), Modifier.size(22.dp))
                    }
                    AnimatedVisibility(expanded, enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()) {
                        Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            state.stages.filter { it.index != ui.activity.nexusFinalStep() }.forEach { stage ->
                                StepOutputCard(ui, stage)
                            }
                        }
                    }
                }
            }
        } else {
            items(state.stages, key = { it.index }) { stage -> StepOutputCard(ui, stage) }
            if (state.active && ui.streaming.isNotBlank()) {
                item {
                    NexusCard(highlighted = true) {
                        Text(stringResource(R.string.status_processing), color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(7.dp))
                        NexusMarkdown(ui.streaming.takeLast(3000))
                    }
                }
            }
        }
        if (!state.active) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!state.complete) NexusPrimaryButton(
                        text = stringResource(R.string.action_resume),
                        onClick = { ui.activity.nexusResume() }, modifier = Modifier.fillMaxWidth())
                    else NexusPrimaryButton(
                        text = stringResource(R.string.action_followup),
                        onClick = { followUp = true }, modifier = Modifier.fillMaxWidth())
                    if (state.versionCount > 0) OutlinedButton(onClick = { ui.activity.nexusOpenVersions() },
                        modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.action_versions)) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { ui.activity.nexusExport() }, Modifier.weight(1f)) {
                            Text(stringResource(R.string.action_export))
                        }
                        OutlinedButton(onClick = { journal = true }, Modifier.weight(1f),
                            enabled = state.log.isNotBlank()) {
                            Text(stringResource(R.string.action_journal))
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(18.dp)) }
    }
    if (followUp) FollowUpDialog(ui, { followUp = false })
    if (journal) AlertDialog(onDismissRequest = { journal = false },
        title = { Text(stringResource(R.string.action_journal)) },
        text = { SelectionContainer {
            Text(state.log, modifier = Modifier.heightIn(max = 450.dp).verticalScroll(rememberScrollState()),
                style = MaterialTheme.typography.bodyMedium)
        } },
        confirmButton = { TextButton(onClick = { journal = false }) { Text(stringResource(R.string.action_close)) } })
}

/** Completion of the model workflow is not evidence of executing or testing generated code. */
@Composable
internal fun verificationOutcomeLabel(check: PythonVerification, hasPython: Boolean): String = when (check.status) {
    PythonVerification.Status.NONE -> stringResource(
        if (hasPython) R.string.ui_python_not_verified else R.string.ui_ai_answer_completed)
    PythonVerification.Status.CHECKING -> stringResource(R.string.verify_checking)
    PythonVerification.Status.REPAIRING -> stringResource(R.string.verify_repairing)
    PythonVerification.Status.PASSED -> stringResource(R.string.verify_passed)
    PythonVerification.Status.RAN -> stringResource(R.string.verify_ran)
    PythonVerification.Status.LIMITED -> stringResource(R.string.verify_limited)
    PythonVerification.Status.ERROR -> stringResource(R.string.ui_verification_failed)
    PythonVerification.Status.STOPPED -> stringResource(R.string.ui_verification_unconfirmed)
}

private fun verificationTitle(status: PythonVerification.Status): Int = when (status) {
    PythonVerification.Status.CHECKING -> R.string.verify_checking
    PythonVerification.Status.REPAIRING -> R.string.verify_repairing
    PythonVerification.Status.PASSED -> R.string.verify_passed
    PythonVerification.Status.RAN -> R.string.verify_ran
    PythonVerification.Status.LIMITED -> R.string.verify_limited
    else -> R.string.verify_stopped
}

@Composable
internal fun VerificationFeatures(check: PythonVerification) {
    val review = remember(check) { check.featureReview() }
    if (review.length() == 0) return
    val labels = mapOf(
        "часы" to R.string.feature_clock, "календарь" to R.string.feature_calendar,
        "погода" to R.string.feature_weather, "Bluetooth" to R.string.feature_bluetooth,
        "графический интерфейс" to R.string.feature_gui
    )
    for ((flag, title) in listOf("source_indicator" to R.string.feature_seen, "not_identified" to R.string.feature_missing)) {
        val names = labels.filterKeys { review.optString(it) == flag }.values.map { stringResource(it) }
        if (names.isNotEmpty()) NexusLabel(stringResource(title, names.joinToString(", ")))
    }
}

@Composable
private fun VerificationCard(check: PythonVerification) {
    var expanded by remember(check.source) { mutableStateOf(false) }
    val history = remember(check) { check.diagnosticsHistory() }
    NexusCard {
        Text(verificationOutcomeLabel(check, true), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        NexusLabel(stringResource(R.string.verify_code))
        if (check.syntax) NexusLabel(stringResource(R.string.verify_syntax))
        if (check.ran) NexusLabel(stringResource(R.string.verify_executed))
        if (check.total > 0) NexusLabel(stringResource(R.string.verify_count, check.passed, check.total))
        VerificationFeatures(check)
        if (check.requests > 0) NexusLabel(stringResource(R.string.verify_calls, check.requests))
        if (history.isNotBlank() && check.rounds > 0) {
            TextButton(onClick = { expanded = !expanded }) { Text(stringResource(R.string.action_journal)) }
            if (expanded) SelectionContainer { Text(history, style = MaterialTheme.typography.bodySmall) }
        }
        if (check.diagnostic.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            SelectionContainer { Text(check.diagnostic, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun StepOutputCard(ui: NexusComposeUi, stage: NexusState.Stage) {
    NexusCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusPill("${stage.index + 1}")
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(roleTitle(stage.role, stage.index), style = MaterialTheme.typography.titleMedium)
                NexusLabel(stage.modelLabel)
            }
            StatusPill(stringResource(if (stage.done) R.string.status_complete else if (stage.current)
                R.string.status_processing else R.string.status_queued), stage.done)
        }
        if (stage.warnings.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text("⚠ " + stringResource(R.string.warning_integrity) + "\n" + stage.warnings,
                color = MaterialTheme.colorScheme.error)
        }
        if (stage.answer.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            NexusMarkdown(stage.answer.take(7000))
            if (stage.hasPython && stage.done) {
                OutlinedButton(enabled = !ui.snapshot.active, onClick = { ui.activity.nexusRunPython(stage.index) }) {
                    Text(stringResource(R.string.action_python))
                }
            }
        } else {
            Spacer(Modifier.height(10.dp)); NexusLabel(stringResource(R.string.status_waiting))
        }
    }
}

@Composable
private fun FollowUpDialog(ui: NexusComposeUi, dismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = dismiss,
        title = { Text(stringResource(R.string.followup_title)) },
        text = { Column {
            NexusLabel(stringResource(R.string.followup_body))
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.followup_hint)) }, maxLines = 6)
        } },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = {
            dismiss(); ui.activity.nexusFollowUp(text)
        }) { Text(stringResource(R.string.action_send)) } },
        dismissButton = { TextButton(onClick = dismiss) { Text(stringResource(R.string.action_cancel)) } })
}

@Composable
fun HistoryScreen(ui: NexusComposeUi) {
    if (ui.historySearching) { MessageSearch(ui, true); return }
    val state = ui.snapshot
    var query by remember { mutableStateOf("") }
    val config = LocalConfiguration.current
    val locale = config.locales[0] ?: Locale.getDefault()
    val formatter = remember(locale) { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, locale) }
    val filtered = state.tasks.filter { it.title.contains(query, ignoreCase = true) }
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            TextButton(onClick = { ui.historySearching = true }) { Text(stringResource(R.string.search_all)) }
            NexusLabel(stringResource(R.string.history_description))
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(),
                leadingIcon = { NexusGlyph(R.drawable.ic_nia_search, null, Modifier.size(24.dp)) },
                label = { Text(stringResource(R.string.history_search)) }, singleLine = true)
        }
        if (filtered.isEmpty()) item {
            NexusCard { NexusLabel(stringResource(R.string.history_empty)) }
        }
        items(filtered, key = { it.id }) { task ->
            NexusCard(highlighted = task.selected, onClick = { ui.activity.nexusOpenTask(task.id) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NexusGlyph(R.drawable.ic_nia_document, null, Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(task.title, style = MaterialTheme.typography.titleMedium, maxLines = 2,
                            overflow = TextOverflow.Ellipsis)
                        NexusLabel(formatter.format(Date(task.updatedAt)))
                        if (task.verification != PythonVerification.Status.NONE)
                            NexusLabel(stringResource(verificationTitle(task.verification)))
                    }
                    if (task.verification == PythonVerification.Status.NONE) StatusPill(stringResource(if (task.completed) R.string.status_complete
                        else if (task.hasRun) R.string.status_saved else R.string.status_draft), task.completed)
                }
                if (task.versions > 0) {
                    Spacer(Modifier.height(8.dp))
                    NexusLabel(stringResource(R.string.history_versions, task.versions))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { ui.deleteTarget = task.id }) {
                        NexusGlyph(R.drawable.ic_nia_delete, null, Modifier.size(28.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(stringResource(R.string.action_delete), color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

}

@Composable
fun ModelsScreen(ui: NexusComposeUi) {
    val state = ui.snapshot
    var provider by remember { mutableStateOf("") }
    val displayed = state.models.filter { provider.isEmpty() || it.provider.contains(provider, ignoreCase = true) }
    LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            NexusLabel(stringResource(R.string.models_description))
            Spacer(Modifier.height(10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("" to R.string.models_all, "OpenRouter" to R.string.models_openrouter,
                    "Groq" to R.string.models_groq, "Gemini" to R.string.models_gemini).forEach { (id, title) ->
                    FilterChip(selected = provider == id, onClick = { provider = id },
                        label = { Text(stringResource(title)) })
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                NexusPrimaryButton(text = stringResource(R.string.models_settings),
                    onClick = { ui.requestKeys() }, modifier = Modifier.weight(1f), glow = false,
                    leadingIcon = { NexusGlyph(R.drawable.ic_nia_key, null, Modifier.size(24.dp)) })
                OutlinedIconButton(onClick = { ui.activity.nexusRefreshModels() },
                    modifier = Modifier.size(54.dp)) {
                    NexusGlyph(R.drawable.ic_nia_refresh, stringResource(R.string.action_refresh), Modifier.size(30.dp))
                }
            }
        }
        items(displayed, key = { it.id }) { model ->
            NexusCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProviderLogo(model.label, model.id, model.provider, Modifier.size(40.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(model.label, style = MaterialTheme.typography.titleMedium)
                        if (model.imageInput) Text(stringResource(R.string.attachment_vision_capable),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(model.provider, modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            KeyStatusPill(stringResource(if (model.configured)
                                R.string.status_key_configured else R.string.status_key_missing), model.configured)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(14.dp)) }
    }
}

@Composable
fun SettingsScreen(ui: NexusComposeUi) {
    val theme = ui.theme
    val language = ui.activity.nexusLanguageChoice()
    var languageOpen by remember { mutableStateOf(false) }
    val themes = listOf("system" to R.string.theme_system, "dark" to R.string.theme_dark,
        "light" to R.string.theme_light)
    val languages = listOf("system" to R.string.language_system, "ru" to R.string.language_ru,
        "en" to R.string.language_en, "zh-CN" to R.string.language_zh,
        "ar" to R.string.language_ar, "ja" to R.string.language_ja)
    LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            NexusCard(modifier = Modifier.fillMaxWidth()) {
                SettingsHeading(R.drawable.ic_nia_theme, stringResource(R.string.settings_appearance))
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    themes.forEach { (key, label) ->
                        FilterChip(selected = theme == key,
                            onClick = { ui.activity.nexusThemeChanged(key) },
                            label = { Text(stringResource(label)) })
                    }
                }
            }
        }
        item {
            NexusCard(modifier = Modifier.fillMaxWidth()) {
                SettingsHeading(R.drawable.ic_nia_language, stringResource(R.string.settings_language))
                Spacer(Modifier.height(10.dp))
                Box {
                    OutlinedButton(onClick = { languageOpen = true },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Text(stringResource(languages.firstOrNull { it.first == language }?.second
                            ?: R.string.language_system), modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(8.dp))
                        NexusGlyph(R.drawable.ic_nia_chevron_down, null, Modifier.size(20.dp))
                    }
                    DropdownMenu(expanded = languageOpen, onDismissRequest = { languageOpen = false }) {
                        languages.forEach { (key, label) ->
                            DropdownMenuItem(text = { Text(stringResource(label)) },
                                leadingIcon = { RadioButton(selected = language == key, onClick = null) },
                                onClick = {
                                    languageOpen = false
                                    ui.activity.nexusLanguageChanged(key)
                                })
                        }
                    }
                }
            }
        }
        item {
            NexusCard(modifier = Modifier.fillMaxWidth(), onClick = { ui.requestKeys() }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SettingsHeading(R.drawable.ic_nia_key, stringResource(R.string.settings_providers))
                        Spacer(Modifier.height(10.dp))
                        NexusLabel(stringResource(R.string.keys_warning))
                    }
                    Spacer(Modifier.width(8.dp))
                    NexusGlyph(R.drawable.ic_nia_chevron_down, null, Modifier.size(20.dp))
                }
            }
        }
        item {
            NexusCard(modifier = Modifier.fillMaxWidth()) {
                SettingsHeading(R.drawable.ic_nia_info, stringResource(R.string.settings_about))
                Spacer(Modifier.height(10.dp))
                NexusLabel(stringResource(R.string.settings_version))
                Spacer(Modifier.height(4.dp))
                NexusLabel(stringResource(R.string.settings_privacy))
            }
        }
        item { Spacer(Modifier.height(15.dp)) }
    }
}

@Composable
private fun SettingsHeading(icon: Int, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        NexusGlyph(icon, null, Modifier.size(30.dp))
        Text(title, style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface)
    }
}


@Composable
fun VersionsDialog(ui: NexusComposeUi) {
    val labels = remember { ui.activity.nexusVersionLabels().toList() }
    var selected by remember { mutableIntStateOf(-1) }
    AlertDialog(onDismissRequest = { ui.dismissVersions() },
        title = { Text(stringResource(R.string.action_versions)) },
        text = {
            if (selected < 0) {
                LazyColumn(Modifier.heightIn(max = 450.dp)) {
                    items(labels.indices.toList()) { index ->
                        ListItem(headlineContent = { Text(labels[index]) },
                            modifier = Modifier.clickable { selected = index })
                    }
                }
            } else {
                val result = remember(selected) { ui.activity.nexusVersionAnswer(selected) }
                Column(Modifier.heightIn(max = 470.dp).verticalScroll(rememberScrollState())) {
                    NexusMarkdown(result)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (selected >= 0) selected = -1 else ui.dismissVersions() }) {
                Text(stringResource(if (selected < 0) R.string.action_close else R.string.action_back))
            }
        })
}
