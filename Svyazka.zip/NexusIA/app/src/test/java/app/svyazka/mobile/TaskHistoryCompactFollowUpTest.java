package app.svyazka.mobile;

import static org.junit.Assert.*;
import org.junit.Test;

/** Follow-up compaction must remove generated scaffolding, not user requirements. */
public class TaskHistoryCompactFollowUpTest {
    private static final String HEADING = "Предыдущие уточнения пользователя:";

    private static int count(String value, String part) {
        int result = 0;
        for (int from = 0; (from = value.indexOf(part, from)) >= 0; from += part.length()) result++;
        return result;
    }

    @Test public void longConversationHasOnlyOneGeneratedUpdatesHeading() {
        String task = "Создай main.py. Сохрани функцию add.";
        for (int turn = 1; turn <= 20; turn++) {
            task = TaskHistory.followUp(task,
                    "```python file=main.py\nprint('version " + turn + "')\n```",
                    "Уточнение номер " + turn + ": добавь самостоятельную проверку " + turn + ".");
            String requirements = TaskHistory.forRepair(task);
            assertEquals("iteration " + turn, 1, count(requirements, HEADING));
            assertTrue(requirements.contains("Создай main.py. Сохрани функцию add."));
            for (int earlier = 1; earlier <= turn; earlier++)
                assertTrue("lost user turn " + earlier,
                        requirements.contains("Уточнение номер " + earlier + ": добавь самостоятельную проверку " + earlier + "."));
            assertEquals("Уточнение: Уточнение номер " + turn + ": добавь самостоятельную проверку " + turn + ".",
                    TaskHistory.displayTask(task));
            assertTrue(task.contains("print('version " + turn + "')"));
        }
    }

    @Test public void newOutputContractReplacesOldWithoutRemovingUniqueRequirements() {
        String task = TaskHistory.followUp("Сохрани функцию add.\nОжидаемый вывод: ПРЕЖНИЙ",
                "```python\nprint('ПРЕЖНИЙ')\n```", "Добавь проверку значений 15 и 25.");
        task = TaskHistory.followUp(task, "```python\nprint('СЛЕДУЮЩИЙ')\n```",
                "Ожидаемый вывод: «НОВЫЙ».\nНе удаляй проверку значений 15 и 25.");
        String requirements = TaskHistory.forRepair(task);
        assertEquals(1, count(requirements, HEADING));
        assertTrue(requirements.contains("Сохрани функцию add."));
        assertTrue(requirements.contains("Добавь проверку значений 15 и 25."));
        assertTrue(requirements.contains("Не удаляй проверку значений 15 и 25."));
        assertTrue(requirements.contains("Ожидаемый вывод: «НОВЫЙ»."));
        assertFalse(requirements.contains("Ожидаемый вывод: ПРЕЖНИЙ"));
    }

    @Test public void noCompactionOfUnrelatedUserTextOrPreviousSource() {
        String user = "Создай main.py.\nЭто буквальный заголовок: Предыдущие уточнения пользователя:";
        String answer = "```python file=main.py\nprint('first source')\n```";
        String task = TaskHistory.followUp(user, answer, "Допиши вторую функцию.");
        assertTrue(TaskHistory.forRepair(task).contains(user));
        assertTrue(task.contains("print('first source')"));
        assertTrue(TaskHistory.currentUserTestRequest(task).contains("Допиши вторую функцию"));
    }
}
