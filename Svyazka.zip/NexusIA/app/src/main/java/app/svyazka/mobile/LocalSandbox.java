package app.svyazka.mobile;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebMessage;
import android.webkit.WebMessagePort;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import org.json.JSONException;
import org.json.JSONObject;

final class LocalSandbox {
    private static final String HOST = "svyazka-python.invalid";
    private static final String ORIGIN = "https://" + HOST;
    private static final String PAGE = ORIGIN + "/index.html";
    private static final String CDN_HOST = "cdn.jsdelivr.net";
    private static final String PACKAGE_PATH = "/pyodide/v314.0.8/full/";
    private static final String CSP = "default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; "
            + "connect-src 'self'; worker-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'";
    private static final String CDN_CSP = "default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; "
            + "connect-src 'self' https://cdn.jsdelivr.net; worker-src 'self'; "
            + "base-uri 'none'; frame-ancestors 'none'; form-action 'none'";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Consumer<SandboxClient.Result> result;
    private final Consumer<String> problem;
    private Consumer<JSONObject> progress;
    private Consumer<JSONObject> verified;
    private Runnable deadline;
    private WebView view;
    private WebMessagePort port;

    LocalSandbox(Consumer<SandboxClient.Result> result, Consumer<String> problem) {
        this.result = result;
        this.problem = problem;
    }

    void execute(Context context, String code, String stdin) {
        execute(context, code, stdin, false);
    }

    void execute(Context context, String code, String stdin, boolean allowMatplotlib) {
        String message;
        try {
            message = new JSONObject().put("code", code).put("stdin", stdin)
                    .put("allow_matplotlib", allowMatplotlib).toString();
        } catch (JSONException e) {
            fail("Не удалось подготовить Python."); return;
        }
        open(context, message, allowMatplotlib);
    }
    void executeProject(Context context, String code, String stdin, JSONObject files,
                        String entry, String allowedPackage, boolean extended) {
        executeProject(context, code, stdin, files, entry, allowedPackage, extended, false);
    }
    void executeProject(Context context, String code, String stdin, JSONObject files,
                        String entry, String allowedPackage, boolean extended, boolean projectTests) {
        if (!allowedPackage.equals("") && !allowedPackage.equals("matplotlib") && !allowedPackage.equals("numpy")) {
            fail("Недопустимый пакет Python."); return;
        }
        try {
            JSONObject payload = new JSONObject().put("code", code).put("stdin", stdin)
                    .put("entry", entry).put("files", files).put("package", allowedPackage)
                    .put("extended", extended).put("project_tests", projectTests);
            open(context, payload.toString(), !allowedPackage.isEmpty(), extended, projectTests);
        } catch (JSONException e) { fail("Не удалось подготовить Python-проект."); }
    }
    void verify(Context context, JSONObject request, Consumer<JSONObject> progress, Consumer<JSONObject> verified) {
        this.progress = progress; this.verified = verified;
        open(context, request.toString(), false);
    }
    private void open(Context context, String message, boolean allowMatplotlib) {
        open(context, message, allowMatplotlib, false);
    }
    private void open(Context context, String message, boolean allowMatplotlib, boolean extended) {
        open(context, message, allowMatplotlib, extended, false);
    }
    private void open(Context context, String message, boolean allowMatplotlib, boolean extended, boolean projectCheck) {
        final boolean automatic = verified != null || projectCheck;
        try { view = new WebView(context); } catch (RuntimeException e) {
            fail("Не удалось запустить Python. Проверь Android System WebView.");
            return;
        }

        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setDomStorageEnabled(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        view.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView page, WebResourceRequest request) {
                return bundledAsset(context, request, allowMatplotlib, automatic);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView page, WebResourceRequest request) {
                return true;
            }

            @Override public void onPageFinished(WebView page, String url) {
                if (view != page || port != null || !PAGE.equals(url)) return;
                WebMessagePort[] channel = page.createWebMessageChannel();
                port = channel[0];
                port.setWebMessageCallback(new WebMessagePort.WebMessageCallback() {
                    @Override public void onMessage(WebMessagePort sender, WebMessage output) {
                        if (port == sender) accept(output.getData());
                    }
                }, handler);
                page.postWebMessage(new WebMessage(message, new WebMessagePort[] {channel[1]}),
                        Uri.parse(ORIGIN));
            }

            @Override public void onReceivedError(WebView page, WebResourceRequest request,
                                                  WebResourceError error) {
                if (view == page && request.isForMainFrame()) fail("Не удалось открыть локальную песочницу.");
            }

            @Override public boolean onRenderProcessGone(WebView page, RenderProcessGoneDetail detail) {
                if (view == page) fail("Песочница завершилась. Проверь объём памяти, который использует код.");
                return true;
            }
        });
        deadline = () -> fail(allowMatplotlib
                ? "Загрузка пакетов и запуск Python не завершились за 180 секунд."
                : extended ? "Запуск Python на телефоне не завершился за 75 секунд."
                : "Запуск Python на телефоне не завершился за 40 секунд.");
        handler.postDelayed(deadline, allowMatplotlib ? 180_000 : extended ? 75_000 : 40_000);
        view.loadUrl(PAGE);
    }

    private static WebResourceResponse bundledAsset(Context context,
                                                    WebResourceRequest request, boolean allowMatplotlib, boolean automatic) {
        Uri url = request.getUrl();
        String path = url.getEncodedPath();
        if (allowMatplotlib && "https".equals(url.getScheme())
                && CDN_HOST.equals(url.getHost()) && path != null
                && path.startsWith(PACKAGE_PATH) && "GET".equals(request.getMethod())
                && !request.isForMainFrame()) {
            // Only explicit user opt-in enables pinned Pyodide wheel downloads.
            // Never forward keys or application data to this origin.
            return null;
        }
        if (!"GET".equals(request.getMethod()) || !"https".equals(url.getScheme())
                || !HOST.equals(url.getEncodedAuthority()) || path == null) {
            return denied();
        }
        String type;
        switch (path) {
            case "/verify.py":
            case "/workspace.py": type = "text/plain"; break;
            case "/index.html": type = "text/html"; break;
            case "/runner.js":
            case "/worker.mjs":
            case "/pyodide/pyodide.mjs":
            case "/pyodide/pyodide.asm.mjs": type = "application/javascript"; break;
            case "/pyodide/pyodide.asm.wasm": type = "application/wasm"; break;
            case "/pyodide/pyodide-lock.json": type = "application/json"; break;
            case "/pyodide/python_stdlib.zip": type = "application/zip"; break;
            default: return denied();
        }
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put("Content-Security-Policy", allowMatplotlib ? CDN_CSP : CSP);
            headers.put("X-Content-Type-Options", "nosniff");
            headers.put("Cache-Control", "no-store");
            java.io.InputStream stream = context.getAssets().open("sandbox" + path);
            if (automatic && "/pyodide/pyodide.asm.wasm".equals(path)) stream = VerificationMemory.limit(stream);
            return new WebResourceResponse(type, null, 200, "OK", headers, stream);
        } catch (IOException e) {
            return denied();
        }
    }

    private static WebResourceResponse denied() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden",
                java.util.Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    private void accept(String message) {
        SandboxClient.Result output;
        try {
            JSONObject json = new JSONObject(message);
            if (json.has("error")) {
                fail(json.getString("error"));
                return;
            }
            if (verified != null) {
                if (json.has("progress")) progress.accept(json.getJSONObject("progress"));
                else if (json.has("verification")) {
                    JSONObject report = json.getJSONObject("verification"); close(); verified.accept(report);
                } else fail(json.optString("status", "Проверка не завершилась."));
                return;
            }
            Integer code = json.isNull("code") ? null : json.getInt("code");
            String html = json.optString("html", "");
            String png = json.optString("image_png", "");
            org.json.JSONArray artifacts = json.optJSONArray("artifacts");
            org.json.JSONArray tests = json.optJSONArray("tests");
            if ((artifacts != null && artifacts.length() > 12) ||
                    (tests != null && tests.length() > 12) || message.length() > 2_600_000 ||
                    html.length() > 100_000 || png.length() > 700_000) {
                fail("Визуальный результат превышает безопасный лимит размера.");
                return;
            }
            output = new SandboxClient.Result(json.getString("stdout"),
                    json.getString("stderr"), json.getString("engine"), code,
                    json.optString("status"), html, png, artifacts, tests, json.optString("snapshot_sha256", ""), json.optJSONObject("generated_tests"), json.optBoolean("input_required"));
        } catch (JSONException | RuntimeException e) {
            fail("Не удалось прочитать вывод локальной песочницы.");
            return;
        }
        close();
        result.accept(output);
    }

    private void fail(String message) {
        close();
        problem.accept(message);
    }

    void close() {
        if (deadline != null) handler.removeCallbacks(deadline);
        deadline = null;
        if (port != null) {
            port.close();
            port = null;
        }
        if (view != null) {
            WebView previous = view;
            view = null;
            previous.destroy();
        }
    }
}
