package app.svyazka.mobile.ui

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import app.svyazka.mobile.AttachmentParser
import app.svyazka.mobile.AttachmentProblem.Code
import app.svyazka.mobile.R
import app.svyazka.mobile.attachments.AttachmentStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.UUID

private class CapturePhoto : ActivityResultContracts.TakePicture() {
    override fun createIntent(context: Context, input: Uri): Intent = super.createIntent(context, input).apply {
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        clipData = ClipData.newRawUri("Nexus AI camera", input)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun rememberAttachFileAction(ui: NexusComposeUi): () -> Unit {
    val context = LocalContext.current
    val store = remember(context.applicationContext) { AttachmentStore.get(context) }
    val keyboard = LocalSoftwareKeyboardController.current
    var open by rememberSaveable { mutableStateOf(false) }
    var targetTask by rememberSaveable { mutableLongStateOf(ui.taskId) }
    var pendingCamera by rememberSaveable { mutableStateOf<String?>(null) }
    val camera = rememberLauncherForActivityResult(CapturePhoto()) { success ->
        val filename = pendingCamera
        pendingCamera = null
        if (filename != null) {
            val file = File(context.cacheDir, "attachment-camera/$filename")
            when {
                !success -> file.delete()
                targetTask != ui.taskId -> {
                    file.delete()
                    Toast.makeText(context, AttachmentMessages.format(context, Code.INTERRUPTED, ""), Toast.LENGTH_LONG).show()
                }
                !file.isFile -> Toast.makeText(context, AttachmentMessages.format(context, Code.MISSING, ""), Toast.LENGTH_LONG).show()
                else -> store.add(targetTask, listOf(FileProvider.getUriForFile(context, context.packageName + ".attachments", file)))
            }
        }
    }
    val photos = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        if (uris.isNotEmpty()) {
            if (targetTask == ui.taskId) store.add(targetTask, uris)
            else Toast.makeText(context, AttachmentMessages.format(context, Code.INTERRUPTED, ""), Toast.LENGTH_LONG).show()
        }
    }
    val documents = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            if (targetTask == ui.taskId) store.add(targetTask, uris)
            else Toast.makeText(context, AttachmentMessages.format(context, Code.INTERRUPTED, ""), Toast.LENGTH_LONG).show()
        }
    }
    if (open) {
        ModalBottomSheet(onDismissRequest = { open = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp)) {
                Text(stringResource(R.string.attachment_menu), style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                AttachmentAction(Icons.Outlined.PhotoCamera, stringResource(R.string.attachment_camera)) {
                    open = false; targetTask = ui.taskId
                    try {
                        val folder = File(context.cacheDir, "attachment-camera").apply { mkdirs() }
                        val file = File(folder, "IMG_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg")
                        check(file.createNewFile())
                        pendingCamera = file.name
                        camera.launch(FileProvider.getUriForFile(context, context.packageName + ".attachments", file))
                    } catch (_: Exception) {
                        pendingCamera?.let { File(context.cacheDir, "attachment-camera/$it").delete() }; pendingCamera = null
                        Toast.makeText(context, R.string.attachment_camera_unavailable, Toast.LENGTH_LONG).show()
                    }
                }
                AttachmentAction(Icons.Outlined.PhotoLibrary, stringResource(R.string.attachment_photos)) {
                    open = false; targetTask = ui.taskId
                    try { photos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                    catch (_: Exception) { Toast.makeText(context, R.string.attachment_file_picker_error, Toast.LENGTH_LONG).show() }
                }
                AttachmentAction(Icons.Outlined.AttachFile, stringResource(R.string.attachment_files)) {
                    open = false; targetTask = ui.taskId
                    try { documents.launch(arrayOf("*/*")) }
                    catch (_: Exception) { Toast.makeText(context, R.string.attachment_file_picker_error, Toast.LENGTH_LONG).show() }
                }
                Text(stringResource(R.string.file_attachment_hint), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp))
            }
        }
    }
    return {
        if (!ui.snapshot.active && !ui.snapshot.clearing) { keyboard?.hide(); open = true }
    }
}

@Composable
private fun AttachmentAction(icon: ImageVector, title: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onClick)
        .heightIn(min = 64.dp).padding(12.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Icon(icon, null, Modifier.size(28.dp), tint = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
internal fun rememberAttachmentTask(ui: NexusComposeUi): AttachmentStore.Task {
    val store = remember(ui.activity.applicationContext) { AttachmentStore.get(ui.activity) }
    val tasks by store.states.collectAsState()
    val pending by store.operations.collectAsState()
    LaunchedEffect(ui.taskId) { store.ensure(ui.taskId) }
    return (tasks[ui.taskId] ?: AttachmentStore.Task()).copy(busy = (pending[ui.taskId] ?: 0) > 0)
}

@Composable
internal fun AttachmentSummary(task: AttachmentStore.Task) {
    val context = LocalContext.current
    if (task.busy && task.loaded) Text(stringResource(R.string.attachment_processing),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
    if (!task.loaded) {
        Text(stringResource(R.string.attachment_err_loading), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (task.items.isNotEmpty()) {
        val total = task.items.filter { it.status == AttachmentStore.Status.READY || it.status == AttachmentStore.Status.PROCESSING }
            .sumOf { it.size.coerceAtLeast(0) }
        Text(stringResource(R.string.attachment_summary, task.items.size, Formatter.formatShortFileSize(context, total)),
            style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    task.notice?.let { code -> Text(AttachmentMessages.format(context, code, ""), color = MaterialTheme.colorScheme.error,
        style = MaterialTheme.typography.bodyMedium) }
    if (task.items.any { it.kind == AttachmentParser.Kind.IMAGE }) {
        Text(stringResource(R.string.attachment_vision_hint), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun typeLabel(item: AttachmentStore.Item): String = if (item.kind == AttachmentParser.Kind.IMAGE && item.mime.isNotEmpty()) {
    item.mime.substringAfter('/').uppercase(Locale.ROOT)
} else AttachmentParser.extension(item.name).ifEmpty { item.kind.name }.uppercase(Locale.ROOT)

@Composable
private fun attachmentStatus(item: AttachmentStore.Item): String = stringResource(when (item.status) {
    AttachmentStore.Status.ADDING -> R.string.attachment_adding
    AttachmentStore.Status.PROCESSING -> R.string.attachment_processing
    AttachmentStore.Status.READY -> if (item.partial) R.string.attachment_partial else R.string.attachment_ready
    AttachmentStore.Status.UNSUPPORTED -> R.string.attachment_unsupported
    AttachmentStore.Status.ERROR -> R.string.attachment_error
    AttachmentStore.Status.LIMIT -> R.string.attachment_limit
})

@Composable
internal fun AttachmentCard(ui: NexusComposeUi, item: AttachmentStore.Item, compact: Boolean = false) {
    val context = LocalContext.current
    val store = remember(context.applicationContext) { AttachmentStore.get(context) }
    var details by rememberSaveable(item.id) { mutableStateOf(false) }
    val error = item.status in listOf(AttachmentStore.Status.ERROR, AttachmentStore.Status.LIMIT, AttachmentStore.Status.UNSUPPORTED)
    val removeLabel = stringResource(R.string.attachment_remove, item.name)
    val cardContent: @Composable ColumnScope.() -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 10.dp)) {
            val previewState = remember(ui.taskId, item.id, item.status) { mutableStateOf<ImageBitmap?>(null) }
            LaunchedEffect(ui.taskId, item.id, item.status) {
                previewState.value = if (item.kind == AttachmentParser.Kind.IMAGE && item.status == AttachmentStore.Status.READY)
                    withContext(Dispatchers.IO) { BitmapFactory.decodeFile(store.preview(ui.taskId, item.id).absolutePath)?.asImageBitmap() }
                else null
            }
            val preview = previewState.value
            if (preview != null) Image(preview, null,
                Modifier.size(if (compact) 28.dp else 44.dp).clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Fit)
            else NexusGlyph(when (item.kind) {
                AttachmentParser.Kind.IMAGE -> R.drawable.ic_nia_image
                AttachmentParser.Kind.ZIP -> R.drawable.ic_nia_folder
                AttachmentParser.Kind.TEXT -> R.drawable.ic_nia_code
                else -> R.drawable.ic_nia_document
            }, null, Modifier.size(if (compact) 26.dp else 36.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, maxLines = if (compact) 1 else 2,
                    overflow = TextOverflow.Ellipsis,
                    style = if (compact) MaterialTheme.typography.labelLarge else MaterialTheme.typography.titleMedium)
                val size = if (item.size >= 0) Formatter.formatShortFileSize(context, item.size)
                    else stringResource(R.string.attachment_unknown_size)
                if (compact) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${typeLabel(item)} · $size", modifier = Modifier.weight(1f, fill = false),
                            style = MaterialTheme.typography.bodySmall, maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(attachmentStatus(item), style = MaterialTheme.typography.bodySmall,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    }
                } else {
                    Text("${typeLabel(item)} · $size", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(attachmentStatus(item), style = MaterialTheme.typography.bodySmall,
                        color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                }
            }
            IconButton(onClick = { store.remove(ui.taskId, item.id) },
                enabled = !ui.snapshot.active && !ui.snapshot.clearing,
                modifier = Modifier.size(48.dp).semantics { contentDescription = removeLabel }) {
                Icon(Icons.Outlined.Close, null, Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (!compact) item.problem?.let {
            Text(AttachmentMessages.format(context, it, ""), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        }
    }
    if (compact) {
        Surface(onClick = { details = true }, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f))) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 3.dp), content = cardContent)
        }
    } else {
        NexusCard(modifier = Modifier.fillMaxWidth(), onClick = { details = true }, content = cardContent)
    }
    if (details) AlertDialog(onDismissRequest = { details = false },
        title = { Text(stringResource(R.string.attachment_details)) },
        text = {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { SelectionContainer { Text(item.name, style = MaterialTheme.typography.titleMedium) } }
                item { Text(attachmentStatus(item), style = MaterialTheme.typography.bodyMedium) }
                if (item.total > 0 && (item.kind == AttachmentParser.Kind.ZIP || item.kind == AttachmentParser.Kind.PDF)) {
                    item { Text(stringResource(R.string.attachment_processed, item.processed, item.total)) }
                }
                item.problem?.let { code -> item { Text(AttachmentMessages.format(context, code, ""), color = MaterialTheme.colorScheme.error) } }
                items(item.notes) { note ->
                    Column {
                        Text(note.name, style = MaterialTheme.typography.labelLarge)
                        Text(if (note.code == null) stringResource(R.string.attachment_report_read)
                            else AttachmentMessages.format(context, note.code, ""),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { details = false }) { Text(stringResource(R.string.action_close)) } })
}
