package app.svyazka.mobile;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

/** Durable events and incremental stream checkpoints in the existing per-chat SQLite database.
 * No network activity, API keys, HTTP headers or automatic replay. */
final class ChatRunJournal {
    private static final int MAX_SNAPSHOT_CHARS = 500_000;
    private final TaskRepository repository;

    static final class Snapshot {
        final String runId;
        final String attemptId;
        final String text;
        final int step;
        final long savedAt;
        Snapshot(String runId, String attemptId, String text, int step, long savedAt) {
            this.runId = runId;
            this.attemptId = attemptId;
            this.text = text;
            this.step = step;
            this.savedAt = savedAt;
        }
    }

    ChatRunJournal(TaskRepository repository) { this.repository = repository; }

    static String newId() { return UUID.randomUUID().toString(); }

    synchronized boolean event(long taskId, String runId, String attemptId, int step,
                               String eventType, String modelId) {
        if (taskId <= 0 || !validId(runId) || (attemptId != null && !validId(attemptId))
                || eventType == null || !eventType.matches("[A-Z_]{3,40}")) return false;
        SQLiteDatabase db = repository.getWritableDatabase();
        ContentValues row = new ContentValues();
        row.put("task_id", taskId);
        row.put("run_id", runId);
        row.put("attempt_id", attemptId);
        row.put("step_id", step);
        row.put("event_type", eventType);
        row.put("created_at", System.currentTimeMillis());
        // Model identifiers are ordinary metadata; never persist network credentials.
        JSONObject payload = new JSONObject();
        if (modelId != null && !modelId.isEmpty()) {
            try { payload.put("model", modelId.length() > 256 ? modelId.substring(0, 256) : modelId); }
            catch (JSONException invalid) { return false; }
        }
        row.put("payload_json", payload.toString());
        try { return db.insertOrThrow("chat_run_events", null, row) != -1; }
        catch (RuntimeException failure) { return false; }
    }

    synchronized String latestRunId(long taskId) {
        try (Cursor cursor = repository.getReadableDatabase().rawQuery(
                "SELECT run_id FROM chat_run_events WHERE task_id=? "
                        + "AND event_type='RUN_STARTED' ORDER BY id DESC LIMIT 1",
                new String[]{Long.toString(taskId)})) {
            return cursor.moveToFirst() ? cursor.getString(0) : "";
        }
    }

    /** Atomically append ONLY new characters and commit their checksum with the checkpoint.
     * Refuses an out-of-order, rewritten or mismatched stream rather than combining its fragments. */
    synchronized boolean checkpoint(long taskId, String runId, String attemptId, int step, String completeText) {
        if (taskId <= 0 || !validId(runId) || !validId(attemptId) || completeText == null
                || completeText.length() > MAX_SNAPSHOT_CHARS) return false;
        SQLiteDatabase db = repository.getWritableDatabase();
        db.beginTransaction();
        try {
            if (!attemptBelongsTo(db, taskId, runId, attemptId)) return false;
            int savedChars = 0;
            int previousChunk = -1;
            String previousHash = null;
            try (Cursor cursor = db.rawQuery(
                    "SELECT last_chunk_no,saved_chars,content_sha256 FROM chat_checkpoints "
                            + "WHERE task_id=? AND run_id=? AND attempt_id=? ORDER BY id DESC LIMIT 1",
                    new String[]{Long.toString(taskId), runId, attemptId})) {
                if (cursor.moveToFirst()) {
                    previousChunk = cursor.getInt(0);
                    savedChars = cursor.getInt(1);
                    previousHash = cursor.getString(2);
                }
            }
            if (savedChars > completeText.length()) return false;
            if (previousHash != null) {
                // Validate the actual stored chunks, not just the previous metadata.
                // A damaged chunk must never become the foundation of a new checkpoint.
                StringBuilder durable = new StringBuilder();
                int expected = 0;
                try (Cursor chunks = db.rawQuery(
                        "SELECT chunk_no,text FROM chat_stream_chunks WHERE task_id=? "
                                + "AND run_id=? AND attempt_id=? AND chunk_no<=? ORDER BY chunk_no",
                        new String[]{Long.toString(taskId), runId, attemptId, Integer.toString(previousChunk)})) {
                    while (chunks.moveToNext()) {
                        if (chunks.getInt(0) != expected++) return false;
                        durable.append(chunks.getString(1));
                        if (durable.length() > MAX_SNAPSHOT_CHARS) return false;
                    }
                }
                if (expected != previousChunk + 1 || durable.length() != savedChars
                        || !previousHash.equals(sha(durable.toString()))
                        || !completeText.startsWith(durable.toString())) return false;
            }
            if (savedChars == completeText.length()) {
                db.setTransactionSuccessful();
                return true; // No duplicate chunk/checkpoint for a repeated callback.
            }
            int nextChunk = previousChunk + 1;
            ContentValues chunk = new ContentValues();
            chunk.put("task_id", taskId);
            chunk.put("run_id", runId);
            chunk.put("attempt_id", attemptId);
            chunk.put("chunk_no", nextChunk);
            chunk.put("text", completeText.substring(savedChars));
            chunk.put("created_at", System.currentTimeMillis());
            db.insertOrThrow("chat_stream_chunks", null, chunk);

            JSONObject state = new JSONObject();
            state.put("step", step);
            state.put("status", "PARTIAL");
            ContentValues point = new ContentValues();
            point.put("task_id", taskId);
            point.put("run_id", runId);
            point.put("attempt_id", attemptId);
            point.put("last_chunk_no", nextChunk);
            point.put("saved_chars", completeText.length());
            point.put("state_json", state.toString());
            point.put("content_sha256", sha(completeText));
            point.put("created_at", System.currentTimeMillis());
            db.insertOrThrow("chat_checkpoints", null, point);
            db.setTransactionSuccessful();
            return true;
        } catch (JSONException | RuntimeException failure) {
            return false;
        } finally {
            db.endTransaction();
        }
    }

    /** Return null when there is no checkpoint OR its data fails an integrity check. */
    synchronized Snapshot latestSnapshot(long taskId, String attemptId) {
        if (taskId <= 0 || !validId(attemptId)) return null;
        SQLiteDatabase db = repository.getReadableDatabase();
        String runId, expectedHash;
        int lastChunk, chars, step;
        long timestamp;
        try (Cursor c = db.rawQuery(
                "SELECT run_id,last_chunk_no,saved_chars,content_sha256,state_json,created_at "
                        + "FROM chat_checkpoints WHERE task_id=? AND attempt_id=? ORDER BY id DESC LIMIT 1",
                new String[]{Long.toString(taskId), attemptId})) {
            if (!c.moveToFirst()) return null;
            runId = c.getString(0);
            lastChunk = c.getInt(1);
            chars = c.getInt(2);
            expectedHash = c.getString(3);
            try { step = new JSONObject(c.getString(4)).getInt("step"); }
            catch (JSONException invalid) { return null; }
            timestamp = c.getLong(5);
        }
        StringBuilder text = new StringBuilder();
        int expectedChunk = 0;
        try (Cursor c = db.rawQuery(
                "SELECT chunk_no,text FROM chat_stream_chunks WHERE task_id=? AND run_id=? "
                        + "AND attempt_id=? AND chunk_no<=? ORDER BY chunk_no",
                new String[]{Long.toString(taskId), runId, attemptId, Integer.toString(lastChunk)})) {
            while (c.moveToNext()) {
                if (c.getInt(0) != expectedChunk++) return null;
                text.append(c.getString(1));
                if (text.length() > MAX_SNAPSHOT_CHARS) return null;
            }
        }
        if (lastChunk != expectedChunk - 1 || chars != text.length()
                || !expectedHash.equals(sha(text.toString()))) return null;
        return new Snapshot(runId, attemptId, text.toString(), step, timestamp);
    }

    private static boolean attemptBelongsTo(SQLiteDatabase db, long taskId, String runId, String attemptId) {
        try (Cursor cursor = db.rawQuery(
                "SELECT 1 FROM chat_run_events WHERE task_id=? AND run_id=? AND attempt_id=? "
                        + "AND event_type='MODEL_ATTEMPT_STARTED' LIMIT 1",
                new String[]{Long.toString(taskId), runId, attemptId})) {
            return cursor.moveToFirst();
        }
    }

    private static String sha(String source) {
        return InputMaterial.sha256(source.getBytes(StandardCharsets.UTF_8));
    }

    private static boolean validId(String id) {
        return id != null && id.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
    }
}
