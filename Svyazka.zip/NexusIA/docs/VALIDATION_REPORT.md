# Отчёт аудита — Nexus AI · 24.11.2026

**Исторический снимок. Актуальные результаты и обязательные правила: [AGENTS.md](../AGENTS.md).** Не использовать этот старый отчёт как приёмку текущего APK.

**Объект:** два предоставленных архива. Программный код и APK не изменялись. Анализ исходников и частичный прогон проверок не являются полным аудитом безопасности или Android-приёмкой.

**Дополнение:** после этого исходного аудита проведены испытания на телефоне и подготовлен отдельный ремонт. Их результаты и ограничения зафиксированы в [PHONE_REPAIR_20261124](PHONE_REPAIR_20261124.md); ниже сохранён исторический отчёт исходного аудита.

## Артефакты и версия

| Объект | Результат |
| --- | --- |
| Svyazka.zip | 382 записей, 318 файлов; CRC без ошибок |
| Nexus-AI-signed-v217777347.zip | 1 файл app-debug.apk; CRC без ошибок |
| Вложенный APK | 352 записи; CRC без ошибок; manifest: 0.7.0, versionCode 217777347, app.svyazka.team, minSdk 26, targetSdk 35 |
| Исходники | app/build.gradle: 0.7.0, versionCode 21, app.svyazka.team, minSdk 26, targetSdk 35 |
| Подпись APK | Маркер APK Signing Block найден; криптографическая проверка и совпадение со старым сертификатом не выполнены (apksigner отсутствует) |

24.11.2026 владелец сообщил, что сборка через GitHub Actions и приложение на телефоне работают, используется постоянный ключ подписи. На предоставленном скриншоте запуск #139 (commit 4289268) имеет статус Success и артефакт Nexus-AI-signed-v217777347. По отдельным функциям протокол приёмки не предоставлен. Различие базового и фактического versionCode не считается подтверждённым дефектом штатной сборки. Сборка, Gradle, workflow, подпись, ключи и нумерация исключены из дальнейших изменений. Независимая проверка происхождения APK и сертификата в данном аудите не выполнялась.

## Выполненные проверки этого снимка

| Проверка | Результат |
| --- | --- |
| CRC всех трёх ZIP-контейнеров (включая APK) | PASS |
| Чтение бинарного AndroidManifest.xml APK | PASS; извлечены поля выше |
| Python: python3 -B -m unittest discover -s tests -p 'test*.py' | FAIL: 148 тестов, 12 failures, 2 errors, остальные 134 без зарегистрированного отказа/ошибки |
| python3 -B scripts/check-resources.py | FAIL: 13 новых кириллических литералов в MainActivity.java, первое нарушение |
| Дополнительная сверка всех Java/Kotlin тем же регулярным выражением с baseline | 81 новая пара файл/уникальный литерал в 10 файлах, всего 492 пары; это результат сканера, не число непереведённых UI-строк |
| node tests/test-python-worker.mjs | НЕ ЗАВЕРШЁН: получены промежуточные результаты, общий процесс не завершился в отведённое время; PASS всему набору не присваивается |
| Gradle compile/lint/JUnit/Robolectric, автономный JVM, WebView, эмулятор, физический телефон | Не запускались в этом аудите; Android SDK/adb/apksigner и Gradle не обнаружены в PATH. Результаты прежнего снимка не переносятся |

### Отказы и ошибки Python-набора

- `ERROR: test_failed_execution_rolls_back_before_ai_retry (test_auto_python_stage4.PythonAutoRepairWiring.test_failed_execution_rolls_back_before_ai_retry)`
- `ERROR: test_workspace_button_remains_visible_and_toggles_link (test_python_chat_link_ui.PythonChatLinkUiTests.test_workspace_button_remains_visible_and_toggles_link)`
- `FAIL: test_chat_link_footer_stacks_with_measurement_and_remains_actionable (test_adaptive_text_150.AdaptiveText150Tests.test_chat_link_footer_stacks_with_measurement_and_remains_actionable)`
- `FAIL: test_followups_replace_old_snapshot_and_detach_prevents_new_snapshot (test_chat_project_connection_end_to_end.ProjectChatConnectionTests.test_followups_replace_old_snapshot_and_detach_prevents_new_snapshot)`
- `FAIL: test_link_is_read_back_before_success (test_chat_project_connection_end_to_end.ProjectChatConnectionTests.test_link_is_read_back_before_success)`
- `FAIL: test_explicit_chat_link_and_separate_save_actions (test_python_chat_history_recovery.PythonArtifactArchitectureTests.test_explicit_chat_link_and_separate_save_actions)`
- `FAIL: test_new_chat_and_standalone_project_have_separate_identifiers (test_python_chat_history_recovery.PythonArtifactArchitectureTests.test_new_chat_and_standalone_project_have_separate_identifiers)`
- `FAIL: test_roboletric_lifecycle_cases_exist (test_python_chat_history_recovery.PythonArtifactArchitectureTests.test_roboletric_lifecycle_cases_exist)`
- `FAIL: test_compose_link_state_is_refreshed_from_database (test_python_chat_link_ui.PythonChatLinkUiTests.test_compose_link_state_is_refreshed_from_database)`
- `FAIL: test_link_does_not_navigate_away (test_python_chat_link_ui.PythonChatLinkUiTests.test_link_does_not_navigate_away)`
- `FAIL: test_zip_replacement_and_backup_are_atomic_and_separate (test_python_easy_mode.EasyPythonWorkspaceTests.test_zip_replacement_and_backup_are_atomic_and_separate)`
- `FAIL: test_frosted_style_uniform (test_python_editor_frosted.PythonEditorAndFrostedUI.test_frosted_style_uniform)`
- `FAIL: test_link_checkmark_comes_from_repository_state (test_theme_transition_and_video_polish.ThemeAndWorkspaceVideoPolish.test_link_checkmark_comes_from_repository_state)`
- `FAIL: test_python_project_and_results_collapsible_preserving_actions (test_tools_and_mode_position.ThreeRequestedUiFixes.test_python_project_and_results_collapsible_preserving_actions)`

Две ошибки вызваны отсутствующими строковыми маркерами в source-contract тестах (ValueError и IndexError). Часть отказов проверяет прежнее расположение UI или устаревшие имена/строки. Это не доказательство отсутствия функции и не основание игнорировать тесты: необходимо сверить поведение, затем исправить тесты либо код. Например, текущий откат перед передачей ошибки учитывает также testFailed; прежний тест ищет точную строку старого условия.

### Дополнительная инвентаризация новых литералов

MainActivity.java 13; PlainTextPromptPolicy.java 10; PythonArtifactRepository.java 12; PythonAutoFeedback.java 23; PythonAutoStage.java 3; PythonAutoTests.java 3; PythonChatFile.java 1; PythonProjectStore.java 3; TaskHistory.java 2; Workflow.java 11. Baseline не изменялся.

### Незавершённый прогон Worker (фактические строки stdout)

```text
independent boundary cases PASSED
wrong result ERROR
syntax ERROR
no oracle RAN
clock and leap calendar PASSED
desktop and BLE LIMITED
dependency LIMITED
file boundary LIMITED
attached data PASSED
incomplete ERROR
memory LIMITED
```

Статусы ERROR/LIMITED/RAN внутри этих сценариев могут быть ожидаемыми ответами тестируемого раннера; без завершения набора нельзя объявлять общий PASS или считать каждую такую строку отказом теста.

## Вывод

Код содержит чёрный ящик, отдельные проекты чатов, оптимизацию контекста и ограниченный цикл автоматического Python. Реестр: [FEATURE_STATUS](FEATURE_STATUS.md). Текущие блокеры и приёмка: [ROADMAP](../ROADMAP.md). Контрольные суммы: [SOURCE_INTEGRITY](SOURCE_INTEGRITY.md).

Старый отчёт от 22.11.2026 сохранён в [archive/VALIDATION_REPORT_2026-11-22.md](archive/VALIDATION_REPORT_2026-11-22.md); его 126 PASS — исторический результат, не текущий. Версия 0.4.1 подтверждена по историческим документам. 24.11.2026 владелец сообщил о работоспособности текущего приложения; детальный протокол сценариев не предоставлен. Это не отменяет зарегистрированные отказы автоматических проверок.
