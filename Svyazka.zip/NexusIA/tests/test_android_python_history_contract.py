"""Verify availability of the Android end-to-end probe (not an execution result)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AndroidPythonHistoryContract(unittest.TestCase):
    def test_real_android_probe_covers_activity_and_ui(self):
        source = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/PythonHistoryProbe.java').read_text()
        for required in (
            'startActivitySync', 'ui.addPythonFile(FILE)', 'ui.editPython(SOURCE)',
            'nexusPythonFlushPending()', 'activity.nexusCreateTask()',
            'activity.nexusOpenHistory()', 'activity.nexusOpenTask(first)',
            'activity.nexusTaskId()', 'ui.getPythonFileList()',
            'activity.nexusDeleteTask(first)', 'credentials',
        ):
            self.assertIn(required, source)

    def test_missing_row_cannot_pass_as_saved_chat_and_diagnostics_are_available(self):
        repository = (ROOT / 'app/src/main/java/app/svyazka/mobile/TaskRepository.java').read_text()
        activity = (ROOT / 'app/src/main/java/app/svyazka/mobile/MainActivity.java').read_text()
        history = (ROOT / 'app/src/main/java/app/svyazka/mobile/ui/NexusScreens.kt').read_text()
        self.assertIn('statement.executeUpdateDelete() == 1', repository)
        self.assertIn('private void requirePythonChat(long taskId) throws IOException', activity)
        self.assertIn('if (!repository.markPythonProject(taskId, path, true))', activity)
        self.assertIn('Saved Python project IDs:', activity)
        self.assertIn('ui.activity.nexusPythonHistoryDiagnostic()', history)

    def test_probe_has_three_process_lifecycle_steps(self):
        fixture = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/UpgradeProbe.java').read_text()
        script = (ROOT / 'scripts/test-android-python-history.py').read_text()
        self.assertIn('PythonHistoryProbe.run(this, step)', fixture)
        for step in ('python_seed', 'python_verify', 'python_deleted'):
            self.assertIn(step, script)
            self.assertIn(step, (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/PythonHistoryProbe.java').read_text())
        self.assertIn("am', 'force-stop'", script)


if __name__ == '__main__':
    unittest.main()
