package app.svyazka.mobile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class PythonInputs {
    private static final Pattern FENCE = Pattern.compile("^ {0,3}(\u0060{3,}|~{3,})(.*)$");
    private static final Pattern HEADER =
            Pattern.compile(
                    "(?:def\\s+[\\p{L}_]\\w*\\s*\\(.*\\)\\s*(?:->[^:]+)?\\s*:.*|"
                        + "(?:from\\s+[.\\w]+\\s+)?import\\s+[.\\w]+(?:\\s+as\\s+\\w+)?(?:\\s*,\\s*[.\\w]+)*|"
                        + "print\\s*\\(.*\\)|if\\s+__name__\\s*==\\s*[\"']__main__[\"']\\s*:)\\s*(?:#.*)?");
    private static final Pattern STATEMENT =
            Pattern.compile(
                    "(?:[\\p{L}_]\\w*\\s*=(?!=).+|[\\p{L}_]\\w*\\(.*\\)|"
                        + "(?:if|elif|for|while|with)\\s+.+:|else:|try:|except\\b.*:)\\s*(?:#.*)?");
    private static final String MATERIALS = "\n\n<attached_materials>\n",
            END = "\n</attached_materials>";

    private PythonInputs() {}

    private static boolean raw(String source) {
        boolean evidence = false;
        for (String line : source.split("\\r?\\n")) {
            String s = line.trim();
            if (s.isEmpty() || s.startsWith("#") || Character.isWhitespace(line.charAt(0)))
                continue;
            if (HEADER.matcher(s).matches()) evidence = true;
            else if (!STATEMENT.matcher(s).matches()) return false;
        }
        return evidence;
    }

    public static final class Candidate {
        public final String code, issue;
        public final boolean ambiguous;
        final List<String> parts;

        Candidate(String code, String issue, boolean ambiguous, List<String> parts) {
            this.code = code;
            this.issue = issue;
            this.ambiguous = ambiguous;
            this.parts = parts;
        }
    }

    private static final class Block {
        final String tag, body, path;
        final boolean closed;

        Block(String tag, String path, String body, boolean closed) {
            this.path = path;
            this.tag = tag;
            this.body = body;
            this.closed = closed;
        }

        boolean python() {
            return tag.equals("py")
                    || tag.equals("python")
                    || tag.equals("python3")
                    || tag.isEmpty() && raw(body);
        }
    }

    /** Read only explicit filename metadata from the leading Python comments.
     * Keep those comments in the source verbatim. Never scan strings, examples
     * or arbitrary prose for paths. Empty string denotes conflicting/invalid
     * metadata, not an unnamed block. */
    private static String pythonHeaderPath(String body, String path) {
        for (String line : body.split("\\r\\n|\\r|\\n")) {
            String value = line.trim();
            if (value.isEmpty()) continue;
            if (!value.startsWith("#")) break;
            Matcher marker = Pattern.compile("(?i)^#\\s*file\\s*[:=]\\s*(.*)$").matcher(value);
            if (marker.matches()) {
                String declared = marker.group(1).trim();
                if (declared.length() >= 2 && declared.startsWith("`") && declared.endsWith("`"))
                    declared = declared.substring(1, declared.length() - 1);
                path = mergePath(path, declared);
            }
        }
        return path;
    }

    private static String mergePath(String first, String second) {
        if (first == null) return second;
        if (second == null || first.equals(second)) return first;
        return ""; // inconsistent declarations: fail closed in namedFiles
    }

    /** Exact adjacent Markdown filename heading, not prose mentioning a file. */
    private static String pythonHeadingPath(String line) {
        Matcher heading = Pattern.compile("^ {0,3}#{1,6}[ \\t]+(?:`([A-Za-z0-9_./-]+\\.py)`|([A-Za-z0-9_./-]+\\.py))[ \\t]*$").matcher(line);
        if (!heading.matches()) return null;
        return heading.group(1) != null ? heading.group(1) : heading.group(2);
    }

    private static Block resolvedBlock(String tag, String path, String heading, String body, boolean closed) {
        if (tag.equals("py") || tag.equals("python") || tag.equals("python3")) {
            path = mergePath(path, heading);
            path = pythonHeaderPath(body, path);
        }
        return new Block(tag, path, body, closed);
    }

    private static List<Block> blocks(String text) {
        List<Block> list = new ArrayList<>();
        String marker = "", tag = "", path = "";
        String heading = null, blockHeading = null;
        int indent = 0;
        StringBuilder body = new StringBuilder();
        java.util.regex.Matcher lines = java.util.regex.Pattern.compile("([^\r\n]*)(\r\n|\r|\n|$)").matcher(text);
        while (lines.find() && lines.start() < text.length()) {
            String line = lines.group(1);
            Matcher m = FENCE.matcher(line);
            boolean fence = m.matches();
            if (marker.isEmpty()) {
                if (fence) {
                    marker = m.group(1);
                    blockHeading = heading;
                    heading = null;
                    indent = m.start(1);
                    String[] info = m.group(2).trim().split("\\s+", 2);
                    tag = info[0].toLowerCase(Locale.ROOT);
                    path = info.length == 2 && info[1].startsWith("file=") ? info[1].substring(5) : null;
                    // A provider may omit the language in an otherwise explicit file header.
                    // Infer from the actual filename, not the surrounding prose.
                    if (info[0].startsWith("file=") && info.length == 1) {
                        path = info[0].substring(5);
                        String lower = path.toLowerCase(Locale.ROOT);
                        tag = lower.endsWith(".py") ? "python" : lower.endsWith(".html") || lower.endsWith(".htm") ? "html"
                                : lower.endsWith(".js") || lower.endsWith(".mjs") ? "javascript"
                                : lower.endsWith(".css") ? "css" : "file";
                    }
                    body.setLength(0);
                } else if (!line.trim().isEmpty()) {
                    heading = pythonHeadingPath(line);
                }
            } else if (fence && m.group(1).startsWith(marker) && m.group(2).trim().isEmpty()) {
                list.add(resolvedBlock(tag, path, blockHeading, body.toString(), true));
                marker = "";
            } else {
                int skip = 0;
                while (skip < indent && skip < line.length() && line.charAt(skip) == ' ') skip++;
                body.append(line, skip, line.length()).append(lines.group(2));
            }
        }
        if (!marker.isEmpty()) list.add(resolvedBlock(tag, path, blockHeading, body.toString(), false));
        return list;
    }

    /** Explicit output blocks and recognizable console transcripts are documentation,
     * not executable source. Arbitrary untyped text remains ambiguous. */
    private static boolean consoleTranscript(Block block) {
        if (!block.closed || block.path != null || block.python()) return false;
        boolean output = block.tag.equals("output") || block.tag.equals("stdout") || block.tag.equals("stderr");
        if (!(output || block.tag.isEmpty() || block.tag.equals("text") || block.tag.equals("plaintext")
                || block.tag.equals("console") || block.tag.equals("terminal") || block.tag.equals("pycon")))
            return false;
        String[] lines = block.body.trim().split("\\r?\\n");
        if (!output && (lines.length < 2 || !lines[0].matches("(?:>>>|>|\\$)[ \\t]+\\S.*"))) return false;
        // A transcript cannot conceal another fenced source or explicit file marker.
        for (String line : lines) {
            if (FENCE.matcher(line).matches()
                    || line.trim().matches("(?i)(?:#\\s*)?file\\s*[:=].*")) return false;
        }
        return true;
    }

    /** Recognize only non-executed, simple Python launch/test instructions referring
     * to files actually delivered in this answer. Unknown shell blocks stay ambiguous. */
    private static boolean launchInstructions(Block block, java.util.Set<String> paths) {
        if (!block.closed || block.path != null || paths.isEmpty()) return false;
        if (!(block.tag.equals("bash") || block.tag.equals("sh") || block.tag.equals("shell")
                || block.tag.equals("console") || block.tag.equals("terminal"))) return false;
        boolean command = false;
        for (String line : block.body.split("\\r?\\n")) {
            String value = line.trim();
            if (value.isEmpty() || value.startsWith("#")) continue;
            boolean matched = false;
            for (String path : paths) {
                if (value.matches("(?:python3?|py)[ \t]+(?:\\./)?" + Pattern.quote(path))
                        || value.matches("(?:python3?|py)[ \t]+-m[ \t]+unittest[ \t]+(?:\\./)?" + Pattern.quote(path))) {
                    matched = true; break;
                }
            }
            if (!matched) return false;
            command = true;
        }
        return command;
    }

    private static List<Block> sourceBlocks(String answer) {
        List<Block> all = blocks(answer);
        int pythonCount = 0;
        boolean hasSource = false;
        java.util.Set<String> paths = new java.util.LinkedHashSet<>();
        for (Block block : all) {
            if (block.python()) {
                pythonCount++;
                if (block.path != null && block.closed && !block.body.trim().isEmpty()) paths.add(block.path);
                hasSource = true;
            } else if (block.path != null || block.tag.equals("html") || block.tag.equals("htm")
                    || block.tag.equals("javascript") || block.tag.equals("js") || block.tag.equals("css")) {
                hasSource = true;
            }
        }
        if (!hasSource) return all;
        if (paths.isEmpty() && pythonCount == 1) paths.add("main.py");
        List<Block> result = new ArrayList<>();
        for (Block block : all) {
            if (!launchInstructions(block, paths) && !consoleTranscript(block)) result.add(block);
        }
        return result;
    }

    /** A full restart may change surrounding prose but cannot delete or rewrite
     * any previously received source bytes. Incomplete final blocks may grow. */
    static boolean preservesCodePrefix(String previous, String replacement) {
        List<Block> old = blocks(previous), fresh = blocks(replacement);
        if (old.isEmpty() || fresh.size() < old.size()) return false;
        for (int i = 0; i < fresh.size(); i++)
            if (!fresh.get(i).closed) return false;
        for (int i = 0; i < old.size(); i++) {
            Block before = old.get(i), after = fresh.get(i);
            if (!before.tag.equals(after.tag) || !java.util.Objects.equals(before.path, after.path))
                return false;
            if (before.closed ? !before.body.equals(after.body) : !after.body.startsWith(before.body)) {
                // A truncated last line has no terminating newline; a genuine
                // continuation must still reproduce its exact received prefix.
                return false;
            }
        }
        return true;
    }

    public static Candidate candidate(String answer) {
        List<Block> all = sourceBlocks(answer);
        java.util.Map<String,String> project = namedFiles(answer);
        if (!project.isEmpty()) {
            java.util.Map<String,String> python = new java.util.LinkedHashMap<>();
            for (java.util.Map.Entry<String,String> entry : project.entrySet())
                if (entry.getKey().endsWith(".py")) python.put(entry.getKey(), entry.getValue());
            if (python.size() > 1)
                return new Candidate("", "Многофайловый проект: синтаксис проверяется по каждому файлу; выполнение — отдельно в рабочей области.",
                        true, new ArrayList<>(python.values()));
            if (python.size() == 1 && project.size() == 1) {
                String name = python.keySet().iterator().next();
                all = java.util.Collections.singletonList(new Block("python", name, python.get(name), true));
            }
        }
        List<String> parts = new ArrayList<>();
        Block found = null;
        for (Block b : all)
            if (b.python()) {
                parts.add(b.body);
                found = b;
            }
        if (found == null)
            return all.isEmpty() && raw(answer) ? new Candidate(answer, "", false, parts) : null;
        if (all.size() > 1 && parts.size() == 1 && !namedFiles(answer).isEmpty() && "main.py".equals(found.path))
            return new Candidate(found.body, "", false, parts);
        if (all.size() > 1 || found.path != null && project.isEmpty())
            return new Candidate(
                    "", "Несколько файлов или примеров. Точка входа неоднозначна.", true, parts);
        if (found.body.trim().isEmpty()) return new Candidate("", "Блок Python пуст.", true, parts);
        // Do not silently strip nested fences or duplicate language markers: both
        // occurred in real multi-provider repairs and can corrupt a runnable file.
        String cleanBody = found.body.trim();
        if (cleanBody.matches("(?s)^python\\s*\\n.*"))
            return new Candidate(found.body, "Внутри блока кода повторена метка python.", false, parts);
        for (String line : found.body.split("\\r?\\n")) {
            Matcher nested = FENCE.matcher(line);
            if (nested.matches() && !nested.group(2).trim().isEmpty())
                return new Candidate(found.body, "Внутри блока Python начинается ещё один блок кода.", false, parts);
        }
        return new Candidate(
                found.body, found.closed ? "" : "Не закрыт блок Python.", false, parts);
    }

    /** A single web entry point. Separate files are never silently concatenated. */
    public static String webSource(String answer, String language) {
        List<Block> fenced = sourceBlocks(answer);
        if (fenced.isEmpty() && language.equals("html") && answer.trim().matches("(?is)^(?:<!doctype\\s+html|<html\\b).*"))
            return answer.trim().toLowerCase(Locale.ROOT).endsWith("</html>") ? answer : "";
        if (fenced.size() != 1) {
            if (!"html".equals(language)) return "";
            Block entry = null;
            for (Block b : fenced) {
                if (!b.closed) return "";
                if (b.tag.equals("html") || b.tag.equals("htm")) {
                    if (entry != null) return "";
                    entry = b;
                }
            }
            if (entry == null || !entry.body.trim().toLowerCase(Locale.ROOT).endsWith("</html>")) return "";
            // A standalone HTML entry can coexist with unrelated Python or data files.
            // Do not pretend a split HTML/CSS/JS package is a standalone page.
            if (fenced.stream().anyMatch(b -> b.path != null)) {
                if (namedFiles(answer).isEmpty() || entry.path == null) return "";
                for (Block sibling : fenced) {
                    if (sibling == entry) continue;
                    String name = sibling.path.toLowerCase(Locale.ROOT);
                    if (name.endsWith(".js") || name.endsWith(".mjs") || name.endsWith(".css")
                            || name.endsWith(".html") || name.endsWith(".htm")) return "";
                }
            }
            return entry.body;
        }
        Block b = fenced.get(0);
        if (!b.closed || b.body.trim().isEmpty()) return "";
        if (language.equals("html") && b.body.trim().matches("(?is)^(?:<!doctype\\s+html|<html\\b).*") &&
                !b.body.trim().toLowerCase(Locale.ROOT).endsWith("</html>")) return "";
        if (b.tag.equals(language) || language.equals("javascript") && b.tag.equals("js")
                || language.equals("html") && b.tag.equals("htm")) return b.body;
        return "";
    }

    public static java.util.Map<String,String> namedFiles(String answer) {
        java.util.Map<String,String> files = new java.util.LinkedHashMap<>();
        java.util.Map<String,String> spellings = new java.util.HashMap<>();
        java.util.Set<String> emptyPython = new java.util.HashSet<>();
        List<Block> blocks = sourceBlocks(answer);
        if (blocks.isEmpty() || blocks.size()>128) return java.util.Collections.emptyMap();
        for (Block b : blocks) {
            String name = b.path;
            if (name == null || !b.closed || name.length() > 200
                    || !name.matches("[A-Za-z0-9_-][A-Za-z0-9._-]*(/[A-Za-z0-9_-][A-Za-z0-9._-]*)*"))
                return java.util.Collections.emptyMap();
            if (name.endsWith(".py") && !b.python()) return java.util.Collections.emptyMap();
            String lower = name.toLowerCase(Locale.ROOT);
            String spelling = spellings.putIfAbsent(lower, name);
            if (spelling != null && !spelling.equals(name)) return java.util.Collections.emptyMap();
            for (String previous : spellings.keySet())
                if (previous.startsWith(lower+"/") || lower.startsWith(previous+"/"))
                    return java.util.Collections.emptyMap();
            if (b.body.matches("(?s).*(?:^|\n) {0,3}(?:```|~~~)[^\n]*(?:\n|$).*")) return java.util.Collections.emptyMap();
            if (b.body.trim().isEmpty()) {
                // An empty Python snapshot can accompany a completed file. Never
                // accept a missing/empty file by itself or discard empty non-code data.
                if (!name.endsWith(".py")) return java.util.Collections.emptyMap();
                emptyPython.add(name);
                continue;
            }
            String previous = files.putIfAbsent(name, b.body);
            if (previous != null && !previous.equals(b.body)) return java.util.Collections.emptyMap();
        }
        if (files.size()>64 || !files.keySet().containsAll(emptyPython)) return java.util.Collections.emptyMap();
        return files;
    }

    /** Format acceptance is distinct from execution and test acceptance. */
    static boolean hasPythonDelivery(String answer) {
        if (hasNamedFiles(answer)) {
            java.util.Map<String,String> named = namedFiles(answer);
            if (named.isEmpty()) return false;
            for (String path : named.keySet()) if (path.endsWith(".py")) return true;
            return false;
        }
        Candidate single = candidate(answer);
        return single != null;
    }

    /** A complete named project, not a guessed concatenation of modules. */
    static java.util.Map<String,String> multiPythonProject(String answer) {
        java.util.Map<String,String> files = namedFiles(answer);
        int python = 0;
        for (String path : files.keySet()) if (path.endsWith(".py")) python++;
        return python > 1 ? files : java.util.Collections.emptyMap();
    }

    /** Same canonical complete project used for pre-review and final syntax checks. */
    static JSONObject projectSyntaxRequest(String answer, Candidate candidate) throws JSONException {
        java.util.Map<String,String> files = multiPythonProject(answer);
        JSONObject request = new JSONObject().put("mode", "verify").put("code", "")
                .put("reason", candidate.issue);
        if (!files.isEmpty()) {
            JSONObject sources = new JSONObject();
            for (java.util.Map.Entry<String,String> entry : files.entrySet())
                if (entry.getKey().endsWith(".py")) sources.put(entry.getKey(), entry.getValue());
            request.put("project_sources", sources);
        } else request.put("syntax_only", new JSONArray(candidate.parts));
        return request;
    }

    static String projectFingerprint(String answer, Candidate candidate) {
        java.util.Map<String,String> files = multiPythonProject(answer);
        if (files.isEmpty()) return candidate.issue + "\n" + candidate.code;
        StringBuilder identity = new StringBuilder("project-v1\n");
        for (java.util.Map.Entry<String,String> file : new java.util.TreeMap<>(files).entrySet())
            identity.append(file.getKey()).append('\n').append(InputMaterial.sha256(
                    file.getValue().getBytes(java.nio.charset.StandardCharsets.UTF_8))).append('\n');
        return identity.toString();
    }

    public static boolean hasNamedFiles(String answer) {
        return blocks(answer).stream().anyMatch(b -> b.path != null);
    }

    public static boolean unfinished(String answer) { return ContinuationIntegrity.unclosedFence(answer); }

    public static String copySource(String answer) {
        java.util.Map<String,String> files = namedFiles(answer);
        if (files.size()==1) return files.values().iterator().next();
        return hasNamedFiles(answer) ? answer : singleSourceOrAnswer(answer);
    }

    static JSONArray fileMetadata(String answer) throws JSONException {
        java.util.Map<String,String> files = namedFiles(answer);
        if (files.isEmpty() && !hasNamedFiles(answer)) {
            String html = webSource(answer,"html");
            Candidate py = candidate(answer);
            if (!html.isEmpty()) files = java.util.Collections.singletonMap("index.html",html);
            else if (py != null && !py.ambiguous && py.issue.isEmpty()) files = java.util.Collections.singletonMap("main.py",py.code);
            else for (String lang : new String[]{"javascript","css"}) {
                String code = webSource(answer,lang);
                if (!code.isEmpty()) files = java.util.Collections.singletonMap(lang.equals("css")?"style.css":"main.js",code);
            }
        }
        JSONArray entries = new JSONArray();
        for (java.util.Map.Entry<String,String> file : files.entrySet()) {
            byte[] bytes = file.getValue().getBytes(java.nio.charset.StandardCharsets.UTF_8);
            entries.put(new JSONObject().put("path",file.getKey()).put("text",file.getValue())
                    .put("bytes",bytes.length).put("sha256",InputMaterial.sha256(bytes)));
        }
        return entries;
    }

    static String singleSourceOrAnswer(String answer) {
        for (String language : new String[]{"html","javascript","css"}) {
            String source = webSource(answer,language);
            if (!source.isEmpty()) return source;
        }
        Candidate py = candidate(answer);
        return py != null && !py.ambiguous && py.issue.isEmpty() ? py.code : answer;
    }

    /** Preserve the full response and export a separately verifiable file only for an unambiguous source. */
    static JSONObject artifact(Workflow.Run run) throws JSONException {
        if (!run.complete()) return null;
        int source = run.finalIndex();
        Candidate result = candidate(run.displayAnswer(source));
        if (result == null) return null;
        boolean usable = !result.ambiguous && result.issue.isEmpty() && !result.code.trim().isEmpty();
        JSONObject meta = new JSONObject()
                .put("source_step", source + 1)
                .put("source", "answers")
                .put("format_complete", usable)
                .put("verification_status", run.verification.status.name())
                .put("issue", result.issue);
        java.util.Map<String,String> project = multiPythonProject(run.displayAnswer(source));
        if (!project.isEmpty()) {
            meta.put("format_complete", true).put("issue", "").put("file_name", "project.zip")
                    .put("language", "python").put("file_count", project.size());
        }
        if (usable) {
            meta.put("file_name", "result.py").put("language", "python").put("source_text", result.code)
                    .put("artifact_version", source + 1).put("models", new JSONArray(run.answerAt(source).models))
                    .put("sha256", InputMaterial.sha256(
                            result.code.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
        }
        return meta;
    }

    static List<String> manualBlocks(String answer) {
        List<String> result = new ArrayList<>();
        Candidate single = candidate(answer);
        if (single == null) return result;
        if (!single.ambiguous) {
            if (single.issue.isEmpty() && !single.code.trim().isEmpty()) result.add(single.code);
            return result;
        }
        java.util.Map<String,String> project = multiPythonProject(answer);
        if (!project.isEmpty()) {
            for (java.util.Map.Entry<String,String> file : project.entrySet())
                if (file.getKey().endsWith(".py")) result.add(file.getValue());
            return result;
        }
        for (Block b : blocks(answer)) {
            if (!b.python() || !b.closed || b.body.trim().isEmpty()) continue;
            boolean nested = b.body.trim().matches("(?s)^python\\s*\\n.*");
            for (String line : b.body.split("\\n")) if (FENCE.matcher(line).matches()) nested = true;
            if (!nested) result.add(b.body);
        }
        return result;
    }

    static String withoutMaterials(String text) {
        String result = text;
        int start;
        while ((start = result.indexOf(MATERIALS)) >= 0) {
            int end = result.indexOf(END, start + MATERIALS.length());
            if (end < 0) break;
            result = result.substring(0, start) + result.substring(end + END.length());
        }
        return result;
    }

    /** Classify the user's requirements, not the attached project snapshot.
     * The snapshot remains available to the model as source material.
     */
    private static String requirementsOnly(String text) {
        return ChatProjectContext.withoutInlineProject(withoutMaterials(text));
    }

    static boolean asksPythonPort(String text) {
        String v = requirementsOnly(text).toLowerCase(java.util.Locale.ROOT);
        return v.matches("(?s).*(?:python|питон|пайтон|بايثون).*")
                && v.matches("(?s).*(?:перепиш|перепис|переве|перенес|перенос|портир|напиш|созда|реализ|rewrite|convert|port to|translate|build|write|create|改写|转换|编写|作成|書き|移植|اكتب|حوّل|تحويل).*");
    }

    static String target(String text) {
        String[] lines = requirementsOnly(text).toLowerCase(java.util.Locale.ROOT).split("\\r?\\n");
        for (int i = lines.length - 1; i >= 0; i--) {
            String v = lines[i];
            if (v.matches("(?s).*(?:android|андроид|安卓|アンドロイド|أندرويد).*")) return "android";
        if (v.matches("(?s).*(?:консол|терминал|командн.{1,4} строк|console|terminal|\\bcli\\b|控制台|コンソール|الطرفية).*")) return "console";
        if (v.matches("(?s).*(?:компьютер|настольн|на пк|desktop|windows|macos|tkinter|pyside|pyqt|\\bgui\\b|桌面|デスクトップ|سطح المكتب).*")) return "desktop";
        }
        return "";
    }

    static boolean defaultWidget(String goals) {
        String v=requirementsOnly(goals).toLowerCase(Locale.ROOT);
        return requiredFeatures(v).length()>0 && target(v).isEmpty() &&
                v.matches("(?s).*(?:сдела|напиш|созда|разработ|код|виджет|добав|реализ|программ|build|generate|make|create|widget|write|add|生成|创建|作成|作って|أنشئ|اكتب).*") &&
                !v.matches("(?s).*(?:python|питон|пайтон|flutter|kotlin|swift|java(?!script)|c\\+\\+|c#|react|vue|arduino|esp32|bash|ruby|typescript|rust|golang|\\bphp\\b).*");
    }

    static JSONArray requiredFeatures(String requirements) {
        String v = requirementsOnly(requirements).toLowerCase(java.util.Locale.ROOT);
        JSONArray features = new JSONArray();
        String[][] patterns = {{"часы","часы|часов|clock|时钟|時計|ساعة"},{"календарь","календар[а-я]*|calendar|日历|カレンダー|تقويم"},
            {"погода","погод[а-я]*|weather|天气|天気|الطقس"},{"Bluetooth","bluetooth|блюту[зс]|\\bble\\b|蓝牙|ブルートゥース|بلوتوث"}};
        for (String[] pair : patterns) {
            Matcher mentions=Pattern.compile(pair[1]).matcher(v);
            boolean needed=false;
            while (mentions.find()) {
                String before=v.substring(Math.max(0,mentions.start()-48),mentions.start());
                needed=!before.matches("(?s).*(?:убери|удали|исключи|отключи|без|remove|omit|without|disable)\\s+(?:(?:модуль|функцию|поддержку|the)\\s+)?$");
            }
            if (needed) features.put(pair[0]);
        }
        return features;
    }

    static JSONObject request(Workflow.Run run, String code) throws JSONException {
        String source = run.userTestTask();
        if (source.length() > Workflow.TASK_LIMIT)
            throw new JSONException("Слишком много исходных материалов.");
        JSONArray specs = new JSONArray();
        JSONObject files = new JSONObject();
        int start;
        while ((start = source.indexOf(MATERIALS)) >= 0) {
            int end = source.indexOf(END, start + MATERIALS.length());
            if (end < 0) throw new JSONException("Незакрытый список вложений.");
            JSONArray entries = new JSONArray(source.substring(start + MATERIALS.length(), end));
            boolean latest = source.indexOf(MATERIALS, end) < 0 && !run.materials.isEmpty();
            if (latest && entries.length() != run.materials.size())
                throw new JSONException("Состав исходных файлов изменился.");
            java.util.Set<String> seen = new java.util.HashSet<>();
            for (int i = 0; i < entries.length(); i++) {
                JSONObject entry = entries.getJSONObject(i);
                String name = entry.getString("name");
                if (latest && !name.equals(run.materials.get(i).name))
                    throw new JSONException("Имя вложения не совпало.");
                if (!"TEXT".equals(entry.getString("type"))) continue;
                if (!seen.add(name)) throw new JSONException("Одинаковые имена вложений: " + name);
                if (name.equalsIgnoreCase("nexus-tests.json")) specs.put(entry.getString("text"));
                else files.put(name, entry.getString("text"));
            }
            source = source.substring(0, start) + source.substring(end + END.length());
        }
        for (Block b : blocks(source))
            if (b.tag.equals("nexus-tests")) {
                if (!b.closed) throw new JSONException("Не закрыт блок nexus-tests.");
                specs.put(b.body);
            }
        String current = withoutMaterials(ChatProjectContext.withoutInlineProject(
                TaskHistory.currentUserTestRequest(run.task)));
        String expected = PythonAutoTests.expectedOutput(current);
        if (expected != null) {
            specs.put(new JSONArray().put(new JSONObject().put("stdin", "")
                    .put("stdout", expected)).toString());
        }
        JSONObject request = new JSONObject();
        if (!run.repairs.isEmpty() && run.nextIndex() > run.mode.stages) {
            Workflow.RepairInput origin = run.repairs.get(run.repairs.size() - 1);
            request.put("previous_code", origin.code);
        }
        String marker = "<previous_source language=\"html\">\n";
        int web = run.task.indexOf(marker);
        int finish = web < 0 ? -1 : run.task.indexOf("</previous_source>", web + marker.length());
        if (finish > web && web >= 0) request.put("previous_web", run.task.substring(web + marker.length(), finish));
        JSONObject config = new JSONObject();
        int sourceStep=run.complete() ? run.finalIndex() : run.nextIndex()-1;
        if (run.hasAnswer(sourceStep)) {
            for (java.util.Map.Entry<String,String> file : namedFiles(run.displayAnswer(sourceStep)).entrySet()) {
                if (file.getKey().endsWith("AndroidManifest.xml") || file.getKey().equals("buildozer.spec"))
                    config.put(file.getKey(), file.getValue());
            }
        }
        return request.put("android_config",config).put("mode", "verify")
                .put("code", code)
                .put("files", files)
                .put("required_features", requiredFeatures(source))
                .put("examples", source)
                .put("specs", specs);
    }
}
