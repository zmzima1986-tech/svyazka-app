package app.svyazka.mobile;

import java.util.Collections;
import java.util.ArrayList;
import java.util.List;

/** Immutable, secret-free projection of the Java workflow into Compose UI. */
public final class NexusState {
    public final String task;
    public final boolean quick;
    public final boolean active;
    public final boolean clearing;
    public final boolean hasRun;
    public final boolean complete;
    public final int finished;
    public final int total;
    public final String note;
    public final String result;
    public final String resultRole;
    public final String resultWarnings;
    public final boolean resultHasPython;
    public final String log;
    public final List<Stage> stages;
    public final List<Model> models;
    public final List<Task> tasks;
    public final boolean groqReserve;
    public final String quickModelId;
    public final String quickModelLabel;
    public final int versionCount;
    public final boolean visualAvailable;
    public final List<Exchange> exchanges;

    public NexusState(String task, boolean quick, boolean active, boolean clearing,
                      boolean hasRun, boolean complete, int finished, int total,
                      String note, String result, String resultRole, String resultWarnings,
                      boolean resultHasPython, String log, List<Stage> stages,
                      List<Model> models, List<Task> tasks, boolean groqReserve,
                      String quickModelId, String quickModelLabel, int versionCount,
                      boolean visualAvailable, List<Exchange> exchanges) {
        this.task = task;
        this.quick = quick;
        this.active = active;
        this.clearing = clearing;
        this.hasRun = hasRun;
        this.complete = complete;
        this.finished = finished;
        this.total = total;
        this.note = note;
        this.result = result;
        this.resultRole = resultRole;
        this.resultWarnings = resultWarnings;
        this.resultHasPython = resultHasPython;
        this.log = log;
        this.stages = Collections.unmodifiableList(new ArrayList<>(stages));
        this.models = Collections.unmodifiableList(new ArrayList<>(models));
        this.tasks = Collections.unmodifiableList(new ArrayList<>(tasks));
        this.groqReserve = groqReserve;
        this.quickModelId = quickModelId;
        this.quickModelLabel = quickModelLabel;
        this.versionCount = versionCount;
        this.visualAvailable = visualAvailable;
        this.exchanges = Collections.unmodifiableList(new ArrayList<>(exchanges));
    }

    /** Chronological, source-backed run versions used by the single chat screen. */
    public static final class SearchMessage {
        public final long taskId;
        public final String title, text;
        public final boolean user;
        public SearchMessage(long taskId, String title, String text, boolean user) {
            this.taskId = taskId; this.title = title; this.text = text; this.user = user;
        }
    }

    public static final class Exchange {
        public final String prompt;
        public final String answer;
        public final boolean complete;

        public Exchange(String prompt, String answer, boolean complete) {
            this.prompt = prompt;
            this.answer = answer;
            this.complete = complete;
        }
    }

    public static final class Stage {
        public final String role;
        public final String instruction;
        public final String modelId;
        public final String modelLabel;
        public final String answer;
        public final String warnings;
        public final boolean hasPython;
        public final boolean done;
        public final boolean current;
        public final int index;

        public Stage(int index, String role, String instruction, String modelId,
                     String modelLabel, String answer, String warnings,
                     boolean hasPython, boolean done, boolean current) {
            this.index = index;
            this.role = role;
            this.instruction = instruction;
            this.modelId = modelId;
            this.modelLabel = modelLabel;
            this.answer = answer;
            this.warnings = warnings;
            this.hasPython = hasPython;
            this.done = done;
            this.current = current;
        }
    }

    public static final class Model {
        public final String id;
        public final String label;
        public final String provider;
        public final boolean configured;
        public final boolean imageInput;
        public final int context;

        public Model(String id, String label, String provider, boolean configured) {
            this(id, label, provider, configured, false, 0);
        }

        public Model(String id, String label, String provider, boolean configured, boolean imageInput, int context) {
            this.imageInput = imageInput;
            this.context = context;
            this.id = id;
            this.label = label;
            this.provider = provider;
            this.configured = configured;
        }
    }

    public static final class Task {
        public final long id;
        public final String title;
        public final long updatedAt;
        public final int versions;
        public final boolean completed;
        public final boolean hasRun;
        public final boolean selected, pinned;
        public final String preview;
        public final PythonVerification.Status verification;

        public Task(long id, String title, long updatedAt, int versions,
                    boolean completed, boolean hasRun, boolean selected) {
            this(id,title,updatedAt,versions,completed,hasRun,selected,PythonVerification.Status.NONE);
        }
        Task(long id,String title,long updatedAt,int versions,boolean completed,boolean hasRun,boolean selected,PythonVerification.Status verification) {
            this(id, title, updatedAt, versions, completed, hasRun, selected, verification, false, "");
        }
        Task(long id, String title, long updatedAt, int versions, boolean completed, boolean hasRun,
             boolean selected, PythonVerification.Status verification, boolean pinned, String preview) {
            this.pinned = pinned;
            this.preview = preview;
            this.verification=verification;
            this.id = id;
            this.title = title;
            this.updatedAt = updatedAt;
            this.versions = versions;
            this.completed = completed;
            this.hasRun = hasRun;
            this.selected = selected;
        }
    }
}
