package app.svyazka.fixture;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;
import app.svyazka.mobile.MainActivity;
import app.svyazka.mobile.NexusArtifact;
import app.svyazka.mobile.NexusState;
import app.svyazka.mobile.ui.NexusComposeUi;
import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/** Device-level, no-AI-keys project lifecycle, across three fresh app processes.
 * Run only on a disposable emulator; the seed phase creates and deletes test files.
 */
final class PythonHistoryProbe {
    private static final String PREFS = "nexus_python_artifacts_probe";
    private static final String FILE = "history_probe.py";
    private static final String SOURCE = "print('artifact-restored')\n";
    private static final String SECOND = "other_chat.py";
    private PythonHistoryProbe() { }

    private static void check(boolean value, String failure) {
        if (!value) throw new AssertionError(failure);
    }

    private static void main(Instrumentation instrumentation, Runnable action) {
        AtomicReference<Throwable> problem = new AtomicReference<>();
        instrumentation.runOnMainSync(() -> {
            try { action.run(); }
            catch (Throwable e) { problem.set(e); }
        });
        if (problem.get() != null) throw new AssertionError("Android UI lifecycle failed", problem.get());
    }

    private static MainActivity launch(Instrumentation instrumentation) {
        Intent intent = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClass(instrumentation.getTargetContext(), MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY);
        MainActivity activity = (MainActivity) instrumentation.startActivitySync(intent);
        instrumentation.waitForIdleSync();
        return activity;
    }

    private static NexusComposeUi ui(MainActivity activity) {
        try {
            Field field = MainActivity.class.getDeclaredField("nexusUi");
            field.setAccessible(true);
            NexusComposeUi compose = (NexusComposeUi) field.get(activity);
            check(compose != null, "Compose UI was not initialized");
            return compose;
        } catch (ReflectiveOperationException e) { throw new AssertionError(e); }
    }

    private static boolean hasChat(MainActivity activity, long id) {
        for (NexusState.Task task : activity.nexusSnapshot().tasks)
            if (task.id == id) return true;
        return false;
    }

    private static boolean hasArtifact(MainActivity activity, long id) {
        for (NexusArtifact artifact : activity.nexusArtifacts())
            if (artifact.id == id) return true;
        return false;
    }

    private static void awaitNewChat(Instrumentation instrumentation, MainActivity activity, long oldId) {
        long deadline = SystemClock.elapsedRealtime() + 12_000;
        AtomicLong current = new AtomicLong();
        while (SystemClock.elapsedRealtime() < deadline) {
            main(instrumentation, () -> current.set(activity.nexusTaskId()));
            if (current.get() > 0 && current.get() != oldId) return;
            SystemClock.sleep(40);
        }
        throw new AssertionError("New chat did not create a distinct ID");
    }

    private static void awaitSavedChat(Instrumentation instrumentation,
                                       MainActivity activity, long chatId) {
        long deadline = SystemClock.elapsedRealtime() + 12_000;
        java.util.concurrent.atomic.AtomicBoolean listed = new java.util.concurrent.atomic.AtomicBoolean();
        while (SystemClock.elapsedRealtime() < deadline) {
            main(instrumentation, () -> listed.set(hasChat(activity, chatId)));
            if (listed.get()) return;
            SystemClock.sleep(40);
        }
        throw new AssertionError("Manually saved chat was not persisted in history");
    }

    /** Exercise the production classifier on Android's own regex implementation. */
    private static void checkTaskRouting(Context app) {
        try {
            Class<?> history = app.getClassLoader().loadClass("app.svyazka.mobile.TaskHistory");
            java.lang.reflect.Method route = history.getDeclaredMethod(
                    "startsIndependentTask", String.class, String.class);
            route.setAccessible(true);
            String python = "Напиши на Python калькулятор";
            String html = "Создай HTML-страницу с цифровыми часами";
            check(Boolean.FALSE.equals(route.invoke(null, html,
                    "Создай на Python калькулятор с четырьмя арифметическими операциями")),
                    "HTML-to-Python follow-up must not crash");
            check(Boolean.TRUE.equals(route.invoke(null, python, "Теперь создай HTML-страницу с часами")),
                    "New HTML task after Python must be independent");
            check(Boolean.TRUE.equals(route.invoke(null, python, "Теперь\u00a0создай\u00a0HTML-страницу")),
                    "Unicode whitespace must work");
            check(Boolean.FALSE.equals(route.invoke(null, python, "Создай HTML-страницу для калькулятора")),
                    "Port must retain prior requirements");
            check(Boolean.FALSE.equals(route.invoke(null, python, "Добавь проверку")),
                    "Ordinary edit must retain prior requirements");
            check(Boolean.TRUE.equals(route.invoke(null, html, "Новая задача: напиши текст")),
                    "Explicit Cyrillic task marker must work");
            check(Boolean.FALSE.equals(route.invoke(null, html, "Новая задачами")),
                    "Partial Cyrillic word must not match");
            check(Boolean.TRUE.equals(route.invoke(null, html, "New task:\nWrite a program")),
                    "Multiline English task marker must work");
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("Android task-routing regression", e);
        }
    }

    static void run(Instrumentation instrumentation, String step) {
        check(Build.FINGERPRINT.contains("generic") || Build.MODEL.contains("SDK")
                || Build.HARDWARE.startsWith("ranchu"), "Only a disposable emulator is permitted");
        Context app = instrumentation.getTargetContext();
        SharedPreferences checkpoint = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if ("python_seed".equals(step)) {
            checkTaskRouting(app);
            check(app.getSharedPreferences("credentials", Context.MODE_PRIVATE).getAll().isEmpty(),
                    "Run without API keys");
            check(!checkpoint.contains("first"), "Seed requires a fresh emulator");
            MainActivity activity = launch(instrumentation);
            NexusComposeUi compose = ui(activity);
            long firstChat = activity.nexusTaskId();
            AtomicLong firstProject = new AtomicLong();
            main(instrumentation, () -> {
                compose.openRight();
                compose.addPythonFile(FILE);
                check(compose.getPythonProjectIssue().isEmpty(), "Python file creation failed");
                compose.editPython(SOURCE);
                activity.nexusPythonFlushPending();
                activity.nexusSaveArtifact(FILE, SOURCE);
                firstProject.set(activity.nexusArtifactId());
                check(firstProject.get() > 0, "No independent artifact ID");
                check(hasArtifact(activity, firstProject.get()), "Saved project absent from Artifacts");
                check(!hasChat(activity, firstChat), "Python-only work should not be an AI chat");
                compose.closePanel();
                activity.nexusCreateTask();
            });
            awaitNewChat(instrumentation, activity, firstChat);
            long secondChat = activity.nexusTaskId();
            AtomicLong secondProject = new AtomicLong();
            main(instrumentation, () -> {
                check(activity.nexusArtifactId() == 0, "New chat inherited previous project");
                compose.openRight();
                compose.addPythonFile(SECOND);
                check(compose.getPythonProjectIssue().isEmpty(), "Second project file creation failed");
                compose.editPython("print('independent')\n");
                activity.nexusPythonFlushPending();
                secondProject.set(activity.nexusArtifactId());
                check(secondProject.get() != firstProject.get(), "Two chats share one artifact ID");
                check(hasArtifact(activity, firstProject.get()), "First project disappeared on switching chats");
                check(hasArtifact(activity, secondProject.get()), "Second project missing");
                activity.nexusAttachArtifactToChat();
                check(activity.nexusChatProjectId() == secondProject.get(),
                        "Existing chat did not attach to artifact");
                activity.nexusDetachArtifactFromChat();
                check(activity.nexusChatProjectId() == 0,
                        "Unlinking chat failed");
                check(hasArtifact(activity, secondProject.get()),
                        "Unlinking chat removed artifact");
                compose.closePanel();
                activity.nexusOpenArtifacts();
                check(compose.getPage() == NexusComposeUi.Page.ARTIFACTS, "Artifacts screen not opened");
                activity.nexusOpenArtifact(firstProject.get());
                check(compose.getPage() == NexusComposeUi.Page.PROJECT, "Standalone project screen missing");
                check(SOURCE.equals(activity.nexusPythonRead(FILE)), "File not restored when opening Artifacts");
                check(compose.getPythonFileList().contains(FILE), "Compose editor did not reload artifact files");
            });
            main(instrumentation, activity::nexusNewChatForArtifact);
            awaitNewChat(instrumentation, activity, secondChat);
            long linkedChat = activity.nexusTaskId();
            main(instrumentation, () -> {
                check(activity.nexusArtifactId() == firstProject.get(),
                        "AI chat did not retain its linked artifact");
                check(activity.nexusChatProjectId() == firstProject.get(),
                        "Chat-to-artifact link was not saved");
                check(SOURCE.equals(activity.nexusPythonRead(FILE)),
                        "Opening AI chat changed project content");
                activity.nexusSaveChat();
            });
            awaitSavedChat(instrumentation, activity, linkedChat);
            check(checkpoint.edit().putLong("first", firstProject.get())
                    .putLong("second", secondProject.get())
                    .putLong("firstChat", firstChat).putLong("secondChat", secondChat)
                    .putLong("linkedChat", linkedChat).commit(),
                    "Could not persist Android probe checkpoint");
            main(instrumentation, activity::finish);
        } else if ("python_verify".equals(step)) {
            long first = checkpoint.getLong("first", 0);
            long second = checkpoint.getLong("second", 0);
            check(first > 0 && second > 0 && first != second, "Missing seed checkpoint");
            MainActivity activity = launch(instrumentation);
            NexusComposeUi compose = ui(activity);
            main(instrumentation, () -> {
                check(!hasChat(activity, checkpoint.getLong("firstChat", 0)),
                        "Python-only work incorrectly stored in history");
                check(activity.nexusTaskId() == checkpoint.getLong("linkedChat", 0),
                        "Linked chat was not restored after restart");
                check(activity.nexusArtifactId() == first,
                        "Linked project was not restored with AI chat");
                check(hasChat(activity, activity.nexusTaskId()),
                        "Manually saved chat missing after restart");
                activity.nexusOpenArtifacts();
                check(hasArtifact(activity, first) && hasArtifact(activity, second),
                        "Artifacts missing after process restart");
                activity.nexusOpenArtifact(first);
                check(SOURCE.equals(activity.nexusPythonRead(FILE)), "File missing after restart");
                activity.nexusOpenArtifact(second);
                check(activity.nexusPythonRead(FILE).isEmpty(), "Project files not isolated");
                check(activity.nexusPythonPaths().length >= 1, "Second project lost its files");
            });
            long linkedChat = checkpoint.getLong("linkedChat", 0);
            main(instrumentation, () -> activity.nexusDeleteTask(linkedChat));
            awaitNewChat(instrumentation, activity, linkedChat);
            main(instrumentation, () -> {
                check(!hasChat(activity, linkedChat), "Deleted chat still appears in history");
                check(hasArtifact(activity, first), "Deleting chat deleted its project");
                activity.nexusOpenArtifact(first);
                check(SOURCE.equals(activity.nexusPythonRead(FILE)),
                        "Code lost when linked chat was deleted");
                activity.nexusDeleteArtifact(first);
                check(!hasArtifact(activity, first), "Deleted artifact still visible");
                check(compose.getPage() == NexusComposeUi.Page.ARTIFACTS,
                        "Deletion must return to Artifacts");
            });
            check(checkpoint.edit().putBoolean("deleted", true).commit(), "Deletion checkpoint missing");
            main(instrumentation, activity::finish);
        } else if ("python_deleted".equals(step)) {
            check(checkpoint.getBoolean("deleted", false), "Verification phase missing");
            MainActivity activity = launch(instrumentation);
            long first = checkpoint.getLong("first", 0);
            long second = checkpoint.getLong("second", 0);
            main(instrumentation, () -> {
                activity.nexusOpenArtifacts();
                check(!hasArtifact(activity, first), "Deleted artifact returned after restart");
                check(hasArtifact(activity, second), "Remaining artifact not saved");
                activity.nexusOpenArtifact(second);
                check(activity.nexusPythonRead(SECOND).equals("print('independent')\n"),
                        "Remaining project content changed");
            });
            main(instrumentation, activity::finish);
        } else throw new IllegalArgumentException("Unknown probe step: " + step);
    }
}
