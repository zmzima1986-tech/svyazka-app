package app.svyazka.mobile;

import android.content.Context;
import android.util.AtomicFile;
import android.util.Base64;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import org.json.JSONException;
import org.json.JSONObject;

/** Private mini-project files. Artifact IDs use their own filename namespace. */
public final class PythonProjectStore {
    public static final int MAX_FILES = 48;
    public static final int MAX_FILE_BYTES = PythonProjectPaths.MAX_FILE_BYTES;
    public static final int MAX_PROJECT_BYTES = 1_800_000;
    private final File directory;
    private final String prefix;

    /** Original chat-keyed storage, read only for upgrades and old project cleanup. */
    public PythonProjectStore(Context context) { this(context, false); }

    /** Independent artifact-keyed files, never implicitly deleted with a chat. */
    public PythonProjectStore(Context context, boolean artifact) {
        directory = new File(context.getFilesDir(), "python-projects");
        prefix = artifact ? "artifact-" : "chat-";
    }

    public static boolean validPath(String path) { return PythonProjectPaths.validPath(path); }

    private AtomicFile file(long taskId) {
        if (taskId <= 0) throw new IllegalArgumentException("Не выбран проект.");
        return new AtomicFile(new File(directory, prefix + taskId + ".json"));
    }

    private LinkedHashMap<String, byte[]> read(long taskId) throws IOException {
        LinkedHashMap<String, byte[]> result = new LinkedHashMap<>();
        AtomicFile store = file(taskId);
        if (!store.getBaseFile().exists() &&
                !new File(store.getBaseFile().getPath() + ".bak").exists()) return result;
        try {
            byte[] raw = store.readFully();
            if (raw.length > 3_000_000) throw new IOException("Проект превышает лимит.");
            JSONObject json = new JSONObject(new String(raw, StandardCharsets.UTF_8));
            JSONObject files = json.getJSONObject("files");
            for (java.util.Iterator<String> names = files.keys(); names.hasNext();) {
                String name = names.next();
                if (!validPath(name)) throw new IOException("Небезопасное имя файла.");
                byte[] bytes = Base64.decode(files.getString(name), Base64.DEFAULT);
                result.put(name, bytes);
            }
            check(result);
            return result;
        } catch (Exception e) {
            throw new IOException("Не удалось прочитать сохранённый проект.", e);
        }
    }

    private static void check(Map<String, byte[]> files) throws IOException {
        if (files.size() > MAX_FILES) throw new IOException("Слишком много файлов в проекте.");
        long total = 0;
        for (Map.Entry<String, byte[]> entry : files.entrySet()) {
            if (!validPath(entry.getKey())) throw new IOException("Недопустимое имя файла: " + entry.getKey());
            byte[] data = entry.getValue();
            if (data.length > MAX_FILE_BYTES) throw new IOException("Файл больше разрешённого размера.");
            total += data.length;
            if (total > MAX_PROJECT_BYTES) throw new IOException("Превышен лимит размера проекта.");
        }
    }

    private void write(long taskId, LinkedHashMap<String, byte[]> files) throws IOException {
        check(files);
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Не удалось создать хранилище.");
        JSONObject json = new JSONObject();
        JSONObject contents = new JSONObject();
        try {
            json.put("version", 1);
            for (Map.Entry<String, byte[]> entry : files.entrySet())
                contents.put(entry.getKey(), Base64.encodeToString(entry.getValue(), Base64.NO_WRAP));
            json.put("files", contents);
        } catch (JSONException e) { throw new IOException(e); }
        byte[] body = json.toString().getBytes(StandardCharsets.UTF_8);
        AtomicFile target = file(taskId);
        FileOutputStream output = null;
        try {
            output = target.startWrite();
            output.write(body);
            target.finishWrite(output);
        } catch (IOException | RuntimeException e) {
            if (output != null) target.failWrite(output);
            throw new IOException("Не удалось сохранить проект.", e);
        }
    }

    /** Chat IDs with actual persisted project files (not the virtual empty main.py). */
    public synchronized long[] savedTaskIds() {
        java.util.TreeSet<Long> ids = new java.util.TreeSet<>();
        File[] files = directory.listFiles();
        if (files == null) return new long[0];
        Pattern stored = Pattern.compile(Pattern.quote(prefix) + "([1-9][0-9]*)\\.json(?:\\.bak)?");
        for (File candidate : files) {
            if (!candidate.isFile()) continue;
            java.util.regex.Matcher matcher = stored.matcher(candidate.getName());
            if (!matcher.matches()) continue;
            try { ids.add(Long.parseLong(matcher.group(1))); }
            catch (NumberFormatException ignored) { /* Not a valid SQLite task ID. */ }
        }
        long[] result = new long[ids.size()];
        int i = 0;
        for (long id : ids) result[i++] = id;
        return result;
    }

    /** Copy all legacy bytes without rewriting/removing the source (including non-Python assets). */
    public synchronized void copyTo(long sourceId, PythonProjectStore destination,
                                    long destinationId) throws IOException {
        if (destination == this && sourceId == destinationId) return;
        LinkedHashMap<String, byte[]> oldFiles = read(sourceId);
        if (oldFiles.isEmpty()) throw new IOException("Исходный проект пуст.");
        destination.write(destinationId, oldFiles);
    }

    /** One consistent snapshot for a linked chat; returned bytes are never shared with the store. */
    synchronized Map<String, byte[]> snapshotForChat(long projectId) throws IOException {
        return read(projectId);
    }

    public synchronized String[] paths(long taskId) throws IOException {
        return read(taskId).keySet().toArray(new String[0]);
    }

    public synchronized String text(long taskId, String path) throws IOException {
        byte[] value = read(taskId).get(path);
        return value == null ? "" : new String(value, StandardCharsets.UTF_8);
    }

    public synchronized byte[] bytes(long taskId, String path) throws IOException {
        return read(taskId).get(path);
    }

    public synchronized void putText(long taskId, String path, String text) throws IOException {
        put(taskId, path, text.getBytes(StandardCharsets.UTF_8));
    }

    /** Replace one existing source only after saving the previous whole project.
     * Used exclusively after explicit confirmation from the linked chat.
     */
    public synchronized void replaceTextWithBackup(long taskId, String path, String text)
            throws IOException {
        if (!validPath(path) || !path.endsWith(".py") || text == null || text.trim().isEmpty())
            throw new IOException("Нужен непустой Python-файл с допустимым именем.");
        LinkedHashMap<String, byte[]> files = read(taskId);
        if (!files.containsKey(path))
            throw new IOException("Исходный файл не найден. Изменения не применены.");
        byte[] updated = text.getBytes(StandardCharsets.UTF_8);
        if (Arrays.equals(files.get(path), updated)) return;
        files.put(path, updated);
        check(files); // Validate sizes before touching the backup or existing files.

        // A backup is the complete pre-edit project, not a truncated source fragment.
        byte[] backup = exportZip(taskId);
        AtomicFile previous = previousFile(taskId);
        if (!directory.isDirectory() && !directory.mkdirs())
            throw new IOException("Не удалось создать хранилище резервных копий.");
        FileOutputStream output = null;
        try {
            output = previous.startWrite();
            output.write(backup);
            previous.finishWrite(output);
        } catch (IOException | RuntimeException error) {
            if (output != null) previous.failWrite(output);
            throw new IOException("Не удалось создать резервную копию. Файл не изменён.", error);
        }
        write(taskId, files);
    }

    public synchronized void put(long taskId, String path, byte[] bytes) throws IOException {
        if (!validPath(path) || bytes == null) throw new IOException("Недопустимый файл.");
        LinkedHashMap<String, byte[]> files = read(taskId);
        files.put(path, Arrays.copyOf(bytes, bytes.length));
        write(taskId, files);
    }

    public synchronized void rename(long taskId, String oldPath, String newPath) throws IOException {
        if (!validPath(oldPath) || !validPath(newPath)) throw new IOException("Недопустимое имя файла.");
        LinkedHashMap<String, byte[]> files = read(taskId);
        if (!files.containsKey(oldPath) || files.containsKey(newPath)) throw new IOException("Файл не найден или имя занято.");
        files.put(newPath, files.remove(oldPath));
        write(taskId, files);
    }

    public synchronized void remove(long taskId, String path) throws IOException {
        if (!validPath(path) || "main.py".equals(path)) throw new IOException("Файл main.py удалять нельзя.");
        LinkedHashMap<String, byte[]> files = read(taskId);
        files.remove(path);
        write(taskId, files);
    }

    /** Same canonical bytes as workspace.py:snapshot_sha256 (paths are ASCII). */
    static String snapshotSha256(Map<String, byte[]> files) {
        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            for (Map.Entry<String, byte[]> entry : new java.util.TreeMap<>(files).entrySet()) {
                byte[] bytes = entry.getValue();
                digest.update(entry.getKey().getBytes(StandardCharsets.UTF_8));
                digest.update((byte) 0);
                digest.update(java.nio.ByteBuffer.allocate(8).putLong(bytes.length).array());
                digest.update(bytes);
            }
            StringBuilder hex = new StringBuilder(64);
            for (byte value : digest.digest())
                hex.append(String.format(java.util.Locale.ROOT, "%02x", value & 255));
            return hex.toString();
        } catch (java.security.NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(impossible);
        }
    }

    /** Base64 only crosses the WebMessagePort boundary; worker receives no Android filesystem paths. */
    public synchronized JSONObject snapshot(long taskId) throws IOException {
        LinkedHashMap<String, byte[]> files = read(taskId);
        JSONObject object = new JSONObject();
        try {
            for (Map.Entry<String, byte[]> entry : files.entrySet())
                object.put(entry.getKey(), Base64.encodeToString(entry.getValue(), Base64.NO_WRAP));
        } catch (JSONException e) { throw new IOException(e); }
        return object;
    }

    public synchronized byte[] exportZip(long taskId) throws IOException {
        Map<String, byte[]> files = read(taskId);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (ZipOutputStream archive = new ZipOutputStream(output)) {
            for (Map.Entry<String, byte[]> entry : files.entrySet()) {
                archive.putNextEntry(new ZipEntry(entry.getKey()));
                archive.write(entry.getValue());
                archive.closeEntry();
            }
        }
        return output.toByteArray();
    }

    /** All-or-nothing import. Never unzip paths onto the Android filesystem. */
    public synchronized void importZip(long taskId, byte[] body) throws IOException {
        if (body == null || body.length > MAX_PROJECT_BYTES) throw new IOException("ZIP превышает лимит.");
        LinkedHashMap<String, byte[]> files = read(taskId);
        LinkedHashMap<String, byte[]> additions = new LinkedHashMap<>();
        try (ZipInputStream archive = new ZipInputStream(new ByteArrayInputStream(body))) {
            ZipEntry entry;
            while ((entry = archive.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                String path = entry.getName();
                if (!validPath(path) || additions.containsKey(path) || files.containsKey(path))
                    throw new IOException("Небезопасный, повторный или существующий путь: " + path);
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int read;
                while ((read = archive.read(buffer)) >= 0) {
                    output.write(buffer, 0, read);
                    if (output.size() > MAX_FILE_BYTES) throw new IOException("Файл превышает лимит.");
                }
                additions.put(path, output.toByteArray());
                if (additions.size() + files.size() > MAX_FILES) throw new IOException("Превышен лимит файлов.");
                archive.closeEntry();
            }
        }
        if (additions.isEmpty()) throw new IOException("В ZIP нет подходящих файлов.");
        files.putAll(additions);
        write(taskId, files);
    }

    /** A user-selected ZIP is a complete project. Preserve the previous project before replacing it. */
    public synchronized void replaceZip(long taskId, byte[] body) throws IOException {
        LinkedHashMap<String, byte[]> replacement = parseFullProjectZip(body);
        Map<String, byte[]> existing = read(taskId);
        if (!existing.isEmpty()) {
            byte[] backup = exportZip(taskId);
            AtomicFile previous = previousFile(taskId);
            if (!directory.isDirectory() && !directory.mkdirs())
                throw new IOException("Не удалось создать хранилище резервных копий.");
            FileOutputStream out = null;
            try {
                out = previous.startWrite();
                out.write(backup);
                previous.finishWrite(out);
            } catch (IOException | RuntimeException error) {
                if (out != null) previous.failWrite(out);
                throw new IOException("Не удалось сохранить резервную копию. Импорт отменён.", error);
            }
        }
        write(taskId, replacement);
    }

    /** Automatic installation is allowed only into this chat's untouched
     * empty main.py, or an already identical project. Never overwrite user work. */
    synchronized boolean installGeneratedProject(long taskId, Map<String,String> sources) throws IOException {
        if (!PythonAutoStage.validGeneratedProject(sources)) return false;
        LinkedHashMap<String, byte[]> existing = read(taskId);
        LinkedHashMap<String, byte[]> replacement = new LinkedHashMap<>();
        for (Map.Entry<String,String> entry : sources.entrySet())
            replacement.put(entry.getKey(), entry.getValue().getBytes(StandardCharsets.UTF_8));
        check(replacement);
        boolean same = existing.keySet().equals(replacement.keySet());
        if (same) for (String path : existing.keySet())
            if (!Arrays.equals(existing.get(path), replacement.get(path))) { same = false; break; }
        if (same) return true;
        if (existing.size() != 1 || !existing.containsKey("main.py") || existing.get("main.py").length != 0)
            return false;
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (ZipOutputStream archive = new ZipOutputStream(output)) {
            for (Map.Entry<String,byte[]> entry : replacement.entrySet()) {
                archive.putNextEntry(new ZipEntry(entry.getKey()));
                archive.write(entry.getValue());
                archive.closeEntry();
            }
        }
        replaceZip(taskId, output.toByteArray()); // Existing atomic full-project backup.
        return true;
    }

    /** Read the full ZIP before touching an existing project (zip-slip, duplicates and limits). */
    private static LinkedHashMap<String, byte[]> parseFullProjectZip(byte[] body) throws IOException {
        return parseProjectZip(body, true);
    }

    private static LinkedHashMap<String, byte[]> parseProjectZip(byte[] body, boolean requireMain)
            throws IOException {
        if (body == null || body.length > 2_000_000) throw new IOException("ZIP слишком большой.");
        LinkedHashMap<String, byte[]> parsed = new LinkedHashMap<>();
        try (ZipInputStream archive = new ZipInputStream(new ByteArrayInputStream(body))) {
            ZipEntry entry;
            while ((entry = archive.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                String path = entry.getName();
                if (!validPath(path) || parsed.containsKey(path))
                    throw new IOException("Недопустимый или повторный путь внутри ZIP: " + path);
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int n;
                while ((n = archive.read(buffer)) != -1) {
                    output.write(buffer, 0, n);
                    if (output.size() > MAX_FILE_BYTES)
                        throw new IOException("Файл внутри ZIP превышает лимит.");
                }
                parsed.put(path, output.toByteArray());
                if (parsed.size() > MAX_FILES) throw new IOException("Слишком много файлов внутри ZIP.");
                archive.closeEntry();
            }
        }
        check(parsed);
        if (requireMain && !parsed.containsKey("main.py"))
            throw new IOException("В архиве нет main.py. Выбери ZIP с Python-проектом.");
        return parsed;
    }

    private AtomicFile previousFile(long taskId) {
        if (taskId <= 0) throw new IllegalArgumentException("Не выбран проект.");
        return new AtomicFile(new File(directory, prefix + taskId + ".previous.zip"));
    }

    public synchronized boolean hasPrevious(long taskId) {
        return taskId > 0 && previousFile(taskId).getBaseFile().isFile();
    }

    public synchronized void restorePrevious(long taskId) throws IOException {
        AtomicFile previous = previousFile(taskId);
        if (!hasPrevious(taskId)) throw new IOException("Резервная копия не найдена.");
        LinkedHashMap<String, byte[]> restored = parseProjectZip(previous.readFully(), false);
        write(taskId, restored);
    }

    public synchronized void deleteTask(long taskId) {
        if (taskId > 0) {
            file(taskId).delete();
            previousFile(taskId).delete();
        }
    }
}
