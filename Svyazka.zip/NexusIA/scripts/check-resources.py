#!/usr/bin/env python3
"""Validate UI locales, manifest references and identity stability without Android SDK."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re

project = Path(__file__).resolve().parents[1]
res = project / "app/src/main/res"
locales = ["values", "values-en", "values-zh-rCN", "values-ar", "values-ja"]
keys = []
for directory in locales:
    root = ET.parse(res / directory / "strings.xml").getroot()
    names = [item.attrib["name"] for item in root if item.tag == "string"]
    assert len(names) == len(set(names)), f"Duplicate keys: {directory}"
    keys.append(set(names))
assert all(item == keys[0] for item in keys), "Missing translations"
assert next(item.text for item in ET.parse(res / "values/strings.xml").getroot()
            if item.attrib["name"] == "app_name") == "Nexus AI"

manifest = (project / "app/src/main/AndroidManifest.xml").read_text()
assert 'android:supportsRtl="true"' in manifest
assert 'android:localeConfig="@xml/locales_config"' in manifest
assert 'android:icon="@mipmap/ic_launcher"' in manifest
assert 'android:roundIcon="@mipmap/ic_launcher_round"' in manifest
assert (res / "drawable/ic_nia_launcher_foreground.xml").is_file()
for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"):
    assert (res / f"mipmap-{density}/ic_launcher.png").is_file()
    assert (res / f"mipmap-{density}/ic_launcher_round.png").is_file()
for name in ("ic_launcher", "ic_launcher_round"):
    assert (res / f"mipmap-anydpi-v26/{name}.xml").is_file()
ET.parse(res / "xml/locales_config.xml")
for xml in res.rglob("*.xml"):
    ET.parse(xml)

# Every drawable identifier in code must resolve after removing the legacy icon sheets.
all_drawable_names = {p.stem for folder in res.glob("drawable*") for p in folder.iterdir() if p.is_file()}
for source in (project / "app/src/main/java").rglob("*"):
    if source.suffix not in (".java", ".kt"):
        continue
    refs = set(re.findall(r"R\.drawable\.(\w+)", source.read_text()))
    assert refs <= all_drawable_names, f"Missing drawable resources: {source}: {refs - all_drawable_names}"

all_refs = set()
for path in (project / "app/src/main").rglob("*"):
    if path.suffix in (".kt", ".java"):
        all_refs.update(re.findall(r"R\.string\.(\w+)", path.read_text()))
assert all_refs <= keys[0], f"Unknown resources: {sorted(all_refs - keys[0])}"

build = (project / "app/build.gradle").read_text()
assert "applicationId 'app.svyazka.team'" in build, "Do not lose existing app data"
assert "versionName '0.7.0'" in build
for name in ("Workflow", "ModelClient", "KeyVault", "LocalSandbox"):
    source = project / f"app/src/main/java/app/svyazka/mobile/{name}.java"
    assert source.is_file()
print(f"Nexus AI resources: PASS ({len(keys[0])} keys x {len(locales)} locales)")
