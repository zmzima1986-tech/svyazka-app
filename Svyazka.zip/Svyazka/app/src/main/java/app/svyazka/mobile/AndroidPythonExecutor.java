package app.svyazka.mobile;

import android.content.Context;
import java.util.function.Consumer;

/** The existing WebView sandbox behind a platform-neutral execution contract. */
final class AndroidPythonExecutor implements PythonExecutor {
    private final Context context;
    private final LocalSandbox delegate;

    AndroidPythonExecutor(Context context, Consumer<SandboxClient.Result> result, Consumer<String> problem) {
        this.context = context;
        delegate = new LocalSandbox(result, problem);
    }

    @Override public void execute(String code, String stdin) {
        delegate.execute(context, code, stdin);
    }

    @Override public void cancel() {
        delegate.close();
    }
}
