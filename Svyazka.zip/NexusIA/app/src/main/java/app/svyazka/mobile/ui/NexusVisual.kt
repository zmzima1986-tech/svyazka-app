package app.svyazka.mobile.ui

import android.graphics.BitmapFactory
import android.util.Base64
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.svyazka.mobile.R
import java.io.ByteArrayInputStream

/** Fullscreen, untrusted visual output with no WebView bridge and no network access. */
@Composable
fun VisualResultOverlay(ui: NexusComposeUi) {
    if (!ui.visualOpen) return
    Dialog(onDismissRequest = { ui.closeVisual() },
        properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { ui.closeVisual() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack,
                            stringResource(R.string.action_close))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.visual_title),
                        style = MaterialTheme.typography.titleLarge)
                }
                Spacer(Modifier.height(6.dp))
                NexusLabel(stringResource(R.string.visual_safety))
                Spacer(Modifier.height(16.dp))
                when {
                    ui.visualPng.isNotBlank() -> {
                        val bitmap = remember(ui.visualPng) { decodeSafePng(ui.visualPng) }
                        if (bitmap == null) {
                            Text(stringResource(R.string.visual_empty))
                        } else {
                            Image(bitmap.asImageBitmap(),
                                contentDescription = stringResource(R.string.visual_png),
                                modifier = Modifier.fillMaxWidth().weight(1f),
                                contentScale = ContentScale.Fit)
                        }
                    }
                    ui.visualHtml.isNotBlank() -> {
                        val markup = remember(ui.visualHtml) { safeHtml(ui.visualHtml) }
                        AndroidView(modifier = Modifier.fillMaxWidth().weight(1f),
                            factory = { context ->
                                WebView(context).apply {
                                    settings.javaScriptEnabled = false
                                    settings.allowFileAccess = false
                                    settings.allowContentAccess = false
                                    settings.domStorageEnabled = false
                                    settings.blockNetworkLoads = true
                                    settings.blockNetworkImage = true
                                    settings.setSupportMultipleWindows(false)
                                    settings.javaScriptCanOpenWindowsAutomatically = false
                                    webViewClient = object : WebViewClient() {
                                        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse {
                                            return WebResourceResponse("text/plain", "UTF-8", 403,
                                                "Forbidden", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                                        }
                                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
                                    }
                                    loadDataWithBaseURL("https://nexus-ia-preview.invalid/", markup,
                                        "text/html", "UTF-8", null)
                                }
                            }, update = {}, onRelease = { it.stopLoading(); it.destroy() })
                    }
                    else -> NexusLabel(stringResource(R.string.visual_empty))
                }
                Button(onClick = { ui.closeVisual() }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.action_close))
                }
            }
        }
    }
}

private fun decodeSafePng(base64: String): android.graphics.Bitmap? {
    if (base64.length > 600_000) return null
    return try {
        val data = Base64.decode(base64, Base64.DEFAULT)
        if (data.size < 8 || data.size > 420_000 ||
            data[0] != 0x89.toByte() || data[1] != 'P'.code.toByte() ||
            data[2] != 'N'.code.toByte() || data[3] != 'G'.code.toByte()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        if (bounds.outWidth < 1 || bounds.outHeight < 1 ||
            bounds.outWidth > 8192 || bounds.outHeight > 8192) return null
        var sample = 1
        while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        BitmapFactory.decodeByteArray(data, 0, data.size, options)
    } catch (_: IllegalArgumentException) { null } catch (_: OutOfMemoryError) { null }
}

private fun safeHtml(body: String): String {
    val csp = "default-src 'none'; style-src 'unsafe-inline'; img-src data:; " +
        "script-src 'none'; connect-src 'none'; frame-src 'none'; form-action 'none'; " +
        "object-src 'none'; base-uri 'none';"
    return "<html><head><meta http-equiv=\"Content-Security-Policy\" content=\"$csp\">" +
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head>" +
        "<body>" + body + "</body></html>"
}
