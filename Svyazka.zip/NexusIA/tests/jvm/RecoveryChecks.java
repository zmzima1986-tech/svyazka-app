package app.svyazka.mobile;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;

/** Replays actual Build 14 answer formats and verifies promotion after final editing. */
public final class RecoveryChecks {
    private static int count;
    private static void verify(boolean value,String name) {
        if (!value) throw new AssertionError(name);
        count++;
    }
    private static ModelClient.Reply stop(String text) {
        return new ModelClient.Reply(text, ModelClient.Finish.STOP, "");
    }
    private static JSONObject report(String status) throws Exception {
        return new JSONObject().put("language","html").put("status","SYNTAX_CHECKED")
                .put("tests",new JSONArray().put(new JSONObject().put("id","clock.tick").put("status",status)));
    }
    static void consoleSourceChecks() throws Exception {
        String answer = Files.readString(Paths.get("tests/fixtures/recovery/observed-console-transcript.md"), StandardCharsets.UTF_8);
        int start = answer.indexOf("```python\n") + "```python\n".length();
        String code = answer.substring(start, answer.indexOf("\n```", start) + 1);
        PythonInputs.Candidate observed = PythonInputs.candidate(answer);
        verify(observed != null && !observed.ambiguous && observed.issue.isEmpty() && observed.code.equals(code),
                "phone response: transcript is not a second source file");
        verify(PythonInputs.copySource(answer).equals(code), "exact source without example output");
        verify(PythonInputs.manualBlocks(answer).size() == 1, "one manual entry");
        verify(PythonAutoStage.select("Создай программу", answer, new String[]{"main.py"}) != null,
                "same source can stage into existing project");
        String single = "```python\nprint(42)\n```";
        String named = "```python file=main.py\nprint(42)\n```";
        for (String tag : new String[]{"", "text", "plaintext", "console", "terminal", "pycon"}) {
            String transcript = "\n```" + tag + "\n> input\noutput\n```";
            verify(!PythonInputs.candidate(single + transcript).ambiguous, "transcript tag " + tag);
            verify(PythonInputs.namedFiles(named + transcript).size() == 1, "named source with transcript " + tag);
        }
        for (String tag : new String[]{"output", "stdout", "stderr"})
            verify(!PythonInputs.candidate(single + "\n```" + tag + "\n42\n```").ambiguous, "explicit output tag " + tag);
        verify(!PythonInputs.candidate(single + "\n```\n>>> f(1)\n2\n```").ambiguous, "doctest transcript");
        verify(!PythonInputs.candidate(single + "\n```terminal\n$ python main.py\n42\n```").ambiguous, "shell transcript");
        for (String extra : new String[]{
                "\n```python\nprint(2)\n```", "\n```\nprint(2)\n```", "\n```\nx = 3\n```",
                "\n```\nunknown configuration\n```", "\n```console\n> input\noutput",
                "\n```text file=notes.txt\n> input\noutput\n```", "\n```output file=log.txt\n42\n```",
                "\n```text\n> input\n# file=another.py\nprint(2)\n```", "\n```json\n{\"key\":1}\n```"})
            verify(PythonInputs.candidate(single + extra).ambiguous, "preserve ambiguity: " + extra);
        verify(PythonInputs.candidate(single + "\n```python file=helper.py\nprint(2)\n```").ambiguous,
                "second executable file stays ambiguous");
        verify(PythonInputs.namedFiles(named + "\n```output file=log.txt\n42\n```").size() == 2,
                "explicit file never discarded");
        String html = "<html><body>ok</body></html>\n";
        String web = "```html file=index.html\n" + html + "```";
        String output = "\n```output\nexample\n```";
        verify(PythonInputs.webSource(web + output, "html").equals(html), "named HTML plus output is previewable");
        verify(PythonInputs.webSource(named + "\n" + web + output, "html").equals(html), "mixed HTML/Python plus output is previewable");
        verify(PythonInputs.namedFiles(named + "\n```python file=helper.py\nprint(2)\n```" + output).size() == 2,
                "named multi-file export preserves both sources");
        verify(PythonInputs.candidate("```python\nprint(1)").issue.length() > 0, "incomplete source still rejected");
    }
    public static void main(String[] args) throws Exception {
        consoleSourceChecks();
        for (String name : new String[]{"clock-calendar-weather","with-bluetooth"}) {
            String answer=new String(Files.readAllBytes(Paths.get("tests/fixtures/recovery/"+name+".md")),StandardCharsets.UTF_8);
            String html=PythonInputs.webSource(answer,"html");
            verify(html.length()>5000 && html.trim().endsWith("</html>"),"primary HTML "+name);
            verify(PythonInputs.copySource(answer).equals(html),"clean clipboard");
            JSONObject f=PythonInputs.fileMetadata(answer).getJSONObject(0);
            verify(f.getInt("bytes")==html.getBytes(StandardCharsets.UTF_8).length && f.getString("sha256").equals(InputMaterial.sha256(html.getBytes(StandardCharsets.UTF_8))),"file identity");
        }
        String project="```python file=main.py\nprint('ok')\n```\n```ini file=buildozer.spec\n[app]\nandroid.permissions = BLUETOOTH_SCAN\n```";
        verify(PythonInputs.namedFiles(project).size()==2 && !PythonInputs.candidate(project).ambiguous,"named source and config");
        for(String unsafe:new String[]{"../main.py","/main.py","one/../../main.py","main.py/part","MAIN.PY","one\\two","a//b"}) {
            verify(PythonInputs.namedFiles(project.replace("buildozer.spec",unsafe)).isEmpty(),"unsafe path "+unsafe);
        }
        verify(PythonInputs.copySource("Объяснение\n```python\nprint('ok')\n```").equals("print('ok')\n"),"no prose in .py");
        verify(PythonInputs.webSource("<html><body>unfinished","html").isEmpty(),"truncated raw HTML");
        String clock = "<html><body><script>setInterval(()=>{},1000)</script></body></html>\n";
        String mixed = "```python file=main.py\nprint('old')\n```\n```html file=index.html\n" + clock + "```";
        verify(PythonInputs.webSource(mixed,"html").equals(clock),"standalone HTML must not disappear beside a Python file");
        String observed = Files.readString(Paths.get("tests/fixtures/recovery/observed-mixed-clock.md"), StandardCharsets.UTF_8);
        verify(PythonInputs.webSource(observed,"html").contains("function updateTime()"),"actual device clock answer is previewable");
        verify(PythonInputs.webSource(mixed + "\n```js file=main.js\nconsole.log(1)\n```","html").isEmpty(),"split web package not silently flattened");
        verify(TaskHistory.startsIndependentTask("Напиши на Python калькулятор", "Теперь создай HTML-страницу с работающими цифровыми часами и текущей датой."),"new HTML task replaces old Python task");
        verify(!TaskHistory.startsIndependentTask("Напиши на Python калькулятор", "Теперь создай HTML-страницу для калькулятора"),"port keeps previous requirements");
        verify(!TaskHistory.startsIndependentTask("Напиши на Python калькулятор", "Добавь проверку"),"ordinary edit keeps context");
        verify(TaskHistory.startsIndependentTask("old", "Новая задача: напиши текст"),"explicit new task");

        // Device regression: HTML -> independent Python request, ordinary launch
        // command after the code, and the reviewer's redundant code appendix.
        String previousWeb = ChatProjectContext.append("Создай HTML-страницу с цифровыми часами и текущей датой.",
                java.util.Collections.singletonMap("main.py", new byte[0]), 100_000);
        String newPython = "Создай на Python калькулятор с четырьмя арифметическими операциями, защитой от деления на ноль и автоматическими тестами через assert.\nВ консоли [console]";
        verify(TaskHistory.startsIndependentTask(previousWeb, newPython), "new Python task replaces old HTML task despite linked Python snapshot");
        verify(!TaskHistory.startsIndependentTask(previousWeb, "Создай на Python программу для часов"), "related web-to-Python request retains context");
        verify(!TaskHistory.startsIndependentTask(previousWeb, "Добавь часы в существующую страницу"), "ordinary web edit retains context");
        String py = "def add(a, b):\n    return a + b\nassert add(2, 3) == 5\n";
        String listing = "**file=main.py**\n```python\n" + py + "```";
        String launch = "\n\n```bash\npython3 main.py\n```";
        String solution = listing + "\n\nRun in the console:" + launch;
        verify(PythonInputs.candidate(solution).code.equals(py) && !PythonInputs.candidate(solution).ambiguous,
                "shell launch command is not a second source");
        verify(PythonInputs.copySource(solution).equals(py), "copy only Python source");
        verify(PythonInputs.fileMetadata(solution).getJSONObject(0).getString("path").equals("main.py"), "export single Python file");
        verify(PythonInputs.namedFiles("```python file=main.py\n" + py + "```" + launch).size() == 1, "named file with launch command");
        verify(PythonInputs.candidate(listing + "\n```python\nprint(2)\n```").ambiguous, "two Python blocks remain ambiguous");
        verify(PythonInputs.candidate(listing + "\n```bash\npython3 other.py\n```").ambiguous, "unrelated shell command remains ambiguous");
        verify(PythonInputs.candidate(listing + "\n```bash\npython3 main.py").ambiguous, "unclosed invocation remains ambiguous");
        verify(PythonInputs.candidate(listing + "\n```bash file=run.sh\npython3 main.py\n```").ambiguous, "explicit shell file is not discarded");
        String review = "All requirements reviewed.\n[[REVIEW: PASS]]\n\n---\n\n" + listing;
        verify(Workflow.Verdict.read(review) == Workflow.Verdict.PASS, "unique PASS followed by redundant closed source");
        Workflow.Run phone = new Workflow.Run(newPython, Workflow.defaultStages()).receive(stop(solution)).receive(stop(review));
        verify(phone.complete() && phone.revisionSkipped() && phone.finalIndex() == 0, "completed review keeps original solution");
        verify(phone.displayAnswer(0).equals(solution) && phone.displayAnswer(1).equals("All requirements reviewed."), "review appendix never replaces original");
        verify(Workflow.Verdict.read(review + "\nActually, an error remains.") == Workflow.Verdict.INVALID, "trailing prose is not ignored");
        verify(Workflow.Verdict.read(review + "\n[[REVIEW: FIX]]") == Workflow.Verdict.INVALID, "conflicting verdict rejected");
        verify(Workflow.Verdict.read(review + "\n[[REVIEW: PASS]]") == Workflow.Verdict.INVALID, "duplicate verdict rejected");
        verify(Workflow.Verdict.read("Checked.\n[[REVIEW: PASS]]\n```python\nprint(1)") == Workflow.Verdict.INVALID, "unclosed appendix rejected");
        verify(Workflow.Verdict.read("Checked.\n```text\n[[REVIEW: PASS]]\n```") == Workflow.Verdict.INVALID, "verdict inside code rejected");
        verify(Workflow.Verdict.read("Checked.\n[[REVIEW: PASS]]\n```text\nAn error remains.\n```") == Workflow.Verdict.INVALID, "text appendix rejected");


        verify(PythonInputs.requiredFeatures("Создай часы и календарь. Добавь Bluetooth. Убери Bluetooth").length()==2,"explicit removal");
        verify(!PythonInputs.defaultWidget("Какая погода завтра?") && !PythonInputs.defaultWidget("Напиши часы на Python для Android"),"respect non-program and explicit target");
        String good="```html\n<html><body>working</body></html>\n```", bad=good.replace("working","broken");
        Workflow.Run run=new Workflow.Run("Сделай часы",Workflow.defaultStages()).receive(stop(good)).withWebCheck(0,report("pass"));
        verify(run.prompt().contains("clock.tick") && run.prompt().contains("required_features"),"critic sees actual test results");
        run=run.receive(stop("- Correct the clock formatting.\n[[REVIEW: FIX]]")).receive(stop(bad)).withWebCheck(2,report("fail"));
        verify(run.complete() && run.finalIndex()==0 && run.displayAnswer(2).equals(bad),"failed final author cannot replace a tested result");
        run=run.addRepair(new Workflow.RepairInput(2,PythonInputs.webSource(bad,"html"),"",report("fail").toString(),"html"));
        verify(run.prompt().contains("html_code") && run.instructions().contains("HTML"),"targeted HTML repair");
        run=Workflow.Run.fromJson(run.toJson()).receive(stop(good)).withWebCheck(3,report("pass"));
        verify(run.finalIndex()==3 && run.repairs.size()==1,"restored repair can improve file");
        Workflow.Run multi=Workflow.Run.quick("Создай на Python для Android",ModelCatalog.NORTH,Workflow.defaultStages().get(1)).receive(stop(project));
        verify(PythonInputs.request(multi,PythonInputs.candidate(project).code).getJSONObject("android_config").has("buildozer.spec"),"pass build config separately");
        multi=multi.addRepair(new Workflow.RepairInput(0,"print('ok')","","invalid callback"));
        verify(multi.prompt().contains("complete_project"),"repair receives manifest and source");
        verify(!multi.receive(stop("```py\nprint('ok')\n```")).complete(),"preserve earlier named project");
        System.out.println(count+" build 15 recovery checks passed");
    }
}
