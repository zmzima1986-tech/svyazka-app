"""Exercise the bundled web workspace in a clean Chromium browser."""
import json
import math
import os
import re
import time
from pathlib import Path
from playwright.sync_api import sync_playwright

ASSETS = Path(__file__).resolve().parents[1] / "app/src/main/assets/web"
ORIGIN = "https://nexus-workspace.invalid/"
DOCUMENT = """<!doctype html><output id="count">0</output><button onclick="return false">x</button>
<script>
const counter = document.getElementById("count");
let value = 0;
setInterval(() => { counter.textContent = String(++value); }, 50);
</script>"""


def check_local_forms(page):
    # Exact exported artifact from phone test 10 (revision 09).
    source = (ASSETS.parents[4] / "tests/fixtures/recovery/observed-todo-form.html").read_text()
    result = json.loads(page.evaluate("s=>inspectSource(s,'html')", source))
    assert result == {"checked": 1, "external": 0, "issues": []}
    page.evaluate("s=>renderSource(s,'html')", source)
    frame = page.frame_locator("iframe")
    field = frame.locator("#new-task-input")
    counter = frame.locator("#counter")
    rows = frame.locator("#task-list li")
    field.wait_for()
    assert counter.inner_text() == "Осталось задач: 0"
    field.fill("Купить хлеб")
    frame.locator("button[type=submit]").click()
    assert rows.count() == 1 and counter.inner_text() == "Осталось задач: 1"
    field.fill("Вторая задача")
    field.press("Enter")
    assert rows.count() == 2 and counter.inner_text() == "Осталось задач: 2"
    field.fill("   ")
    frame.locator("button[type=submit]").click()
    assert rows.count() == 2 and counter.inner_text() == "Осталось задач: 2"
    rows.first.locator("input[type=checkbox]").check()
    assert counter.inner_text() == "Осталось задач: 1"
    rows.first.locator("input[type=checkbox]").uncheck()
    assert counter.inner_text() == "Осталось задач: 2"
    rows.first.locator("input[type=checkbox]").check()
    rows.first.locator("button").click()
    assert rows.count() == 1 and counter.inner_text() == "Осталось задач: 1"
    rows.first.locator("button").click()
    assert rows.count() == 0 and counter.inner_text() == "Осталось задач: 0"
    print("Observed todo form: 8/8 interaction checks passed", flush=True)

    # Actual submission (including form.submit(), which bypasses submit events)
    # must remain blocked by CSP, for GET and POST and both self/top targets.
    requests = []
    page.on("request", lambda req: requests.append(req.url))
    page.route("**/*", lambda route: route.abort())
    messages = []
    page.on("console", lambda message: messages.append(message.text))
    page.evaluate("s=>renderSource(s,'html')", "<output id=alive>alive</output>")
    page.frame_locator("iframe").locator("#alive").wait_for()
    child = page.frames[1]
    assert child.evaluate("self.origin") == "null"
    assert child.evaluate("() => {try {void parent.document;return false}catch{return true}}")
    assert child.evaluate("() => {try {localStorage.setItem('test','1');return false}catch{return true}}")
    assert child.evaluate("async () => {try {await fetch('https://blocked.invalid/fetch');return false}catch{return true}}")
    original_url = page.url
    for method in ("get", "post"):
        for target in ("_self", "_top"):
            # A CSP-blocked self navigation can replace the child with a browser
            # error document. Start each attempt from a fresh isolated frame.
            page.evaluate("s=>renderSource(s,'html')", "<output id=alive>alive</output>")
            page.frame_locator("iframe").locator("#alive").wait_for()
            child = page.frames[1]
            messages.clear()
            child.evaluate("""([method,target])=>{
                const f=document.createElement('form'); f.method=method; f.target=target;
                f.action='https://blocked.invalid/'+method+target;
                document.body.append(f); f.submit();
            }""", [method,target])
            until = time.monotonic() + 3
            while time.monotonic() < until:
                if any(("form-action" in msg and "blocked.invalid" in msg) if target == "_self"
                       else ("sandboxed" in msg and "navigation" in msg) for msg in messages):
                    break
                page.wait_for_timeout(50)
            else:
                raise AssertionError((method,target,messages))
            assert page.url == original_url and page.locator("iframe").count() == 1
    assert not any('blocked.invalid' in url for url in requests), requests
    print("Form navigation blocked: GET/POST, self/top; isolation, storage and fetch checks passed", flush=True)


def check_split_project(page):
    fixture = ASSETS.parents[4] / "tests/fixtures/recovery/observed-split-todo.json"
    captured = json.loads(fixture.read_text())
    files = {entry['path']:entry['text'] for entry in captured['source_files']['files']}
    def inspect(bundle):
        return json.loads(page.evaluate("s=>inspectSource(s,'web-project')",json.dumps(bundle)))
    def render(bundle):
        return page.evaluate("s=>renderSource(s,'web-project')",json.dumps(bundle))
    check = inspect(files)
    assert check == {'checked':1,'external':0,'issues':[],'project_entry':'index.html','preview_supported':True}, check
    # A valid check only parses syntax, never claims runtime execution.
    assert 'tests' not in check
    assert render(files)
    frame = page.frame_locator('iframe')
    field=frame.locator('#new-task-input'); rows=frame.locator('#task-list li'); counter=frame.locator('#counter')
    field.wait_for()
    assert counter.inner_text() == 'Осталось задач: 0'
    assert frame.locator('body').evaluate('e=>getComputedStyle(e).backgroundColor') == 'rgb(249, 249, 249)'
    field.fill('Первая'); frame.locator('button[type=submit]').click()
    assert rows.count()==1 and counter.inner_text()=='Осталось задач: 1'
    field.fill('Вторая'); field.press('Enter')
    assert rows.count()==2 and counter.inner_text()=='Осталось задач: 2'
    field.fill('   '); field.press('Enter')
    assert rows.count()==2
    rows.first.locator('input').check(); assert counter.inner_text()=='Осталось задач: 1'
    rows.first.locator('input').uncheck(); assert counter.inner_text()=='Осталось задач: 2'
    rows.first.locator('input').check(); rows.first.locator('button').click()
    assert rows.count()==1 and counter.inner_text()=='Осталось задач: 1'
    rows.first.locator('button').click(); assert rows.count()==0 and counter.inner_text()=='Осталось задач: 0'
    print('Split todo: 9/9 initial state, CSS and interactions passed', flush=True)
    broken=dict(files, **{'script.js':'let x = ;'})
    assert inspect(broken)['issues'][0].startswith('script.js:') and not render(broken)
    absent={p:t for p,t in files.items() if p!='script.js'}
    assert inspect(absent)['external']==1 and not inspect(absent)['preview_supported'] and not render(absent)
    no_css={p:t for p,t in files.items() if p!='style.css'}
    assert not inspect(no_css)['preview_supported'] and not render(no_css)
    external=dict(files, **{'index.html':files['index.html'].replace('script.js','https://blocked.invalid/script.js')})
    assert inspect(external)['external']==1 and not render(external)
    module=dict(files, **{'index.html':files['index.html'].replace('<script src','<script type="module" src')})
    assert inspect(module)['checked']==1 and not inspect(module)['preview_supported'] and not render(module)
    unsafe=dict(files, **{'script.js':'const text = "</script>";'})
    assert not inspect(unsafe)['issues'] and not render(unsafe)
    deferred=dict(files, **{'index.html':files['index.html'].replace('<script src','<script defer src')})
    assert not inspect(deferred)['preview_supported'] and not render(deferred)
    nested={'pages/index.html':files['index.html'].replace('style.css','../css/style.css').replace('script.js','../js/script.js'), 'css/style.css':files['style.css'],'js/script.js':files['script.js']}
    assert inspect(nested)['project_entry']=='pages/index.html' and inspect(nested)['checked']==1 and render(nested)
    beyond=dict(nested, **{'pages/index.html':nested['pages/index.html'].replace('../js','../../js')})
    assert inspect(beyond)['external']==1 and not render(beyond)
    two=dict(nested, **{'pages/other.html':'<html></html>'})
    assert inspect(two)['project_entry']=='' and not render(two)
    extra=dict(files, **{'extra.js':'let x = ;'})
    assert inspect(extra)['issues'][0].startswith('extra.js:') and not render(extra)
    # A changed file must affect preview; old single-file buffer cannot pass this check.
    updated=dict(files, **{'script.js':files['script.js'].replace('Осталось задач:', 'Текущий проект:'), 'style.css':files['style.css'].replace('#f9f9f9','#123456')})
    assert render(updated)
    frame.locator('#counter').wait_for()
    assert frame.locator('#counter').inner_text()=='Текущий проект: 0'
    assert frame.locator('body').evaluate('e=>getComputedStyle(e).backgroundColor')=='rgb(18, 52, 86)'
    child = page.frames[1]
    assert child.evaluate("self.origin") == "null"
    assert child.evaluate("() => {try {void parent.document;return false}catch{return true}}")
    assert child.evaluate("() => {try {localStorage.setItem('test','1');return false}catch{return true}}")
    assert child.evaluate("async () => {try {await fetch('https://blocked.invalid/split');return false}catch{return true}}")
    # Syntax inspection itself must not run any supplied JavaScript.
    poison=dict(files, **{'script.js':'window.nexusInspectionExecuted = true;'})
    assert inspect(poison)['checked']==1
    assert page.evaluate("typeof window.nexusInspectionExecuted === 'undefined'")
    print('Split project negative/path, changed-source and isolation checks passed', flush=True)


def main():
    shell = (ASSETS / "shell.html").read_text()
    for name, marker in (("acorn.js", "PARSER"), ("controller.js", "CONTROLLER")):
        shell = shell.replace("/*" + marker + "*/", (ASSETS / name).read_text())
    with sync_playwright() as driver:
        browser = driver.chromium.launch(executable_path=os.environ.get("CHROMIUM_EXECUTABLE"))
        page = browser.new_page()
        page.route("**/*", lambda route: route.fulfill(body=shell, content_type="text/html")
                   if route.request.url == ORIGIN else route.abort())
        if os.environ.get("NEXUS_FORMS_ONLY") == "1":
            # No synthetic URL navigation needed for the isolated local regression.
            page.set_content(shell)
            check_split_project(page)
            check_local_forms(page)
            browser.close()
            return
        page.goto(ORIGIN)

        def inspect(source, language="html"):
            return json.loads(page.evaluate("([code, kind]) => inspectSource(code, kind)", [source, language]))

        assert inspect(DOCUMENT) == {"checked": 2, "external": 0, "issues": []}
        assert inspect("<script>let value = ;</script>")["issues"]
        mixed = '<script type="module">export const x=2;</script><script src="foo.js"></script>'
        assert inspect(mixed) == {"checked": 1, "external": 1, "issues": [], "resources": ["foo.js"]}
        assert inspect("export const a = 1", "javascript")["checked"] == 1
        assert inspect('<button onclick="("></button>')["issues"]
        page.evaluate('source => renderSource(source, "html")', DOCUMENT)
        page.frame_locator("iframe").locator("#count").wait_for()
        frame = page.frames[1]
        until = time.monotonic() + 4
        while frame.evaluate('Number(document.getElementById("count").textContent)') <= 1:
            assert time.monotonic() < until, "Timer did not advance"
            page.wait_for_timeout(50)
        assert frame.evaluate("self.origin") == "null"
        assert frame.evaluate("() => {try {void parent.document; return false} catch {return true}}")
        assert frame.evaluate('async () => {try {await fetch("https://weather.invalid/test"); return false} catch {return true}}')
        assert frame.evaluate('() => {try {localStorage.setItem("test","1"); return false} catch {return true}}')
        def checks(source, features, kind="html"):
            page.evaluate("([s,f,k])=>startWidgetChecks(s,f,k)", [source,features,kind])
            until = time.monotonic()+11
            while time.monotonic()<until:
                report = page.evaluate("window.nexusTestResult")
                if report is not None:
                    return {r["id"]: r["status"] for r in report}
                page.wait_for_timeout(100)
            raise AssertionError("No probe report")

        fixtures = ASSETS.parents[4] / "tests/fixtures/recovery"
        form = """<input id="name"><button>Show</button><output id="answer"></output>
            <script>document.querySelector('button').onclick=()=>{document.querySelector('output').textContent=
            document.querySelector('input').value;};</script>"""
        def scenario(value, expected):
            return {"scenario":{"actions":[{"fill":"#name","value":value},{"click":"button"}],
                                "expected":{"selector":"#answer","text":expected}}}
        cases = checks(form,[scenario("Анна","Анна"),scenario("example","wrong")])
        assert cases == {"scenario.1":"pass","scenario.2":"fail","page.startup":"pass"}, cases
        body, code = form.split("<script>",1)
        split = {"index.html":body+'<script src="actions.js"></script>', "actions.js":code.split("</script>",1)[0]}
        assert checks(json.dumps(split),[scenario("Анна","Анна")],"web-project") == {
            "scenario.1":"pass","page.startup":"pass"}

        assert checks(form,[{"scenario":{"actions":[]}}])["scenario.1"] == "unverified"
        phone = json.loads((fixtures / "phone-r31-programs.json").read_text())
        broken = checks(phone["calculatorHtml"], ["calculator"])
        assert broken["arithmetic.multiply"] == "fail", broken
        assert all(broken["arithmetic."+op] == "fail" for op in ("add", "subtract", "divide")), broken
        keys = "".join("<button>" + k + "</button>" for k in "0123456789+-*/=C")
        arithmetic = """<output id="display">0</output><script>
            const display=document.querySelector('output');let left=0,op='',digits='';
            document.addEventListener('click',e=>{
                if(e.target.tagName!=='BUTTON')return;
                const key=e.target.textContent;
                if(key==='C'){digits='';op='';left=0;display.textContent='0';}
                else if(key==='='){const n=Number(digits);display.textContent=op==='+'?left+n:op==='-'?left-n:op==='*'?left*n:left/n;}
                else if('+-*/'.includes(key)){left=Number(digits);op=key;digits='';}
                else{digits+=key;display.textContent=digits;}
            });</script>"""
        fixed = checks(keys+arithmetic, ["calculator"])
        assert all(fixed["arithmetic."+op] == "pass" for op in ("add","subtract","multiply","divide")), fixed
        assert fixed["page.startup"] == "pass"
        assert checks("<button>Save</button>", [])["interaction.coverage"] == "unverified"
        assert checks("<script>throw Error('startup')</script>", [])["page.startup"] == "fail"
        print("Phone HTML calculator rejected; corrected button operations and startup observed", flush=True)
        for name in ["clock-calendar-weather", "with-bluetooth"]:
            answer = (fixtures / (name+".md")).read_text()
            html = re.search(r"```html[^\n]*\n(.*?)\n```",answer,re.S)[1]
            features=["часы","календарь","погода"]
            if name=="with-bluetooth": features.append("Bluetooth")
            found=checks(html,features)
            print(name,found, flush=True)
            assert all(found.get(k)=="pass" for k in ("clock.tick","calendar.current","calendar.december",
                "calendar.january","calendar.leap","weather.current","weather.leap","weather.offline")),found
            if name=="with-bluetooth": assert found["bluetooth.device"]=="unverified"
        observed = (fixtures / "observed-mixed-clock.md").read_text()
        actual_html = re.search(r"```html[^\n]*\n(.*?)\n```", observed, re.S)[1]
        assert inspect(actual_html)["issues"] == []
        assert checks(actual_html, ["часы"]) == {"clock.tick": "pass", "page.startup": "pass"}
        page.evaluate('source => renderSource(source, "html")', actual_html)
        clock = page.frame_locator("iframe").locator("#clock")
        clock.wait_for()
        first = clock.inner_text()
        page.wait_for_timeout(1300)
        assert clock.inner_text() != first and re.fullmatch(r"\d{2}:\d{2}:\d{2}", clock.inner_text())
        assert re.search(r"\d{4}$", page.frame_locator("iframe").locator("#date").inner_text())
        single_clock = """<time data-nexus="clock"></time><script>
            function tick(){document.querySelector('time').textContent=new Date().toTimeString().slice(0,8)}
            setInterval(tick,1000);tick();</script>"""
        assert checks(single_clock,["часы"])=={"clock.tick":"pass","page.startup":"pass"}
        calendar = """<p data-nexus="month"></p><div data-nexus="calendar"></div>
            <button data-nexus="next">Next</button><script>
            let d=new Date();d.setDate(1);
            function draw(){document.querySelector('p').textContent=d.toLocaleString('en',{month:'long',year:'numeric'});
                const grid=document.querySelector('[data-nexus=calendar]');grid.replaceChildren();
                for(let i=1;i<=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();i++){
                    const e=document.createElement('span');e.textContent=i;grid.append(e);}}
            document.querySelector('button').onclick=()=>{d.setMonth(d.getMonth()+1);draw()};draw();</script>"""
        extended=checks(single_clock+calendar,["часы","календарь"])
        assert extended["clock.tick"]=="pass" and extended["calendar.nextyear"]=="pass",extended
        assert checks(calendar.replace("d.setMonth(d.getMonth()+1)","d.setMonth(11)"),["календарь"])["calendar.nextyear"]=="fail"
        assert checks('<div id="clock">08:00:00</div>',["часы"])["clock.tick"]=="fail"
        assert checks('<p>Clock</p>',["часы"])["clock.tick"]=="unverified"
        # Real provider response from the Python -> HTML device regression.
        task_switch = json.loads((fixtures / "observed-python-to-html.json").read_text())
        replies = [task_switch["draft"]["text"]] + [
            item["text"] for item in task_switch["draft"]["preceding_sources"]]
        pages = [re.search(r"^```html file=index\.html\n(.*?)^```", reply, re.M | re.S)[1]
                 for reply in replies]
        assert all(source == pages[0] for source in pages)
        todo = pages[0]
        assert inspect(todo) == {"checked": 1, "external": 0, "issues": []}
        page.evaluate('source => renderSource(source, "html")', todo)
        frame = page.frame_locator("iframe")
        counter = frame.locator("#remaining-count")
        field = frame.locator("#new-task")
        rows = frame.locator("#task-list li")
        counter.wait_for()
        assert counter.inner_text() == "Осталось задач: 0" and rows.count() == 0
        field.fill("Первая задача")
        frame.locator("#add-btn").click()
        assert rows.count() == 1 and counter.inner_text() == "Осталось задач: 1"
        field.fill("Вторая задача")
        field.press("Enter")
        assert rows.count() == 2 and counter.inner_text() == "Осталось задач: 2"
        field.fill("   ")
        frame.locator("#add-btn").click()
        assert rows.count() == 2 and counter.inner_text() == "Осталось задач: 2"
        rows.first.locator("button").first.click()
        assert rows.first.evaluate("el=>el.classList.contains('completed')") and counter.inner_text() == "Осталось задач: 1"
        rows.first.locator("button").first.click()
        assert not rows.first.evaluate("el=>el.classList.contains('completed')") and counter.inner_text() == "Осталось задач: 2"
        rows.first.locator("button").last.click()
        assert rows.count() == 1 and counter.inner_text() == "Осталось задач: 1"
        rows.first.locator("button").last.click()
        assert rows.count() == 0 and counter.inner_text() == "Осталось задач: 0"
        print("Observed standalone HTML: 8/8 interaction checks passed", flush=True)
        check_split_project(page)
        check_local_forms(page)
        if os.environ.get("NEXUS_LIVE_WEATHER")=="1":
            from urllib.request import urlopen
            from urllib.parse import urlparse
            live=browser.new_page()
            received=[]
            def fetch_live(route):
                req=route.request
                parts=urlparse(req.url)
                if req.url==ORIGIN:
                    return route.fulfill(body=html,content_type="text/html")
                if (parts.scheme,parts.netloc,parts.path)!=("https","api.open-meteo.com","/v1/forecast"):
                    return route.abort()
                with urlopen(req.url,timeout=15) as response:
                    body=response.read(65536)
                current=json.loads(body)["current_weather"]
                received.append(current)
                route.fulfill(body=body,content_type="application/json",headers={"Access-Control-Allow-Origin":"*"})
            live.route("**/*",fetch_live)
            live.goto(ORIGIN)
            live.locator("#weather strong").wait_for(timeout=20000)
            temperature=live.locator("#weather strong").inner_text()
            assert received and temperature==str(math.floor(float(received[0]["temperature"])+0.5))+"°C",(received,temperature)
            print("External widget, real Open-Meteo response:",received[0]["time"],temperature)
        browser.close()
    print("JavaScript syntax, event handlers, timer and offline frame checks passed")


if __name__ == "__main__":
    main()
