"""Read-only probe of a synthetic project and the ordinary Python JS namespace.
No network calls, real secrets or Android file paths. Run in Nexus, not on host CPython.
"""
from pathlib import Path
import os
import sys

if sys.platform != 'emscripten':
    raise RuntimeError('Run inside the Nexus WASM runtime')

assert Path('probe.txt').read_text(encoding='utf-8') == 'nexus-public-fixture\n'
print('WORKSPACE: PASS')
assert 'NEXUS_TEST_HOST_MARKER' not in os.environ
print('ENV_CANARY_ABSENT: PASS')
try:
    import js
except ImportError:
    js = None
assert not any(hasattr(js, name) for name in ('fetch', 'XMLHttpRequest', 'WebSocket', 'document', 'Android'))
print('JS_NAMESPACE: PASS')
