package app.svyazka.mobile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class ModelPool {
    private static final int MAX_ATTEMPTS = 4;

    private ModelPool() {}

    static List<ModelCatalog.Model> forStep(ModelCatalog catalog, Workflow.Step step,
                                            ModelCatalog.Model selected, boolean routerKey,
                                            boolean groqKey, boolean allowGroqReserve,
                                            boolean geminiKey) {
        Map<String, ModelCatalog.Model> available = new LinkedHashMap<>();
        boolean primaryConfigured;
        switch (selected.provider) {
            case OPENROUTER: primaryConfigured = routerKey; break;
            case GROQ: primaryConfigured = groqKey; break;
            case GEMINI: primaryConfigured = geminiKey; break;
            default: throw new IllegalArgumentException("Неизвестный провайдер");
        }
        if (primaryConfigured) add(available, catalog, selected);
        if (groqKey && allowGroqReserve && selected.provider != Workflow.Provider.GROQ) {
            add(available, catalog, ModelCatalog.GROQ_120B);
        }
        if (routerKey) {
            List<ModelCatalog.Model> preferred = step == Workflow.Step.REVIEW
                    ? Arrays.asList(ModelCatalog.NEMOTRON, ModelCatalog.LING, ModelCatalog.GEMMA)
                    : Arrays.asList(ModelCatalog.NORTH, ModelCatalog.PARTICLE, ModelCatalog.FLINT);
            for (ModelCatalog.Model model : preferred) add(available, catalog, model);
        }
        if (groqKey && allowGroqReserve) {
            add(available, catalog, ModelCatalog.GROQ_120B);
            add(available, catalog, ModelCatalog.GROQ_20B);
        }
        if (routerKey) {
            for (ModelCatalog.Model model : catalog.choices()) {
                if (model.provider == Workflow.Provider.OPENROUTER) add(available, catalog, model);
            }
        }
        return new ArrayList<>(available.values());
    }

    private static void add(Map<String, ModelCatalog.Model> pool, ModelCatalog catalog,
                            ModelCatalog.Model model) {
        if (pool.size() < MAX_ATTEMPTS && catalog.available(model)) {
            pool.putIfAbsent(model.id, catalog.details(model));
        }
    }

    static boolean shouldTryNext(ModelClient.Reply reply) {
        if (reply.finish != ModelClient.Finish.ERROR) return false;
        if (reply.status == 0) return reply.failure.reason == RequestFailure.Reason.UNKNOWN;
        return reply.status == 408 || reply.status == 429
                || (reply.status == 413 && reply.failure.reason == RequestFailure.Reason.TOKEN_RATE_LIMIT)
                || reply.status == 503
                || reply.status == 504
                || (reply.status == 404 && reply.failure.reason == RequestFailure.Reason.MODEL_UNAVAILABLE);
    }

    static final class Cooldowns {
        private final Map<Workflow.Provider, Long> providers = new EnumMap<>(Workflow.Provider.class);
        private final Map<String, Long> routes = new HashMap<>();

        long availableAt(ModelCatalog.Model model) {
            return Math.max(providers.getOrDefault(model.provider, 0L),
                    routes.getOrDefault(model.id, 0L));
        }

        void record(ModelCatalog.Model model, RequestFailure failure, long now) {
            if (failure.retryAt <= now) return;
            if (failure.reason == RequestFailure.Reason.ROUTE
                    || failure.reason == RequestFailure.Reason.MODEL_UNAVAILABLE) {
                routes.merge(model.id, failure.retryAt, Math::max);
            } else {
                providers.merge(model.provider, failure.retryAt, Math::max);
            }
        }

        int next(List<ModelCatalog.Model> pool, int from, long now) {
            for (int i = from; i < pool.size(); i++) {
                if (availableAt(pool.get(i)) <= now) return i;
            }
            return -1;
        }

        long firstRetry(List<ModelCatalog.Model> pool, long now) {
            long earliest = Long.MAX_VALUE;
            for (ModelCatalog.Model model : pool) {
                long time = availableAt(model);
                if (time > now) earliest = Math.min(earliest, time);
            }
            return earliest == Long.MAX_VALUE ? 0 : earliest;
        }
    }
}
