#!/usr/bin/env python3
"""Validate UI locales, manifest references and identity stability without Android SDK."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re

project = Path(__file__).resolve().parents[1]
res = project / "app/src/main/res"
locales = ["values", "values-en", "values-zh-rCN", "values-ar", "values-ja"]
keys = []
for directory in locales:
    root = ET.parse(res / directory / "strings.xml").getroot()
    names = [item.attrib["name"] for item in root if item.tag == "string"]
    assert len(names) == len(set(names)), f"Duplicate keys: {directory}"
    keys.append(set(names))
assert all(item == keys[0] for item in keys), "Missing translations"
assert next(item.text for item in ET.parse(res / "values/strings.xml").getroot()
            if item.attrib["name"] == "app_name") == "Nexus IA"

manifest = (project / "app/src/main/AndroidManifest.xml").read_text()
assert 'android:supportsRtl="true"' in manifest
assert 'android:localeConfig="@xml/locales_config"' in manifest
assert 'android:icon="@drawable/ic_nexus"' in manifest
ET.parse(res / "xml/locales_config.xml")
for xml in res.rglob("*.xml"):
    ET.parse(xml)

all_refs = set()
for path in (project / "app/src/main").rglob("*"):
    if path.suffix in (".kt", ".java"):
        all_refs.update(re.findall(r"R\.string\.(\w+)", path.read_text()))
assert all_refs <= keys[0], f"Unknown resources: {sorted(all_refs - keys[0])}"

build = (project / "app/build.gradle").read_text()
assert "applicationId 'app.svyazka.team'" in build, "Do not lose existing app data"
assert "versionName '0.7.0'" in build
for name in ("Workflow", "ModelClient", "KeyVault", "LocalSandbox"):
    source = project / f"app/src/main/java/app/svyazka/mobile/{name}.java"
    assert source.is_file()
print(f"Nexus IA resources: PASS ({len(keys[0])} keys x {len(locales)} locales)")
