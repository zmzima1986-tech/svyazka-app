package app.svyazka.fixture;

import android.app.Instrumentation;
import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Disposable artifact IDs. Exercise public storage operations of the installed APK. */
final class ProjectArchiveProbe {
    private static byte[] zip(String name, byte[] data) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
            zip.putNextEntry(new ZipEntry(name));
            zip.write(data);
            zip.closeEntry();
        }
        return bytes.toByteArray();
    }

    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    static void run(Instrumentation test, String step) throws Exception {
        Context context = test.getTargetContext();
        Class<?> type = context.getClassLoader().loadClass("app.svyazka.mobile.PythonProjectStore");
        Object store = type.getConstructor(Context.class, boolean.class).newInstance(context, true);
        java.lang.reflect.Method put = type.getMethod("putText", long.class, String.class, String.class);
        java.lang.reflect.Method get = type.getMethod("bytes", long.class, String.class);
        java.lang.reflect.Method merge = type.getMethod("importZip", long.class, byte[].class);
        java.lang.reflect.Method replace = type.getMethod("replaceZip", long.class, byte[].class);
        long id = (System.nanoTime() & Long.MAX_VALUE) | 1;
        byte[] fresh = "print(41)\n".getBytes(StandardCharsets.UTF_8);
        byte[] original = "print(5)\n".getBytes(StandardCharsets.UTF_8);
        try {
            put.invoke(store, id, "main.py", new String(original, StandardCharsets.UTF_8));
            switch (step) {
                case "project_roundtrip":
                    put.invoke(store, id, "res/data.txt", "ёж\n");
                    byte[] snapshot = (byte[]) type.getMethod("exportZip", long.class).invoke(store, id);
                    put.invoke(store, id, "res/data.txt", "changed");
                    replace.invoke(store, id, snapshot);
                    check(Arrays.equals("ёж\n".getBytes(StandardCharsets.UTF_8), (byte[])get.invoke(store,id,"res/data.txt")), "Nested bytes changed");
                    break;
                case "project_merge":
                    merge.invoke(store, id, zip("data.bin", fresh));
                    check(Arrays.equals(fresh, (byte[])get.invoke(store,id,"data.bin")), "Missing new file");
                    break;
                case "project_rollback":
                    replace.invoke(store, id, zip("main.py", fresh));
                    check(Arrays.equals(fresh, (byte[])get.invoke(store,id,"main.py")), "Replacement failed");
                    type.getMethod("restorePrevious", long.class).invoke(store, id);
                    break;
                case "project_conflict":
                case "project_incomplete":
                case "project_budget":
                    java.lang.reflect.Method action = step.equals("project_conflict") ? merge : replace;
                    byte[] body = zip("main.py", step.equals("project_budget") ? new byte[420001] : fresh);
                    if (step.equals("project_incomplete")) body = Arrays.copyOf(body, body.length - 1);
                    try {
                        action.invoke(store, id, body);
                        throw new AssertionError("Invalid candidate was accepted");
                    } catch (InvocationTargetException error) {
                        if (!(error.getCause() instanceof IOException)) throw error;
                    }
                    check(!(Boolean)type.getMethod("hasPrevious", long.class).invoke(store, id), "Unexpected backup");
                    break;
                default: throw new IllegalArgumentException(step);
            }
            check(Arrays.equals(original, (byte[])get.invoke(store,id,"main.py")), "Working source changed");
        } finally { type.getMethod("deleteTask", long.class).invoke(store, id); }
    }
}
