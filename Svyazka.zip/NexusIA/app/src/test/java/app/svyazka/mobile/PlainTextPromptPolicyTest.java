package app.svyazka.mobile;

import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.junit.Assert.*;
import org.junit.Test;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 33)
public final class PlainTextPromptPolicyTest {
    private Workflow.Run run(String task) {
        return Workflow.Run.quick(task, ModelCatalog.GROQ_120B,
                Workflow.defaultStages().get(Workflow.Step.REVIEW.ordinal()));
    }

    @Test public void ordinaryAndroidTipsSavesWebWidgetInstructions() {
        Workflow.Run r = run("Напиши подробный список из 50 способов улучшить производительность Android. "
                + "Каждый пункт объясни двумя предложениями.");
        assertTrue(r.plainTextInstructionBytesSaved() > 600);
        assertEquals(0, r.consoleInstructionBytesSaved());
        assertFalse(r.instructions().contains("data-nexus"));
        assertTrue(r.instructions().contains("Не выдумывай данные."));
        assertTrue(r.estimatedPlainTextInstructionTokensSaved() > 0);
    }

    @Test public void shortGreetingAlsoOmitsWidgetAdvice() {
        assertTrue(PlainTextPromptPolicy.unambiguousProse("Привет!"));
        assertTrue(run("Привет!").plainTextInstructionBytesSaved() > 0);
    }

    @Test public void codeAndAppRequestsKeepAllOriginalRules() {
        for (String task : new String[] {
                "Создай приложение Android с главной страницей",
                "Объясни, как написать код Python",
                "Напиши список функций приложения",
                "Напиши HTML виджет часов",
                "Сделай веб-сайт для погоды",
                "Расскажи про интерфейс в Kotlin",
                "Напиши программу для консоли",
                "Напиши ```javascript\\nconsole.log(1);\\n```"
        }) {
            assertFalse("Task must remain conservative: " + task,
                    PlainTextPromptPolicy.unambiguousProse(task));
            assertTrue(run(task).instructions().contains("data-nexus"));
            assertEquals(0, run(task).plainTextInstructionBytesSaved());
        }
    }

    @Test public void olderCodeInFollowUpsDisablesProseShortcut() {
        String task = "Объясни работу Android без кода.\\nПредыдущие уточнения пользователя:\\n"
                + "- Сделай HTML виджет часов";
        assertFalse(PlainTextPromptPolicy.unambiguousProse(task));
        assertEquals(0, run(task).plainTextInstructionBytesSaved());
    }

    @Test public void weatherCalendarAndClockKeepSpecialRules() {
        for (String task : new String[] {
                "Расскажи о погоде завтра", "Напиши список функций календаря",
                "Объясни, как работают часы"
        }) {
            assertTrue(run(task).instructions().contains("data-nexus"));
        }
    }

    @Test public void contentAndTaskDoNotChange() throws Exception {
        String task = "Напиши список из пяти советов по здоровому сну";
        Workflow.Run run = run(task);
        assertEquals(task, run.task);
        assertEquals(run.unoptimizedPrompt(), run.prompt());
    }

    @Test public void longAndAmbiguousTasksRemainFull() {
        StringBuilder tooLong = new StringBuilder("Объясни ");
        for (int i = 0; i < 13000; i++) tooLong.append('a');
        assertFalse(PlainTextPromptPolicy.unambiguousProse(tooLong.toString()));
        assertFalse(PlainTextPromptPolicy.unambiguousProse("Создай что-нибудь полезное"));
        assertFalse(PlainTextPromptPolicy.unambiguousProse(""));
    }
}
