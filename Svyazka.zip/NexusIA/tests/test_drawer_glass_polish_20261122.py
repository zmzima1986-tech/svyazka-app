"""Contracts for the 2026-11-22 minimal glass and drawer refinements.

These are source checks; they do not replace a running Android Compose screenshot test.
"""
from pathlib import Path
import unittest
import re

UI = Path(__file__).resolve().parents[1] / 'app/src/main/java/app/svyazka/mobile/ui'


class DrawerGlassPolishTests(unittest.TestCase):
    def test_workspace_has_no_duplicate_message_composer(self):
        source = (UI / 'NexusDrawers.kt').read_text()
        workspace = source.split('private fun ColumnScope.RightWorkspace', 1)[1]
        workspace = workspace.split('@Composable\nprivate fun NexusLightTabDivider', 1)[0]
        self.assertNotIn('NexusLightWorkspaceComposer(ui)', workspace)
        self.assertNotIn('NexusDarkWorkspaceComposer(ui)', workspace)
        self.assertIn('NexusPythonWorkspace(ui)', workspace)
        self.assertIn('WorkspaceFiles(ui)', workspace)
        self.assertIn('WorkspaceLogs(ui)', workspace)

    def test_main_chat_composer_only_drawn_without_drawer(self):
        source = (UI / 'NexusChat.kt').read_text()
        self.assertIn('if (ui.panel == NexusComposeUi.Panel.NONE) {', source)
        self.assertIn('.clickable(enabled = canSend, onClick = { ui.submitChat() })', source)
        self.assertIn('ui.chatTextChanged(it)', source)

    def test_shared_glass_and_right_drawer_remain_translucent(self):
        design = (UI / 'NexusLightDesign.kt').read_text()
        frosted = (UI / 'NexusFrosted.kt').read_text()
        self.assertIn('val glass = Color.White.copy(alpha = .88f)', design)
        self.assertIn('Color.White.copy(alpha = .88f)', frosted)
        source = (UI / 'NexusDrawers.kt').read_text()
        right = source.split('AnimatedVisibility(visible = ui.panel == NexusComposeUi.Panel.RIGHT', 1)[1]
        right = right.split('private fun FrostedDrawer', 1)[0]
        self.assertIn('lightBackground = NexusLightDesign.glass', right)
        self.assertIn('showBorder = nexusLightMode()', right)
        self.assertIn('else RoundedCornerShape(0.dp)', right)

    def test_left_drawer_is_opaque_in_both_themes(self):
        source = (UI / 'NexusDrawers.kt').read_text()
        left = source.split('private fun FrostedDrawer', 1)[1].split('private fun leftDrawerSelection', 1)[0]
        self.assertIn('darkBackground = Color(0xFF', left)
        self.assertIn('lightBackground = Color(0xFF', left)
        self.assertIn('Brush.verticalGradient', left)
        self.assertIn('Modifier.fillMaxSize().background(matte)', left)
        colors = re.findall(r'Color\(0x([0-9A-Fa-f]{8})\)', left)
        self.assertGreaterEqual(len(colors), 8)
        self.assertTrue(all(color[:2].upper() == 'FF' for color in colors))
        self.assertNotIn('.copy(alpha', left)
        self.assertNotIn('nexusFrostedColor()', left)
        self.assertIn('showBorder = false', left)

    def test_left_slide_has_no_opacity_animation(self):
        source = (UI / 'NexusDrawers.kt').read_text()
        left = source.split('AnimatedVisibility(visible = ui.panel == NexusComposeUi.Panel.LEFT', 1)[1]
        left = left.split('AnimatedVisibility(visible = ui.panel == NexusComposeUi.Panel.RIGHT', 1)[0]
        self.assertIn('slideInHorizontally', left)
        self.assertIn('slideOutHorizontally', left)
        self.assertNotIn('fadeIn(', left)
        self.assertNotIn('fadeOut(', left)
        self.assertIn('detectHorizontalDragGestures', left)
        self.assertIn('ui.closePanel()', left)
        self.assertIn('FrostedDrawer { LeftTools(ui) }', left)

    def test_left_drawer_navigation_and_chat_controls_preserved(self):
        source = (UI / 'NexusDrawers.kt').read_text()
        left = source.split('private fun ColumnScope.LeftTools', 1)[1].split('private fun ColumnScope.RightWorkspace', 1)[0]
        for action in ('ui.requestNewTask()', 'ui.activity.nexusOpenHistory()',
                       'ui.activity.nexusOpenArtifacts()', 'ui.selectPage(NexusComposeUi.Page.MODELS)',
                       'ui.openTeamSettingsFromDrawer()', 'ui.openRight()',
                       'ui.selectPage(NexusComposeUi.Page.SETTINGS)', 'ui.requestKeys()',
                       'ui.activity.nexusOpenTask(task.id)', 'ui.activity.nexusPinTask(task.id, !task.pinned)',
                       'ui.deleteTarget = task.id', 'ui.activity.nexusRenameTask(task.id, name)'):
            with self.subTest(action=action):
                self.assertIn(action, left)
        self.assertIn('verticalScroll(rememberScrollState())', left)
        self.assertIn('.heightIn(min = 48.dp)', left)
        self.assertIn('task.selected) leftDrawerSelection()', left)

    def test_light_settings_controls_use_single_frosted_fill(self):
        source = (UI / 'NexusLightSettings.kt').read_text()
        self.assertNotIn('Surface(onClick = { languageOpen = true }', source)
        self.assertNotIn('Surface(onClick = onClick, modifier = modifier.heightIn', source)
        self.assertIn('.clickable(role = Role.Button) { languageOpen = true }', source)
        self.assertIn('.clickable(role = Role.Button, onClick = onClick)', source)
        self.assertIn('ui.activity.nexusLanguageChanged(key)', source)
        self.assertIn('ui.activity.nexusThemeChanged(key)', source)


if __name__ == '__main__':
    unittest.main()
