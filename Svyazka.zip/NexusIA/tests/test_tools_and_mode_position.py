"""Source contracts for the tools tap and mode-switch alignment fixes.

Android rendering and gesture behavior still need device validation.
"""
from pathlib import Path
import unittest

UI = Path(__file__).resolve().parents[1] / 'app/src/main/java/app/svyazka/mobile/ui'


class ToolsAndModePositionTests(unittest.TestCase):
    def test_tools_title_opens_existing_panel(self):
        source = (UI / 'NexusPythonWorkspace.kt').read_text(encoding='utf-8')
        title = source.index('text = stringResource(R.string.ws_easy_tools),')
        start = source.rfind('NexusSectionTitle(', 0, title)
        end = source.index('NexusPrimaryButton(', title)
        section = source[start:end]
        self.assertIn('.clickable(role = Role.Button) { toolPanel = PythonToolPanel.MENU }', section)
        self.assertIn('NexusAiStack(Modifier.size(22.dp))', section)
        self.assertIn('PythonToolPanel.MENU -> Column(', source)
        self.assertIn('PythonToolPanel.FILES -> PythonProjectFileManager(ui)', source)
        self.assertIn('PythonToolPanel.EDITOR -> PythonEditorTool', source)
        self.assertIn('PythonToolPanel.SETTINGS -> PythonRunSettingsTool', source)

    def test_mode_chips_have_identical_layout_in_both_states(self):
        source = (UI / 'NexusChat.kt').read_text(encoding='utf-8')
        start = source.index('internal fun ModeChip(')
        end = source.index('\n@Composable', start + 1)
        chip = source[start:end]
        self.assertEqual(chip.count('Text(label,'), 1)
        self.assertEqual(chip.count('.clickable(onClick = onClick)'), 1)
        self.assertIn('Modifier.padding(horizontal = 9.dp, vertical = 9.dp)', chip)
        self.assertIn('fontSize = 12.sp', chip)
        self.assertNotIn('Surface(onClick', chip)
        self.assertIn('contentAlignment = Alignment.Center', chip)

    def test_home_actions_keep_existing_compact_dimensions(self):
        source = (UI / 'NexusChat.kt').read_text(encoding='utf-8')
        self.assertIn('Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)', source)
        self.assertEqual(source.count('modifier = Modifier.weight(1f),\n                icon = { Icon(Icons.Outlined.'), 2)
        components = (UI / 'NexusComponents.kt').read_text(encoding='utf-8')
        self.assertIn('modifier = modifier.heightIn(min = 44.dp)', components)
        self.assertIn('val fontSize = (13 downTo 9)', components)


if __name__ == '__main__':
    unittest.main()
