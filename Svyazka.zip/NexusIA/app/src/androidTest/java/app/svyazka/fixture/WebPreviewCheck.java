package app.svyazka.fixture;

import android.app.Activity;
import android.app.Dialog;
import app.svyazka.mobile.ui.WebWorkspaceKt;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import org.json.JSONTokener;
import java.io.InputStream;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Run the same shell and iframe as the workspace in a visible Android WebView. */
final class WebPreviewCheck {
    private static String asset(Context context, String name) throws Exception {
        try (InputStream stream = context.getAssets().open(name); Scanner input = new Scanner(stream, "UTF-8")) {
            return input.useDelimiter("\\A").next();
        }
    }

    private static WebView findWebView(View view) {
        if (view instanceof WebView) return (WebView) view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                WebView found = findWebView(group.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    static void run(Instrumentation test) throws Exception {
        Context app = test.getTargetContext();
        String code = asset(test.getContext(),"web-fixture.html");
        Intent launch = new Intent().setClassName(app.getPackageName(),"app.svyazka.mobile.MainActivity")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Activity host = test.startActivitySync(launch);
        Handler main = new Handler(Looper.getMainLooper());
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Dialog> surface = new AtomicReference<>();
        AtomicReference<Throwable> error = new AtomicReference<>();
        AtomicReference<String> stage = new AtomicReference<>("creating view");
        test.runOnMainSync(() -> {
            try {
                // Exercise the actual preview window, not an independently attached WebView.
                Dialog dialog = WebWorkspaceKt.openWebPreviewDialog(host, code, () -> kotlin.Unit.INSTANCE);
                surface.set(dialog);
                WebView web = findWebView(dialog.getWindow().getDecorView());
                if (web == null) throw new AssertionError("No WebView in preview window");
                stage.set("native preview opened");
                main.post(new Runnable() {
                    @Override public void run() {
                        if (done.getCount()==0) return;
                        if (!dialog.isShowing() || !web.isShown() || web.getWidth() <= 0 || web.getHeight() <= 0) {
                            main.postDelayed(this,250);
                            return;
                        }
                        stage.set("visible preview waiting for isolated frame");
                        web.evaluateJavascript("if(!window.watching){window.watching=true;addEventListener('message',e=>{if(e.source===document.querySelector('iframe')?.contentWindow)window.fixtureResult=e.data})};window.fixtureResult || null", value -> {
                            if (value == null || "null".equals(value)) { main.postDelayed(this,250); return; }
                            try {
                                if (!"tick / isolated / offline".equals(new JSONTokener(value).nextValue()))
                                    throw new AssertionError(value);
                            } catch (Throwable failure) { error.set(failure); }
                            done.countDown();
                        });
                    }
                });
            } catch (Throwable failure) { error.set(failure); done.countDown(); }
        });
        try {
            if (!done.await(100, TimeUnit.SECONDS))
                throw new AssertionError("WebView timeout at " + stage.get());
            if (error.get()!=null) throw new AssertionError(error.get());
        } finally {
            done.countDown();
            test.runOnMainSync(() -> {
                Dialog dialog = surface.get();
                if (dialog != null && dialog.isShowing()) dialog.dismiss();
                host.finish();
            });
        }
    }
}
