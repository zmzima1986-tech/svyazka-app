package app.svyazka.mobile;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Local history. Secrets and role settings never enter this database. */
final class TaskRepository extends SQLiteOpenHelper {
    private static final String DATABASE = "svyazka_tasks.db";
    private static final int SCHEMA = 2;
    static final String ACTIVE_ID = "current_task_id";
    private static final String MIGRATED = "legacy_v042_imported";
    private static final String ACTIVE_META = "active_task_id";

    static final class Entry {
        final long id;
        final String title;
        final String task;
        final String runJson;
        final String attemptLog;
        final boolean resultsVisible;
        final long createdAt;
        final long updatedAt;
        final int versions;
        final boolean pinned;

        Entry(long id, String title, String task, String runJson, String attemptLog,
              boolean resultsVisible, long createdAt, long updatedAt, int versions, boolean pinned) {
            this.pinned = pinned;
            this.id = id;
            this.title = title;
            this.task = task;
            this.runJson = runJson;
            this.attemptLog = attemptLog;
            this.resultsVisible = resultsVisible;
            this.createdAt = createdAt;
            this.updatedAt = updatedAt;
            this.versions = versions;
        }
    }

    static final class Version {
        final long id;
        final int number;
        final String runJson;
        final long createdAt;
        Version(long id, int number, String runJson, long createdAt) {
            this.id = id;
            this.number = number;
            this.runJson = runJson;
            this.createdAt = createdAt;
        }
    }

    TaskRepository(Context context) {
        super(context.getApplicationContext(), DATABASE, null, SCHEMA);
    }

    @Override public void onConfigure(SQLiteDatabase database) {
        super.onConfigure(database);
        database.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase database) {
        database.execSQL("CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "title TEXT NOT NULL, task TEXT NOT NULL DEFAULT '', "
                + "run_json TEXT NOT NULL DEFAULT '', attempt_log TEXT NOT NULL DEFAULT '', "
                + "results_visible INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, "
                + "updated_at INTEGER NOT NULL, custom_title TEXT, pinned INTEGER NOT NULL DEFAULT 0)");
        database.execSQL("CREATE TABLE versions (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE, "
                + "version_no INTEGER NOT NULL, run_json TEXT NOT NULL, created_at INTEGER NOT NULL, "
                + "UNIQUE(task_id, version_no))");
        database.execSQL("CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
        database.execSQL("CREATE INDEX tasks_recent ON tasks(updated_at DESC)");
    }

    @Override public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        if (oldVersion == 1 && newVersion == 2) {
            database.execSQL("ALTER TABLE tasks ADD COLUMN custom_title TEXT");
            database.execSQL("ALTER TABLE tasks ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0");
            return;
        }
        throw new IllegalStateException("Неизвестная версия базы " + oldVersion);
    }

    /** Import the old active workspace once, atomically with the migration marker. */
    synchronized void migrateLegacy(SharedPreferences legacy) {
        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        try {
            if (!hasMigrationMarker(database)) {
                String task = legacy.getString(WorkspaceStore.TASK, "");
                String run = legacy.getString(WorkspaceStore.RUN, "");
                String history = legacy.getString(WorkspaceStore.HISTORY, "");
                if (!task.isEmpty() || !run.isEmpty() || !history.isEmpty()) {
                    long id = insert(database, task, run, history,
                            legacy.getBoolean(WorkspaceStore.RESULTS, false));
                    // Stored in DB as well: a process killed between the DB commit and
                    // SharedPreferences.commit cannot import the same workspace twice.
                    ContentValues active = new ContentValues();
                    active.put("key", "legacy_task_id");
                    active.put("value", String.valueOf(id));
                    database.insertOrThrow("metadata", null, active);
                    ContentValues current = new ContentValues();
                    current.put("key", ACTIVE_META);
                    current.put("value", String.valueOf(id));
                    database.insertOrThrow("metadata", null, current);
                }
                ContentValues mark = new ContentValues();
                mark.put("key", MIGRATED);
                mark.put("value", "1");
                database.insertOrThrow("metadata", null, mark);
            }
            database.setTransactionSuccessful();
        } finally {
            database.endTransaction();
        }
    }

    private boolean hasMigrationMarker(SQLiteDatabase database) {
        try (Cursor cursor = database.rawQuery("SELECT 1 FROM metadata WHERE key=?", new String[] {MIGRATED})) {
            return cursor.moveToFirst();
        }
    }

    synchronized long legacyId() {
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT value FROM metadata WHERE key='legacy_task_id'", null)) {
            return cursor.moveToFirst() ? Long.parseLong(cursor.getString(0)) : 0;
        }
    }

    synchronized long activeId() {
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT value FROM metadata WHERE key=?", new String[] {ACTIVE_META})) {
            return cursor.moveToFirst() ? Long.parseLong(cursor.getString(0)) : 0;
        }
    }

    synchronized void select(long id) {
        if (load(id) == null) throw new IllegalArgumentException("Неизвестная задача");
        ContentValues row = new ContentValues();
        row.put("key", ACTIVE_META);
        row.put("value", String.valueOf(id));
        getWritableDatabase().insertWithOnConflict("metadata", null, row,
                SQLiteDatabase.CONFLICT_REPLACE);
    }

    synchronized long create(String task) {
        return insert(getWritableDatabase(), task, "", "", false);
    }

    private static long insert(SQLiteDatabase database, String task, String run, String history, boolean visible) {
        long now = System.currentTimeMillis();
        ContentValues row = new ContentValues();
        row.put("title", TaskHistory.title(task));
        row.put("task", task);
        row.put("run_json", run);
        row.put("attempt_log", history);
        row.put("results_visible", visible ? 1 : 0);
        row.put("created_at", now);
        row.put("updated_at", now);
        return database.insertOrThrow("tasks", null, row);
    }

    synchronized Entry load(long id) {
        if (id <= 0) return null;
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id, COALESCE(custom_title, title), task, run_json, attempt_log, results_visible, created_at, updated_at, "
                + "(SELECT COUNT(*) FROM versions WHERE task_id=tasks.id), pinned FROM tasks WHERE id=?",
                new String[] {String.valueOf(id)})) {
            return cursor.moveToFirst() ? entry(cursor) : null;
        }
    }

    synchronized List<Entry> list() {
        List<Entry> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id, COALESCE(custom_title, title), task, run_json, attempt_log, results_visible, created_at, updated_at, "
                + "(SELECT COUNT(*) FROM versions WHERE task_id=tasks.id), pinned FROM tasks "
                + "WHERE task<>'' OR run_json<>'' OR custom_title IS NOT NULL OR pinned<>0 ORDER BY pinned DESC, updated_at DESC, id DESC", null)) {
            while (cursor.moveToNext()) items.add(entry(cursor));
        }
        return items;
    }

    private static Entry entry(Cursor cursor) {
        return new Entry(cursor.getLong(0), cursor.getString(1), cursor.getString(2),
                cursor.getString(3), cursor.getString(4), cursor.getInt(5) != 0,
                cursor.getLong(6), cursor.getLong(7), cursor.getInt(8), cursor.getInt(9) != 0);
    }

    /** Snapshot updates are atomic and tied to the originating task ID. */
    synchronized boolean save(Map<String, Object> changes) {
        Object identifier = changes.get(WorkspaceStore.TASK_ID);
        if (!(identifier instanceof Long)) return false;
        long id = (Long) identifier;
        String draft = value(changes.get(WorkspaceStore.TASK));
        String run = value(changes.get(WorkspaceStore.RUN));
        String journal = value(changes.get(WorkspaceStore.HISTORY));
        ContentValues values = new ContentValues();
        values.put("task", draft);
        values.put("run_json", run);
        values.put("attempt_log", journal);
        values.put("results_visible", Boolean.TRUE.equals(changes.get(WorkspaceStore.RESULTS)) ? 1 : 0);
        values.put("updated_at", System.currentTimeMillis());
        Entry existing = load(id);
        if (existing == null) return false;
        if (existing.task.trim().isEmpty() && !draft.trim().isEmpty()) {
            values.put("title", TaskHistory.title(draft));
        }
        return getWritableDatabase().update("tasks", values, "id=?",
                new String[] {String.valueOf(id)}) == 1;
    }

    private static String value(Object item) { return item == null ? "" : item.toString(); }

    /** Store a completed or interrupted previous cycle before starting the next one. */
    synchronized boolean preserveVersion(long taskId, String runJson) {
        if (runJson == null || runJson.isEmpty()) return false;
        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        try {
            int next = 1;
            try (Cursor cursor = database.rawQuery(
                    "SELECT COALESCE(MAX(version_no),0)+1 FROM versions WHERE task_id=?",
                    new String[] {String.valueOf(taskId)})) {
                if (cursor.moveToFirst()) next = cursor.getInt(0);
            }
            ContentValues row = new ContentValues();
            row.put("task_id", taskId);
            row.put("version_no", next);
            row.put("run_json", runJson);
            row.put("created_at", System.currentTimeMillis());
            database.insertOrThrow("versions", null, row);
            database.setTransactionSuccessful();
            return true;
        } finally {
            database.endTransaction();
        }
    }

    synchronized List<Version> versions(long taskId) {
        List<Version> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id,version_no,run_json,created_at FROM versions WHERE task_id=? ORDER BY version_no DESC",
                new String[] {String.valueOf(taskId)})) {
            while (cursor.moveToNext()) {
                items.add(new Version(cursor.getLong(0), cursor.getInt(1), cursor.getString(2), cursor.getLong(3)));
            }
        }
        return items;
    }

    synchronized boolean rename(long id, String name) {
        String title = name.trim();
        if (title.isEmpty() || title.length() > 100) return false;
        ContentValues values = new ContentValues();
        values.put("custom_title", title);
        return getWritableDatabase().update("tasks", values, "id=?", new String[]{String.valueOf(id)}) == 1;
    }

    synchronized boolean pin(long id, boolean pinned) {
        ContentValues values = new ContentValues();
        values.put("pinned", pinned ? 1 : 0);
        return getWritableDatabase().update("tasks", values, "id=?", new String[]{String.valueOf(id)}) == 1;
    }

    synchronized boolean delete(long taskId) {
        return getWritableDatabase().delete("tasks", "id=?", new String[] {String.valueOf(taskId)}) == 1;
    }
}
