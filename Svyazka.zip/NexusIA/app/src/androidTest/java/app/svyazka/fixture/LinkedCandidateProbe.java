package app.svyazka.fixture;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import app.svyazka.mobile.MainActivity;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONObject;

/** Replay model deliveries at the final-verification boundary. No model API,
 * recorded verification or production test bypass. Uses the real Activity,
 * linked repository, WebView/Pyodide and automatic installation decision. */
final class LinkedCandidateProbe {
    private LinkedCandidateProbe() { }
    private interface Checked { void run() throws Exception; }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void main(Instrumentation test, Checked action) {
        AtomicReference<Throwable> failure = new AtomicReference<>();
        test.runOnMainSync(() -> {
            try { action.run(); } catch (Throwable problem) { failure.set(problem); }
        });
        if (failure.get() != null) throw new AssertionError("Linked candidate probe", failure.get());
    }

    private static Field field(Class<?> owner, String name) throws Exception {
        Field value = owner.getDeclaredField(name);
        value.setAccessible(true);
        return value;
    }

    private static Method method(Class<?> owner, String name, Class<?>... types) throws Exception {
        Method value = owner.getDeclaredMethod(name, types);
        value.setAccessible(true);
        return value;
    }

    private static void unchanged(MainActivity activity, JSONObject files, long linked) throws Exception {
        check(activity.nexusChatProjectId() == linked && activity.nexusArtifactId() == linked,
                "Wrong active or linked project");
        check(new HashSet<>(Arrays.asList(activity.nexusPythonPaths())).equals(
                new HashSet<>(Arrays.asList("main.py", "test_main.py"))), "Project file set changed");
        for (String path : activity.nexusPythonPaths()) {
            check(Arrays.equals(activity.nexusPythonBytes(path),
                    files.getString(path).getBytes(StandardCharsets.UTF_8)), "Changed saved file: " + path);
        }
    }

    static void run(Instrumentation test) throws Exception {
        Context app = test.getTargetContext();
        check(app.getSharedPreferences("credentials", Context.MODE_PRIVATE).getAll().isEmpty(),
                "Run only without API keys on disposable emulator");
        JSONObject fixture;
        try (Scanner input = new Scanner(test.getContext().getAssets().open("linked-candidate.json"), "UTF-8")) {
            fixture = new JSONObject(input.useDelimiter("\\A").next());
        }
        JSONObject files = fixture.getJSONObject("working_files");
        MainActivity activity = (MainActivity) test.startActivitySync(new Intent(Intent.ACTION_MAIN)
                .setClass(app, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        test.waitForIdleSync();
        try {
            Field run = field(MainActivity.class, "run");
            Field active = field(MainActivity.class, "active");
            // A blank chat is intentionally reused by nexusCreateTask(). Do not
            // require a different ID if the previous probe already left one.
            AtomicReference<Boolean> blank = new AtomicReference<>(false);
            main(test, () -> blank.set(activity.nexusTaskId() > 0
                    && activity.nexusArtifactId() == 0 && activity.nexusChatProjectId() == 0
                    && run.get(activity) == null && !active.getBoolean(activity)));
            long deadline;
            if (!blank.get()) {
                long old = activity.nexusTaskId();
                main(test, activity::nexusCreateTask);
                deadline = SystemClock.elapsedRealtime() + 12000;
                AtomicReference<Long> id = new AtomicReference<>(old);
                while (SystemClock.elapsedRealtime() < deadline) {
                    main(test, () -> id.set(activity.nexusTaskId()));
                    if (id.get() > 0 && id.get() != old) break;
                    SystemClock.sleep(40);
                }
                check(id.get() > 0 && id.get() != old, "Fresh chat not created");
            }
            main(test, () -> {
                check(activity.nexusArtifactId() == 0, "Fresh chat inherited project");
                for (String path : Arrays.asList("main.py", "test_main.py"))
                    check(activity.nexusPythonPut(path, files.getString(path).getBytes(StandardCharsets.UTF_8)).isEmpty(),
                            "Could not seed " + path);
                activity.nexusAttachArtifactToChat();
                check(activity.nexusChatProjectId() > 0, "Project not linked");
            });
            AtomicReference<Long> linked = new AtomicReference<>();
            main(test, () -> linked.set(activity.nexusChatProjectId()));
            Class<?> runClass = run.getType();
            Method fromJson = method(runClass, "fromJson", JSONObject.class);
            Method toJson = method(runClass, "toJson");
            Method start = method(MainActivity.class, "startVerification", int.class);
            // Both cases use the exact captured task, including its saved-project context.
            for (boolean single : new boolean[]{true, false}) {
                JSONObject replay = new JSONObject(fixture.getJSONObject("run").toString());
                if (single) {
                    replay.getJSONArray("answers").getJSONObject(2).put("text", fixture.getString("single_reply"));
                }
                main(test, () -> {
                    unchanged(activity, files, linked.get());
                    check(!active.getBoolean(activity), "Previous run still active");
                    run.set(activity, fromJson.invoke(null, replay));
                    check(Boolean.TRUE.equals(start.invoke(activity, 2)), "Verification did not start");
                });
                AtomicReference<JSONObject> result = new AtomicReference<>();
                deadline = SystemClock.elapsedRealtime() + 105000;
                while (SystemClock.elapsedRealtime() < deadline) {
                    main(test, () -> {
                        if (!active.getBoolean(activity)) result.set((JSONObject) toJson.invoke(run.get(activity)));
                    });
                    if (result.get() != null) break;
                    SystemClock.sleep(80);
                }
                check(result.get() != null, "Verification timeout");
                check(result.get().getBoolean("complete") && result.get().getInt("final_step") == 3,
                        "Wrong completed replay stage");
                JSONObject report = result.get().getJSONObject("python_verification");
                check(result.get().getJSONArray("repairs").length() == 0 && report.getInt("requests") == 0,
                        "Unexpected repair request");
                check(report.getString("status").equals(single ? "ERROR" : "LIMITED"),
                        "Unexpected verification: " + report);
                check(report.getBoolean("ran") == single, "Unexpected execution status");
                if (single) {
                    check(report.getBoolean("syntax"), "Candidate syntax was not verified");
                    JSONObject history = report.getJSONArray("history").getJSONObject(0);
                    JSONObject execution = history.getJSONObject("project_execution");
                    JSONObject suite = execution.getJSONObject("generated_tests");
                    check(execution.getInt("exit_code") == 1 && suite.getString("status").equals("FAILED")
                            && suite.getInt("discovered") == 3 && suite.getInt("ran") == 3
                            && suite.getInt("passed") == 0 && suite.getInt("failed") == 3
                            && suite.getInt("skipped") == 0, "Expected all three actual tests to fail: " + suite);
                    check(execution.getJSONObject("project_file_sha256").getString("test_main.py")
                            .equals("d1ce8d31fec5e24fb6ab4ec22f38d556d8928e88ae8c0dfaf1b262ceb7dbe5c5"),
                            "Wrong test bytes executed");
                    check(execution.getJSONObject("project_file_sha256").getString("main.py")
                            .equals("dfabcf97c26692ff52f9158cdd4126bca48574cabbf9506dca0454fedb8a35a0"),
                            "Wrong candidate bytes executed");
                } else {
                    JSONObject history = report.getJSONArray("history").getJSONObject(0);
                    check(!history.has("project_execution") || history.isNull("project_execution"),
                            "Unexpected execution evidence for rejected extra file");
                }
                main(test, () -> unchanged(activity, files, linked.get()));
            }
        } finally {
            main(test, activity::finish);
        }
    }
}
