package app.svyazka.mobile;

/** Offline checks: no network, billing API or Android runtime required. */
public final class AutonomyQuotaGuardChecks {
    public static void main(String[] args) {
        long now = 1_800_000_000_000L;
        long recent = now - 5_000L;
        assert AutonomyQuotaGuard.groqExhausted(0, 999, recent, now);
        assert AutonomyQuotaGuard.groqExhausted(7000, 0, recent, now);
        assert AutonomyQuotaGuard.openRouterExhausted(0, recent, now);
        assert !AutonomyQuotaGuard.groqExhausted(-1, -1, recent, now);
        assert !AutonomyQuotaGuard.openRouterExhausted(-1, recent, now);
        assert !AutonomyQuotaGuard.groqExhausted(0, 0, now - 60_000, now);
        assert !AutonomyQuotaGuard.openRouterExhausted(0, now + 1000, now);
        assert !AutonomyQuotaGuard.openRouterExhausted(4, recent, now);
        assert !AutonomyQuotaGuard.groqExhausted(0, 0, 0, now);
        var budget = new AutonomyQuotaGuard.Session(now);
        assert budget.reserve(now, 100_000);
        assert !budget.reserve(now, 80_001);
        assert budget.reserve(now, 80_000);
        assert !budget.reserve(now, 1);
        assert budget.calls == 2 && budget.reservedTokens == 180_000;
        var calls = new AutonomyQuotaGuard.Session(now);
        for (int i=0;i<18;i++) assert calls.reserve(now, 100);
        assert !calls.reserve(now, 100);
        assert !new AutonomyQuotaGuard.Session(now).reserve(now+600_000, 100);
        assert !new AutonomyQuotaGuard.Session(now).reserve(now-1, 100);
        var retry = new AutonomyQuotaGuard.Recovery();
        assert retry.next("A","first") == AutonomyQuotaGuard.Recovery.Action.RETRY;
        assert retry.next("A","second") == AutonomyQuotaGuard.Recovery.Action.RETRY;
        assert retry.next("A","third") == AutonomyQuotaGuard.Recovery.Action.SWITCH;
        assert retry.next("B","third") == AutonomyQuotaGuard.Recovery.Action.STOP;
        var repeat = new AutonomyQuotaGuard.Recovery();
        assert repeat.next("A","same") == AutonomyQuotaGuard.Recovery.Action.RETRY;
        assert repeat.next("A","same") == AutonomyQuotaGuard.Recovery.Action.SWITCH;
        assert repeat.next("B","same") == AutonomyQuotaGuard.Recovery.Action.STOP;
        System.out.println("AutonomyQuotaGuard: 42 assertions passed");
    }
}
