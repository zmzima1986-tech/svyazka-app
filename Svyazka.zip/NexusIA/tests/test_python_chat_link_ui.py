"""Regression contracts for reversible Python-project chat linking.

These checks cover source wiring; Android runtime UI testing remains required.
"""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / "app/src/main/java/app/svyazka/mobile"


class PythonChatLinkUiTests(unittest.TestCase):
    def test_link_does_not_navigate_away(self):
        activity = (JAVA / "MainActivity.java").read_text(encoding="utf-8")
        body = activity.split("public void nexusAttachArtifactToChat() {", 1)[1].split(
            "/** Start a separate chat for this project", 1
        )[0]
        self.assertIn("artifactRepository.attachChat(activeTaskId, activeArtifactId)", body)
        self.assertIn("nexusUi.refreshChatProjectLink();", body)
        self.assertNotIn("nexusRender(", body)
        self.assertNotIn("nexusRender(NexusComposeUi.Page.TASK)", body)
        self.assertIn('toast("Чат подключен к проекту.");', body)

    def test_workspace_button_remains_visible_and_toggles_link(self):
        workspace = (JAVA / "ui/NexusPythonWorkspace.kt").read_text(encoding="utf-8")
        action = workspace.split("// The chat link is a status/action footer", 1)[1].split(
            "AnimatedVisibility(visible = toolPanel != null", 1)[0]
        self.assertIn("ui.linkedProjectId == ui.projectId", action)
        self.assertIn("R.string.artifacts_detach_chat", action)
        self.assertIn("R.string.artifacts_attach_chat", action)
        self.assertIn("ui.activity.nexusDetachArtifactFromChat()", action)
        self.assertIn("ui.activity.nexusAttachArtifactToChat()", action)
        self.assertIn("R.string.ws_chat_linked_status", action)
        self.assertIn("R.string.ws_chat_unlinked_status", action)
        self.assertNotIn("ui.closePanel()", action)

    def test_compose_link_state_is_refreshed_from_database(self):
        compose = (JAVA / "ui/NexusComposeUi.kt").read_text(encoding="utf-8")
        self.assertIn("var linkedProjectId by mutableLongStateOf(activity.nexusChatProjectId())", compose)
        self.assertIn("linkedProjectId = activity.nexusChatProjectId()", compose)
        activity = (JAVA / "MainActivity.java").read_text(encoding="utf-8")
        self.assertIn("public long nexusChatProjectId() { return artifactRepository.forChat(activeTaskId); }", activity)
        self.assertIn("artifactRepository.unlinkChat(activeTaskId);", activity)
        repo = (JAVA / "PythonArtifactRepository.java").read_text(encoding="utf-8")
        self.assertIn('db.insertWithOnConflict("chat_projects", null, row,', repo)
        self.assertIn("SQLiteDatabase.CONFLICT_REPLACE", repo)


if __name__ == "__main__":
    unittest.main()
