"""Checks the editor source that GitHub Actions compiles from this ZIP."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/svyazka/mobile/ui/NexusPythonWorkspace.kt'
GRADLE = ROOT / 'app/build.gradle'

class EditorButtonsReleaseContract(unittest.TestCase):
    def test_one_clear_button_and_no_undo_redo(self):
        code = UI.read_text(encoding='utf-8')
        self.assertIn('Text(stringResource(R.string.editor_clear),', code)
        self.assertNotIn('Text(stringResource(R.string.ws_undo))', code)
        self.assertNotIn('Text(stringResource(R.string.ws_redo))', code)
        self.assertNotIn('Text(stringResource(R.string.action_save_file))', code)

    def test_save_stays_single_line(self):
        code = UI.read_text(encoding='utf-8')
        self.assertIn('Text(stringResource(R.string.action_save),', code)
        self.assertIn('maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)', code)
        self.assertIn('modifier = Modifier.weight(1f)', code)

    def test_search_does_not_expand_by_default(self):
        code = UI.read_text(encoding='utf-8')
        self.assertIn('var showSearchTools by remember(ui.pythonFileName) { mutableStateOf(false) }', code)
        self.assertIn('if (showSearchTools)', code)
        self.assertIn('minLines = 5, maxLines = 8', code)

    def test_gradle_refuses_old_editor(self):
        gradle = GRADLE.read_text(encoding='utf-8')
        self.assertIn('verifyPythonEditorButtons', gradle)
        self.assertIn("tasks.named('preBuild')", gradle)
        self.assertIn('WRONG PYTHON EDITOR:', gradle)

if __name__ == '__main__':
    unittest.main()
