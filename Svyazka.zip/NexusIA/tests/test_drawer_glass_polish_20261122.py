"""Contracts for the 2026-11-22 minimal glass and drawer refinements.

These are source checks; they do not replace a running Android Compose screenshot test.
"""
from pathlib import Path
import unittest

UI = Path(__file__).resolve().parents[1] / 'app/src/main/java/app/svyazka/mobile/ui'


class DrawerGlassPolishTests(unittest.TestCase):
    def test_workspace_has_no_duplicate_message_composer(self):
        source = (UI / 'NexusDrawers.kt').read_text()
        workspace = source.split('private fun ColumnScope.RightWorkspace', 1)[1]
        workspace = workspace.split('@Composable\nprivate fun NexusLightTabDivider', 1)[0]
        self.assertNotIn('NexusLightWorkspaceComposer(ui)', workspace)
        self.assertNotIn('NexusDarkWorkspaceComposer(ui)', workspace)
        self.assertIn('NexusPythonWorkspace(ui)', workspace)
        self.assertIn('WorkspaceFiles(ui)', workspace)
        self.assertIn('WorkspaceLogs(ui)', workspace)

    def test_main_chat_composer_only_drawn_without_drawer(self):
        source = (UI / 'NexusChat.kt').read_text()
        self.assertIn('if (ui.panel == NexusComposeUi.Panel.NONE) {', source)
        self.assertIn('.clickable(enabled = canSend, onClick = { ui.submitChat() })', source)
        self.assertIn('ui.chatTextChanged(it)', source)

    def test_light_glass_matches_left_drawer(self):
        design = (UI / 'NexusLightDesign.kt').read_text()
        frosted = (UI / 'NexusFrosted.kt').read_text()
        self.assertIn('val glass = Color.White.copy(alpha = .88f)', design)
        self.assertIn('Color.White.copy(alpha = .88f)', frosted)
        self.assertIn('lightBackground = NexusLightDesign.glass', (UI / 'NexusDrawers.kt').read_text())

    def test_dark_drawer_has_no_exterior_border(self):
        source = (UI / 'NexusDrawers.kt').read_text()
        self.assertIn('showBorder = nexusLightMode()', source)
        self.assertIn('else RoundedCornerShape(0.dp)', source)
        self.assertNotIn('Box(Modifier.fillMaxSize().background(Color.Black))', source)
        self.assertIn('FrostedDrawer { LeftTools(ui) }', source)

    def test_light_settings_controls_use_single_frosted_fill(self):
        source = (UI / 'NexusLightSettings.kt').read_text()
        self.assertNotIn('Surface(onClick = { languageOpen = true }', source)
        self.assertNotIn('Surface(onClick = onClick, modifier = modifier.heightIn', source)
        self.assertIn('.clickable(role = Role.Button) { languageOpen = true }', source)
        self.assertIn('.clickable(role = Role.Button, onClick = onClick)', source)
        self.assertIn('ui.activity.nexusLanguageChanged(key)', source)
        self.assertIn('ui.activity.nexusThemeChanged(key)', source)


if __name__ == '__main__':
    unittest.main()
