package app.svyazka.mobile;

import java.io.*;
import java.util.Arrays;

/**
 * Replace only the known memory declaration of the bundled module. Fail closed after incompatible
 * upgrades.
 */
final class VerificationMemory {
    static final int MAX_PAGES = 1536;

    private VerificationMemory() {}

    static InputStream limit(InputStream source) throws IOException {
        DataInputStream in = new DataInputStream(source);
        try {
            ByteArrayOutputStream prefix = new ByteArrayOutputStream();
            byte[] header = new byte[8];
            in.readFully(header);
            if (!Arrays.equals(header, new byte[] {0, 97, 115, 109, 1, 0, 0, 0}))
                throw new IOException("Unknown Wasm header");
            prefix.write(header);
            while (prefix.size() < 1_048_576) {
                int section = in.readUnsignedByte();
                prefix.write(section);
                int length = 0;
                ByteArrayOutputStream encoded = new ByteArrayOutputStream();
                for (int shift = 0; ; shift += 7) {
                    if (shift > 21) throw new IOException("Invalid section size");
                    int b = in.readUnsignedByte();
                    encoded.write(b);
                    length |= (b & 127) << shift;
                    if ((b & 128) == 0) break;
                }
                if (section > 5 || length < 0 || length > 1_048_576 - prefix.size())
                    throw new IOException("Unexpected Wasm layout");
                byte[] data = new byte[length];
                in.readFully(data);
                if (section == 5) {
                    byte[] known = {1, 1, (byte) 0xe0, 3, (byte) 0x80, (byte) 0x80, 4};
                    if (!Arrays.equals(data, known))
                        throw new IOException("Unknown Wasm memory layout");
                    byte[] capped = {
                        1,
                        1,
                        (byte) 0xe0,
                        3,
                        (byte) (128 | (MAX_PAGES & 127)),
                        (byte) (MAX_PAGES >> 7)
                    };
                    prefix.write(capped.length);
                    prefix.write(capped);
                    return new SequenceInputStream(
                            new ByteArrayInputStream(prefix.toByteArray()), in);
                }
                encoded.writeTo(prefix);
                prefix.write(data);
            }
            throw new IOException("Missing Wasm memory");
        } catch (IOException e) {
            in.close();
            throw e;
        }
    }
}
