package app.svyazka.mobile;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/** Bounded parallel calls, no waiting queue behind disconnected or blocked connections. */
final class RequestExecutor {
    static final int MAX_PARALLEL = 8;

    private RequestExecutor() { }

    static ExecutorService create() {
        return new ThreadPoolExecutor(0, MAX_PARALLEL, 30L, TimeUnit.SECONDS,
                new SynchronousQueue<>(), new ThreadPoolExecutor.AbortPolicy());
    }
}
