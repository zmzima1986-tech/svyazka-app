"""Wiring contracts for stage 2. Android runtime must still be tested on device."""
import unittest
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ACTIVITY = ROOT / 'app/src/main/java/app/svyazka/mobile/MainActivity.java'
AUTO = ROOT / 'app/src/main/java/app/svyazka/mobile/PythonAutoStage.java'


class AutomaticPythonStage2Contracts(unittest.TestCase):
    def test_auto_execution_only_after_durable_save(self):
        code = ACTIVITY.read_text()
        stage = code.split('private AutoPythonLaunch autoStageChatPython() {', 1)[1].split(
            'private void finishRunUi()', 1)[0]
        self.assertLess(stage.index('replaceTextWithBackup(linked'), stage.index('snapshot(linked)'))
        self.assertLess(stage.index('artifactRepository.touch(linked'), stage.index('snapshot(linked)'))
        self.assertIn('PythonAutoStage.select(userMessage,', stage)
        self.assertIn('PythonAutoStage.runAllowed(userMessage)', stage)
        self.assertIn('PythonAutoStage.launchEntry(selected.path, paths)', stage)
        self.assertIn('SandboxClient.validate(code, "")', stage)

    def test_no_fake_execution_or_automatic_ai_retries(self):
        code = ACTIVITY.read_text()
        finish = code.split('private void finishRunUi() {', 1)[1].split(
            'private boolean startVerification(', 1)[0]
        self.assertIn('runSandbox(run, launch.step, launch.code', finish)
        self.assertIn('launch.files, launch.entry, "", false, true', finish)
        self.assertNotIn('requestNextModel(', finish)
        self.assertNotIn('addRepair(', finish)
        self.assertIn('job.local.executeProject(code, stdin, projectFiles, entryFile, allowedPackage, extended)', code)
        self.assertIn('nexusUi.pythonFinished(new NexusPythonReport(output.engine, output.stdout', code)

    def test_old_report_is_invalidated_before_new_execution(self):
        code = ACTIVITY.read_text()
        helper = code.split('private void invalidatePythonReport(long id) {', 1)[1].split(
            'private void savedPythonArtifact(', 1)[0]
        self.assertIn('pythonReportEpoch.put(id,', helper)
        self.assertIn('new PythonLastRunStore(this, true).deleteTask(id)', helper)
        stage = code.split('private AutoPythonLaunch autoStageChatPython() {', 1)[1].split(
            'private void finishRunUi()', 1)[0]
        self.assertLess(stage.index('invalidatePythonReport(linked)'), stage.index('snapshot(linked)'))
        self.assertIn('invalidatePythonReport(artifactRepository.forChat(activeTaskId))', code)
        self.assertIn('saved.snapshotSha256.equals(PythonProjectStore.snapshotSha256(', code)
        self.assertIn('pythonReportEpoch.getOrDefault(resultProject, 0) == reportEpoch', code)
        self.assertIn('nexusUi.dismissPythonResult()', code)

    def test_running_local_without_piston(self):
        code = ACTIVITY.read_text()
        finish = code.split('private void finishRunUi() {', 1)[1].split(
            'private boolean startVerification(', 1)[0]
        self.assertIn('launch.code, "", "", false', finish)
        self.assertIn('launch.entry, "", false, true', finish)

    def test_all_five_languages_have_strings(self):
        keys = {'python_auto_saved', 'python_auto_running',
                'python_auto_run_success', 'python_auto_run_error'}
        for lang in ('values', 'values-en', 'values-ar', 'values-zh-rCN', 'values-ja'):
            with self.subTest(lang=lang):
                root = ET.parse(ROOT / 'app/src/main/res' / lang / 'strings.xml').getroot()
                present = {s.attrib['name'] for s in root.findall('string')}
                self.assertTrue(keys <= present)

    def test_python_auto_has_entry_resolution_and_opt_out(self):
        code = AUTO.read_text()
        self.assertIn('static boolean runAllowed(', code)
        self.assertIn('static String launchEntry(', code)
        self.assertIn('return count == 1 ? editedPath : "";', code)


if __name__ == '__main__':
    unittest.main()
