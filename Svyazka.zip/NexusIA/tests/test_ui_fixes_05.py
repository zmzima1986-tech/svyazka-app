"""Static guards for three Android UI regressions found during phone testing.

These checks verify source contracts only; final layout/touch testing needs an APK.
"""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/svyazka/mobile/ui'
RES = ROOT / 'app/src/main/res'


class UiFixes05Tests(unittest.TestCase):
    def test_visual_preview_has_android_navbar_clearance(self):
        source = (UI / 'NexusVisual.kt').read_text(encoding='utf-8')
        self.assertIn('Column(Modifier.fillMaxSize().navigationBarsPadding()', source)
        self.assertIn('top = 16.dp, bottom = 32.dp', source)
        self.assertIn('Button(onClick = { ui.closeVisual() }', source)

    def test_first_add_provides_feedback_and_second_action_is_explicit_replace(self):
        source = (UI / 'NexusPythonProjectFiles.kt').read_text(encoding='utf-8')
        self.assertIn('fun saveToProject(artifact: Artifact)', source)
        self.assertIn('ui.projectChanged(result)', source)
        self.assertIn('projectSaveFeedback = if (result.isBlank())', source)
        self.assertIn('Toast.makeText(context, projectSaveFeedback, Toast.LENGTH_SHORT).show()', source)
        self.assertIn('if (alreadyInProject) confirmReplace = artifact', source)
        self.assertIn('else saveToProject(artifact)', source)
        self.assertIn('if (alreadyInProject) app.svyazka.mobile.R.string.ws_replace', source)
        self.assertIn('saveToProject(artifact)', source.split('confirmReplace?.let { artifact ->')[1])

    def test_success_diagnostics_are_collapsed_not_dropped(self):
        source = (UI / 'NexusPythonWorkspace.kt').read_text(encoding='utf-8')
        self.assertIn('var showRunDiagnostics by rememberSaveable(report)', source)
        self.assertIn('if (success) {', source)
        self.assertIn('TextButton(onClick = { showRunDiagnostics = !showRunDiagnostics }', source)
        self.assertIn('if (!success || showRunDiagnostics)', source)
        self.assertIn('Text(report.stderr, maxLines = if (success) 20 else 6', source)
        self.assertIn('R.string.ws_show_run_diagnostics', source)

    def test_new_strings_exist_in_every_supported_locale(self):
        expected = {'ws_artifact_project_saved', 'ws_show_run_diagnostics', 'ws_hide_run_diagnostics'}
        for name in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            tree = ET.parse(RES / name / 'python_workbench.xml')
            strings = {s.attrib['name']: s.text for s in tree.getroot() if s.tag == 'string'}
            self.assertTrue(expected <= strings.keys(), name)
            self.assertIn('%1$s', strings['ws_artifact_project_saved'])
            self.assertTrue(all(strings[k] for k in expected))


if __name__ == '__main__':
    unittest.main()
