package app.svyazka.mobile.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.rememberTextMeasurer
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.PythonVerification
import app.svyazka.mobile.R

/** Both translucent drawers slide from their own sides and dismiss with an inward swipe. */
@Composable
fun NexusSidePanels(ui: NexusComposeUi) {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val open = ui.panel != NexusComposeUi.Panel.NONE
    val density = LocalDensity.current
    // Touching content does not close a drawer. Swipe it toward the outside edge instead.
    val leftDismissDirection = if (rtl) 1f else -1f
    val rightDismissDirection = -leftDismissDirection
    var leftDrag by remember { mutableFloatStateOf(0f) }
    var rightDrag by remember { mutableFloatStateOf(0f) }
    // Retain the finger position until the exit transition completes (no visual jump).
    LaunchedEffect(ui.panel) {
        delay(300)
        if (ui.panel != NexusComposeUi.Panel.LEFT) leftDrag = 0f
        if (ui.panel != NexusComposeUi.Panel.RIGHT) rightDrag = 0f
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val leftWidth = minOf(344.dp, maxWidth - 12.dp)
        val rightWidth = minOf(420.dp, maxWidth - 12.dp)
        val leftThreshold = with(density) { leftWidth.toPx() * .23f }
        val rightThreshold = with(density) { rightWidth.toPx() * .23f }

        AnimatedVisibility(open, enter = fadeIn(tween(200)), exit = fadeOut(tween(180))) {
            Box(Modifier.fillMaxSize()
                .background(Color.Black.copy(alpha = .52f))
                .clickable(onClick = { ui.closePanel() }))
        }
        AnimatedVisibility(visible = ui.panel == NexusComposeUi.Panel.LEFT,
            modifier = Modifier.align(Alignment.CenterStart).width(leftWidth).fillMaxHeight()
                .offset { IntOffset(leftDrag.roundToInt(), 0) }
                .pointerInput(rtl, leftThreshold) {
                    detectHorizontalDragGestures(
                        onDragStart = { leftDrag = 0f },
                        onDragCancel = { leftDrag = 0f },
                        onDragEnd = {
                            if (leftDrag * leftDismissDirection >= leftThreshold) ui.closePanel()
                            else leftDrag = 0f
                        },
                        onHorizontalDrag = { change, amount ->
                            val next = (leftDrag + amount) * leftDismissDirection
                            if (next >= 0f) {
                                leftDrag = (next.coerceAtMost(size.width.toFloat())) * leftDismissDirection
                                change.consume()
                            }
                        }
                    )
                },
            enter = slideInHorizontally(tween(260)) { if (rtl) it else -it } + fadeIn(tween(170)),
            exit = slideOutHorizontally(tween(240)) { if (rtl) it else -it } + fadeOut(tween(170))) {
            FrostedDrawer { LeftTools(ui) }
        }
        AnimatedVisibility(visible = ui.panel == NexusComposeUi.Panel.RIGHT,
            modifier = Modifier.align(Alignment.CenterEnd).width(rightWidth).fillMaxHeight()
                .offset { IntOffset(rightDrag.roundToInt(), 0) }
                .then(if (ui.pythonToolsOpen) Modifier else Modifier.pointerInput(rtl, rightThreshold) {
                    detectHorizontalDragGestures(
                        onDragStart = { rightDrag = 0f },
                        onDragCancel = { rightDrag = 0f },
                        onDragEnd = {
                            if (rightDrag * rightDismissDirection >= rightThreshold) ui.closePanel()
                            else rightDrag = 0f
                        },
                        onHorizontalDrag = { change, amount ->
                            val next = (rightDrag + amount) * rightDismissDirection
                            if (next >= 0f) {
                                rightDrag = (next.coerceAtMost(size.width.toFloat())) * rightDismissDirection
                                change.consume()
                            }
                        }
                    )
                }),
            enter = slideInHorizontally(tween(260)) { if (rtl) -it else it } + fadeIn(tween(170)),
            exit = slideOutHorizontally(tween(240)) { if (rtl) -it else it } + fadeOut(tween(170))) {
            NexusFrostedPanel(
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(topStart = 26.dp, bottomStart = 26.dp)
            ) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)) {
                    RightWorkspace(ui)
                }
            }
        }
    }
}

/** Translucent high-contrast frosted surface; avoids costly background blur on older devices. */
@Composable
private fun FrostedDrawer(content: @Composable ColumnScope.() -> Unit) {
    NexusFrostedPanel(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp), content = content)
    }
}

@Composable
private fun ColumnScope.LeftTools(ui: NexusComposeUi) {
    Row(Modifier.fillMaxWidth().padding(bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        NexusBrandMark(Modifier.size(32.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.ui_brand_subtitle),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall)
        }
        IconButton(onClick = { ui.closePanel() }) {
            Icon(Icons.Outlined.Close, stringResource(R.string.action_close))
        }
    }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(3.dp)) {
        LeftTool(Icons.Outlined.AddComment, stringResource(R.string.ui_new_chat), true) {
            ui.closePanel(); ui.requestNewTask()
        }
        val groups = listOf(R.string.chat_pinned to ui.snapshot.tasks.filter { it.pinned },
            R.string.chat_recent to ui.snapshot.tasks.filterNot { it.pinned }.take(8))
        groups.forEach { (heading, tasks) ->
            if (tasks.isNotEmpty()) {
                NexusLabel(stringResource(heading))
                tasks.forEach { task -> key(task.id) { DrawerChat(ui, task) } }
            }
        }
        LeftTool(Icons.Outlined.History, stringResource(R.string.nav_history)) {
            ui.closePanel(); ui.activity.nexusOpenHistory()
        }
        LeftTool(Icons.Outlined.FolderOpen, stringResource(R.string.artifacts_title)) {
            ui.closePanel(); ui.activity.nexusOpenArtifacts()
        }
        LeftTool(Icons.Outlined.Layers, stringResource(R.string.models_title)) {
            ui.selectPage(NexusComposeUi.Page.MODELS)
        }
        LeftTool(Icons.Outlined.Groups, stringResource(R.string.ui_team)) {
            ui.closePanel(); ui.teamSettingsRequested = true
        }
        LeftTool(Icons.Outlined.AttachFile, stringResource(R.string.ui_attachments)) {
            ui.workspaceFilesView = NexusComposeUi.WorkspaceFilesView.ATTACHMENTS
            ui.workspaceTab = NexusComposeUi.WorkspaceTab.FILES; ui.openRight()
        }
        LeftTool(Icons.Outlined.Code, stringResource(R.string.ui_python_code)) {
            ui.workspaceTab = NexusComposeUi.WorkspaceTab.PYTHON; ui.openRight()
        }
        HorizontalDivider(Modifier.padding(vertical = 9.dp))
        LeftTool(Icons.Outlined.Settings, stringResource(R.string.settings_title)) {
            ui.selectPage(NexusComposeUi.Page.SETTINGS)
        }
        LeftTool(Icons.Outlined.Key, stringResource(R.string.models_settings)) {
            ui.selectPage(NexusComposeUi.Page.SETTINGS); ui.requestKeys()
        }
        LeftTool(Icons.Outlined.Info, stringResource(R.string.settings_about)) {
            ui.selectPage(NexusComposeUi.Page.SETTINGS)
        }
    }
    HorizontalDivider()
    Row(Modifier.padding(top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        NexusBrandMark(Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.labelLarge)
            Text(stringResource(R.string.settings_version),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DrawerChat(ui: NexusComposeUi, task: app.svyazka.mobile.NexusState.Task) {
    var showMenu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var name by remember(task.title) { mutableStateOf(task.title) }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
        .background(if (task.selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
        .combinedClickable(onClick = { ui.closePanel(); ui.activity.nexusOpenTask(task.id) },
            onLongClick = { showMenu = true }).padding(start = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(task.title, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            if (task.preview.isNotBlank() && task.preview != task.title)
                Text(task.preview, maxLines = 1, style = MaterialTheme.typography.bodySmall,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
        Box {
            IconButton(onClick = { showMenu = true }) { Icon(Icons.Outlined.MoreVert, stringResource(R.string.chat_options)) }
            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }, containerColor = nexusFrostedColor()) {
                DropdownMenuItem(text = { Text(stringResource(R.string.chat_rename)) },
                    onClick = { showMenu = false; name = task.title; rename = true })
                DropdownMenuItem(text = { Text(stringResource(if (task.pinned) R.string.chat_unpin else R.string.chat_pin)) },
                    onClick = { showMenu = false; ui.activity.nexusPinTask(task.id, !task.pinned) })
                DropdownMenuItem(text = { Text(stringResource(R.string.action_delete)) }, enabled = !ui.snapshot.active,
                    onClick = { showMenu = false; ui.deleteTarget = task.id })
            }
        }
    }
    if (rename) NexusFrostedAlertDialog(onDismissRequest = { rename = false }, title = { Text(stringResource(R.string.chat_rename)) },
        text = { OutlinedTextField(name, { if (it.length <= 100) name = it }, singleLine = true) },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = {
            ui.activity.nexusRenameTask(task.id, name); rename = false
        }) { Text(stringResource(R.string.action_save)) } },
        dismissButton = { TextButton(onClick = { rename = false }) { Text(stringResource(R.string.action_cancel)) } })
}

@Composable
private fun LeftTool(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String,
                     highlighted: Boolean = false, action: () -> Unit) {
    val tint = if (highlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
        .clickable(role = Role.Button, onClick = action)
        .heightIn(min = 44.dp).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(23.dp))
        Spacer(Modifier.width(11.dp))
        Text(label, maxLines = 1, softWrap = false, style = MaterialTheme.typography.bodyMedium, color = tint)
    }
}

@Composable
private fun ColumnScope.RightWorkspace(ui: NexusComposeUi) {
    Row(Modifier.fillMaxWidth().padding(bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        NexusGlyph(R.drawable.ic_nia_work, null, Modifier.size(22.dp))
        Spacer(Modifier.width(9.dp))
        Text(stringResource(R.string.ui_workspace), style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.weight(1f))
        IconButton(onClick = { ui.closePanel() }) {
            Icon(Icons.Outlined.Close, stringResource(R.string.action_close))
        }
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = Color.White.copy(alpha = .04f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .32f))
    ) {
        Row(Modifier.fillMaxWidth().padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            WorkspaceTab(ui, NexusComposeUi.WorkspaceTab.PYTHON, stringResource(R.string.ui_python), Icons.Outlined.Terminal, Modifier.weight(1f))
            WorkspaceTab(ui, NexusComposeUi.WorkspaceTab.CODE, stringResource(R.string.ui_code), Icons.Outlined.Code, Modifier.weight(1f))
            WorkspaceTab(ui, NexusComposeUi.WorkspaceTab.LOGS, stringResource(R.string.ui_logs), Icons.Outlined.Description, Modifier.weight(1f))
            WorkspaceTab(ui, NexusComposeUi.WorkspaceTab.FILES, stringResource(R.string.ui_files), Icons.Outlined.Folder, Modifier.weight(1f))
        }
    }
    Spacer(Modifier.height(8.dp))
    Box(Modifier.fillMaxWidth().weight(1f)) {
        when (ui.workspaceTab) {
            NexusComposeUi.WorkspaceTab.PYTHON -> NexusPythonWorkspace(ui)
            NexusComposeUi.WorkspaceTab.CODE -> WebWorkspace(ui)
            NexusComposeUi.WorkspaceTab.LOGS -> WorkspaceLogs(ui)
            NexusComposeUi.WorkspaceTab.FILES -> WorkspaceFiles(ui)
        }
    }
}

@Composable
private fun WorkspaceTab(ui: NexusComposeUi, tab: NexusComposeUi.WorkspaceTab,
                         label: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                         modifier: Modifier = Modifier) {
    val selected = ui.workspaceTab == tab
    Surface(onClick = {
        if (tab == NexusComposeUi.WorkspaceTab.FILES)
            ui.workspaceFilesView = NexusComposeUi.WorkspaceFilesView.PROJECT
        ui.workspaceTab = tab
    }, modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = if (selected) NexusBlue else Color.Transparent,
        contentColor = if (selected) Color.White else MaterialTheme.colorScheme.onSurface) {
        BoxWithConstraints(Modifier.fillMaxWidth().height(40.dp), contentAlignment = Alignment.Center) {
            val measurer = rememberTextMeasurer()
            val density = LocalDensity.current
            val labelStyle = MaterialTheme.typography.labelMedium
            fun widthAt(size: Int) = with(density) {
                measurer.measure(AnnotatedString(label),
                    style = labelStyle.copy(fontSize = size.sp),
                    softWrap = false).size.width.toDp()
            }
            val withIcon = widthAt(12) + 21.dp <= maxWidth - 4.dp
            val available = maxWidth - (if (withIcon) 21.dp else 0.dp) - 4.dp
            val fontSize = (12 downTo 9).firstOrNull { widthAt(it) <= available } ?: 9
            Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                if (withIcon) {
                    Icon(icon, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                }
                Text(label, fontSize = fontSize.sp, maxLines = 1, softWrap = false)
            }
        }
    }
}

@Composable
private fun WorkspaceLogs(ui: NexusComposeUi) {
    val state = ui.snapshot
    val verification = ui.verification
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.ui_logs), style = MaterialTheme.typography.titleMedium)
        if (verification.status != PythonVerification.Status.NONE) {
            Text(stringResource(R.string.ui_verify_details), style = MaterialTheme.typography.titleMedium)
            Text(verificationOutcomeLabel(verification, true),
                color = if (verification.status == PythonVerification.Status.STOPPED ||
                    verification.status == PythonVerification.Status.ERROR)
                    MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            VerificationFeatures(verification)
            if (verification.syntax) Text(stringResource(R.string.verify_syntax))
            if (verification.ran) Text(stringResource(R.string.verify_executed))
            if (verification.total > 0) Text(stringResource(R.string.verify_count,
                verification.passed, verification.total))
            if (verification.diagnostic.isNotBlank()) SelectionContainer {
                Text(verification.diagnostic, color = MaterialTheme.colorScheme.error)
            }
            if (verification.rounds > 0) SelectionContainer {
                Text(verification.diagnosticsHistory(), style = MaterialTheme.typography.bodySmall)
            }
            HorizontalDivider()
        }
        state.stages.forEach { stage ->
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(roleTitle(stage.role, stage.index), style = MaterialTheme.typography.titleMedium)
                NexusLabel(stage.modelLabel)
                Text(stringResource(if (stage.done) R.string.status_complete else if (stage.current && !state.active) R.string.status_draft else if (stage.current)
                    R.string.status_processing else R.string.status_queued),
                    style = MaterialTheme.typography.bodySmall)
                if (stage.warnings.isNotBlank()) Text(stage.warnings, color = MaterialTheme.colorScheme.error)
                if (stage.answer.isNotBlank()) SelectionContainer {
                    Text(stage.answer.take(4000), style = MaterialTheme.typography.bodySmall)
                }
                if (stage.hasPython && stage.done && !state.active) {
                    TextButton(onClick = { ui.activity.nexusRunPython(stage.index) }) {
                        Text(stringResource(R.string.action_python))
                    }
                }
            }
            HorizontalDivider()
        }
        if (state.log.isNotBlank()) SelectionContainer {
            Text(state.log, style = MaterialTheme.typography.bodySmall)
        }
        if (state.stages.isEmpty() && state.log.isBlank())
            NexusLabel(stringResource(R.string.ui_no_logs))
        OutlinedButton(enabled = state.hasRun && !state.active,
            onClick = { ui.activity.nexusExport() }) {
            Text(stringResource(R.string.action_export))
        }
    }
}

@Composable
private fun WorkspaceFiles(ui: NexusComposeUi) {
    val attachments = rememberAttachmentTask(ui)
    val projectView = ui.workspaceFilesView == NexusComposeUi.WorkspaceFilesView.PROJECT
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(if (projectView) R.string.ws_easy_files_tool else R.string.ui_attachments),
                style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = {
                ui.workspaceFilesView = if (projectView) NexusComposeUi.WorkspaceFilesView.ATTACHMENTS
                    else NexusComposeUi.WorkspaceFilesView.PROJECT
            }, contentPadding = PaddingValues(horizontal = 6.dp)) {
                Text(stringResource(if (projectView) R.string.ui_attachments
                    else R.string.ws_easy_files_tool), maxLines = 1, softWrap = false)
            }
        }
        Box(Modifier.fillMaxWidth().weight(1f)) {
            if (projectView) {
                // The imported ZIP belongs to the Python project, not the chat attachment list.
                PythonProjectFileManager(ui)
            } else {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AttachmentSummary(attachments)
                    if (attachments.items.isEmpty()) NexusLabel(stringResource(R.string.ui_no_files))
                    attachments.items.forEach { AttachmentCard(ui, it) }
                }
            }
        }
    }
}

/** Existing three model roles and quick-model picker are kept accessible outside the chat. */
@Composable
fun NexusTeamSettings(ui: NexusComposeUi) {
    var editing by remember { mutableIntStateOf(-1) }
    var quickPicker by remember { mutableStateOf(false) }
    val state = ui.snapshot
    NexusFrostedAlertDialog(onDismissRequest = { ui.teamSettingsRequested = false },
        title = { Text(stringResource(R.string.ui_models_setup)) },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedButton(onClick = { quickPicker = true }) {
                    Text(stringResource(R.string.ui_quick) + ": " + state.quickModelLabel)
                }
                val configured = ui.activity.nexusConfiguredStages()
                var allow by remember { mutableStateOf(ui.activity.nexusAllowFallback()) }
                Text(stringResource(R.string.role_next_task), style = MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(if (allow) R.string.route_allow else R.string.route_strict), Modifier.weight(1f))
                    Switch(checked = allow, onCheckedChange = {
                        if (ui.activity.nexusSetFallback(it)) allow = it
                    })
                }
                configured.forEach { stage ->
                    OutlinedButton(onClick = { editing = stage.index }, Modifier.fillMaxWidth()) {
                        Text(roleTitle(stage.role, stage.index) + " · " + stage.modelLabel,
                            maxLines = 3)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { ui.teamSettingsRequested = false }) {
            Text(stringResource(R.string.action_close))
        } })
    if (quickPicker) ModelPicker(ui, state.quickModelId, { quickPicker = false }) { id ->
        ui.activity.nexusChooseQuickModel(id); quickPicker = false
    }
    val stage = ui.activity.nexusConfiguredStages().firstOrNull { it.index == editing }
    if (stage != null) RoleEditor(ui, stage) { editing = -1 }
}
