package app.svyazka.mobile;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import androidx.test.core.app.ApplicationProvider;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class WorkspaceMigrationTest {
    @Test public void versionOneMigratesWithoutRewritingConversationOrCredentials() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        Workflow.Run quick = Workflow.Run.quick("calendar", ModelCatalog.NORTH, Workflow.defaultStages().get(1))
                .receive(new ModelClient.Reply("saved calendar", ModelClient.Finish.STOP, ""));
        String snapshot = quick.toJson().toString();
        context.getSharedPreferences("credentials", 0).edit().putString("marker", "existing").commit();
        try (SQLiteDatabase db = context.openOrCreateDatabase("svyazka_tasks.db", 0, null)) {
            db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY,title TEXT,task TEXT,run_json TEXT,attempt_log TEXT,results_visible INTEGER,created_at INTEGER,updated_at INTEGER)");
            db.execSQL("CREATE TABLE versions(id INTEGER PRIMARY KEY,task_id INTEGER REFERENCES tasks(id) ON DELETE CASCADE,version_no INTEGER,run_json TEXT,created_at INTEGER)");
            db.execSQL("CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT)");
            db.execSQL("INSERT INTO tasks VALUES(7,'начало','calendar',?,'log',1,10,20)", new Object[]{snapshot});
            db.execSQL("INSERT INTO versions VALUES(5,7,1,?,10)", new Object[]{snapshot});
            db.execSQL("INSERT INTO metadata VALUES('active_task_id','7')");
            db.setVersion(1);
        }
        try (TaskRepository db = new TaskRepository(context)) {
            assertEquals(7, db.activeId());
            assertEquals(snapshot, db.load(7).runJson);
            assertEquals(snapshot, db.versions(7).get(0).runJson);
            assertTrue(db.rename(7, "Мой календарь"));
            assertTrue(db.pin(7, true));
        }
        try (TaskRepository db = new TaskRepository(context)) {
            assertTrue(db.list().get(0).pinned);
            assertEquals("Мой календарь", db.load(7).title);
            assertEquals(1, db.load(7).versions);
            assertTrue(Workflow.Run.fromJson(new JSONObject(db.load(7).runJson)).complete());
            assertTrue(db.pin(7, false));
            assertFalse(db.load(7).pinned);
        }
        assertEquals("existing", context.getSharedPreferences("credentials", 0).getString("marker", ""));
    }
}
