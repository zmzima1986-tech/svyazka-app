"""Verify availability of the Android end-to-end probe (not an execution result)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AndroidPythonHistoryContract(unittest.TestCase):
    def test_real_android_probe_covers_activity_and_ui(self):
        source = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/PythonHistoryProbe.java').read_text()
        for required in (
            'startActivitySync', 'ui.addPythonFile(FILE)', 'ui.editPython(SOURCE)',
            'nexusPythonFlushPending()', 'activity.nexusCreateTask()',
            'activity.nexusOpenHistory()', 'activity.nexusOpenTask(first)',
            'activity.nexusTaskId()', 'ui.getPythonFileList()',
            'activity.nexusDeleteTask(first)', 'credentials',
        ):
            self.assertIn(required, source)

    def test_probe_has_three_process_lifecycle_steps(self):
        fixture = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/UpgradeProbe.java').read_text()
        script = (ROOT / 'scripts/test-android-python-history.py').read_text()
        self.assertIn('PythonHistoryProbe.run(this, step)', fixture)
        for step in ('python_seed', 'python_verify', 'python_deleted'):
            self.assertIn(step, script)
            self.assertIn(step, (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/PythonHistoryProbe.java').read_text())
        self.assertIn("am', 'force-stop'", script)


if __name__ == '__main__':
    unittest.main()
