package app.svyazka.mobile.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import app.svyazka.mobile.R
import app.svyazka.mobile.PythonInputs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class SavePayload(val filename: String, val text: String,
    val files: Map<String,String> = emptyMap())

@Composable
fun rememberSaveResultAction(answer: String, filename: String? = null): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<SavePayload?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data?.takeIf { result.resultCode == android.app.Activity.RESULT_OK }
        val payload = pending
        pending = null
        if (uri != null && payload != null) {
            scope.launch {
                val saved = withContext(Dispatchers.IO) {
                    runCatching {
                        val output = context.contentResolver.openOutputStream(uri, "w")
                            ?: throw IllegalStateException("Cannot open output")
                        if (payload.files.isEmpty()) output.bufferedWriter(Charsets.UTF_8).use { it.write(payload.text) }
                        else java.util.zip.ZipOutputStream(output).use { zip ->
                            payload.files.forEach { (name, body) ->
                                zip.putNextEntry(java.util.zip.ZipEntry(name))
                                zip.write(body.toByteArray(Charsets.UTF_8))
                                zip.closeEntry()
                            }
                        }
                    }.isSuccess
                }
                Toast.makeText(context, if (saved) R.string.file_saved else R.string.file_save_error,
                    if (saved) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show()
            }
        }
    }
    return {
        if (answer.isNotBlank()) {
            val payload = if (filename == null) chooseSavePayload(answer) else SavePayload(filename, answer)
            pending = payload
            val mime = when (payload.filename.substringAfterLast('.')) {
                "zip" -> "application/zip"
                "html" -> "text/html"
                "py" -> "text/x-python"
                "js" -> "text/javascript"
                "css" -> "text/css"
                "md" -> "text/markdown"
                else -> "text/plain"
            }
            launcher.launch(android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(android.content.Intent.CATEGORY_OPENABLE).setType(mime)
                .putExtra(android.content.Intent.EXTRA_TITLE, payload.filename))
        }
    }
}

/** A single fenced code block is exported as code; a multi-file answer stays intact as Markdown. */
private fun chooseSavePayload(answer: String): SavePayload {
    // Use the exact same fenced-source rules as the automatic verifier.
    // A malformed or ambiguous code block is exported intact, never disguised
    // as a verified or runnable .py file.
    val files = PythonInputs.namedFiles(answer)
    if (files.size > 1) return SavePayload("project.zip", "", files)
    if (files.size == 1) return files.entries.first().let { SavePayload(it.key.substringAfterLast('/'),it.value) }
    if (PythonInputs.hasNamedFiles(answer) || PythonInputs.unfinished(answer))
        return SavePayload("draft-incomplete-unverified.txt", answer)
    for ((language, name) in listOf("html" to "index.html", "javascript" to "main.js", "css" to "style.css")) {
        val source = PythonInputs.webSource(answer, language)
        if (source.isNotEmpty()) return SavePayload(name, source)
    }
    val python = PythonInputs.candidate(answer)
    if (python != null) {
        if (python.ambiguous || python.issue.isNotEmpty()) return SavePayload("result.md", answer)
        if (python.code.isNotBlank()) return SavePayload("result.py", python.code)
    }
    return if (answer.contains("```") || answer.contains("~~~")) SavePayload("result.md", answer)
        else SavePayload("result.txt", answer)
}
