package app.svyazka.mobile;

import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small dependency-free Markdown subset for displaying *untrusted* model text as styled text. */
final class MarkdownText {
    private static final Pattern INLINE = Pattern.compile(
            "`([^`\\n]+)`|\\*\\*([^*\\n]+)\\*\\*|\\*([^*\\n]+)\\*|"
                    + "\\[([^]\\n]+)\\]\\((https?://[^)\\s]+)\\)");

    private MarkdownText() { }

    static SpannableStringBuilder render(String source) {
        SpannableStringBuilder out = new SpannableStringBuilder();
        boolean fenced = false;
        String[] lines = (source == null ? "" : source).replace("\r\n", "\n").split("\n", -1);
        for (String original : lines) {
            String trimmed = original.trim();
            if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
                fenced = !fenced;
                continue;
            }
            int start = out.length();
            if (fenced) {
                out.append(original);
                if (out.length() > start) {
                    out.setSpan(new TypefaceSpan("monospace"), start, out.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    out.setSpan(new BackgroundColorSpan(0xff263449), start, out.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            } else {
                String line = original;
                int heading = 0;
                while (heading < line.length() && heading < 6 && line.charAt(heading) == '#') heading++;
                if (heading > 0 && heading < line.length() && line.charAt(heading) == ' ') {
                    line = line.substring(heading + 1);
                } else {
                    heading = 0;
                }
                String left = line.replaceFirst("^\\s+", "");
                if (left.startsWith("- ") || left.startsWith("* ") || left.startsWith("+ ")) {
                    int prefix = line.length() - left.length();
                    line = line.substring(0, prefix) + "• " + left.substring(2);
                } else if (left.startsWith("> ")) {
                    int prefix = line.length() - left.length();
                    line = line.substring(0, prefix) + "│ " + left.substring(2);
                }
                appendInline(out, line);
                if (heading > 0 && out.length() > start) {
                    out.setSpan(new StyleSpan(Typeface.BOLD), start, out.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    out.setSpan(new RelativeSizeSpan(heading <= 2 ? 1.23f : 1.08f),
                            start, out.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
            out.append('\n');
        }
        return out;
    }

    private static void appendInline(SpannableStringBuilder out, String line) {
        Matcher m = INLINE.matcher(line);
        int index = 0;
        while (m.find()) {
            out.append(line, index, m.start());
            int begin = out.length();
            if (m.group(1) != null) {
                out.append(m.group(1));
                out.setSpan(new TypefaceSpan("monospace"), begin, out.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                out.setSpan(new BackgroundColorSpan(0xff263449), begin, out.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else if (m.group(2) != null) {
                out.append(m.group(2));
                out.setSpan(new StyleSpan(Typeface.BOLD), begin, out.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else if (m.group(3) != null) {
                out.append(m.group(3));
                out.setSpan(new StyleSpan(Typeface.ITALIC), begin, out.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else if (m.group(4) != null) {
                out.append(m.group(4));
                out.setSpan(new ForegroundColorSpan(0xff8ce5dc), begin, out.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            index = m.end();
        }
        out.append(line, index, line.length());
    }
}
