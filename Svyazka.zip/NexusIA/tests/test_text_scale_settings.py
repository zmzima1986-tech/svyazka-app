"""Source contracts for the in-app text scale patch; no APK screenshot claims."""
from pathlib import Path
import unittest
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/svyazka/mobile/ui'
MAIN = ROOT / 'app/src/main/java/app/svyazka/mobile/MainActivity.java'


class TextScaleSettingsTest(unittest.TestCase):
    def test_persistent_validated_percentage_without_activity_recreation(self):
        source = MAIN.read_text(encoding='utf-8')
        getter = source.split('public int nexusTextScalePercent() {', 1)[1].split('\n    }', 1)[0]
        setter = source.split('public void nexusTextScaleChanged(int percent) {', 1)[1].split('\n    }', 1)[0]
        self.assertIn('getInt("ui_text_scale_percent", 100)', getter)
        self.assertIn('stored >= 80 && stored <= 150 && stored % 10 == 0', getter)
        self.assertIn('percent < 80 || percent > 150 || percent % 10 != 0', setter)
        self.assertIn('putInt("ui_text_scale_percent", percent).apply()', setter)
        self.assertIn('nexusUi.onTextScaleChanged(percent)', setter)
        self.assertNotIn('recreate()', setter)

    def test_user_scale_multiplies_system_accessibility_scale(self):
        source = (UI / 'NexusComposeUi.kt').read_text(encoding='utf-8')
        self.assertIn('mutableIntStateOf(activity.nexusTextScalePercent())', source)
        self.assertIn('Density(deviceDensity.density, deviceDensity.fontScale * ui.textScalePercent / 100f)', source)
        self.assertIn('CompositionLocalProvider(LocalDensity provides adjustedDensity)', source)
        self.assertIn('NexusAppThemeContent(ui, displayedTheme)', source)

    def test_both_themes_use_shared_control_and_dynamic_theme_layout(self):
        for filename, flag in [('NexusDarkSettings.kt', 'true'), ('NexusLightSettings.kt', 'false')]:
            source = (UI / filename).read_text(encoding='utf-8')
            self.assertIn(f'NexusTextScaleControl(ui, dark = {flag})', source)
            self.assertIn('LocalDensity.current.fontScale', source)
        control = (UI / 'NexusTextScaleControl.kt').read_text(encoding='utf-8')
        self.assertIn('percent > 80', control)
        self.assertIn('percent < 150', control)
        self.assertIn('nexusTextScaleChanged(percent - 10)', control)
        self.assertIn('nexusTextScaleChanged(percent + 10)', control)
        self.assertIn('Modifier.size(48.dp)', control)
        self.assertIn('NexusDarkDesign.chatGlass', control)
        self.assertIn('NexusLightDesign.glass', control)

    def test_text_size_strings_in_every_supported_locale(self):
        required = {'settings_text_size', 'settings_text_smaller', 'settings_text_larger'}
        for directory in ('values', 'values-en', 'values-ar', 'values-ja', 'values-zh-rCN'):
            path = ROOT / 'app/src/main/res' / directory / 'strings.xml'
            strings = ET.parse(path).getroot()
            names = [e.get('name') for e in strings if e.tag == 'string']
            self.assertTrue(required.issubset(names), directory)
            for key in required:
                self.assertEqual(names.count(key), 1, f'{directory}: {key}')


if __name__ == '__main__':
    unittest.main()
