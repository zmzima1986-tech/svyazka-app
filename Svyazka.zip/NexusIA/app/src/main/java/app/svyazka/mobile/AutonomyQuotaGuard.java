package app.svyazka.mobile;

/** A conservative, local stop for unattended AI retries.
 * Only a recent, provider-reported zero is authoritative; missing or stale
 * quota information must never be presented as exhaustion.
 */
final class AutonomyQuotaGuard {
    static final long SNAPSHOT_VALID_MS = 60_000L;

    private AutonomyQuotaGuard() { }

    /** One explicit user start/resume owns this budget, shared by all stages.
     * Monotonic clock: wall-clock changes cannot extend unattended retries. */
    static final class Session {
        static final int MAX_CALLS = 18;
        static final long MAX_ESTIMATED_TOKENS = 180_000L;
        static final long MAX_MS = 10 * 60_000L;
        final long started;
        int calls;
        long reservedTokens;
        Session(long now) { started = now; }
        String limit(long now, long estimate) {
            if (now < started || now - started >= MAX_MS) return "Истёк общий лимит времени работы команды.";
            if (calls >= MAX_CALLS) return "Исчерпан общий лимит запросов команды (18).";
            if (estimate < 0 || estimate > MAX_ESTIMATED_TOKENS - reservedTokens)
                return "Исчерпан общий расчётный бюджет токенов команды.";
            return "";
        }
        boolean reserve(long now, long estimate) {
            if (!limit(now, estimate).isEmpty()) return false;
            calls++; reservedTokens += estimate;
            return true;
        }
        boolean unattended() { return calls > 0; }
    }

    /** Per-stage recovery decisions. Each route can get at most two fresh retries;
     * repeated identical failures switch early, and a repeat on another route stops. */
    static final class Recovery {
        private final java.util.Map<String,Integer> retries = new java.util.HashMap<>();
        private final java.util.Map<String,String> failures = new java.util.HashMap<>();
        private final java.util.Set<String> repeated = new java.util.HashSet<>();
        enum Action { RETRY, SWITCH, STOP }
        Action next(String model, String fingerprint) {
            String first = failures.putIfAbsent(fingerprint, model);
            if (first != null) {
                if (!first.equals(model) || !repeated.add(fingerprint)) return Action.STOP;
                return Action.SWITCH;
            }
            int used = retries.getOrDefault(model, 0);
            if (used >= 2) return Action.SWITCH;
            retries.put(model, used + 1);
            return Action.RETRY;
        }
    }

    static boolean recentZero(long remaining, long recordedAt, long now) {
        return remaining == 0 && recordedAt > 0 && now >= recordedAt
                && now - recordedAt < SNAPSHOT_VALID_MS;
    }

    static boolean groqExhausted(long tokensThisMinute, long requestsToday,
                                 long recordedAt, long now) {
        return recentZero(tokensThisMinute, recordedAt, now)
                || recentZero(requestsToday, recordedAt, now);
    }

    static boolean openRouterExhausted(long freeRequestsToday, long recordedAt, long now) {
        return recentZero(freeRequestsToday, recordedAt, now);
    }
}
