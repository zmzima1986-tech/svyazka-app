package app.svyazka.mobile;

import android.content.Context;
import java.util.function.Consumer;

/** The existing WebView sandbox behind a platform-neutral execution contract. */
final class AndroidPythonExecutor implements PythonExecutor {
    private final Context context;
    private final LocalSandbox delegate;

    AndroidPythonExecutor(Context context, Consumer<SandboxClient.Result> result, Consumer<String> problem) {
        this.context = context;
        delegate = new LocalSandbox(result, problem);
    }

    @Override public void execute(String code, String stdin) {
        delegate.execute(context, code, stdin);
    }

    @Override public void execute(String code, String stdin, boolean loadMatplotlib) {
        delegate.execute(context, code, stdin, loadMatplotlib);
    }

    @Override public void executeProject(String code, String stdin, org.json.JSONObject files,
                                         String entry, String allowedPackage, boolean extended) {
        delegate.executeProject(context, code, stdin, files, entry, allowedPackage, extended);
    }

    @Override public void executeProject(String code, String stdin, org.json.JSONObject files,
                                         String entry, String allowedPackage, boolean extended, boolean projectTests) {
        delegate.executeProject(context, code, stdin, files, entry, allowedPackage, extended, projectTests);
    }

    @Override public void cancel() {
        delegate.close();
    }
}
