package app.svyazka.mobile;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Select an existing Python file for an explicitly approved chat edit. Never invent paths. */
final class PythonChatFile {
    private static final Pattern HEADER = Pattern.compile(
            "^#\\s*(?:(?:file|файл)\\s*:\\s*)?([A-Za-z0-9_./-]+\\.py)\\s*$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private PythonChatFile() { }

    static String target(String code, String[] savedPaths) {
        if (code == null || code.trim().isEmpty() || savedPaths == null) return "";
        Set<String> pythonFiles = new LinkedHashSet<>();
        for (String path : savedPaths) {
            if (PythonProjectPaths.validPath(path) && path.endsWith(".py")) pythonFiles.add(path);
        }
        if (pythonFiles.isEmpty()) return "";

        String declared = "";
        // File markers are only trusted in the header, before the first source statement.
        for (String line : code.split("\\r?\\n", 12)) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) continue;
            if (!trimmed.startsWith("#")) break;
            Matcher name = HEADER.matcher(trimmed);
            if (name.matches()) {
                declared = name.group(1);
                break;
            }
        }
        if (!declared.isEmpty()) {
            if (!PythonProjectPaths.validPath(declared)) return "";
            if (pythonFiles.contains(declared)) return declared;
            // A chat example may call the sole main.py "src/main.py". A user sees
            // the actual selected filename before approving the replacement.
            if (declared.equals("src/main.py") && pythonFiles.size() == 1
                    && pythonFiles.contains("main.py")) return "main.py";
            return "";
        }
        // No guess in a multi-file project: the model must identify a real file.
        return pythonFiles.size() == 1 ? pythonFiles.iterator().next() : "";
    }
}
