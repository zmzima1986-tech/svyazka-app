"""Source-level regression checks. Runtime rendering still requires Android UI tests."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/app/svyazka/mobile/ui'


class PythonEditorAndFrostedUI(unittest.TestCase):
    def test_cannot_reintroduce_inside_drawer_gap(self):
        workspace = (UI / 'NexusPythonWorkspace.kt').read_text()
        self.assertIn('val drawerWidth = maxWidth', workspace)
        self.assertNotIn('maxWidth - 4.dp', workspace)
        self.assertIn('NexusFrostedPanel(', workspace)

    def test_source_coloring_does_not_modify_editor_or_execution_bytes(self):
        editor = (UI / 'PythonCodeEditor.kt').read_text()
        self.assertIn('object : VisualTransformation', editor)
        self.assertIn('pythonSyntaxAnnotated(text.text, palette)', editor)
        self.assertIn('OffsetMapping.Identity', editor)
        self.assertIn('value = value,', editor)
        self.assertIn('onValueChange = onValueChange,', editor)
        for token_type in ('color.keyword', 'color.string', 'color.comment', 'color.number'):
            self.assertIn(token_type, editor)

    def test_explicit_gutter_not_reliant_on_native_canvas(self):
        editor = (UI / 'PythonCodeEditor.kt').read_text()
        self.assertIn('lineStarts.forEachIndexed { line, offset ->', editor)
        self.assertIn('text = (line + 1).toString()', editor)
        self.assertIn('if (line == currentLine)', editor)
        self.assertNotIn('drawContext.canvas.nativeCanvas', editor)

    def test_editor_runs_same_execution_path(self):
        workspace = (UI / 'NexusPythonWorkspace.kt').read_text()
        self.assertIn('PythonToolPanel.EDITOR -> PythonEditorTool', workspace)
        self.assertIn('onRun = {', workspace)
        self.assertIn('launch()', workspace)
        self.assertIn('Button(onClick = onRun, modifier = Modifier.weight(1f)', workspace)
        self.assertIn('R.string.ws_editor_run', workspace)
        self.assertIn('toolPanel = null', workspace)

    def test_frosted_style_uniform(self):
        frosted = (UI / 'NexusFrosted.kt').read_text()
        self.assertIn('Color(0xFF10121C).copy(alpha = .94f)', frosted)
        self.assertIn('Color.White.copy(alpha = .94f)', frosted)
        self.assertIn('NexusFrostedAlertDialog(', frosted)
        for file in UI.glob('*.kt'):
            if file.name == 'NexusFrosted.kt':
                continue
            source = file.read_text()
            self.assertNotIn(' AlertDialog(', source, file.name)
        self.assertIn('NexusFrostedPanel(', (UI / 'NexusDrawers.kt').read_text())
        self.assertIn('NexusFrostedPanel(', (UI / 'NexusVisual.kt').read_text())


if __name__ == '__main__':
    unittest.main()
