package app.svyazka.mobile;

import java.io.BufferedReader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;

public final class WorkflowChecks {
    private static int count;

    private static void check(boolean ok, String label) {
        if (!ok) throw new AssertionError(label);
        count++;
    }

    private static ModelClient.Reply reply(String text, ModelClient.Finish finish) {
        return new ModelClient.Reply(text, finish, "");
    }

    private static String event(String value, String finish) throws Exception {
        JSONObject choice = new JSONObject()
                .put("delta", new JSONObject().put("content", value))
                .put("finish_reason", finish == null ? JSONObject.NULL : finish);
        return "data: " + new JSONObject().put("choices", new JSONArray().put(choice)) + "\n\n";
    }

    private static ModelClient.Reply stream(String raw) {
        return ModelClient.parseRouterStream(new BufferedReader(new StringReader(raw)));
    }

    public static void main(String[] args) throws Exception {
        String prior = event("kept", null);
        ModelClient.Reply excessive = stream(prior + "data: " + "x".repeat(ModelClient.MAX_EVENT_CHARS));
        check(excessive.finish == ModelClient.Finish.ERROR && excessive.text.equals("kept")
                && excessive.failure.reason == RequestFailure.Reason.RESPONSE_LIMIT, "oversized line preserves committed events");
        check(!ModelPool.shouldTryNext(excessive), "response limit does not consume another route");
        String piece = "x".repeat(800_000);
        ModelClient.Reply large = stream(event(piece, null) + event(piece, null) + event(piece, "stop"));
        check(large.finish == ModelClient.Finish.ERROR && large.text.equals(piece + piece)
                && large.failure.reason == RequestFailure.Reason.RESPONSE_LIMIT, "over-budget event rolls back");
        check(stream(event("line", "stop").replace("\n", "\r\n")).text.equals("line"), "CRLF terminates events");
        ModelClient.Cancellation stopped = new ModelClient.Cancellation();
        stopped.signal();
        java.net.HttpURLConnection stub = new java.net.HttpURLConnection(new java.net.URL("https://example.invalid/")) {
            @Override public void connect() { throw new AssertionError("Connection unexpectedly opened"); }
            @Override public void disconnect() { }
            @Override public boolean usingProxy() { return false; }
        };
        try {
            stopped.attach(stub);
            throw new AssertionError("Cancelled request accepted a connection");
        } catch (java.io.IOException expected) { check(true, "cancelled token rejects late transport"); }
        ModelCatalog catalog = ModelCatalog.fromOpenRouter(new JSONObject(new String(
                Files.readAllBytes(Paths.get(args[0])), StandardCharsets.UTF_8)));
        check(catalog.refreshed && catalog.routerCount() > 3, "offline catalog fixture loaded");
        for (Workflow.Stage each : Workflow.defaultStages()) {
            check(catalog.available(each.model), "free default found: " + each.model.id);
            check(catalog.details(each.model).maxOutput > 4096, "default cap exceeds old cap");
        }
        check(!ModelCatalog.isFreeId("thinkingmachines/inkling"), "paid route rejected");
        check(!ModelCatalog.isFreeId("meta-llama/llama-4-scout"), "paid sibling rejected");
        check(ModelCatalog.fromCache(catalog.cacheData()).routerCount() == catalog.routerCount(), "cached catalog");
        check(catalog.choices().stream().anyMatch(m -> m.id.equals("recursive/flint-v1.0:free")), "new model is selectable");

        JSONObject paidFree = new JSONObject().put("id", "example/paid:free")
                .put("architecture", new JSONObject().put("input_modalities", new JSONArray().put("text"))
                        .put("output_modalities", new JSONArray().put("text")))
                .put("pricing", new JSONObject().put("prompt", "0").put("completion", "0").put("request", "0.01"));
        ModelCatalog mix = ModelCatalog.fromOpenRouter(new JSONObject().put("data", new JSONArray().put(paidFree)));
        check(mix.routerCount() == 0, "paid requests excluded even with a free-looking ID");

        String task = "Напиши программу для обработки фото.\n" + "Оригинальная задача. ".repeat(650);
        Workflow.Run run = new Workflow.Run(task, Workflow.defaultStages());
        ModelCatalog constrained = ModelCatalog.fromCache(new JSONArray().put(new JSONObject()
                .put("id", "example/tiny:free").put("label", "Tiny")
                .put("context", 1024).put("max_output", 1024)
                .put("reasoning", false).put("image_input", false)));
        ModelCatalog.Model tiny = constrained.choices().get(0);
        Workflow.Run tinyRun = Workflow.Run.quick("This prompt is too long for the tiny context.",
                tiny, Workflow.defaultStages().get(1));
        boolean tooLarge = false;
        try { ModelClient.routerBody(tinyRun, tiny); }
        catch (ModelClient.Problem expected) { tooLarge = expected.getMessage().contains("контекста"); }
        check(tooLarge, "context preflight rejects without silently cropping existing text");
        JSONObject initial = ModelClient.routerBody(run, catalog.details(ModelCatalog.LING));
        check("deny".equals(initial.getJSONObject("provider").getString("data_collection")),
                "OpenRouter refuses training-data collection by default");
        JSONObject allowed = ModelClient.routerBody(run, catalog.details(ModelCatalog.LING), false);
        check(!allowed.getJSONObject("provider").has("data_collection"),
                "user choice removes only the OpenRouter collection filter");
        check(!ModelClient.groqBody(run, catalog.details(ModelCatalog.LING)).has("provider"),
                "OpenRouter provider policy is not sent to Groq");
        check(initial.getBoolean("stream"), "streaming enabled");
        check(initial.getInt("max_tokens") == 32768, "large initial budget");
        JSONObject price = initial.getJSONObject("provider").getJSONObject("max_price");
        check(price.getInt("prompt") == 0 && price.getInt("completion") == 0 && price.getInt("request") == 0,
                "zero input, output and request price ceiling");
        check(new JSONObject(run.prompt()).getString("task").equals(task), "long source task preserved verbatim");
        check(new JSONObject(run.prompt()).getJSONObject("inputs").length() == 0, "external task is first input");

        String prefix = "Готовый пример кода\n```python\ndef improve(img):\n    return img.";
        String suffix = "convert('RGB')\n```";
        ModelClient.Reply fragment = stream(": OPENROUTER PROCESSING\r\n\r\n"
                + event(prefix.substring(0, 29), null) + event(prefix.substring(29), "length") + "data: [DONE]\n\n");
        check(fragment.finish == ModelClient.Finish.LENGTH && fragment.text.equals(prefix), "real SSE length shape preserves text");
        run = run.receive(fragment);
        check(run.answers.isEmpty() && run.nextStep() == Workflow.Step.SOLUTION
                && run.draftMode == Workflow.DraftMode.CONTINUE, "partial answer held before handoff");
        run = Workflow.Run.fromJson(new JSONObject(run.toJson().toString()));
        check(run.draft.text.equals(prefix), "partial survives saved state");
        ModelCatalog.Model replacement = catalog.details(ModelCatalog.FLINT);
        run = run.withModel(replacement);
        JSONArray continued = ModelClient.routerBody(run, replacement).getJSONArray("messages");
        check(continued.length() == 4 && continued.getJSONObject(2).getString("content").equals(prefix),
                "continue as same step from exact saved text");
        run = run.receive(stream(event(suffix, "stop")));
        check(run.answers.isEmpty() && run.draft.text.equals(prefix) && !run.draft.preceding.isEmpty(),
                "cross-model partial code is retained separately without being accepted");
        run = run.receive(stream(event(prefix + suffix, "stop")));
        check(run.answers.get(0).text.equals(prefix + suffix)
                        && run.answers.get(0).models.equals(java.util.Collections.singletonList(replacement.id))
                        && run.answers.get(0).preceding.stream().anyMatch(item -> prefix.equals(item.optString("text")))
                        && run.answers.get(0).preceding.stream().anyMatch(item -> suffix.equals(item.optString("text"))),
                "new complete source retains its producer and previous fragment");
        JSONObject reviewInput = new JSONObject(run.prompt()).getJSONObject("inputs");
        check(reviewInput.length() == 1 && reviewInput.getJSONObject("solution").getString("text").equals(prefix + suffix),
                "review receives completed solution");
        check(run.nextStep() == Workflow.Step.REVIEW && !run.complete(), "review required for completion");

        Workflow.Run interruptedReview = run.receive(stream(event("- Сохранить яркость\n", null)));
        check(interruptedReview.draftMode == Workflow.DraftMode.CONTINUE && interruptedReview.answers.size() == 1,
                "mid-stream disconnect holds received review");
        Workflow.Run invalid = run.receive(reply("Нужна правка.\n[[REVIEW: FIX]]", ModelClient.Finish.STOP));
        check(invalid.draftMode == Workflow.DraftMode.REPEAT_REVIEW && invalid.answers.size() == 1,
                "fix marker alone cannot start revision");
        check(new JSONObject(invalid.prompt()).has("review_draft"), "malformed review retained for retry");
        Workflow.Run conflict = run.receive(reply("Возможно [[REVIEW: PASS]]\n- Проблема формата\n[[REVIEW: FIX]]",
                ModelClient.Finish.STOP));
        check(conflict.answers.size() == 1, "ambiguous verdict cannot start revision");

        Workflow.Run noFindings = run.receive(reply("Решение удовлетворяет требованиям.\n[[REVIEW: PASS]]",
                ModelClient.Finish.STOP));
        check(noFindings.complete() && noFindings.revisionSkipped() && noFindings.finalIndex() == 0,
                "valid PASS preserves the original result");
        Workflow.Run savedPass = Workflow.Run.fromJson(noFindings.toJson());
        check(savedPass.complete() && savedPass.answers.size() == 2 && savedPass.revisionSkipped()
                && savedPass.displayAnswer(0).equals(run.displayAnswer(0)), "PASS survives restart");
        check(!noFindings.displayAnswer(1).contains("[[REVIEW"), "protocol marker hidden from review display");
        Workflow.Run checking = savedPass.withVerification(PythonVerification.NONE.start(0, "print(1)"));
        Workflow.Run recoveredCheck = Workflow.Run.fromJson(checking.toJson());
        check(recoveredCheck.verification.source == 0 && recoveredCheck.finalIndex() == 0,
                "verification of preserved solution survives restart");
        Workflow.Run repairAfterPass = savedPass.addRepair(new Workflow.RepairInput(0, "print(1)", "", "error"));
        check(repairAfterPass.nextIndex() == 3 && repairAfterPass.nextStep() == Workflow.Step.REPAIR,
                "repair remains available after skipped revision");
        check(Workflow.Run.fromJson(repairAfterPass.toJson()).revisionSkipped(), "skipped revision survives repair history");
        Workflow.Run shortCode = Workflow.Run.quick("Write a Python program", ModelCatalog.GROQ_120B,
                Workflow.defaultStages().get(1));
        check(ModelClient.requestedOutput(shortCode, ModelCatalog.GROQ_120B, 1000) == 7000,
                "short code request gets adaptive Groq output budget");
        check(ModelClient.requestedOutput(shortCode, ModelCatalog.GROQ_120B, 6000) == 2000,
                "large input leaves less free-tier completion room");

        Workflow.Run technicalFailure = run.withWebCheck(0, new JSONObject().put("status", "ERROR"))
                .receive(reply("Checked.\n[[REVIEW: PASS]]", ModelClient.Finish.STOP));
        check(!technicalFailure.complete() && technicalFailure.nextStep() == Workflow.Step.REVISION,
                "actual local error overrides PASS");
        check(technicalFailure.instructions().contains("actual local check failed"), "revision sees failed check");

        Workflow.Run fix = invalid.receive(reply("- Сохрани исходную яркость и обработай пустой вход.\n[[REVIEW: FIX]]",
                ModelClient.Finish.STOP));
        check(!fix.complete() && fix.nextStep() == Workflow.Step.REVISION && fix.missingInput().isEmpty(),
                "valid concrete review starts revision");
        JSONObject revision = new JSONObject(fix.prompt()).getJSONObject("inputs");
        check(revision.length() == 2 && revision.has("solution") && revision.has("review"),
                "revision receives both required outputs");
        check(ModelClient.routerBody(fix, catalog.details(ModelCatalog.NORTH)).getInt("max_tokens") == 64000,
                "final step respects North's published output cap");

        String longResult = "line of code with Russian text Задача.\n".repeat(5600);
        StringBuilder events = new StringBuilder();
        for (int i = 0; i < longResult.length(); i += 6) {
            events.append(event(longResult.substring(i, Math.min(i + 6, longResult.length())), null));
        }
        events.append(event("", "stop"));
        check(events.toString().getBytes(StandardCharsets.UTF_8).length > 2 * 1024 * 1024,
                "realistic SSE fixture exceeds old whole-response byte cap");
        Workflow.Run finished = fix.receive(stream(events.toString()));
        check(finished.complete() && finished.finalIndex() == 2 && finished.displayAnswer(2).equals(longResult),
                "large final output preserved exactly");
        check(Workflow.Run.fromJson(new JSONObject(finished.toJson().toString())).displayAnswer(2).equals(longResult),
                "large final output survives JSON save and restore");

        JSONObject legacy = new JSONObject().put("version", 1).put("task", "Задача")
                .put("stages", Workflow.stagesToJson(Workflow.defaultStages()))
                .put("answers", new JSONArray().put("Решение").put("Старое ревью без формата"));
        Workflow.Run migrated = Workflow.Run.fromJson(legacy);
        check(migrated.answers.size() == 1 && migrated.draftMode == Workflow.DraftMode.REPEAT_REVIEW,
                "previous unvalidated review restored as a draft");

        ModelClient.Reply limitEmpty = stream(event("", "length"));
        Workflow.Run noText = new Workflow.Run("Задача", Workflow.defaultStages()).receive(limitEmpty);
        check(noText.answers.isEmpty() && noText.draftMode == Workflow.DraftMode.NONE && !noText.note.isEmpty(),
                "empty provider length limit stays actionable");
        ModelClient.Reply error = stream(event("Уже полученный текст", null)
                + "data: {\"error\":{\"code\":429,\"message\":\"rate limit\"}}\n\n");
        check(error.finish == ModelClient.Finish.ERROR && error.text.equals("Уже полученный текст")
                && error.problem.contains("лимит запросов"), "quota error keeps streamed text");
        ModelClient.Reply gemini = ModelClient.parseGemini(new JSONObject(
                "{\"candidates\":[{\"finishReason\":\"MAX_TOKENS\",\"content\":{\"parts\":["
                  + "{\"thought\":true,\"text\":\"thinking\"},{\"text\":\"Полученный ответ\"}]}}]}"));
        check(gemini.finish == ModelClient.Finish.LENGTH && gemini.text.equals("Полученный ответ"),
                "optional Google client preserves truncated visible text");

        System.out.println(count + " checks passed; " + catalog.routerCount() + " free text models in the catalog fixture");
    }
}
