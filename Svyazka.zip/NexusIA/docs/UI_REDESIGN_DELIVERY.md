# Nexus AI 0.7.0 — Minimal Hi-Tech UI: implementation handoff

**Merged source distribution (19 November 2026):** `NexusIA-0.7.0-PythonCheck-FULL.zip` + `NexusIA-0.7.0-MinimalHiTech-UI-PATCH.zip`, with cleanup of legacy raster UI icon sets and obsolete old APK. The current ZIP is a **complete source tree**, not a small patch. The built-in launcher identity is `@mipmap/ic_launcher` + `@mipmap/ic_launcher_round` in `AndroidManifest.xml`, with adaptive and density-specific assets. There is **no built redesigned APK** in this archive; build and test on Android before release.

## Implemented in the supplied sources

- One Compose chat view for both historical Java states `TASK` and `RESULT`. The Java workflow, order of model roles, automatic Python verification, model fallback, database tables, and attachments parser are intact.
- A chronological view of actual prior run versions and their saved answers. The chat view does **not** invent missing user messages; if a legacy version lacks the original user prompt, only its stored answer is shown. All prior versions remain available through the existing version viewer.
- Compact quick/team selector, a small empty-chat greeting, message bubbles, markdown/code, copy/save of the current final answer, inline progress and errors, a small expandable input area, and a `+` attachment picker. No permanently visible bottom navigation bar or decorative waves.
- Left overlay navigation drawer for actual existing features only: new chat, history, models, team settings, attachments, Python/Code, settings, keys, about.
- Right overlay workspace with Python, Code, Logs, Files. Manual Python execution, stop, error, output and visual result now render nonmodally in the workspace. Closing the drawer does not cancel execution; report and editor content are held by `NexusComposeUi` while its Activity is alive.
- Timed drawer slide/fade transitions; a translucent, thin-bordered surface providing a frosted appearance. **Opening gestures are not registered**: horizontal swipes over chat/code cannot open a drawer. Scrim, close button, and Android Back close it.
- Pure `#000000` and `#FFFFFF` chat backgrounds, restrained cyan/blue/purple, smaller cards, flat new navigation icons, new official three-layer logo and Android launcher asset, 23 translated new strings across RU/EN/AR/JA/ZH-CN.

## Boundaries (important)

1. **No successful APK compilation is claimed.** The environment lacks a cached Gradle 8.9 distribution and Android SDK. `./gradlew --offline :app:compileDebugKotlin` attempted to fetch the distribution and failed due to inaccessible network. Compile and test on a real Android device before releasing.
2. Python continuity is guaranteed **by code structure for drawer close only**, not yet demonstrated on a device. The existing `MainActivity.onDestroy()` still cancels work. Exiting the Activity, process death, device restart and prolonged execution while the app is backgrounded are different lifecycle cases and are not implemented as a foreground service.
3. Manual Python output is retained while `NexusComposeUi` is alive; it is not saved to SQLite. The automatic Python verification result continues using the existing workflow persistence.
4. Actual background blur (`RenderEffect`) is **not** enabled; the panels use a translucent contrasting surface, because blur over live chat can substantially reduce performance on older devices. Verify the visual effect in both themes and assess whether native blur is warranted.
5. This patch corrects the architectural cause of the first-message transition by rendering `TASK` and `RESULT` in the same chat. It does not prove that every prior black-screen incident was caused by that transition; device reproduction/Logcat is still required to distinguish a crash or hardware rendering issue.
6. No absent modules (projects/technology DB/plugins/voice input) were fabricated. Attachments remain bound by the existing storage and API limitations. The new UI is a migration, not a redesign of the Java model engine.
7. The single central chat uses `nexusFollowUp` for a completed task. A new unrelated task should be created with «Новый чат»; saved versions remain available.

## Automatically executed checks

| Check | Outcome |
|---|---|
| ZIP source integrity (base) | PASS, original archive tested in stage 0 |
| `python scripts/check-resources.py` | PASS, 254 string keys × 5 locales |
| `python -m unittest discover -s tests -p 'test_python_verifier.py'` | PASS, 20 tests |
| `node tests/test-python-worker.mjs` | PASS, 11 scenarios + manual run |
| `python -m unittest discover -s tests -p 'test_ui_redesign_contract.py'` | PASS, 6 static checks |
| Kotlin parsing using local compiler without Android/Compose classpath | No lexical/syntactic "expecting" diagnostics; not a type/build check |
| `./gradlew --offline :app:compileDebugKotlin` | BLOCKED, Gradle distribution missing and internet unavailable |
| Compose instrumented tests, Android runtime, phone screenshots | NOT RUN |

## Mandatory device acceptance sequence

1. Make a backup of the current project and database. Replace the files from the ZIP patch preserving paths rooted at `NexusIA/`. Rebuild and install the APK using the project's existing Gradle configuration. Do not distribute the pre-patch APK.
2. **Both themes:** new empty chat → send first text → confirm user bubble and real progress remain visible → receive answer → send follow-up → open history and return → scroll a long code answer.
3. Switch between quick/team for a subsequent request. Verify the selected model and all three team roles retain their original instructions. Verify model fallback with available test accounts, without exposing API secrets.
4. Open the left and right drawers by tapping buttons. Swipe left/right across a message and a code block: **no drawer should open**. Back/scrim/close should dismiss each drawer without leaving chat. Reopen repeatedly and rotate the device.
5. Open a task containing executable Python. Start `print("OK")`, close the right panel during execution, keep the chat interactive, reopen and confirm the actual result. Separately test the existing `while True: pass` hard timeout and Worker recovery. Do not interpret a lack of exceptions as functional test success.
6. Check code and result retention across drawer close, not just a redraw. Test an actual exception, unavailable dependency, stop button, and passing an error to the Critic when available.
7. Check keyboard insets, attachment picker, selected and processed file states, photo/camera permissions, 10-file limit, settings, localizations, RTL and increased font sizes.
8. Confirm the app identifier, signing certificate, saved task history, providers and API credentials survive the in-place upgrade. No database migration is part of this patch.
9. If compilation or UI test fails, preserve the original files, send the compiler error or Logcat and a screenshot. Do not apply unrelated fixes in bulk.

**Release status:** UI implementation candidate — static and engine regression checks pass; Android compilation and on-device acceptance are outstanding.


### Завершение заставки (19.11.2026)

Полный архив Nexus AI содержит исправление фиксированной задержки: Compose-заставка закрывается после первого отрисованного кадра основного интерфейса; Android-система удерживает свой splash, пока Activity и хранилище инициализируются. Добавлены волна снизу, индетерминированная полоса загрузки без выдуманных процентов и текст «Загрузка…». Подпись «ИИ-платформа» со splash удалена (в навигации она может оставаться). Выбор темы в `SharedPreferences(workspace).ui_theme` учитывается в `attachBaseContext`, в первой фоновой заливке и Compose. Первый системный кадр Android, показанный до запуска приложения, может соответствовать системной теме. Реальный APK и проверка на устройстве обязательны.
