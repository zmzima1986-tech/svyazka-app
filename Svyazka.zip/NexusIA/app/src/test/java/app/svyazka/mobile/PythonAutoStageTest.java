package app.svyazka.mobile;

import org.junit.Test;
import static org.junit.Assert.*;

public class PythonAutoStageTest {
    private static final String[] ONE_FILE = { "main.py", "notes.txt" };

    @Test public void russianRequestStagesOnlyRealFile() {
        PythonAutoStage.Selection result = PythonAutoStage.select(
                "Измени подключённую программу, чтобы она выводила новый текст",
                "Файл: src/main.py\n```python\n# src/main.py\nprint('новый текст')\n```",
                ONE_FILE);
        assertNotNull(result);
        assertEquals("main.py", result.path);
        assertTrue(result.code.contains("новый текст"));
    }

    @Test public void explicitFenceFileWorksForMultiplePythonFiles() {
        PythonAutoStage.Selection result = PythonAutoStage.select(
                "Update script.py", "```python file=script.py\nprint('new')\n```",
                new String[] { "main.py", "script.py" });
        assertNotNull(result);
        assertEquals("script.py", result.path);
    }

    @Test public void nonCodeDiscussionNeverModifiesProject() {
        assertNull(PythonAutoStage.select("Расскажи, как работает Python",
                "```python\nprint('example')\n```", ONE_FILE));
        assertNull(PythonAutoStage.select("Не изменяй проект, просто покажи пример",
                "```python\nprint('example')\n```", ONE_FILE));
        assertNull(PythonAutoStage.select("Please do not modify any files",
                "```python\nprint('example')\n```", ONE_FILE));
    }

    @Test public void extraCommandAndOutputAreIgnoredAsCode() {
        PythonAutoStage.Selection result = PythonAutoStage.select("Исправь программу",
                "```python\n# main.py\nprint('ok')\n```\n"
                        + "```bash\npython main.py\n```\n```text\nok\n```",
                ONE_FILE);
        assertNotNull(result);
        assertEquals("main.py", result.path);
        assertFalse(result.code.contains("bash"));
    }

    @Test public void multiplePythonExamplesAreAmbiguous() {
        assertNull(PythonAutoStage.select("Измени программу",
                "```python\nprint(1)\n```\n```python\nprint(2)\n```", ONE_FILE));
    }

    @Test public void unclosedOrIncompleteResponseDoesNotStageCode() {
        assertNull(PythonAutoStage.select("Измени программу",
                "```python\n# main.py\nprint('broken')", ONE_FILE));
        assertNull(PythonAutoStage.select("Измени программу", "", ONE_FILE));
    }

    @Test public void ambiguousAndUnknownPathsNeverStage() {
        assertNull(PythonAutoStage.select("Измени программу", "```python\nprint('ok')\n```",
                new String[] { "main.py", "other.py" }));
        assertNull(PythonAutoStage.select("Измени программу",
                "```python file=unknown.py\nprint('ok')\n```", ONE_FILE));
        assertNull(PythonAutoStage.select("Измени программу",
                "```python file=main.py\n# other.py\nprint('ok')\n```",
                new String[] { "main.py", "other.py" }));
    }

    @Test public void invalidMixedFencesNeverGetAutoApplied() {
        assertNull(PythonAutoStage.select("Добавь проверку",
                "```python file=main.py\nprint('ok')\n```\n```bash\npython main.py\n```", ONE_FILE));
    }

    @Test public void supportedLanguagesExpressEditIntent() {
        for (String task : new String[] { "Создай калькулятор", "Write a calculator",
                "プログラムを修正して", "修改程序", "اكتب البرنامج" })
            assertTrue(task, PythonAutoStage.requested(task));
    }
}
