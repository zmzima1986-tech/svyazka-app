package app.svyazka.mobile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Stage 5: compare real Python output with an explicit USER-SUPPLIED result.
 * A successful process exit is never proof of functional correctness on its own.
 * No model-generated claim or model-generated test is accepted as an oracle.
 */
final class PythonAutoTests {
    private static final Pattern EXPECTED = Pattern.compile(
            "(?ium)^[ \t]*(?:ожидаемый вывод|expected output|预期输出|期待する出力|期待される出力|الناتج المتوقع)[ \t]*[:：][ \t]*(.*)$");
    private static final int MAX_EXPECTED = 512;
    private static final int MAX_DISPLAY = 240;
    private static final String KIND = "expected_stdout";

    private PythonAutoTests() { }

    static final class Assessment {
        final boolean checked, passed;
        final String expected, actual;
        private final SandboxClient.Result original;

        Assessment(boolean checked, boolean passed, String expected, String actual,
                   SandboxClient.Result original) {
            this.checked = checked;
            this.passed = passed;
            this.expected = expected;
            this.actual = actual;
            this.original = original;
        }

        SandboxClient.Result report(String note) {
            if (!checked) return original;
            JSONArray tests;
            try {
                tests = new JSONArray(original.tests.toString());
                tests.put(new JSONObject().put("kind", KIND).put("passed", passed)
                        .put("expected", expected).put("actual", actual));
            } catch (JSONException broken) {
                return original; // Do not manufacture a test result if JSON cannot be encoded.
            }
            // The runner's generic 'no tests' notice becomes incorrect once this
            // independent, user-specified output test has actually run.
            String status = original.status.replace(
                    "Код выполнен; корректность результата не доказана тестами.", "")
                    .replace("Код выполнен; независимые контрольные тесты не предоставлены.", "").trim();
            if (note != null && !note.isEmpty())
                status += (status.isEmpty() ? "" : "\n") + note;
            return new SandboxClient.Result(original.stdout, original.stderr, original.engine,
                    original.exitCode, status, original.html, original.pngBase64,
                    original.artifacts, tests, original.snapshotSha256, original.generatedTests, original.inputRequired);
        }
    }

    /**
     * Read a user-quoted literal, optionally followed by punctuation ending the
     * instruction (outside the closing quote). Punctuation inside the quotes is
     * part of the expected stdout and must remain significant. Unquoted values
     * are kept verbatim to avoid silently changing a user's test contract.
     */
    private static String expectedLiteral(String raw) {
        String value = raw.trim();
        if (value.length() < 2) return value;
        char closing;
        switch (value.charAt(0)) {
            case '«': closing = '»'; break;
            case '\"': closing = '\"'; break;
            case '\'': closing = '\''; break;
            case '“': closing = '”'; break;
            case '„': closing = '“'; break;
            case '「': closing = '」'; break;
            case '『': closing = '』'; break;
            case '《': closing = '》'; break;
            default: return value;
        }
        int end = value.length() - 1;
        // E.g. «Done». is prose; «Done.» includes the dot in stdout.
        char tail = value.charAt(end);
        if (tail == '.' || tail == '!' || tail == '?' || tail == '。' || tail == '۔') {
            end--;
            while (end > 0 && Character.isWhitespace(value.charAt(end))) end--;
        }
        if (end > 0 && value.charAt(end) == closing)
            return value.substring(1, end);
        return value; // Malformed quotes: never guess where the literal ends.
    }

    /** Only an explicit, unambiguous user stdout contract is a test oracle. */
    static String expectedOutput(String requirements) {
        if (requirements == null) return null;
        String expected = null;
        boolean inFence = false;
        for (String line : requirements.split("\\r?\\n", -1)) {
            if (line.trim().startsWith("```") || line.trim().startsWith("~~~")) {
                inFence = !inFence;
                continue;
            }
            if (inFence) continue;
            Matcher match = EXPECTED.matcher(line);
            if (!match.matches()) continue;
            String value = expectedLiteral(match.group(1));
            if (value.isEmpty() || value.length() > MAX_EXPECTED || value.indexOf('\r') >= 0)
                return null;
            if (expected != null && !expected.equals(value)) return null;
            expected = value;
        }
        return expected;
    }

    static Assessment evaluate(String requirements, SandboxClient.Result result) {
        if (result == null) throw new IllegalArgumentException("Missing Python result");
        if (result.exitCode == null || result.exitCode != 0 || requirements == null)
            return new Assessment(false, false, "", "", result);
        String expected = expectedOutput(requirements);
        if (expected == null) return new Assessment(false, false, "", "", result);
        String actual = result.stdout == null ? "" : result.stdout.replace("\r\n", "\n");
        if (actual.endsWith("\n")) actual = actual.substring(0, actual.length() - 1);
        return new Assessment(true, expected.equals(actual), expected, actual, result);
    }

    static boolean failed(SandboxClient.Result result) {
        if (result == null || result.tests == null) return false;
        for (int i = 0; i < result.tests.length(); i++) {
            JSONObject item = result.tests.optJSONObject(i);
            // The sandbox already runs independently saved tests.json cases.
            // Treat *all* real failed cases as failures, not just the stdout contract.
            if (item != null && !item.optBoolean("passed", false)) return true;
        }
        return false;
    }

    /** Exact failed test evidence to send to the next AI attempt (bounded). */
    static String failureDiagnostic(SandboxClient.Result output) {
        if (output == null || output.tests == null) return "";
        int failed = 0;
        StringBuilder details = new StringBuilder();
        for (int i = 0; i < output.tests.length(); i++) {
            JSONObject test = output.tests.optJSONObject(i);
            if (test == null || test.optBoolean("passed", false)) continue;
            failed++;
            if (failed > 3) continue;
            if (details.length() > 0) details.append("\n");
            details.append("Test ").append(i + 1);
            String name = test.optString("name", "");
            if (!name.isEmpty()) details.append(" (").append(display(name)).append(")");
            details.append(": expected ").append(display(test.optString("expected", "")));
            details.append("; actual ").append(display(test.optString("actual", "")));
            if (test.has("stdin")) details.append("; stdin ").append(display(test.optString("stdin", "")));
        }
        return failed == 0 ? "" : "Failed user-provided Python tests: " + failed + "\n" + details;
    }

    static String display(String value) {
        if (value == null || value.isEmpty()) return "∅";
        String shown = value.replace("\r", "\\r").replace("\n", "\\n");
        return shown.length() <= MAX_DISPLAY ? shown : shown.substring(0, MAX_DISPLAY) + "…";
    }
}
