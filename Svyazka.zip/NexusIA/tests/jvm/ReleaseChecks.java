package app.svyazka.mobile;

import java.io.BufferedReader;
import java.io.StringReader;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

public final class ReleaseChecks {
    private static int passed;

    private static void check(boolean valid, String name) {
        if (!valid) throw new AssertionError(name);
        passed++;
    }

    private static ModelClient.Reply stop(String text) {
        return new ModelClient.Reply(text, ModelClient.Finish.STOP, "");
    }

    private static ModelClient.Reply gemini(String events, List<String> text) {
        return ModelClient.parseGeminiStream(new BufferedReader(new StringReader(events)), text::add);
    }

    public static void main(String[] args) throws Exception {
        List<Workflow.Stage> team = Workflow.defaultStages();
        Workflow.Run old = new Workflow.Run("Рабочая задача", team).receive(stop("Решение"))
                .receive(stop("Проверено.\n[[REVIEW: PASS]]"));
        JSONObject legacy = old.toJson().put("version", 3);
        legacy.remove("mode");
        check(Workflow.Run.fromJson(legacy).mode == Workflow.Mode.TEAM
                && Workflow.Run.fromJson(legacy).nextStep() == Workflow.Step.REVISION,
                "legacy v3 with PASS can continue to final author");
        JSONObject skippedLegacy = new JSONObject(legacy.toString()).put("revision_skipped", true);
        check(Workflow.Run.fromJson(skippedLegacy).revisionSkipped()
                && Workflow.Run.fromJson(skippedLegacy).complete(),
                "already skipped historical v3 result stays readable");

        Workflow.Run quick = Workflow.Run.quick("Привет", ModelCatalog.NORTH, team.get(1));
        check(quick.nextIndex() == 0 && quick.stages.size() == 1, "one scheduled generation");
        Workflow.Run answered = quick.receive(stop("Привет!"));
        check(answered.complete() && answered.finalIndex() == 0 && answered.verdict() == Workflow.Verdict.INVALID,
                "quick result does not enter automatic review");
        Workflow.Run restored = Workflow.Run.fromJson(answered.toJson());
        check(restored.mode == Workflow.Mode.QUICK && restored.displayAnswer(0).equals("Привет!"),
                "quick mode saved with result");
        Workflow.Run repair = restored.addRepair(new Workflow.RepairInput(0, "raise ValueError()", "", "ValueError"));
        check(repair.nextIndex() == 1 && repair.nextStep() == Workflow.Step.REPAIR
                && repair.nextStage().model.id.equals(team.get(1).model.id), "quick run supports a requested repair");
        Workflow.Run repaired = Workflow.Run.fromJson(repair.receive(stop("print(1)")).toJson());
        check(repaired.complete() && repaired.finalIndex() == 1 && repaired.displayAnswer(1).equals("print(1)"),
                "quick repair saved as its own step");
        Workflow.Run unfinished = quick.receive(ModelClient.Reply.error("Частичный ответ", "обрыв", 429));
        check(Workflow.Run.fromJson(unfinished.toJson()).draft.text.equals("Частичный ответ"),
                "quick draft survives interruption");

        for (String marker : Arrays.asList("- ", "* ", "• ", "1. ", "2) ", "+ ", "— ")) {
            check(Workflow.Verdict.read(marker + "Нужно проверить ввод.\n[[REVIEW: FIX]]") == Workflow.Verdict.FIX,
                    "list marker recognized: " + marker);
        }
        check(Workflow.Verdict.read("```python\n- пример\n```\n[[REVIEW: FIX]]") == Workflow.Verdict.INVALID,
                "code fence is not a finding");
        check(Workflow.Verdict.read("- Настоящий пункт\n```\n[[REVIEW: FIX]]") == Workflow.Verdict.INVALID,
                "verdict inside unclosed code fence is rejected");
        check(Workflow.Verdict.read("Объяснение\n- \n[[REVIEW: FIX]]") == Workflow.Verdict.INVALID,
                "empty bullet cannot trigger revision");

        long now = Instant.parse("2026-11-17T10:00:00Z").toEpochMilli();
        check(RequestFailure.parseRetryAfter("30", now) == now + 30_000, "numeric Retry-After");
        check(RequestFailure.parseRetryAfter("Tue, 17 Nov 2026 10:00:30 GMT", now) == now + 30_000, "date Retry-After");
        check(RequestFailure.parseRetryAfter("99999999999999999", now) == 0
                && RequestFailure.parseRetryAfter("do not guess", now) == 0, "invalid or overflowing header ignored");
        JSONObject tpmError = new JSONObject().put("message",
                "Rate limit exceeded: TPM 8000; requested 9013 tokens");
        RequestFailure tpm = RequestFailure.read(413, tpmError, null, now);
        check(tpm.reason == RequestFailure.Reason.TOKEN_RATE_LIMIT,
                "413 TPM is not mislabeled as context length");
        check(ModelPool.shouldTryNext(ModelClient.Reply.error("", "TPM", tpm)),
                "token-per-minute rejection may try a different provider");
        JSONObject contextError = new JSONObject().put("message", "Maximum context length exceeded");
        check(RequestFailure.read(413, contextError, null, now).reason
                        == RequestFailure.Reason.CONTEXT_LIMIT,
                "actual context limit is separate from TPM");
        check(RequestFailure.read(413, new JSONObject().put("message", "Request too large"), null, now).reason
                        == RequestFailure.Reason.REQUEST_SIZE,
                "ambiguous 413 is not invented as a specific limit");
        RequestFailure route = RequestFailure.read(429,
                new JSONObject().put("metadata", new JSONObject().put("provider_name", "test")), "30", now);
        ModelPool.Cooldowns cooldown = new ModelPool.Cooldowns();
        List<ModelCatalog.Model> pool = Arrays.asList(ModelCatalog.NEMOTRON, ModelCatalog.LING, ModelCatalog.GROQ_20B);
        cooldown.record(ModelCatalog.NEMOTRON, route, now);
        check(cooldown.next(pool, 0, now) == 1 && cooldown.next(pool, 0, now + 30_000) == 0,
                "upstream rate limit affects one route and expires");
        RequestFailure quota = RequestFailure.of(429).dailyQuota(now);
        cooldown.record(ModelCatalog.LING, quota, now);
        check(cooldown.next(pool, 0, now) == 2
                && quota.retryAt == Instant.parse("2026-11-18T00:00:00Z").toEpochMilli(),
                "confirmed daily quota skips same-provider alternatives");
        check(ModelClient.routerDailyQuotaExhausted(new JSONObject(
                "{\"data\":{\"free_model_daily_requests\":{\"limit\":50,\"remaining\":0}}}"))
                && !ModelClient.routerDailyQuotaExhausted(new JSONObject("{\"data\":{}}")),
                "daily exhaustion needs explicit account data");
        RequestFailure missingModel = RequestFailure.read(404,
                new JSONObject().put("message", "No endpoints found for example/model:free"), null, now);
        check(ModelPool.shouldTryNext(ModelClient.Reply.error("", "", missingModel)),
                "model-specific 404 continues on another model");
        check(!ModelPool.shouldTryNext(ModelClient.Reply.error("", "Unknown URL", 404)),
                "generic 404 is not silently retried");
        for (int status : Arrays.asList(0, 408, 429, 503, 504)) {
            check(ModelPool.shouldTryNext(ModelClient.Reply.error("", "Temporary problem", status)),
                    "fallback is allowed for status " + status);
        }
        check(!ModelPool.shouldTryNext(ModelClient.Reply.error("", "Invalid credentials", 401))
                && !ModelPool.shouldTryNext(stop("Готовый ответ")),
                "authentication failures and successful answers do not trigger reserve");

        List<String> visible = new ArrayList<>();
        String g1 = "data: {\"candidates\":[{\"content\":{\"parts\":["
                + "{\"text\":\"private thought\",\"thought\":true},{\"text\":\"Первый \"}]}}]}\n\n";
        String g2 = "data: {\"candidates\":[{\"content\":{\"parts\":[{\"text\":\"ответ\"}]},"
                + "\"finishReason\":\"STOP\"}]}\n\n";
        ModelClient.Reply streamed = gemini(g1 + g2, visible);
        check(streamed.finish == ModelClient.Finish.STOP && streamed.text.equals("Первый ответ")
                && visible.get(0).equals("Первый "), "Gemini chunks shown, thought excluded");
        check(gemini(g1, new ArrayList<>()).text.equals("Первый ")
                && gemini(g1, new ArrayList<>()).finish == ModelClient.Finish.ERROR,
                "Gemini interruption preserves visible partial");
        check(gemini(g1 + "data: {\"candidates\":[{\"finishReason\":\"MAX_TOKENS\"}]}\n\n",
                new ArrayList<>()).finish == ModelClient.Finish.LENGTH, "Gemini token limit preserves draft");
        check(gemini(g1 + "data: {\"error\":{\"code\":429,\"message\":\"limited\"}}\n\n",
                new ArrayList<>()).status == 429, "Gemini streamed rate limit remains typed");
        ModelClient.Reply rejected = gemini("data: {\"promptFeedback\":{\"blockReason\":\"SAFETY\"}}\n\n",
                new ArrayList<>());
        check(rejected.finish == ModelClient.Finish.ERROR && !ModelPool.shouldTryNext(rejected),
                "Gemini explicit rejection does not start a reserve");

        Deque<Runnable> queue = new ArrayDeque<>();
        Map<String, Object> prefs = new LinkedHashMap<>();
        prefs.put("stages", "roles");
        prefs.put("selected_mode", "QUICK");
        prefs.put("key.OPENROUTER", "opaque");
        WorkspaceStore store = new WorkspaceStore(new WorkspaceStore.State("до очистки", old, true, "[{}]"),
                queue::addLast, changes -> {
                    changes.forEach((key, value) -> {
                        if (value == null) prefs.remove(key);
                        else prefs.put(key, value);
                    });
                    return true;
                });
        long owner = store.attach();
        store.save(owner, store.current(), saved -> check(saved, "first saved"));
        queue.removeFirst().run();
        store.save(owner, new WorkspaceStore.State("черновик", unfinished, false, "[{}]"), saved -> {});
        store.clear(owner, saved -> check(saved, "clear confirmation from disk"));
        long newOwner = store.attach();
        store.save(owner, new WorkspaceStore.State("запоздалый ответ", old, true, "[{}]"), saved -> {});
        while (!queue.isEmpty()) queue.removeFirst().run();
        check(store.current().run == null && store.current().task.isEmpty()
                && !prefs.containsKey("run") && !prefs.containsKey("draft")
                && !prefs.containsKey("results_visible") && !prefs.containsKey("attempt_log"),
                "clear wins against pending save and expired Activity");
        check(prefs.size() == 3 && "roles".equals(prefs.get("stages")) && "opaque".equals(prefs.get("key.OPENROUTER")),
                "clear does not delete settings or keys");
        store.save(newOwner, new WorkspaceStore.State("новый вопрос", null, false, ""),
                saved -> check(saved, "new task written after clear"));
        while (!queue.isEmpty()) queue.removeFirst().run();
        check("новый вопрос".equals(prefs.get("draft")) && !prefs.containsKey("run"),
                "new work starts from empty state");

        WorkspaceStore.State beforeFailure = new WorkspaceStore.State("сохранённый черновик", old, true, "[{}]");
        WorkspaceStore failureStore = new WorkspaceStore(beforeFailure, Runnable::run, changes -> false);
        long failingOwner = failureStore.attach();
        final boolean[] failureReported = {false};
        failureStore.clear(failingOwner, saved -> failureReported[0] = !saved);
        check(failureReported[0] && failureStore.current() == beforeFailure,
                "disk failure preserves workspace in memory");

        System.out.println(passed + " release checks passed");
    }
}
