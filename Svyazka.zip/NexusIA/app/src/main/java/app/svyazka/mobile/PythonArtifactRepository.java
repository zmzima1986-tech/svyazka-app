package app.svyazka.mobile;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Durable artifact catalog, independent of the chat database and API providers. */
final class PythonArtifactRepository extends SQLiteOpenHelper {
    private static final String DATABASE = "nexus_python_artifacts.db";
    private static final String DEFAULT_TITLE = "Python-проект";

    PythonArtifactRepository(Context context) {
        super(context.getApplicationContext(), DATABASE, null, 1);
    }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "title TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, "
                + "legacy_chat_id INTEGER UNIQUE, deleted INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE chat_projects (chat_id INTEGER PRIMARY KEY, "
                + "project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX projects_recent ON projects(deleted, updated_at DESC)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        throw new IllegalStateException("Unknown artifact database schema: " + oldVersion);
    }

    private static long insert(SQLiteDatabase db, String title, Long legacyChatId) {
        long now = System.currentTimeMillis();
        ContentValues row = new ContentValues();
        row.put("title", title);
        row.put("created_at", now);
        row.put("updated_at", now);
        if (legacyChatId != null) row.put("legacy_chat_id", legacyChatId);
        return db.insertOrThrow("projects", null, row);
    }

    private long linkedProject(SQLiteDatabase db, long chatId) {
        try (Cursor cursor = db.rawQuery("SELECT p.id FROM chat_projects c "
                + "JOIN projects p ON p.id=c.project_id WHERE c.chat_id=? AND p.deleted=0",
                new String[]{Long.toString(chatId)})) {
            return cursor.moveToFirst() ? cursor.getLong(0) : 0;
        }
    }

    synchronized long forChat(long chatId) {
        return chatId <= 0 ? 0 : linkedProject(getReadableDatabase(), chatId);
    }

    private static void link(SQLiteDatabase db, long chatId, long projectId) {
        ContentValues values = new ContentValues();
        values.put("chat_id", chatId);
        values.put("project_id", projectId);
        db.insertWithOnConflict("chat_projects", null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    /** Only an actual file creation causes a chat's first project to be allocated. */
    synchronized long ensureForChat(long chatId) {
        if (chatId <= 0) throw new IllegalArgumentException("Missing chat ID");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long result = linkedProject(db, chatId);
            if (result == 0) {
                result = insert(db, DEFAULT_TITLE, null);
                link(db, chatId, result);
            }
            db.setTransactionSuccessful();
            return result;
        } finally {
            db.endTransaction();
        }
    }

    synchronized long createUnlinked() {
        return insert(getWritableDatabase(), DEFAULT_TITLE, null);
    }

    /** Explicit, reversible chat-to-project association. Projects may belong to many chats.
     * An unrelated chat never acquires ownership of project files. */
    synchronized boolean attachChat(long chatId, long projectId) {
        if (chatId <= 0 || projectId <= 0) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            try (Cursor cursor = db.rawQuery(
                    "SELECT 1 FROM projects WHERE id=? AND deleted=0",
                    new String[]{Long.toString(projectId)})) {
                if (!cursor.moveToFirst()) return false;
            }
            ContentValues row = new ContentValues();
            row.put("chat_id", chatId);
            row.put("project_id", projectId);
            if (db.insertWithOnConflict("chat_projects", null, row,
                    SQLiteDatabase.CONFLICT_REPLACE) == -1) return false;
            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }

    /** A tombstone is retained if an imported artifact was deleted, preventing re-import. */
    synchronized long registerLegacy(long chatId, boolean chatExists, String title) {
        if (chatId <= 0) throw new IllegalArgumentException("Invalid legacy chat ID");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long project = 0;
            boolean deleted = false;
            try (Cursor cursor = db.rawQuery("SELECT id, deleted FROM projects WHERE legacy_chat_id=?",
                    new String[]{Long.toString(chatId)})) {
                if (cursor.moveToFirst()) {
                    project = cursor.getLong(0);
                    deleted = cursor.getInt(1) != 0;
                }
            }
            if (deleted) {
                db.setTransactionSuccessful();
                return 0;
            }
            if (project == 0) project = insert(db, title, chatId);
            if (chatExists) link(db, chatId, project);
            db.setTransactionSuccessful();
            return project;
        } finally {
            db.endTransaction();
        }
    }

    /** Restore catalog rows for actual artifact files after an interrupted index write.
     * Explicit deletion tombstones are never restored, even if file cleanup failed. */
    synchronized void recoverSavedFiles(PythonProjectStore files) {
        SQLiteDatabase db = getWritableDatabase();
        for (long id : files.savedTaskIds()) {
            try (Cursor cursor = db.rawQuery("SELECT 1 FROM projects WHERE id=?",
                    new String[]{Long.toString(id)})) {
                if (cursor.moveToFirst()) continue; // Includes deliberate deletion tombstones.
            }
            ContentValues recovered = new ContentValues();
            long now = System.currentTimeMillis();
            recovered.put("id", id);
            recovered.put("title", "Восстановленный Python-проект");
            recovered.put("created_at", now);
            recovered.put("updated_at", now);
            db.insertWithOnConflict("projects", null, recovered, SQLiteDatabase.CONFLICT_IGNORE);
        }
    }

    synchronized boolean exists(long id) {
        if (id <= 0) return false;
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT 1 FROM projects WHERE id=? AND deleted=0", new String[]{Long.toString(id)})) {
            return cursor.moveToFirst();
        }
    }

    synchronized boolean touch(long id, String path) {
        if (id <= 0) return false;
        SQLiteDatabase db = getWritableDatabase();
        android.database.sqlite.SQLiteStatement statement = db.compileStatement(
                "UPDATE projects SET updated_at=?, title=CASE WHEN title=? THEN ? ELSE title END "
                        + "WHERE id=? AND deleted=0");
        try {
            statement.bindLong(1, System.currentTimeMillis());
            statement.bindString(2, DEFAULT_TITLE);
            statement.bindString(3, "Python · " + path);
            statement.bindLong(4, id);
            return statement.executeUpdateDelete() == 1;
        } finally {
            statement.close();
        }
    }

    synchronized List<NexusArtifact> list(PythonProjectStore files) {
        List<NexusArtifact> result = new ArrayList<>();
        Set<Long> saved = new HashSet<>();
        for (long id : files.savedTaskIds()) saved.add(id);
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id, title, updated_at FROM projects WHERE deleted=0 "
                        + "ORDER BY updated_at DESC, id DESC", null)) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(0);
                if (!saved.contains(id)) continue; // Never display a failed, empty allocation.
                int count = 0;
                try { count = files.paths(id).length; }
                catch (IOException ignored) { /* Keep a damaged saved artifact visible for diagnosis. */ }
                result.add(new NexusArtifact(id, cursor.getString(1), cursor.getLong(2), count));
            }
        }
        return result;
    }

    synchronized boolean rename(long id, String name) {
        String title = name == null ? "" : name.trim();
        if (id <= 0 || title.isEmpty() || title.length() > 100) return false;
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("updated_at", System.currentTimeMillis());
        return getWritableDatabase().update("projects", values, "id=? AND deleted=0",
                new String[]{Long.toString(id)}) == 1;
    }

    synchronized void unlinkChat(long chatId) {
        if (chatId > 0) getWritableDatabase().delete("chat_projects", "chat_id=?",
                new String[]{Long.toString(chatId)});
    }

    synchronized boolean delete(long id) {
        if (id <= 0) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put("deleted", 1);
            int changed = db.update("projects", values, "id=? AND deleted=0",
                    new String[]{Long.toString(id)});
            if (changed != 1) return false;
            db.delete("chat_projects", "project_id=?", new String[]{Long.toString(id)});
            db.setTransactionSuccessful();
            return true;
        } finally {
            db.endTransaction();
        }
    }
}
