/** Run the shipped JS controller, worker, grader and WASM using Node worker_threads. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Worker as NodeWorker, MessageChannel, parentPort, workerData } from 'node:worker_threads';
import { spawnSync } from 'node:child_process';

const tests = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(tests);
if (parentPort) {
    let callback;
    parentPort.on('message', message => callback({data: message.data, ports: message.ports}));
    globalThis.self = {addEventListener(event, listener) {
        assert.equal(event, 'message');
        callback = listener;
        parentPort.postMessage('listening');
    }};
    const systemFetch = globalThis.fetch;
    globalThis.fetch = (url, ...options) => {
        if (url === './verify.py' || url === './workspace.py') return Promise.resolve(new Response(fs.readFileSync(path.join(workerData,url.slice(2)))));
        if (/^https?:/.test(String(url))) throw Error('Unexpected external fetch');
        return systemFetch(url,...options);
    };
    await import(pathToFileURL(path.join(workerData,'worker.mjs')));
} else {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-python-'));
    const source = path.join(root,'app/src/main/assets/sandbox');
    const copy = path.join(tmp,'sandbox');
    fs.cpSync(source,copy,{recursive:true});
    const command = (name,args) => {
        const home = process.env.JAVA_HOME;
        const result = spawnSync(home ? path.join(home,'bin',name) : name,args,{encoding:'utf8'});
        assert.equal(result.status,0,result.error?.message || result.stderr);
    };
    const wasm = 'pyodide/pyodide.asm.wasm';
    fs.unlinkSync(path.join(copy,wasm));
    command('javac',['-d',tmp,path.join(tests,'jvm/CappedWasm.java'),path.join(root,'app/src/main/java/app/svyazka/mobile/VerificationMemory.java')]);
    command('java',['-cp',tmp,'app.svyazka.mobile.CappedWasm',path.join(source,wasm),path.join(copy,wasm)]);
    const activeWorkers = new Set();
    globalThis.Worker = class {
        constructor(script) {
            assert.equal(script,'worker.mjs');
            this.w = new NodeWorker(new URL(import.meta.url),{workerData:copy});
            activeWorkers.add(this.w);
            this.w.once('exit', () => activeWorkers.delete(this.w));
            this.w.on('error', error => {console.error(error); this.onerror?.(error);});
        }
        postMessage(data,ports) {this.w.once('message',()=>this.w.postMessage({data,ports},ports));}
        terminate() {this.w.terminate();}
    };
    let start;
    globalThis.window = {addEventListener(_,fn) {start=fn;}};
    await import(pathToFileURL(path.join(copy,'runner.js')));
    async function run(data) {
        const {port1,port2} = new MessageChannel(), events = [];
        return new Promise((resolve,reject) => {
            const timer=setTimeout(()=>{
                port1.close(); port2.close();
                reject(Error('outer deadline'));
            },45000);
            port1.onmessage=({data: output})=>{
                const msg=JSON.parse(output);
                if(msg.progress) events.push(msg.progress);
                else {clearTimeout(timer);port1.close();port2.close();resolve({msg,events});}
            };
            start({ports:[port2],data:JSON.stringify(data)});
        });
    }
    let count=0;
    async function verify(label,code,status,inputs={}) {
        const {msg,events}=await run({mode:'verify',code,...inputs});
        if(status==='TIMEOUT') assert.match(msg.status??'',/5 секунд/,JSON.stringify(msg));
        else assert.equal(msg.verification?.status,status,label+' '+JSON.stringify(msg));
        if(['PASSED','RAN'].includes(status)) {
            assert.equal(events[0].stage,'syntax');assert.equal(events.at(-1).stage,'executed');
        }
        count++;console.log(label,status);
        return msg.verification;
    }
    try {
      if (process.env.NEXUS_ONLY_MANUAL !== '1') {
        const specs=[JSON.stringify([{function:'diff',args:[0,-2],expected:2},{function:'diff',args:[3,0],expected:3}])];
        const good=await verify('independent boundary cases','def diff(a,b):\n return a-b','PASSED',{specs});
        assert.equal(good.passed,2);
        await verify('wrong result','def diff(a,b):\n return a+b','ERROR',{specs});
        await verify('syntax','def bad(:\n pass','ERROR');
        await verify('no oracle','print(3)','RAN');
        const calculator = fs.readFileSync(path.join(tests,'fixtures/recovery/observed-calculator.py'),'utf8');
        const calculatorResult = await verify('observed calculator repair',calculator,'RAN');
        assert.match(calculatorResult.diagnostic,/assert без ошибок: 10/);
        assert.equal(calculatorResult.total,0);
        const integerCalculator = fs.readFileSync(path.join(tests,'fixtures/recovery/observed-calculator-is-integer.py'),'utf8');
        const integerResult = await verify('calculator float.is_integer',integerCalculator,'RAN');
        assert.match(integerResult.diagnostic,/assert без ошибок: 10/);
        assert.equal(integerResult.total,0);
        const transcriptAnswer = fs.readFileSync(path.join(tests,'fixtures/recovery/observed-console-transcript.md'),'utf8');
        const transcriptCode = transcriptAnswer.split('```python\n')[1].split('\n```')[0]+'\n';
        const transcriptResult = await verify('observed console transcript source',transcriptCode,'RAN');
        assert.match(transcriptResult.diagnostic,/assert без ошибок: 6/);
        assert.equal(transcriptResult.total,0);
        await verify('broad catch cannot hide file boundary',"try:\n    open('private.txt')\nexcept Exception:\n    pass\nprint('ok')",'LIMITED');
        const integerCases = await verify('float.is_integer independent inputs',
            'print((2.0).is_integer(), (2.5).is_integer())','PASSED',
            {specs:['[{"stdin":"","stdout":"True False"}]']});
        assert.equal(integerCases.passed,1);
        await verify('clock and leap calendar', "import calendar\nfrom datetime import datetime\nprint(calendar.monthrange(2024, 2)[1], 0 <= datetime.now().hour < 24)", 'PASSED',
            {specs:['[{"stdin":"","stdout":"29 True"}]']});
        const desktop = await verify('desktop and BLE', 'import sys, tkinter, bleak, requests', 'LIMITED');
        assert.equal(desktop.category,'ENVIRONMENT_UNSUPPORTED'); assert.equal(desktop.ran,false);
        for (const module of ['tkinter','bleak','requests']) assert.ok(desktop.diagnostic.includes(module));
        await verify('dependency','from neo4j import GraphDatabase','LIMITED');
        await verify('file boundary',"open('other.txt').read()",'LIMITED');
        await verify('attached data',"print(open('data.txt').read().strip())",'PASSED',
            {files:{'data.txt':'17\n'},specs:['[{"stdin":"","stdout":"17"}]']});
        await verify('incomplete','def f():\n ...','ERROR');
        await verify('memory',"a='x' * 150_000_000",'LIMITED');
        await verify('deadline','while True:\n pass','TIMEOUT');
        await verify('worker after timeout','print(int(input())+1)','PASSED',{examples:'Ввод: 0\nВывод: 1'});
      }
        if (process.env.NEXUS_ONLY_VERIFY !== '1') {
        for (const name of ['observed-expenses-project.md','observed-expenses-comment-header.md','observed-review-interruption.json']) {
            const raw = fs.readFileSync(path.resolve('tests/fixtures/recovery',name),'utf8');
            const fixture = name.endsWith('.json') ? JSON.parse(raw).answers[0].text : raw;
            const bundle = {};
            const blocks = name.includes('comment-header') || name.endsWith('.json')
                ? Array.from(fixture.matchAll(/^```python\n((?:# file=([^\n]+)\n)[\s\S]*?)^```/gm), m=>[m[0],m[2],m[1]])
                : fixture.matchAll(/```file=([^\n]+)\n([\s\S]*?)^```/gm);
            for (const match of blocks) {
                if (!match[2].trim()) continue;
                if (bundle[match[1]]) assert.equal(bundle[match[1]], match[2]);
                bundle[match[1]] = match[2];
            }
            assert.equal(Object.keys(bundle).length,3);
            const syntax = await run({mode:'verify',code:'',project_sources:bundle,reason:'syntax only'});
            assert.equal(syntax.msg.verification?.syntax,true,JSON.stringify(syntax.msg));
            assert.equal(syntax.msg.verification?.ran,false);
            const encoded = Object.fromEntries(Object.entries(bundle).map(([k,v])=>[k,Buffer.from(v).toString('base64')]));
            const project = await run({code:bundle['main.py'], entry:'main.py', files:encoded, project_tests:true});
            assert.equal(project.msg.code,0,JSON.stringify(project.msg));
            assert.equal(project.msg.generated_tests?.passed,10,JSON.stringify(project.msg));
            assert.equal(project.msg.generated_tests?.status,'PASSED');
            assert.equal(project.msg.tests.length,0);
            console.log(name+': syntax and 10 generated unittest cases PASS');
        }
        // Replay both complete responses to the actually interrupted independent task.
        const interrupted = JSON.parse(fs.readFileSync(path.join(tests,'fixtures/recovery/observed-independent-password.json'),'utf8'));
        for (const [index, attempt] of interrupted.draft.preceding_sources.entries()) {
            const bundle = Object.fromEntries(Array.from(attempt.text.matchAll(/^```python\n((?:# file=([^\n]+)\n)[\s\S]*?)^```/gm), m => [m[2],m[1]]));
            assert.equal(Object.keys(bundle).length,2);
            const syntax = await run({mode:'verify',code:'',project_sources:bundle,reason:'syntax only'});
            assert.equal(syntax.msg.verification?.syntax,true,JSON.stringify(syntax.msg));
            assert.equal(syntax.msg.verification?.ran,false);
            const entry = 'password_generator.py';
            const encoded = Object.fromEntries(Object.entries(bundle).map(([k,v])=>[k,Buffer.from(v).toString('base64')]));
            const project = await run({code:bundle[entry],entry,files:encoded,project_tests:true});
            assert.equal(project.msg.code,0,JSON.stringify(project.msg));
            assert.equal(project.msg.generated_tests?.passed,5,JSON.stringify(project.msg));
            assert.equal(project.msg.generated_tests?.status,'PASSED');
            assert.equal(project.msg.tests.length,0);
            console.log(`observed independent recovery ${index+1}: syntax and 5 generated unittest cases PASS`);
        }
        const single = fs.readFileSync(path.join(tests,'fixtures/recovery/observed-single-password.py'),'utf8');
        const eligible = await run({mode:'verify',code:single});
        assert.equal(eligible.msg.verification?.workspace_eligible,true,JSON.stringify(eligible.msg));
        assert.equal(eligible.msg.verification?.ran,false);
        for (const [code, expected] of [[single,0],[single.replace('self.assertEqual(len(pwd), 10)','self.assertEqual(len(pwd), 11)'),1]]) {
            const checked = await run({code,entry:'main.py',files:{'main.py':Buffer.from(code).toString('base64')},project_tests:true});
            assert.equal(checked.msg.code,expected,JSON.stringify(checked.msg));
            assert.equal(checked.msg.generated_tests?.discovered,5,JSON.stringify(checked.msg));
            assert.equal(checked.msg.generated_tests?.passed,expected === 0 ? 5 : 4,JSON.stringify(checked.msg));
            assert.equal(checked.msg.tests.length,0);
            assert.match(checked.msg.stderr, /Ran 5 tests/);
            console.log('observed single-file unittest suite: '+(expected === 0 ? '5/5 PASS' : 'correctly failed'));
        }
        const badSuite = await run({code:'print(1)', entry:'main.py', project_tests:true, files:{
            'test_bad.py':Buffer.from('import unittest\nclass T(unittest.TestCase):\n def test_bad(self): self.assertEqual(1,2)\n').toString('base64'),
            'tests.json':Buffer.from('[{"stdin":"","stdout":"1"}]').toString('base64'),
        }});
        assert.equal(badSuite.msg.code,1,JSON.stringify(badSuite.msg));
        assert.equal(badSuite.msg.generated_tests?.failed,1);
        assert.equal(badSuite.msg.tests.length,0);
        console.log('failed generated unittest is not PASS; generated tests.json not independent: PASS');
        if (process.env.NEXUS_ONLY_PROJECT !== '1') {
        fs.copyFileSync(path.join(source,wasm),path.join(copy,wasm));
        const manual=await run({code:'print(int(input())+2)',stdin:'5',allow_matplotlib:false});
        assert.equal(manual.msg.code,0,JSON.stringify(manual.msg));assert.equal(manual.msg.stdout,'7\n');
        // Stage 1 (ART-T04 file path): an already-closed graph is represented by
        // a PNG file, not by Matplotlib's registry of open figures.
        const tinyPng = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC';
        const savedPng = await run({
            code: `import base64\nwith open('chart.png', 'wb') as f: f.write(base64.b64decode('${tinyPng}'))\nprint('saved')`,
            stdin: '', allow_matplotlib: false,
        });
        assert.equal(savedPng.msg.code, 0, JSON.stringify(savedPng.msg));
        assert.equal(savedPng.msg.image_png, tinyPng);
        assert.equal(savedPng.msg.stdout, 'saved\n');
        const damagedPng = await run({
            code: `with open('chart.png', 'wb') as f: f.write(b'not a png')\nprint('ok')`,
            stdin: '', allow_matplotlib: false,
        });
        assert.equal(damagedPng.msg.code, 0);
        assert.equal(damagedPng.msg.image_png, '');
        const oversizedPng = await run({
            code: `with open('chart.png', 'wb') as f: f.write(b'\\x89PNG\\r\\n\\x1a\\n'+b'0'*420001)\nprint('ok')`,
            stdin: '', allow_matplotlib: false,
        });
        assert.equal(oversizedPng.msg.code, 0);
        assert.equal(oversizedPng.msg.image_png, '');
        const noPicture = await run({code: 'print(4)', stdin: '', allow_matplotlib: false});
        assert.equal(noPicture.msg.image_png, '');
        const memoryOnly = await run({
            code: 'from io import BytesIO\n# fig.savefig(BytesIO())\nprint(3)',
            stdin: '', allow_matplotlib: false,
        });
        assert.equal(memoryOnly.msg.image_png, '');
        assert.match(memoryOnly.msg.status, /BytesIO/);
        const b64 = text => Buffer.from(text,'utf8').toString('base64');
        const withProject = await run({code:
            "from utils import doubled\nimport json\nprint(doubled(8))\nopen('report.json','w').write(json.dumps({'ok': True}))",
            stdin:'',entry:'main.py',files:{
                'utils.py':b64('def doubled(x):\n    return 2*x\n'),
                'data.csv':b64('number\n8\n'),
                'tests.json':b64(JSON.stringify([
                    {name:'expect 16',stdin:'',stdout:'16'},
                    {name:'detect wrong expectation',stdin:'',stdout:'17'},
                ])),
            },package:'',extended:false});
        assert.equal(withProject.msg.code,0,JSON.stringify(withProject.msg));
        assert.equal(withProject.msg.stdout,'16\n');
        assert.match(withProject.msg.snapshot_sha256,/^[0-9a-f]{64}$/);
        assert.deepEqual(withProject.msg.tests.map(t=>t.passed),[true,false]);
        const otherEntry = await run({code:'print(20)',stdin:'',entry:'test04.py',files:{
            'main.py':b64('print(16)'),
            'tests.json':b64(JSON.stringify([{name:'main only',stdin:'',stdout:'16'}])),
        }});
        assert.equal(otherEntry.msg.code,0,JSON.stringify(otherEntry.msg));
        assert.equal(otherEntry.msg.stdout,'20\n');
        assert.equal(otherEntry.msg.tests.length,0,'Unrelated main.py tests must not run for test04.py');
        assert.match(otherEntry.msg.status,/независимые контрольные тесты не предоставлены/i);
        assert.ok(withProject.msg.artifacts.some(a=>a.name==='report.json'));
        const projectEntry = withProject.msg.artifacts.find(a=>a.name==='report.json');
        assert.equal(JSON.parse(Buffer.from(projectEntry.data,'base64').toString('utf8')).ok,true);
        const traversal = await run({code:'print(9)',stdin:'',files:{'../secret.py':b64('print(4)')}});
        assert.match(traversal.msg.error,/Проект отклонён/);
        const extraFile = await run({code:`import base64\n`+
            `open('a.png','wb').write(base64.b64decode('${tinyPng}'))\n`+
            `open('b.png','wb').write(base64.b64decode('${tinyPng}'))`,stdin:''});
        assert.equal(extraFile.msg.artifacts.filter(x=>x.mime==='image/png').length,2);
        console.log(count+' automatic executions, 6 baseline manual + 4 project runs: PASS');
        }
        }
        if (process.env.NEXUS_ONLY_VERIFY === '1') console.log(count+' automatic verification checks: PASS');
    } finally {
        await Promise.allSettled([...activeWorkers].map(worker => worker.terminate()));
        fs.rmSync(tmp,{recursive:true,force:true});
    }
}
