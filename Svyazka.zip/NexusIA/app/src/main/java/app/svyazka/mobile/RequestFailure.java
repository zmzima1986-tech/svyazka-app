package app.svyazka.mobile;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import org.json.JSONObject;

final class RequestFailure {
    enum Reason { UNKNOWN, ROUTE, DAILY_QUOTA, MODEL_UNAVAILABLE, RESPONSE_REJECTED,
        TOKEN_RATE_LIMIT, CONTEXT_LIMIT, REQUEST_SIZE, RESPONSE_LIMIT }

    final int status;
    final Reason reason;
    final long retryAt;

    RequestFailure(int status, Reason reason, long retryAt) {
        this.status = status;
        this.reason = reason;
        this.retryAt = retryAt;
    }

    static RequestFailure of(int status) { return new RequestFailure(status, Reason.UNKNOWN, 0); }

    static RequestFailure read(int status, JSONObject error, String retryAfter, long now) {
        String message = error == null ? "" : error.optString("message").toLowerCase(Locale.ROOT).trim();
        String code = error == null ? "" : error.optString("code");
        JSONObject metadata = error == null ? null : error.optJSONObject("metadata");
        Reason reason = classify(status, error);
        if (status == 404 && ("model_not_found".equals(code)
                || message.startsWith("no endpoints found for ")
                || message.startsWith("no endpoint found for model "))) {
            reason = Reason.MODEL_UNAVAILABLE;
        } else if (reason == Reason.UNKNOWN && (status == 429 || status == 503) && metadata != null
                && !metadata.isNull("provider_name")
                && !metadata.optString("provider_name", "").trim().isEmpty()) {
            reason = Reason.ROUTE;
        }
        return new RequestFailure(status, reason, parseRetryAfter(retryAfter, now));
    }

    static Reason classify(int status, JSONObject error) {
        if (error == null) return Reason.UNKNOWN;
        JSONObject metadata = error.optJSONObject("metadata");
        String details = (error.optString("message", "") + " " + error.optString("code", "")
                + " " + (metadata == null ? "" : metadata.optString("raw", "")))
                .toLowerCase(Locale.ROOT);
        // Provider-defined TPM is not the same as model context-window length.
        boolean tokenRate = details.contains("tpm") || details.contains("tokens per minute")
                || details.contains("tokens/min") || details.contains("token per minute")
                || details.contains("per-minute token") || details.contains("per minute token")
               ;
        if (tokenRate && (status == 413 || status == 429)) return Reason.TOKEN_RATE_LIMIT;
        if (status == 413) {
            if (details.contains("context window") || details.contains("context length")
                    || details.contains("maximum context") || details.contains("context limit")
                   ) return Reason.CONTEXT_LIMIT;
            if (details.contains("too large") || details.contains("payload size") || details.contains("body size")
                    || details.contains("maximum request size")) return Reason.REQUEST_SIZE;
            return Reason.UNKNOWN;
        }
        if (status == 429 && (details.contains("daily quota") || details.contains("requests per day")
                || details.contains("tokens per day") || details.contains("per-day"))) return Reason.DAILY_QUOTA;
        return Reason.UNKNOWN;
    }

    RequestFailure dailyQuota(long now) {
        long reset = java.time.Instant.ofEpochMilli(now).atZone(ZoneOffset.UTC).toLocalDate()
                .plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
        return new RequestFailure(status, Reason.DAILY_QUOTA, Math.max(retryAt, reset));
    }

    RequestFailure unavailable() {
        return new RequestFailure(status, Reason.MODEL_UNAVAILABLE, retryAt);
    }

    static long parseRetryAfter(String value, long now) {
        if (value == null) return 0;
        String header = value.trim();
        try {
            long time = header.matches("[0-9]+")
                    ? Math.addExact(now, Math.multiplyExact(Long.parseLong(header), 1000))
                    : ZonedDateTime.parse(header, DateTimeFormatter.RFC_1123_DATE_TIME)
                            .toInstant().toEpochMilli();
            return time > now ? time : 0;
        } catch (java.time.DateTimeException | ArithmeticException | NumberFormatException e) {
            return 0;
        }
    }
}
