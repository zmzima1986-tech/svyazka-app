"""Replay the captured provider response, parser and local project runner.
Pure parser methods are compiled unchanged, without Android or org.json.
The full Workflow/JSON handoff contract is in RecoveryChecks.java.
"""
from pathlib import Path
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'
FIXTURE = ROOT / 'tests/fixtures/recovery/observed-expenses-project.md'
ASSETS = ROOT / 'app/src/main/assets/sandbox'


def asset(name):
    spec = importlib.util.spec_from_file_location('nexus_' + name, ASSETS / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def captured_files():
    files = {}
    for path, body in re.findall(r'^```file=([^\n]+)\n(.*?)^```', FIXTURE.read_text(), re.M | re.S):
        if body.strip():
            if path in files:
                assert files[path] == body
            files[path] = body
    assert set(files) == {'main.py', 'expenses.py', 'test_expenses.py'}
    return files


class MultiProjectChain(unittest.TestCase):
    @unittest.skipUnless(shutil.which('javac') and shutil.which('java'), 'JDK unavailable')
    def test_real_parser_with_captured_response(self):
        source = (JAVA / 'PythonInputs.java').read_text()
        # Extract the actual parser, not a second implementation of its rules.
        source = re.sub(r'^import org\.json\..*;\n', '', source, flags=re.M)
        start = source.index('    /** Same canonical complete project')
        end = source.index('    public static boolean hasNamedFiles(', start)
        source = source[:start] + source[end:source.index('    public static String copySource(', end)] + '}\n'
        harness = r'''package app.svyazka.mobile;
import java.nio.file.*;
import java.util.*;
public class MultiCheck {
  static void check(boolean ok, String label) {if(!ok)throw new AssertionError(label);}
  static String file(String path,String code){return "```file="+path+"\n"+code+"```\n";}
  public static void main(String[] args)throws Exception {
    String raw=Files.readString(Path.of(args[0]));
    Map<String,String> got=PythonInputs.namedFiles(raw);
    check(got.size()==3,"captured file count");
    check(PythonInputs.hasPythonDelivery(raw),"accept complete package");
    check(PythonInputs.multiPythonProject(raw).equals(got),"same project at validation");
    check(PythonInputs.candidate(raw).parts.size()==3,"exactly three Python sources");
    for(var e:got.entrySet()) Files.writeString(Path.of(args[1],e.getKey()),e.getValue());
    String main=file("main.py","print(1)\n"), lib=file("lib.py","x=1\n");
    String project=main+lib;
    check(PythonInputs.namedFiles(project+project).size()==2,"identical duplicate");
    check(PythonInputs.namedFiles(project+file("main.py","")).size()==2,"empty old snapshot");
    check(PythonInputs.namedFiles(project+file("lib.py","x=2\n")).isEmpty(),"conflicting duplicate");
    check(PythonInputs.namedFiles(project+file("LIB.py","x=1\n")).isEmpty(),"case collision");
    check(PythonInputs.namedFiles(project+file("../outside.py","x=1\n")).isEmpty(),"unsafe path");
    check(PythonInputs.namedFiles(project+file("lib.py/child.py","x=1\n")).isEmpty(),"prefix collision");
    check(PythonInputs.namedFiles(project+file("missing.py","")).isEmpty(),"missing source");
    check(PythonInputs.namedFiles(project+"```file=more.py\nprint(2)\n").isEmpty(),"unfinished source");
    check(PythonInputs.namedFiles(project+"```bash\npython main.py\npython -m unittest lib.py\n```\n").size()==2,"launch docs");
    check(PythonInputs.namedFiles(project+"```bash\npython unknown.py\n```\n").isEmpty(),"unrelated commands");
    check(!PythonInputs.hasPythonDelivery("```file=index.html\n<html></html>\n```"),"wrong language");
    check(PythonInputs.candidate(main).code.equals("print(1)\n"),"single source still works");
  }
}'''
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)
            (p / 'PythonInputs.java').write_text(source)
            (p / 'MultiCheck.java').write_text(harness)
            subprocess.run(['javac','-encoding','UTF-8','-d',tmp,str(p/'PythonInputs.java'),str(p/'MultiCheck.java'),str(JAVA/'ContinuationIntegrity.java')],check=True)
            subprocess.run(['java','-cp',tmp,'app.svyazka.mobile.MultiCheck',str(FIXTURE),tmp],check=True)
            for name, body in captured_files().items():
                self.assertEqual((p/name).read_bytes(),body.encode())

    def test_syntax_every_file_not_execution(self):
        grader = asset('verify')
        files = captured_files()
        def check(sources):
            return json.loads(grader.verify_request(json.dumps({'project_sources':sources,'reason':'syntax only'})))
        good = check(files)
        self.assertEqual(good['status'],'LIMITED')
        self.assertTrue(good['syntax'])
        self.assertFalse(good['ran'])
        self.assertEqual(good['total'],0)
        bad = check(dict(files, **{'expenses.py':'def broken('}))
        self.assertEqual(bad['status'],'ERROR')
        self.assertIn('expenses.py',bad['diagnostic'])
        self.assertFalse(bad['ran'])

    def test_generated_suite_actual_and_failure(self):
        ws = asset('workspace')
        cwd, old_path = Path.cwd(), list(sys.path)
        with tempfile.TemporaryDirectory() as tmp:
            ws.ROOT = Path(tmp)/'workspace'
            try:
                ws.reset_workspace({k:v.encode() for k,v in captured_files().items()})
                result = ws.run_generated_tests()
                self.assertEqual(result, dict(status='PASSED',discovered=10,ran=10,passed=10,failed=0,skipped=0))
                ws.reset_workspace({'main.py':b'print(1)', 'test_bad.py':b'import unittest\nclass T(unittest.TestCase):\n def test_bad(self): self.assertEqual(1,2)\n'})
                result = ws.run_generated_tests()
                self.assertEqual((result['status'],result['failed'],result['passed']),('FAILED',1,0))
                ws.reset_workspace({'main.py':b'print(1)'})
                self.assertEqual(ws.run_generated_tests()['status'],'LIMITED')
            finally:
                os.chdir(cwd)
                sys.path[:] = old_path
                for name,module in list(sys.modules.items()):
                    if str(getattr(module,'__file__','')).startswith(str(ws.ROOT)+'/'):
                        sys.modules.pop(name,None)
