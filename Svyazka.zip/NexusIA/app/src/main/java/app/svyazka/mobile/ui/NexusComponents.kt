package app.svyazka.mobile.ui

import android.content.res.Configuration
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.semantics.Role
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.annotation.DrawableRes
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import app.svyazka.mobile.R

@Composable
private fun ModeSelector(ui: NexusComposeUi, modifier: Modifier) {
    val quick = ui.snapshot.quick
    val enabled = !ui.snapshot.active && !ui.snapshot.clearing
    val single = stringResource(R.string.ui_quick)
    val team = stringResource(R.string.ui_team)
    val measurer = rememberTextMeasurer()
    val style = MaterialTheme.typography.labelLarge
    val density = LocalDensity.current
    fun chipWidth(label: String) = with(density) {
        val width = measurer.measure(AnnotatedString(label), style = style, softWrap = false).size.width
        (width.toDp() + 18.dp).coerceAtLeast(48.dp)
    }
    val requiredWidth = chipWidth(single) + chipWidth(team)
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        if (maxWidth >= requiredWidth) {
            Row(horizontalArrangement = Arrangement.Center) {
                ModeChip(quick, single) { if (enabled) ui.activity.nexusModeChanged(true) }
                ModeChip(!quick, team) { if (enabled) ui.activity.nexusModeChanged(false) }
            }
        } else {
            var menu by remember { mutableStateOf(false) }
            Box {
                TextButton(onClick = { menu = true }, enabled = enabled,
                    contentPadding = PaddingValues(horizontal = 3.dp)) {
                    Text(if (quick) single else team, Modifier.weight(1f, fill = false),
                        maxLines = 2, style = MaterialTheme.typography.labelLarge)
                    Icon(Icons.Outlined.ArrowDropDown, null, Modifier.size(16.dp))
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    for ((label, mode) in listOf(single to true, team to false)) {
                        DropdownMenuItem(text = { Text(label) }, onClick = {
                            menu = false
                            ui.activity.nexusModeChanged(mode)
                        })
                    }
                }
            }
        }
    }
}

@Composable
fun NexusTopBar(ui: NexusComposeUi) {
    val chat = ui.page == NexusComposeUi.Page.TASK || ui.page == NexusComposeUi.Page.RESULT
    val title = when (ui.page) {
        NexusComposeUi.Page.TASK, NexusComposeUi.Page.RESULT -> stringResource(R.string.ui_chat)
        NexusComposeUi.Page.MODELS -> stringResource(R.string.models_title)
        NexusComposeUi.Page.HISTORY -> stringResource(R.string.history_title)
        NexusComposeUi.Page.SETTINGS -> stringResource(R.string.settings_title)
    }
    Surface(modifier = Modifier.statusBarsPadding(), color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (chat) ui.openLeft() else ui.navigateBack() },
                modifier = Modifier.size(48.dp)) {
                Icon(if (chat) Icons.Outlined.Menu else Icons.Outlined.ArrowBack,
                    contentDescription = stringResource(if (chat) R.string.ui_open_menu else R.string.action_back))
            }
            if (chat) {
                ModeSelector(ui, Modifier.weight(1f))
                IconButton(onClick = { ui.searching = !ui.searching }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Outlined.Search, stringResource(R.string.search_current))
                }
            } else Text(title, modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
            if (chat) {
                if (ui.pythonBusy) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                }
                IconButton(onClick = { ui.openRight() }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Outlined.Terminal,
                        contentDescription = stringResource(R.string.ui_open_workspace),
                        tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

/** Shared flat vectors follow Compose theme colors; branded images stay in their original colors. */
private val FlatNexusIcons = setOf(
    R.drawable.ic_nia_attach,
    R.drawable.ic_nia_back,
    R.drawable.ic_nia_chevron_down,
    R.drawable.ic_nia_chevron_up,
    R.drawable.ic_nia_code,
    R.drawable.ic_nia_copy,
    R.drawable.ic_nia_delete,
    R.drawable.ic_nia_document,
    R.drawable.ic_nia_download,
    R.drawable.ic_nia_folder,
    R.drawable.ic_nia_image,
    R.drawable.ic_nia_info,
    R.drawable.ic_nia_key,
    R.drawable.ic_nia_language,
    R.drawable.ic_nia_play,
    R.drawable.ic_nia_refresh,
    R.drawable.ic_nia_search,
    R.drawable.ic_nia_stop,
    R.drawable.ic_nia_success,
    R.drawable.ic_nia_task,
    R.drawable.ic_nia_theme,
    R.drawable.ic_nia_work
)

@Composable
fun NexusGlyph(@DrawableRes id: Int, description: String?, modifier: Modifier = Modifier.size(32.dp)) {
    val mirror = id == R.drawable.ic_nia_back && LocalLayoutDirection.current == LayoutDirection.Rtl
    // A manual theme switch must reload bitmaps even if the system theme did not change.
    key(LocalConfiguration.current.uiMode and Configuration.UI_MODE_NIGHT_MASK) {
        val iconModifier = modifier.graphicsLayer { scaleX = if (mirror) -1f else 1f }
        if (id in FlatNexusIcons) {
            Icon(painter = painterResource(id), contentDescription = description,
                modifier = iconModifier, tint = if (id == R.drawable.ic_nia_success)
                    Color(0xFF20B35B) else LocalContentColor.current)
        } else {
            // Keep provider logos and the three-color Nexus brand untinted.
            Image(painter = painterResource(id), contentDescription = description,
                modifier = iconModifier)
        }
    }
}

@Composable
fun NexusCard(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val isDark = MaterialTheme.colorScheme.background == Color.Black
    val cardColor = if (isDark) Color(0xFF101116) else Color.White
    val stroke = BorderStroke(1.dp,
        if (isDark) Color.White.copy(alpha = .1f) else Color(0xFFE1E5EB))
    val decorated = modifier.shadow(
        elevation = 0.dp,
        shape = shape,
        clip = false,
        ambientColor = if (isDark) Color.Black.copy(alpha = .3f) else Color(0xFF8D96A3).copy(alpha = .2f),
        spotColor = if (isDark) Color.Black.copy(alpha = .35f) else Color(0xFF8D96A3).copy(alpha = .24f)
    )
    if (onClick == null) {
        Surface(modifier = decorated, shape = shape, color = cardColor,
            contentColor = MaterialTheme.colorScheme.onSurface,
            tonalElevation = 0.dp, border = stroke) { Column(Modifier.padding(16.dp), content = content) }
    } else {
        Surface(onClick = onClick, modifier = decorated, shape = shape,
            color = cardColor, contentColor = MaterialTheme.colorScheme.onSurface,
            tonalElevation = 0.dp, border = stroke) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
fun NexusLabel(text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Text(text, color = color, style = MaterialTheme.typography.bodyMedium)
}

@Composable
fun StatusPill(label: String, success: Boolean = false) {
    val foreground = if (success) Color(0xFF27D6A6) else MaterialTheme.colorScheme.primary
    Surface(shape = RoundedCornerShape(50), color = foreground.copy(alpha = .15f), contentColor = foreground,
        border = BorderStroke(1.dp, foreground.copy(alpha = .38f))) {
        Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            color = foreground, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun KeyStatusPill(label: String, configured: Boolean) {
    val isDark = MaterialTheme.colorScheme.background == Color.Black
    val accent = if (configured) {
        if (isDark) Color(0xFF38E2AD) else Color(0xFF086E48)
    } else {
        if (isDark) Color(0xFFFF8B93) else Color(0xFFAC2634)
    }
    Surface(shape = RoundedCornerShape(50), color = accent.copy(alpha = .2f), contentColor = accent,
        border = BorderStroke(.8.dp, accent.copy(alpha = .35f))) {
        Text(label, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
            color = accent, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun NexusPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable () -> Unit)? = null,
    glow: Boolean = true
) {
    val shape = RoundedCornerShape(16.dp)
    val colors = listOf(NexusBlue.copy(alpha = if (enabled) 1f else .45f),
        NexusPurple.copy(alpha = if (enabled) 1f else .45f))
    Box(modifier.clip(shape).background(Brush.horizontalGradient(colors), shape)
        .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
        .heightIn(min = 48.dp).padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center) {
            if (leadingIcon != null) {
                CompositionLocalProvider(LocalContentColor provides Color.White) { leadingIcon() }
                Spacer(Modifier.width(8.dp))
            }
            Text(text, color = Color.White, style = MaterialTheme.typography.labelLarge)
        }
    }
}

/** The same raster model artwork is used in the hero and model navigation. */
@Composable
fun NexusAiStack(modifier: Modifier = Modifier) {
    NexusGlyph(R.drawable.ic_nia_models, null, modifier)
}

/** No HTML rendering and no network. Plain text, headings, fences and common Markdown spans. */
internal data class MarkdownBlock(val kind: String, val value: String)

internal fun parseMarkdown(source: String): List<MarkdownBlock> {
    val out = ArrayList<MarkdownBlock>()
    val lines = source.replace("\r\n", "\n").split('\n')
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trimStart()
        if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
            val marker = trimmed.takeWhile { it == trimmed[0] }
            val code = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trimStart().startsWith(marker)) {
                if (code.isNotEmpty()) code.append('\n')
                code.append(lines[i]); i++
            }
            out.add(MarkdownBlock("code", code.toString()))
        } else if (trimmed.startsWith("#") && trimmed.takeWhile { it == '#' }.length in 1..6 &&
            trimmed.dropWhile { it == '#' }.startsWith(' ')) {
            out.add(MarkdownBlock("heading", trimmed.dropWhile { it == '#' }.trim()))
        } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ") ||
            Regex("^\\d+[.)] ").containsMatchIn(trimmed)) {
            out.add(MarkdownBlock("bullet", trimmed))
        } else if (line.isNotBlank()) {
            out.add(MarkdownBlock("body", line))
        } else if (out.isNotEmpty() && out.last().kind != "space") {
            out.add(MarkdownBlock("space", ""))
        }
        i++
    }
    return out
}

internal fun inlineMarkup(source: String) = buildAnnotatedString {
    val pattern = Regex("(`[^`\\n]+`|\\*\\*[^*\\n]+\\*\\*|\\*[^*\\n]+\\*)")
    var previous = 0
    pattern.findAll(source).forEach { match ->
        append(source.substring(previous, match.range.first))
        val word = match.value
        when {
            word.startsWith("**") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                append(word.drop(2).dropLast(2))
            }
            word.startsWith('`') -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace)) {
                append(word.drop(1).dropLast(1))
            }
            else -> withStyle(SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)) {
                append(word.drop(1).dropLast(1))
            }
        }
        previous = match.range.last + 1
    }
    append(source.substring(previous))
}

@Composable
fun NexusMarkdown(markdown: String) {
    val blocks = remember(markdown) { parseMarkdown(markdown) }
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            blocks.forEach { block ->
                when (block.kind) {
                    "code" -> Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.background,
                        contentColor = MaterialTheme.colorScheme.onBackground,
                        border = BorderStroke(.7.dp, MaterialTheme.colorScheme.outline.copy(alpha = .5f))
                    ) {
                        Text(block.value, Modifier.fillMaxWidth().padding(12.dp),
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    "heading" -> Text(inlineMarkup(block.value),
                        style = MaterialTheme.typography.titleLarge)
                    "bullet" -> Text(inlineMarkup(block.value),
                        style = MaterialTheme.typography.bodyMedium)
                    "space" -> Spacer(Modifier.height(4.dp))
                    else -> Text(inlineMarkup(block.value), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
