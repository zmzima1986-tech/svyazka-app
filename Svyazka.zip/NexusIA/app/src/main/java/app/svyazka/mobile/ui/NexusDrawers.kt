package app.svyazka.mobile.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.PythonVerification
import app.svyazka.mobile.R

/** Drawers open only by explicit buttons, never by horizontal swipe across the chat. */
@Composable
fun NexusSidePanels(ui: NexusComposeUi) {
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val open = ui.panel != NexusComposeUi.Panel.NONE
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val width = minOf(344.dp, maxWidth - 32.dp)
        AnimatedVisibility(open, enter = fadeIn(tween(200)), exit = fadeOut(tween(180))) {
            Box(Modifier.fillMaxSize()
                .background(Color.Black.copy(alpha = .52f))
                .clickable(onClick = { ui.closePanel() }))
        }
        AnimatedVisibility(visible = ui.panel == NexusComposeUi.Panel.LEFT,
            modifier = Modifier.align(Alignment.CenterStart).width(width).fillMaxHeight(),
            enter = slideInHorizontally(tween(270)) { if (rtl) it else -it } + fadeIn(tween(200)),
            exit = slideOutHorizontally(tween(240)) { if (rtl) it else -it } + fadeOut(tween(170))) {
            FrostedDrawer { LeftTools(ui) }
        }
        AnimatedVisibility(visible = ui.panel == NexusComposeUi.Panel.RIGHT,
            modifier = Modifier.align(Alignment.CenterEnd).width(width).fillMaxHeight(),
            enter = slideInHorizontally(tween(270)) { if (rtl) -it else it } + fadeIn(tween(200)),
            exit = slideOutHorizontally(tween(240)) { if (rtl) -it else it } + fadeOut(tween(170))) {
            FrostedDrawer { RightWorkspace(ui) }
        }
    }
}

/** Translucent high-contrast frosted surface; avoids costly background blur on older devices. */
@Composable
private fun FrostedDrawer(content: @Composable ColumnScope.() -> Unit) {
    val dark = MaterialTheme.colorScheme.background == Color.Black
    val surface = if (dark) Color(0xFF10121C).copy(alpha = .94f)
        else Color.White.copy(alpha = .94f)
    Surface(Modifier.fillMaxSize(), shape = RoundedCornerShape(0.dp), color = surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp), content = content)
    }
}

@Composable
private fun ColumnScope.LeftTools(ui: NexusComposeUi) {
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        NexusBrandMark(Modifier.size(37.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.ui_brand_subtitle),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall)
        }
        IconButton(onClick = { ui.closePanel() }) {
            Icon(Icons.Outlined.Close, stringResource(R.string.action_close))
        }
    }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(3.dp)) {
        LeftTool(Icons.Outlined.AddComment, stringResource(R.string.ui_new_chat), true) {
            ui.closePanel(); ui.requestNewTask()
        }
        LeftTool(Icons.Outlined.History, stringResource(R.string.nav_history)) {
            ui.closePanel(); ui.activity.nexusOpenHistory()
        }
        LeftTool(Icons.Outlined.Layers, stringResource(R.string.models_title)) {
            ui.selectPage(NexusComposeUi.Page.MODELS)
        }
        LeftTool(Icons.Outlined.Groups, stringResource(R.string.ui_team)) {
            ui.closePanel(); ui.teamSettingsRequested = true
        }
        LeftTool(Icons.Outlined.AttachFile, stringResource(R.string.ui_attachments)) {
            ui.workspaceTab = NexusComposeUi.WorkspaceTab.FILES; ui.openRight()
        }
        LeftTool(Icons.Outlined.Code, stringResource(R.string.ui_python_code)) {
            ui.workspaceTab = NexusComposeUi.WorkspaceTab.PYTHON; ui.openRight()
        }
        HorizontalDivider(Modifier.padding(vertical = 9.dp))
        LeftTool(Icons.Outlined.Settings, stringResource(R.string.settings_title)) {
            ui.selectPage(NexusComposeUi.Page.SETTINGS)
        }
        LeftTool(Icons.Outlined.Key, stringResource(R.string.models_settings)) {
            ui.closePanel(); ui.requestKeys()
        }
        LeftTool(Icons.Outlined.Info, stringResource(R.string.settings_about)) {
            ui.selectPage(NexusComposeUi.Page.SETTINGS)
        }
    }
    HorizontalDivider()
    Row(Modifier.padding(top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        NexusBrandMark(Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.labelLarge)
            Text(stringResource(R.string.settings_version),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun LeftTool(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String,
                     highlighted: Boolean = false, action: () -> Unit) {
    val tint = if (highlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
        .clickable(role = Role.Button, onClick = action)
        .heightIn(min = 50.dp).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(23.dp))
        Spacer(Modifier.width(15.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = tint)
    }
}

@Composable
private fun ColumnScope.RightWorkspace(ui: NexusComposeUi) {
    Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Terminal, null, Modifier.size(25.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.ui_workspace), style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.weight(1f))
        IconButton(onClick = { ui.closePanel() }) {
            Icon(Icons.Outlined.Close, stringResource(R.string.action_close))
        }
    }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        WorkspaceTab(ui, NexusComposeUi.WorkspaceTab.PYTHON, stringResource(R.string.ui_python), Icons.Outlined.Terminal)
        WorkspaceTab(ui, NexusComposeUi.WorkspaceTab.CODE, stringResource(R.string.ui_code), Icons.Outlined.Code)
        WorkspaceTab(ui, NexusComposeUi.WorkspaceTab.LOGS, stringResource(R.string.ui_logs), Icons.Outlined.Description)
        WorkspaceTab(ui, NexusComposeUi.WorkspaceTab.FILES, stringResource(R.string.ui_files), Icons.Outlined.Folder)
    }
    HorizontalDivider()
    Box(Modifier.fillMaxWidth().weight(1f)) {
        when (ui.workspaceTab) {
            NexusComposeUi.WorkspaceTab.PYTHON -> NexusPythonWorkspace(ui)
            NexusComposeUi.WorkspaceTab.CODE -> {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.ui_code), style = MaterialTheme.typography.titleMedium)
                    val source = ui.pythonEditingCode.ifBlank { ui.snapshot.result }
                    if (source.isBlank()) NexusLabel(stringResource(R.string.ui_no_code))
                    else SelectionContainer { NexusMarkdown(source) }
                    if (ui.snapshot.resultHasPython && !ui.snapshot.active) {
                        OutlinedButton(onClick = {
                            ui.activity.nexusRunPython(ui.activity.nexusFinalStep())
                        }) { Text(stringResource(R.string.action_python)) }
                    }
                }
            }
            NexusComposeUi.WorkspaceTab.LOGS -> WorkspaceLogs(ui)
            NexusComposeUi.WorkspaceTab.FILES -> WorkspaceFiles(ui)
        }
    }
}

@Composable
private fun WorkspaceTab(ui: NexusComposeUi, tab: NexusComposeUi.WorkspaceTab,
                         label: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    val selected = ui.workspaceTab == tab
    Surface(onClick = { ui.workspaceTab = tab }, shape = RoundedCornerShape(12.dp),
        color = if (selected) NexusBlue else Color.Transparent,
        contentColor = if (selected) Color.White else MaterialTheme.colorScheme.onSurface) {
        Row(Modifier.heightIn(min = 44.dp).padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun WorkspaceLogs(ui: NexusComposeUi) {
    val state = ui.snapshot
    val verification = ui.verification
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.ui_logs), style = MaterialTheme.typography.titleMedium)
        if (verification.status != PythonVerification.Status.NONE) {
            Text(stringResource(R.string.ui_verify_details), style = MaterialTheme.typography.titleMedium)
            if (verification.syntax) Text(stringResource(R.string.verify_syntax))
            if (verification.ran) Text(stringResource(R.string.verify_executed))
            if (verification.total > 0) Text(stringResource(R.string.verify_count,
                verification.passed, verification.total))
            if (verification.diagnostic.isNotBlank()) SelectionContainer {
                Text(verification.diagnostic, color = MaterialTheme.colorScheme.error)
            }
            if (verification.rounds > 0) SelectionContainer {
                Text(verification.diagnosticsHistory(), style = MaterialTheme.typography.bodySmall)
            }
            HorizontalDivider()
        }
        state.stages.forEach { stage ->
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(roleTitle(stage.role, stage.index), style = MaterialTheme.typography.titleMedium)
                NexusLabel(stage.modelLabel)
                Text(stringResource(if (stage.done) R.string.status_complete else if (stage.current)
                    R.string.status_processing else R.string.status_queued),
                    style = MaterialTheme.typography.bodySmall)
                if (stage.warnings.isNotBlank()) Text(stage.warnings, color = MaterialTheme.colorScheme.error)
                if (stage.answer.isNotBlank()) SelectionContainer {
                    Text(stage.answer.take(4000), style = MaterialTheme.typography.bodySmall)
                }
                if (stage.hasPython && stage.done && !state.active) {
                    TextButton(onClick = { ui.activity.nexusRunPython(stage.index) }) {
                        Text(stringResource(R.string.action_python))
                    }
                }
            }
            HorizontalDivider()
        }
        if (state.log.isNotBlank()) SelectionContainer {
            Text(state.log, style = MaterialTheme.typography.bodySmall)
        }
        if (state.stages.isEmpty() && state.log.isBlank())
            NexusLabel(stringResource(R.string.ui_no_logs))
        OutlinedButton(enabled = state.hasRun && !state.active,
            onClick = { ui.activity.nexusExport() }) {
            Text(stringResource(R.string.action_export))
        }
    }
}

@Composable
private fun WorkspaceFiles(ui: NexusComposeUi) {
    val attachments = rememberAttachmentTask(ui)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(stringResource(R.string.ui_files), style = MaterialTheme.typography.titleMedium)
        AttachmentSummary(attachments)
        if (attachments.items.isEmpty()) NexusLabel(stringResource(R.string.ui_no_files))
        attachments.items.forEach { AttachmentCard(ui, it) }
    }
}

/** Existing three model roles and quick-model picker are kept accessible outside the chat. */
@Composable
fun NexusTeamSettings(ui: NexusComposeUi) {
    var editing by remember { mutableIntStateOf(-1) }
    var quickPicker by remember { mutableStateOf(false) }
    val state = ui.snapshot
    AlertDialog(onDismissRequest = { ui.teamSettingsRequested = false },
        title = { Text(stringResource(R.string.ui_models_setup)) },
        text = {
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedButton(onClick = { quickPicker = true }) {
                    Text(stringResource(R.string.ui_quick) + ": " + state.quickModelLabel)
                }
                state.stages.forEach { stage ->
                    OutlinedButton(onClick = { editing = stage.index }, Modifier.fillMaxWidth()) {
                        Text(roleTitle(stage.role, stage.index) + " · " + stage.modelLabel,
                            maxLines = 3)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { ui.teamSettingsRequested = false }) {
            Text(stringResource(R.string.action_close))
        } })
    if (quickPicker) ModelPicker(ui, state.quickModelId, { quickPicker = false }) { id ->
        ui.activity.nexusChooseQuickModel(id); quickPicker = false
    }
    val stage = state.stages.firstOrNull { it.index == editing }
    if (stage != null) RoleEditor(ui, stage) { editing = -1 }
}
