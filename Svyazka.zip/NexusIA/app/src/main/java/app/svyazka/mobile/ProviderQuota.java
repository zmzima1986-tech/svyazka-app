package app.svyazka.mobile;

import java.net.HttpURLConnection;
import org.json.JSONObject;

/** Provider-reported quotas only. -1 means that no reliable value was provided. */
final class ProviderQuota {
    static final long UNKNOWN = -1;
    final long tokensPerMinute;
    final long requestsPerDay;
    final long dailyLimit;

    private ProviderQuota(long tokensPerMinute, long requestsPerDay, long dailyLimit) {
        this.tokensPerMinute = tokensPerMinute;
        this.requestsPerDay = requestsPerDay;
        this.dailyLimit = dailyLimit;
    }

    static long nonNegative(String value) {
        if (value == null) return UNKNOWN;
        try {
            long number = Long.parseLong(value.trim());
            return number >= 0 ? number : UNKNOWN;
        } catch (NumberFormatException invalid) {
            return UNKNOWN;
        }
    }

    static ProviderQuota groq(String remainingTokens, String remainingRequests) {
        return new ProviderQuota(nonNegative(remainingTokens), nonNegative(remainingRequests), UNKNOWN);
    }

    static ProviderQuota groq(HttpURLConnection response) {
        return groq(response.getHeaderField("x-ratelimit-remaining-tokens"),
                response.getHeaderField("x-ratelimit-remaining-requests"));
    }

    static ProviderQuota openRouter(JSONObject response) {
        JSONObject data = response.optJSONObject("data");
        JSONObject free = data == null ? null : data.optJSONObject("free_model_daily_requests");
        if (free == null) return new ProviderQuota(UNKNOWN, UNKNOWN, UNKNOWN);
        return new ProviderQuota(UNKNOWN,
                nonNegative(free.opt("remaining") == null ? null : String.valueOf(free.opt("remaining"))),
                nonNegative(free.opt("limit") == null ? null : String.valueOf(free.opt("limit"))));
    }

    boolean available() { return tokensPerMinute >= 0 || requestsPerDay >= 0; }
}
