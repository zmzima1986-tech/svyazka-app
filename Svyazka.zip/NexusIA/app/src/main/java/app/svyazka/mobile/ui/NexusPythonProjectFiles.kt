package app.svyazka.mobile.ui

import android.app.Activity
import android.content.Intent
import android.provider.OpenableColumns
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.PythonProjectStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

/** SAF is the only import/export path. Nothing here requests broad storage permissions. */
@Composable
fun PythonProjectFiles(ui: NexusComposeUi) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingConflict by remember { mutableStateOf<Pair<String, ByteArray>?>(null) }
    var pendingProject by remember(ui.projectId) { mutableStateOf<ByteArray?>(null) }
    var importFeedback by remember(ui.projectId) { mutableStateOf("") }
    var pendingExport by remember { mutableStateOf<Pair<String, ByteArray>?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val pending = pendingExport
        pendingExport = null
        val uri = result.data?.data
        if (result.resultCode == Activity.RESULT_OK && uri != null && pending != null) {
            scope.launch {
                val saved = withContext(Dispatchers.IO) {
                    runCatching { context.contentResolver.openOutputStream(uri, "w")!!.use { it.write(pending.second) } }.isSuccess
                }
                Toast.makeText(context, if (saved) context.getString(app.svyazka.mobile.R.string.ws_file_saved) else context.getString(app.svyazka.mobile.R.string.ws_file_save_error),Toast.LENGTH_SHORT).show()
            }
        }
    }
    fun export(name: String, binary: ByteArray, mime: String) {
        pendingExport = name to binary
        exportLauncher.launch(Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE).setType(mime)
            .putExtra(Intent.EXTRA_TITLE,name))
    }
    fun finishImport(error: String) {
        ui.projectChanged(error)
        if (error.isBlank()) {
            ui.dismissPythonResult()
            if (ui.pythonFileName != "main.py") ui.openPythonFile("main.py")
            else ui.reloadPythonFile()
            importFeedback = context.getString(app.svyazka.mobile.R.string.ws_easy_import_success,
                ui.pythonFileList.size)
            Toast.makeText(context, importFeedback, Toast.LENGTH_LONG).show()
        } else {
            importFeedback = error
            Toast.makeText(context, error, Toast.LENGTH_LONG).show()
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        if (result.resultCode == Activity.RESULT_OK && uri != null) {
            scope.launch {
                val incoming = withContext(Dispatchers.IO) {
                    runCatching {
                        val name = displayName(context, uri)
                        val bytes = context.contentResolver.openInputStream(uri)!!.use { stream ->
                            val buffer = ByteArrayOutputStreamLimited(2_000_000)
                            val chunk = ByteArray(8192)
                            while (true) {
                                val n = stream.read(chunk)
                                if (n < 0) break
                                buffer.add(chunk, n)
                            }
                            buffer.bytes()
                        }
                        name to bytes
                    }.getOrNull()
                }
                if (incoming == null) {
                    finishImport(context.getString(app.svyazka.mobile.R.string.ws_easy_read_failed))
                } else if (incoming.first.endsWith(".zip",ignoreCase = true)) {
                    if (ui.pythonEditingCode.isNotBlank() || ui.pythonFileList.size > 1) {
                        pendingProject = incoming.second
                    } else {
                        finishImport(ui.activity.nexusPythonReplaceZip(incoming.second))
                    }
                } else if (!PythonProjectStore.validPath(incoming.first)) {
                    finishImport(context.getString(app.svyazka.mobile.R.string.ws_invalid_name))
                } else if (ui.pythonFileList.contains(incoming.first)) {
                    pendingConflict = incoming
                } else {
                    finishImport(ui.activity.nexusPythonPut(incoming.first, incoming.second))
                }
            }
        }
    }

    NexusPrimaryButton(text = stringResource(app.svyazka.mobile.R.string.ws_easy_choose_project),
        onClick = { importer.launch(Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")) },
        modifier = Modifier.fillMaxWidth(), enabled = !ui.pythonBusy,
        leadingIcon = { NexusGlyph(app.svyazka.mobile.R.drawable.ic_nia_document,
            null, Modifier.size(20.dp)) }, glow = false)
    if (importFeedback.isNotBlank()) {
        Text(importFeedback, color = if (ui.pythonProjectIssue.isBlank())
            MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodyMedium)
    }
    if (ui.pythonProjectIssue.isNotBlank() && ui.pythonProjectIssue != importFeedback) {
        Text(ui.pythonProjectIssue, color=MaterialTheme.colorScheme.error)
    }
    pendingProject?.let { bytes ->
        NexusFrostedAlertDialog(onDismissRequest={pendingProject=null},
            title={Text(stringResource(app.svyazka.mobile.R.string.ws_easy_replace_title))},
            text={Text(stringResource(app.svyazka.mobile.R.string.ws_easy_replace_body))},
            confirmButton={TextButton(onClick={
                pendingProject=null
                finishImport(ui.activity.nexusPythonReplaceZip(bytes))
            }) {Text(stringResource(app.svyazka.mobile.R.string.ws_easy_replace_confirm))}},
            dismissButton={TextButton(onClick={pendingProject=null}){
                Text(stringResource(app.svyazka.mobile.R.string.ws_cancel))}})
    }
    pendingConflict?.let { conflict ->
        NexusFrostedAlertDialog(onDismissRequest={pendingConflict=null},
            title={Text(stringResource(app.svyazka.mobile.R.string.ws_exists))},
            text={Text(stringResource(app.svyazka.mobile.R.string.ws_replace_body, conflict.first))},
            confirmButton={TextButton(onClick={
                pendingConflict=null
                finishImport(ui.activity.nexusPythonPut(conflict.first,conflict.second))
                if (conflict.first==ui.pythonFileName) ui.reloadPythonFile()
            }) {Text(stringResource(app.svyazka.mobile.R.string.ws_replace))}},
            dismissButton={TextButton(onClick={pendingConflict=null}){Text(stringResource(app.svyazka.mobile.R.string.ws_cancel))}})
    }
}

@Composable
fun PythonProjectFileManager(ui: NexusComposeUi) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var newName by remember { mutableStateOf("") }
    var renameName by remember { mutableStateOf("") }
    var deleteConfirm by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf<Pair<String, ByteArray>?>(null) }
    var feedback by remember(ui.projectId) { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val pending = pendingExport
        pendingExport = null
        val uri = result.data?.data
        if (result.resultCode == Activity.RESULT_OK && uri != null && pending != null) {
            scope.launch {
                val saved = withContext(Dispatchers.IO) {
                    runCatching { context.contentResolver.openOutputStream(uri, "w")!!.use { it.write(pending.second) } }.isSuccess
                }
                Toast.makeText(context, if (saved) context.getString(app.svyazka.mobile.R.string.ws_file_saved) else context.getString(app.svyazka.mobile.R.string.ws_file_save_error),Toast.LENGTH_SHORT).show()
            }
        }
    }
    fun export(name: String, binary: ByteArray, mime: String) {
        pendingExport = name to binary
        exportLauncher.launch(Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE).setType(mime)
            .putExtra(Intent.EXTRA_TITLE,name))
    }
    fun finishRestore(error: String) {
        ui.projectChanged(error)
        feedback = if (error.isBlank()) {
            ui.dismissPythonResult()
            if (ui.pythonFileName != "main.py") ui.openPythonFile("main.py") else ui.reloadPythonFile()
            context.getString(app.svyazka.mobile.R.string.ws_easy_import_success, ui.pythonFileList.size)
        } else error
        if (feedback.isNotBlank()) Toast.makeText(context, feedback, Toast.LENGTH_LONG).show()
    }

    val light = nexusLightMode()
    val darkFieldColors = if (light) OutlinedTextFieldDefaults.colors(
        focusedTextColor = NexusLightDesign.ink,
        unfocusedTextColor = NexusLightDesign.ink,
        focusedContainerColor = NexusLightDesign.glass,
        unfocusedContainerColor = NexusLightDesign.glass,
        focusedBorderColor = NexusLightDesign.blue,
        unfocusedBorderColor = NexusLightDesign.border,
        focusedLabelColor = NexusLightDesign.secondary,
        unfocusedLabelColor = NexusLightDesign.secondary,
        cursorColor = NexusLightDesign.blue) else
        OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = NexusDarkDesign.workspaceBorder,
            unfocusedBorderColor = NexusDarkDesign.chatBorder,
            focusedLabelColor = NexusDarkDesign.secondaryText,
            unfocusedLabelColor = NexusDarkDesign.mutedText,
            cursorColor = NexusDarkDesign.cyan)
    val darkOutlineColors = if (light) ButtonDefaults.outlinedButtonColors(
        containerColor = NexusLightDesign.glass,
        contentColor = NexusLightDesign.blue,
        disabledContainerColor = NexusLightDesign.disabled.copy(alpha = .78f),
        disabledContentColor = NexusLightDesign.disabledText) else
        ButtonDefaults.outlinedButtonColors(
            contentColor = Color.White,
            disabledContentColor = NexusDarkDesign.disabledText,
            containerColor = NexusDarkDesign.chatGlass,
            disabledContainerColor = NexusDarkDesign.workspaceGlass.copy(alpha = .65f))
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(if (light) 8.dp else 12.dp)) {
        if (light) {
            Text(stringResource(app.svyazka.mobile.R.string.ws_project_info),
                style = MaterialTheme.typography.labelMedium)
        } else {
            Surface(shape = RoundedCornerShape(17.dp),
                color = Color(0xC5223155),
                border = BorderStroke(1.dp, NexusDarkDesign.modalBorder),
                modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(app.svyazka.mobile.R.string.ws_project_info),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 11.dp),
                    fontSize = 14.sp, color = Color.White)
            }
        }
        if (light) {
            Surface(shape = NexusLightDesign.cardShape,
                color = NexusLightDesign.glass,
                border = BorderStroke(1.dp, NexusLightDesign.glassHighlight),
                modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 8.dp)) {
                    ui.pythonFileList.forEachIndexed { index, path ->
                        if (index > 0) HorizontalDivider(
                            color = NexusLightDesign.border, thickness = .7.dp)
                        Row(Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Icon(Icons.Outlined.Description, null, Modifier.size(19.dp),
                                tint = NexusLightDesign.ink)
                            TextButton(onClick = { ui.openPythonFile(path) },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 5.dp),
                                colors = ButtonDefaults.textButtonColors(
                                    contentColor = NexusLightDesign.blue)) {
                                Text((if (ui.pythonFileName == path) "● " else "") + path,
                                    modifier = Modifier.fillMaxWidth(),
                                    fontWeight = FontWeight.SemiBold, maxLines = 1,
                                    softWrap = false, overflow = TextOverflow.Ellipsis)
                            }
                            TextButton(onClick = {
                                ui.activity.nexusPythonFlushPending()
                                val bytes = ui.activity.nexusPythonBytes(path)
                                if (bytes != null) export(path, bytes, contentType(path))
                            }, contentPadding = PaddingValues(horizontal = 4.dp),
                                colors = ButtonDefaults.textButtonColors(
                                    contentColor = NexusLightDesign.blue)) {
                                Text(stringResource(app.svyazka.mobile.R.string.ws_export),
                                    maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        } else {
        ui.pythonFileList.forEach { path ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(onClick = { ui.openPythonFile(path) }, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = if (light) MaterialTheme.colorScheme.primary else NexusDarkDesign.cyan)) {
                    Text((if (ui.pythonFileName == path) "● " else "") + path,
                        maxLines = 2, fontWeight = if (light) FontWeight.Normal else FontWeight.SemiBold)
                }
                TextButton(onClick = {
                    ui.activity.nexusPythonFlushPending()
                    val bytes = ui.activity.nexusPythonBytes(path)
                    if (bytes != null) export(path, bytes, contentType(path))
                }, colors = ButtonDefaults.textButtonColors(
                    contentColor = if (light) MaterialTheme.colorScheme.primary else NexusDarkDesign.cyan)
                ) { Text(stringResource(app.svyazka.mobile.R.string.ws_export)) }
            }
        }
        }
        OutlinedTextField(value = newName, onValueChange = { newName = it.take(180) },
            modifier=Modifier.fillMaxWidth(),singleLine=true,
            shape = if (light) RoundedCornerShape(18.dp) else RoundedCornerShape(14.dp),
            colors = darkFieldColors,
            label={Text(stringResource(app.svyazka.mobile.R.string.ws_new_name))})
        Button(onClick = { ui.addPythonFile(newName.trim()); if (ui.pythonProjectIssue.isEmpty()) newName = "" },
            enabled = newName.isNotBlank(),
            shape = if (light) RoundedCornerShape(22.dp) else RoundedCornerShape(20.dp),
            colors = if (light) ButtonDefaults.buttonColors(
                containerColor = NexusLightDesign.glass,
                contentColor = NexusLightDesign.blue,
                disabledContainerColor = NexusLightDesign.disabled,
                disabledContentColor = NexusLightDesign.disabledText) else ButtonDefaults.buttonColors(
                containerColor = NexusDarkDesign.solidBlue,
                disabledContainerColor = NexusDarkDesign.disabled,
                disabledContentColor = NexusDarkDesign.disabledText)) {
            Text(stringResource(app.svyazka.mobile.R.string.ws_create))
        }
        OutlinedTextField(value = renameName, onValueChange = { renameName = it.take(180) },
            modifier=Modifier.fillMaxWidth(),singleLine=true,
            shape = if (light) RoundedCornerShape(18.dp) else RoundedCornerShape(14.dp),
            colors = darkFieldColors,
            label={Text(stringResource(app.svyazka.mobile.R.string.ws_rename_to, ui.pythonFileName))})
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { ui.renamePythonFile(renameName.trim()); renameName = "" },
                enabled = renameName.isNotBlank() && ui.pythonFileName != "main.py",
                colors = darkOutlineColors,
                shape = if (light) RoundedCornerShape(22.dp) else RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, if (light) MaterialTheme.colorScheme.outline
                    else NexusDarkDesign.chatBorder)) {
                Text(stringResource(app.svyazka.mobile.R.string.ws_rename))
            }
            OutlinedButton(onClick = { deleteConfirm = true }, enabled = ui.pythonFileName != "main.py",
                colors = darkOutlineColors,
                shape = if (light) RoundedCornerShape(22.dp) else RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, if (light) MaterialTheme.colorScheme.outline
                    else NexusDarkDesign.chatBorder)) {
                Text(stringResource(app.svyazka.mobile.R.string.ws_delete),
                    color = if (light && ui.pythonFileName != "main.py") NexusLightDesign.destructive
                        else if (light) NexusLightDesign.disabledText else Color.Unspecified)
            }
        }
        HorizontalDivider()
        if (light) {
            NexusPrimaryButton(text = stringResource(app.svyazka.mobile.R.string.ws_export_zip),
                onClick = {
                    val bytes = ui.activity.nexusPythonExportZip()
                    if (bytes != null) export("python-project.zip", bytes, "application/zip")
                }, modifier = Modifier.widthIn(max = 275.dp), glow = false)
        } else {
        OutlinedButton(onClick = {
            val bytes = ui.activity.nexusPythonExportZip()
            if (bytes != null) export("python-project.zip", bytes, "application/zip")
        }, colors = darkOutlineColors,
            shape = if (light) RoundedCornerShape(22.dp) else RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, if (light) MaterialTheme.colorScheme.outline
                else NexusDarkDesign.workspaceBorder)) {
            Text(stringResource(app.svyazka.mobile.R.string.ws_export_zip))
        }
        }
        if (ui.activity.nexusPythonHasPreviousProject()) {
            OutlinedButton(onClick = {
                finishRestore(ui.activity.nexusPythonRestorePreviousProject())
            }, enabled = !ui.pythonBusy, colors = darkOutlineColors,
                border = BorderStroke(1.dp, if (light) MaterialTheme.colorScheme.outline
                    else NexusDarkDesign.chatBorder)) {
                Text(stringResource(app.svyazka.mobile.R.string.ws_easy_restore_previous))
            }
        }
        NexusLabel(stringResource(app.svyazka.mobile.R.string.ws_project_scope))
        if (feedback.isNotBlank()) {
            Text(feedback, color = if (ui.pythonProjectIssue.isBlank())
                MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        }
        if (ui.pythonProjectIssue.isNotBlank() && ui.pythonProjectIssue != feedback) {
            Text(ui.pythonProjectIssue, color=MaterialTheme.colorScheme.error)
        }
    }
    if (deleteConfirm) NexusFrostedAlertDialog(onDismissRequest={deleteConfirm=false},
        title={Text(stringResource(app.svyazka.mobile.R.string.ws_delete_title, ui.pythonFileName))},
        text={Text(stringResource(app.svyazka.mobile.R.string.ws_delete_body))},
        confirmButton={TextButton(onClick={deleteConfirm=false;ui.removePythonFile()}){Text(stringResource(app.svyazka.mobile.R.string.ws_delete))}},
        dismissButton={TextButton(onClick={deleteConfirm=false}){Text(stringResource(app.svyazka.mobile.R.string.ws_cancel))}})
}

private class ByteArrayOutputStreamLimited(private val limit: Int) {
    private val stream = java.io.ByteArrayOutputStream()
    fun add(bytes:ByteArray, size:Int) {
        if (stream.size() + size > limit) throw java.io.IOException("Файл больше $limit байт")
        stream.write(bytes,0,size)
    }
    fun bytes():ByteArray = stream.toByteArray()
}

private fun displayName(context: android.content.Context, uri: Uri): String {
    context.contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use { cursor ->
        if (cursor.moveToFirst()) return cursor.getString(0).substringAfterLast('/')
    }
    return "unknown"
}

private fun contentType(name:String) = when(name.substringAfterLast('.').lowercase()) {
    "zip" -> "application/zip"
    "png" -> "image/png"
    "json" -> "application/json"
    "csv" -> "text/csv"
    "py" -> "text/plain"
    else -> "text/plain"
}

private data class Artifact(val name:String,val mime:String,val data:String,val size:Int)

@Composable
fun PythonRunArtifacts(ui:NexusComposeUi) {
    val report = ui.pythonReport
    if (report == null) {NexusLabel(stringResource(app.svyazka.mobile.R.string.ws_artifacts_empty));return}
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var pendingSave by remember { mutableStateOf<Artifact?>(null) }
    var confirmReplace by remember { mutableStateOf<Artifact?>(null) }
    var projectSaveFeedback by remember(report.artifactsJson) { mutableStateOf("") }
    fun saveToProject(artifact: Artifact) {
        val result = ui.activity.nexusPythonPut(artifact.name,
            Base64.decode(artifact.data, Base64.DEFAULT))
        ui.projectChanged(result)
        projectSaveFeedback = if (result.isBlank()) {
            context.getString(app.svyazka.mobile.R.string.ws_artifact_project_saved, artifact.name)
        } else result
        Toast.makeText(context, projectSaveFeedback, Toast.LENGTH_SHORT).show()
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val artifact = pendingSave
        pendingSave = null
        val uri = result.data?.data
        if (artifact != null && uri != null && result.resultCode == Activity.RESULT_OK) {
            scope.launch {
                val saved=withContext(Dispatchers.IO) {
                    runCatching {
                        val binary=Base64.decode(artifact.data,Base64.DEFAULT)
                        context.contentResolver.openOutputStream(uri,"w")!!.use {it.write(binary)}
                    }.isSuccess
                }
                Toast.makeText(context, if(saved) context.getString(app.svyazka.mobile.R.string.ws_artifact_saved) else context.getString(app.svyazka.mobile.R.string.ws_artifact_error), Toast.LENGTH_SHORT).show()
            }
        }
    }
    val artifacts = remember(report.artifactsJson) {
        val results=mutableListOf<Artifact>()
        runCatching {
            val array=JSONArray(report.artifactsJson)
            for(index in 0 until array.length()) {
                val item=array.getJSONObject(index)
                results.add(Artifact(item.getString("name"),item.getString("mime"),
                    item.getString("data"),item.getInt("size")))
            }
        }
        results
    }
    if (artifacts.isEmpty()) {NexusLabel(stringResource(app.svyazka.mobile.R.string.ws_no_artifacts));return}
    for (artifact in artifacts) {
        Text(stringResource(app.svyazka.mobile.R.string.ws_artifact_size, artifact.name, artifact.size),
            style=MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
            if (artifact.mime=="image/png" || artifact.name.endsWith(".html")) {
                TextButton(onClick={
                    if (artifact.mime=="image/png") ui.showVisual(artifact.data,"")
                    else ui.showVisual("",String(Base64.decode(artifact.data,Base64.DEFAULT),Charsets.UTF_8))
                }) {Text(stringResource(app.svyazka.mobile.R.string.ws_open))}
            }
            TextButton(onClick={
                pendingSave=artifact
                saveLauncher.launch(Intent(Intent.ACTION_CREATE_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE).setType(contentType(artifact.name))
                    .putExtra(Intent.EXTRA_TITLE,artifact.name.substringAfterLast('/')))
            }) {Text(stringResource(app.svyazka.mobile.R.string.ws_save_phone))}
            val alreadyInProject = ui.pythonFileList.contains(artifact.name)
            TextButton(onClick = {
                if (alreadyInProject) confirmReplace = artifact
                else saveToProject(artifact)
            }) {
                Text(stringResource(if (alreadyInProject) app.svyazka.mobile.R.string.ws_replace
                    else app.svyazka.mobile.R.string.ws_save_project))
            }
        }
    }
    confirmReplace?.let { artifact ->
        NexusFrostedAlertDialog(onDismissRequest={confirmReplace=null},
            title={Text(stringResource(app.svyazka.mobile.R.string.ws_replace_title))},
            text={Text(stringResource(app.svyazka.mobile.R.string.ws_replace_artifact, artifact.name))},
            confirmButton={TextButton(onClick={
                confirmReplace = null
                saveToProject(artifact)
            }){Text(stringResource(app.svyazka.mobile.R.string.ws_replace))}},
            dismissButton={TextButton(onClick={confirmReplace=null}){Text(stringResource(app.svyazka.mobile.R.string.ws_cancel))}})
    }
    if (projectSaveFeedback.isNotBlank()) {
        Text(projectSaveFeedback, style = MaterialTheme.typography.bodySmall,
            color = if (ui.pythonProjectIssue.isBlank()) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.error)
    }
    if (ui.pythonProjectIssue.isNotBlank() && ui.pythonProjectIssue != projectSaveFeedback) {
        Text(ui.pythonProjectIssue, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun PythonRunTests(ui:NexusComposeUi) {
    val report=ui.pythonReport
    if (report == null) {NexusLabel(stringResource(app.svyazka.mobile.R.string.ws_not_tested));return}
    val tests=remember(report.testsJson) {
        runCatching {JSONArray(report.testsJson)}.getOrDefault(JSONArray())
    }
    if (tests.length()==0) {
        NexusLabel(stringResource(app.svyazka.mobile.R.string.ws_no_test_cases))
        return
    }
    var passed=0
    for (index in 0 until tests.length()) if (tests.optJSONObject(index)?.optBoolean("passed") == true) passed++
    Text(stringResource(app.svyazka.mobile.R.string.ws_passed,passed,tests.length()),
        style=MaterialTheme.typography.titleMedium)
    for (index in 0 until tests.length()) {
        val test=tests.optJSONObject(index)?:continue
        val ok=test.optBoolean("passed")
        Text((if(ok) "PASS" else "FAIL") + " · " + test.optString("name"),
            color=if(ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        Text(stringResource(app.svyazka.mobile.R.string.ws_input,test.optString("stdin")),
            style=MaterialTheme.typography.bodySmall)
        Text(stringResource(app.svyazka.mobile.R.string.ws_expected,test.optString("expected")),
            style=MaterialTheme.typography.bodySmall)
        Text(stringResource(app.svyazka.mobile.R.string.ws_actual,test.optString("actual")),
            style=MaterialTheme.typography.bodySmall)
        Text(stringResource(app.svyazka.mobile.R.string.ws_duration,test.optInt("duration_ms",0)),
            style=MaterialTheme.typography.labelSmall)
        HorizontalDivider()
    }
    NexusLabel(stringResource(app.svyazka.mobile.R.string.ws_pass_scope))
}
