package app.svyazka.mobile.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.R

/** Drawer visibility does not own any running Python jobs or stored results. */
@Composable
fun NexusPythonWorkspace(ui: NexusComposeUi) {
    val state = ui.snapshot
    val blocks = ui.pythonCodeBlocks
    var selected by remember(blocks, ui.pythonStep) { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(stringResource(R.string.python_run_title), style = MaterialTheme.typography.titleMedium)
        if (blocks.isEmpty() && ui.pythonEditingCode.isBlank() && !ui.pythonBusy && ui.pythonReport == null) {
            NexusLabel(stringResource(R.string.ui_no_code))
            if (state.resultHasPython && state.complete) {
                OutlinedButton(onClick = { ui.activity.nexusRunPython(ui.activity.nexusFinalStep()) }) {
                    Text(stringResource(R.string.action_python))
                }
            }
        }
        if (blocks.size > 1 && !ui.pythonBusy) {
            blocks.forEachIndexed { index, code ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = index == selected, onClick = {
                        selected = index
                        ui.pythonEditingCode = code
                    })
                    Text(stringResource(R.string.python_block, index + 1),
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (ui.pythonEditingCode.isNotBlank()) {
            OutlinedTextField(value = ui.pythonEditingCode,
                onValueChange = { if (it.length <= 75_000) ui.pythonEditingCode = it },
                modifier = Modifier.fillMaxWidth(), enabled = !ui.pythonBusy && !state.active,
                label = { Text(stringResource(R.string.ui_code)) },
                textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                minLines = 5, maxLines = 12)
            if (!ui.pythonBusy) {
                OutlinedTextField(value = ui.pythonStdin,
                    onValueChange = { if (it.length <= 16_000) ui.pythonStdin = it },
                    modifier = Modifier.fillMaxWidth(), maxLines = 4,
                    label = { Text(stringResource(R.string.python_input_hint)) })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = ui.pythonMatplotlib, onCheckedChange = {
                        ui.pythonMatplotlib = it
                        if (it) ui.pythonRemote = false
                    })
                    Text(stringResource(R.string.python_package_permission),
                        style = MaterialTheme.typography.bodySmall)
                }
                if (ui.pythonHasPiston) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = ui.pythonRemote, onCheckedChange = {
                            ui.pythonRemote = it
                            if (it) ui.pythonMatplotlib = false
                        })
                        Text(stringResource(R.string.python_use_piston),
                            style = MaterialTheme.typography.bodySmall)
                    }
                    if (ui.pythonRemote) NexusLabel(stringResource(R.string.python_warning_remote))
                }
                NexusPrimaryButton(text = stringResource(R.string.action_start),
                    enabled = !state.active && !state.clearing && ui.pythonEditingCode.isNotBlank(),
                    onClick = {
                        ui.activity.nexusExecutePython(ui.pythonStep, ui.pythonEditingCode,
                            ui.pythonStdin, ui.pythonRemote, ui.pythonMatplotlib)
                    }, modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Outlined.PlayArrow, null) }, glow = false)
            }
        }
        if (ui.pythonBusy) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(21.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(9.dp))
                Text(stringResource(R.string.status_processing), modifier = Modifier.weight(1f))
                IconButton(onClick = { ui.activity.nexusCancelPython() }) {
                    Icon(Icons.Outlined.Stop, stringResource(R.string.action_stop))
                }
            }
            NexusLabel(stringResource(R.string.ui_python_background))
        }
        ui.pythonError?.let { error ->
            Text(error, color = MaterialTheme.colorScheme.error)
        }
        ui.pythonReport?.let { report ->
            HorizontalDivider()
            Text(stringResource(R.string.ui_result), style = MaterialTheme.typography.titleMedium)
            NexusLabel(report.engine + (report.exitCode?.let { " · $it" } ?: ""))
            if (report.status.isNotBlank()) Text(report.status, color = MaterialTheme.colorScheme.error)
            Text(stringResource(R.string.python_stdout), style = MaterialTheme.typography.labelLarge)
            SelectionContainer {
                Text(report.stdout.ifBlank { stringResource(R.string.python_no_output) },
                    style = MaterialTheme.typography.bodyMedium)
            }
            if (report.stderr.isNotBlank()) {
                Text(stringResource(R.string.python_stderr), style = MaterialTheme.typography.labelLarge)
                SelectionContainer {
                    Text(report.stderr, color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (report.hasVisual) TextButton(onClick = { ui.openVisual() }) {
                Text(stringResource(R.string.action_show_result))
            }
            if (report.diagnostic.isNotBlank()) TextButton(onClick = {
                ui.activity.nexusSendPythonError()
                ui.dismissPythonResult()
            }) { Text(stringResource(R.string.python_error_to_review)) }
            OutlinedButton(onClick = { ui.dismissPythonResult() }) {
                Text(stringResource(R.string.action_close))
            }
        }
    }
}
