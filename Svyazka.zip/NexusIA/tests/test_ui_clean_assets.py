"""Regression checks for the merged source package and Android launcher identity.

No Android SDK, Gradle, or optional packages are needed for these structural tests.
"""
from pathlib import Path
from unittest import TestCase
import re
import struct
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'app/src/main/res'

class UiAssetCleanupTests(TestCase):
    def test_launcher_manifest_points_to_new_mipmap(self):
        manifest = ET.parse(ROOT / 'app/src/main/AndroidManifest.xml').getroot()
        app = manifest.find('application')
        android = '{http://schemas.android.com/apk/res/android}'
        self.assertEqual(app.get(android + 'icon'), '@mipmap/ic_launcher')
        self.assertEqual(app.get(android + 'roundIcon'), '@mipmap/ic_launcher_round')

    def test_launcher_adaptive_and_all_legacy_densities_exist(self):
        for name in ('ic_launcher', 'ic_launcher_round'):
            p = RES / 'mipmap-anydpi-v26' / (name + '.xml')
            self.assertTrue(p.is_file(), p)
            self.assertEqual(ET.parse(p).getroot().tag, 'adaptive-icon')
        for density, expected in [('mdpi',48), ('hdpi',72), ('xhdpi',96),
                                  ('xxhdpi',144), ('xxxhdpi',192)]:
            for name in ('ic_launcher.png','ic_launcher_round.png'):
                image = RES / f'mipmap-{density}' / name
                data = image.read_bytes()
                self.assertEqual(data[:8], b'\x89PNG\r\n\x1a\n')
                self.assertEqual(struct.unpack('>II', data[16:24]), (expected,expected))

    def test_no_old_internal_png_icons(self):
        allowed = {'ic_nia_logo', 'ic_nia_models'}
        for folder in ('drawable','drawable-night'):
            for image in (RES / folder).glob('ic_nia_*.png'):
                self.assertIn(image.stem,allowed,image)
        self.assertFalse((RES / 'drawable/ic_nexus.xml').exists())
        self.assertFalse((RES / 'drawable-v26/ic_nexus.xml').exists())
        self.assertFalse((ROOT / 'design/icon-sheets').exists())
        self.assertFalse((ROOT / 'scripts/crop-icons.py').exists())

    def test_all_used_drawable_names_resolve(self):
        ids = {p.stem for folder in RES.glob('drawable*') for p in folder.iterdir()
               if p.is_file()}
        for source in (ROOT / 'app/src/main/java').rglob('*'):
            if source.suffix not in ('.kt', '.java'):
                continue
            for name in re.findall(r'R\.drawable\.(\w+)', source.read_text()):
                self.assertIn(name,ids,f'{source}: {name}')

    def test_old_apk_excluded_and_app_identity_unchanged(self):
        self.assertFalse((ROOT / 'apk').exists())
        gradle=(ROOT / 'app/build.gradle').read_text()
        self.assertIn("applicationId 'app.svyazka.team'",gradle)
        self.assertIn("versionCode 19",gradle)
        self.assertIn("versionName '0.7.0'",gradle)

if __name__ == '__main__':
    import unittest
    unittest.main()
