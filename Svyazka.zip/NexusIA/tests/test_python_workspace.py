"""Tests for the manual Python WASM workspace implementation.

These tests run with CPython as contract tests; the shipped Pyodide is additionally
run by tests/test-python-worker.mjs. They do not simulate Android UI.
"""
import base64
import contextlib
import importlib.util
import io
from pathlib import Path
import tempfile
import unittest
import json

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/assets/sandbox/workspace.py'
spec = importlib.util.spec_from_file_location('nexus_workspace', SRC)
ws = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ws)

TINY_PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC')


class WorkspaceContracts(unittest.TestCase):
    def test_safe_paths(self):
        for ok in ('main.py', 'lib/utils.py', 'data_1.csv', 'data/sub/file.json'):
            self.assertTrue(ws.valid_path(ok), ok)
        for bad in ('', '../secret', '/etc/passwd', 'data//x', '.git/config', 'data/../../q',
                    'a\\b.py', 'a/'+'x'*65, 'with space.py', 'a/./b', 'C:/data.csv'):
            self.assertFalse(ws.valid_path(bad), bad)

    def test_decode_limits(self):
        with self.assertRaises(ValueError):
            ws.decode_files(json.dumps({'../secret': base64.b64encode(b'hi').decode()}))
        with self.assertRaises(ValueError):
            ws.decode_files(json.dumps({'main.py': base64.b64encode(b'x'*420001).decode()}))
        files = ws.decode_files(json.dumps({'main.py': base64.b64encode(b'print(7)').decode()}))
        self.assertEqual(files['main.py'], b'print(7)')

    def test_files_modules_results(self):
        cwd = Path.cwd()
        with tempfile.TemporaryDirectory() as dirname:
            ws.ROOT = Path(dirname) / 'w'
            files = {'main.py': b'from utils import twice\nprint(twice(3))\n',
                     'utils.py': b'def twice(x):\n return 2*x\n'}
            try:
                ws.reset_workspace(files)
                stdout = io.StringIO()
                with contextlib.redirect_stdout(stdout):
                    code = ws.run_script(files['main.py'].decode(), 'main.py')
                self.assertEqual(code, 0)
                self.assertEqual(stdout.getvalue(), '6\n')
                (ws.ROOT / 'a.png').write_bytes(TINY_PNG)
                (ws.ROOT / 'report.json').write_text('{"ok":true}', encoding='utf8')
                items = ws.collect_artifacts(files)
                self.assertEqual([a['name'] for a in items], ['a.png','report.json'])
                self.assertEqual(ws.snapshot_sha256(files),ws.snapshot_sha256(dict(reversed(list(files.items())))))
                self.assertTrue(ws.valid_png(TINY_PNG))
                self.assertFalse(ws.valid_png(b'not png'))
            finally:
                import os
                os.chdir(cwd)

    def test_tests_contract(self):
        cases = ws.tests_from_files({'tests.json':json.dumps([{'name':'t','stdin':'5','stdout':'6'}]).encode()})
        self.assertEqual(len(cases),1)
        with self.assertRaises(ValueError): ws.tests_from_files({'tests.json':b'[{}]'})
        with self.assertRaises(ValueError): ws.tests_from_files({'tests.json':b'['})


if __name__ == '__main__': unittest.main()
