import csv
import json
from utils import twice

with open('data.csv', newline='', encoding='utf-8') as stream:
    value = int(next(csv.DictReader(stream))['number'])
result = twice(value)
print(result)
with open('report.json', 'w', encoding='utf-8') as stream:
    json.dump({'original': value, 'doubled': result}, stream)
