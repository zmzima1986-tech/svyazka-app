package app.svyazka.mobile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Immutable verification state belonging to one workflow cycle. */
public final class PythonVerification {
    public enum Status {
        NONE,
        CHECKING,
        REPAIRING,
        PASSED,
        RAN,
        LIMITED,
        ERROR,
        STOPPED
    }

    static final int MAX_REQUESTS = 3;
    public final Status status;
    public final int source, rounds, requests, passed, total;
    public final boolean syntax, ran;
    public final String diagnostic;
    private final String digest, history;
    static final PythonVerification NONE =
            new PythonVerification(Status.NONE, -1, 0, 0, false, false, 0, 0, "", "", "[]");

    private PythonVerification(
            Status status,
            int source,
            int rounds,
            int requests,
            boolean syntax,
            boolean ran,
            int passed,
            int total,
            String diagnostic,
            String digest,
            String history) {
        this.status = status;
        this.source = source;
        this.rounds = rounds;
        this.requests = requests;
        this.syntax = syntax;
        this.ran = ran;
        this.passed = passed;
        this.total = total;
        this.diagnostic = diagnostic;
        this.digest = digest;
        this.history = history;
    }

    boolean busy() {
        return status == Status.CHECKING || status == Status.REPAIRING;
    }

    static String hash(String code) {
        return InputMaterial.sha256(code.trim().getBytes(StandardCharsets.UTF_8));
    }

    /** Only pass the source that produced this verifier result to an AI diagnostic. */
    boolean matchesCheckedSource(String source, String issue) {
        return !digest.isEmpty() && source != null && issue != null
                && digest.equals(hash(issue + "\n" + source));
    }

    PythonVerification start(int index, String code) {
        return new PythonVerification(
                Status.CHECKING,
                index,
                rounds,
                requests,
                false,
                false,
                0,
                0,
                "",
                hash(code),
                history);
    }

    /** Structured generated tests from the latest check of these exact bytes. */
    public int generatedSuitePassed() {
        JSONArray log = entries();
        JSONObject latest = log.optJSONObject(log.length() - 1);
        if (status != Status.RAN || latest == null || !digest.equals(latest.optString("digest"))) return -1;
        JSONObject execution = latest.optJSONObject("project_execution");
        JSONObject suite = execution == null ? null : execution.optJSONObject("generated_tests");
        if (suite == null || !"PASSED".equals(suite.optString("status"))) return -1;
        int n = suite.optInt("discovered", -1);
        return n > 0 && n <= 24 && suite.optInt("ran", -1) == n && suite.optInt("passed", -1) == n
                && suite.optInt("failed", -1) == 0 && suite.optInt("skipped", -1) == 0 ? n : -1;
    }

    private JSONArray entries() {
        try {
            return new JSONArray(history);
        } catch (JSONException impossible) {
            throw new IllegalStateException(impossible);
        }
    }

    private boolean seen(String key, String value) {
        JSONArray log = entries();
        for (int i = 0; i < log.length(); i++)
            if (value.equals(log.optJSONObject(i).optString(key))) return true;
        return false;
    }

    boolean seenCode(String code) {
        return seen("digest", hash(code));
    }

    PythonVerification progress(boolean parsed, boolean executed, int count, int all) {
        return new PythonVerification(
                status,
                source,
                rounds,
                requests,
                parsed,
                executed,
                count,
                all,
                diagnostic,
                digest,
                history);
    }

    private PythonVerification outcome(Status kind, String reason) {
        return new PythonVerification(
                kind, source, rounds, requests, syntax, ran, passed, total, reason, digest,
                history);
    }

    PythonVerification stopped(String reason) {
        return outcome(Status.STOPPED, reason);
    }

    PythonVerification keepPrevious(int step, String reason) {
        return new PythonVerification(Status.STOPPED, step, rounds, requests, false, false,
                0, 0, reason, "", history);
    }

    PythonVerification limited(String reason) {
        return outcome(Status.LIMITED, reason);
    }

    PythonVerification report(JSONObject j) throws JSONException {
        Status kind;
        try {
            kind = Status.valueOf(j.getString("status"));
        } catch (IllegalArgumentException e) {
            throw new JSONException("Unknown verifier status");
        }
        boolean parsed = j.getBoolean("syntax"), executed = j.getBoolean("ran");
        int count = j.getInt("passed"), all = j.getInt("total");
        String why = j.getString("diagnostic"), signature = j.getString("signature");
        if ((kind != Status.PASSED
                        && kind != Status.RAN
                        && kind != Status.ERROR
                        && kind != Status.LIMITED)
                || count < 0
                || all < count
                || all > 24
                || executed && !parsed
                || kind == Status.PASSED && (!executed || all == 0 || count != all)
                || kind == Status.RAN && (!executed || all != 0)
                || kind == Status.ERROR && (signature.isEmpty() || why.isEmpty()))
            throw new JSONException("Inconsistent verifier report");
        String category = j.optString("category", kind == Status.ERROR ? "RUNTIME_ERROR" : "NOT_TESTED");
        if (kind == Status.ERROR && (category.equals("DEPENDENCY_UNAVAILABLE") ||
                category.equals("ENVIRONMENT_UNSUPPORTED") || category.equals("REQUIRES_EXTERNAL_SERVICE")
                || !category.equals("ANDROID_API_CONTRACT") && environmentalDiagnostic(why))) kind = Status.LIMITED;
        boolean repeated = kind == Status.ERROR && seen("signature", signature);
        JSONArray log = entries();
        log.put(
                new JSONObject()
                        .put("source", source)
                        .put("round", rounds)
                        .put("digest", digest)
                        .put("status", kind.name())
                        .put("category", category)
                        .put("feature_review", j.optJSONObject("feature_review"))
                        .put("android_permissions", j.optJSONObject("android_permissions"))
                        .put("project_execution", j.optJSONObject("project_execution"))
                        .put("signature", signature)
                        .put("diagnostic", why)
                        .put("passed", count)
                        .put("total", all));
        if (repeated
                || kind == Status.ERROR && (requests >= MAX_REQUESTS || rounds >= MAX_REQUESTS)) {
            why =
                    (repeated ? "Та же ошибка обнаружена повторно." : "Исчерпан лимит исправлений.")
                            + "\n"
                            + why;
            kind = Status.STOPPED;
        }
        return new PythonVerification(
                kind,
                source,
                rounds,
                requests,
                parsed,
                executed,
                count,
                all,
                why,
                digest,
                log.toString());
    }

    PythonVerification repair() {
        if (status != Status.ERROR || rounds >= MAX_REQUESTS || requests >= MAX_REQUESTS)
            throw new IllegalStateException("Repair budget");
        return new PythonVerification(
                Status.REPAIRING,
                source,
                rounds + 1,
                requests,
                syntax,
                ran,
                passed,
                total,
                diagnostic,
                digest,
                history);
    }

    PythonVerification dispatch() {
        if (status != Status.REPAIRING || requests >= MAX_REQUESTS)
            throw new IllegalStateException("Request budget");
        return new PythonVerification(
                status,
                source,
                rounds,
                requests + 1,
                syntax,
                ran,
                passed,
                total,
                diagnostic,
                digest,
                history);
    }

    PythonVerification withUnfinishedRepair(Workflow.Artifact draft) {
        if (draft.text.isEmpty()) return this;
        JSONArray log = entries();
        try {
            log.put(
                    new JSONObject()
                            .put("round", rounds)
                            .put("status", "PARTIAL")
                            .put("partial_answer", draft.toJson())
                            .put("diagnostic", diagnostic));
        } catch (JSONException e) {
            throw new IllegalStateException(e);
        }
        return new PythonVerification(
                status,
                source,
                rounds,
                requests,
                syntax,
                ran,
                passed,
                total,
                diagnostic,
                digest,
                log.toString());
    }

    public JSONObject featureReview() {
        JSONArray log = entries();
        for (int i = log.length() - 1; i >= 0; i--) {
            JSONObject entry = log.optJSONObject(i);
            if (entry == null || !entry.has("status")) continue;
            JSONObject features = entry.optJSONObject("feature_review");
            return features == null ? new JSONObject() : features;
        }
        return new JSONObject();
    }

    public String category() {
        JSONArray log = entries();
        if (log.length() == 0) return "NOT_TESTED";
        JSONObject last = log.optJSONObject(log.length() - 1);
        return last == null ? "NOT_TESTED" : last.optString("category", "NOT_TESTED");
    }

    static boolean environmentalDiagnostic(String diagnostic) {
        String text = diagnostic.toLowerCase(java.util.Locale.ROOT);
        return text.contains("modulenotfounderror") || text.contains("no module named")
                || text.contains("модуль недоступен") || text.contains("bluetooth adapter")
                || text.contains("no display name") || text.contains("failed to fetch")
                || text.contains("network is unreachable") || text.contains("permissionerror");
    }

    public String diagnosticsHistory() {
        JSONArray log = entries();
        List<String> lines = new ArrayList<>();
        for (int i = 0; i < log.length(); i++) {
            String detail = log.optJSONObject(i).optString("diagnostic");
            if (!detail.isEmpty()) lines.add((i + 1) + ". " + detail);
        }
        return String.join("\n\n", lines);
    }

    JSONObject json() throws JSONException {
        return new JSONObject()
                .put("status", status.name())
                .put("source", source)
                .put("category", category())
                .put("rounds", rounds)
                .put("requests", requests)
                .put("syntax", syntax)
                .put("ran", ran)
                .put("passed", passed)
                .put("total", total)
                .put("diagnostic", diagnostic)
                .put("digest", digest)
                .put("history", entries());
    }

    static PythonVerification read(JSONObject j) throws JSONException {
        if (j == null) return NONE;
        try {
            int r = j.getInt("rounds"), c = j.getInt("requests");
            if (r < 0 || r > MAX_REQUESTS || c < 0 || c > MAX_REQUESTS)
                throw new JSONException("Invalid repair budget");
            JSONArray log = j.getJSONArray("history");
            for (int i = 0; i < log.length(); i++) log.getJSONObject(i);
            return new PythonVerification(
                    Status.valueOf(j.getString("status")),
                    j.getInt("source"),
                    r,
                    c,
                    j.getBoolean("syntax"),
                    j.getBoolean("ran"),
                    j.getInt("passed"),
                    j.getInt("total"),
                    j.getString("diagnostic"),
                    j.getString("digest"),
                    log.toString());
        } catch (IllegalArgumentException e) {
            throw new JSONException("Invalid verification status");
        }
    }
}
