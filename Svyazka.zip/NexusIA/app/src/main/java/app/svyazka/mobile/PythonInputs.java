package app.svyazka.mobile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class PythonInputs {
    private static final Pattern FENCE = Pattern.compile("^ {0,3}(\u0060{3,}|~{3,})(.*)$");
    private static final Pattern HEADER =
            Pattern.compile(
                    "(?:def\\s+[\\p{L}_]\\w*\\s*\\(.*\\)\\s*(?:->[^:]+)?\\s*:.*|"
                        + "(?:from\\s+[.\\w]+\\s+)?import\\s+[.\\w]+(?:\\s+as\\s+\\w+)?(?:\\s*,\\s*[.\\w]+)*|"
                        + "print\\s*\\(.*\\)|if\\s+__name__\\s*==\\s*[\"']__main__[\"']\\s*:)\\s*(?:#.*)?");
    private static final Pattern STATEMENT =
            Pattern.compile(
                    "(?:[\\p{L}_]\\w*\\s*=(?!=).+|[\\p{L}_]\\w*\\(.*\\)|"
                        + "(?:if|elif|for|while|with)\\s+.+:|else:|try:|except\\b.*:)\\s*(?:#.*)?");
    private static final String MATERIALS = "\n\n<attached_materials>\n",
            END = "\n</attached_materials>";

    private PythonInputs() {}

    private static boolean raw(String source) {
        boolean evidence = false;
        for (String line : source.split("\\r?\\n")) {
            String s = line.trim();
            if (s.isEmpty() || s.startsWith("#") || Character.isWhitespace(line.charAt(0)))
                continue;
            if (HEADER.matcher(s).matches()) evidence = true;
            else if (!STATEMENT.matcher(s).matches()) return false;
        }
        return evidence;
    }

    public static final class Candidate {
        public final String code, issue;
        public final boolean ambiguous;
        final List<String> parts;

        Candidate(String code, String issue, boolean ambiguous, List<String> parts) {
            this.code = code;
            this.issue = issue;
            this.ambiguous = ambiguous;
            this.parts = parts;
        }
    }

    private static final class Block {
        final String tag, body;
        final boolean closed;

        Block(String tag, String body, boolean closed) {
            this.tag = tag;
            this.body = body;
            this.closed = closed;
        }

        boolean python() {
            return tag.equals("py")
                    || tag.equals("python")
                    || tag.equals("python3")
                    || tag.isEmpty() && raw(body);
        }
    }

    private static List<Block> blocks(String text) {
        List<Block> list = new ArrayList<>();
        String marker = "", tag = "";
        int indent = 0;
        StringBuilder body = new StringBuilder();
        for (String line : text.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1)) {
            Matcher m = FENCE.matcher(line);
            boolean fence = m.matches();
            if (marker.isEmpty()) {
                if (fence) {
                    marker = m.group(1);
                    indent = m.start(1);
                    tag = m.group(2).trim().toLowerCase(Locale.ROOT).split("\\s+", 2)[0];
                    body.setLength(0);
                }
            } else if (fence && m.group(1).startsWith(marker) && m.group(2).trim().isEmpty()) {
                list.add(new Block(tag, body.toString(), true));
                marker = "";
            } else {
                int skip = 0;
                while (skip < indent && skip < line.length() && line.charAt(skip) == ' ') skip++;
                body.append(line, skip, line.length()).append('\n');
            }
        }
        if (!marker.isEmpty()) list.add(new Block(tag, body.toString(), false));
        return list;
    }

    public static Candidate candidate(String answer) {
        List<Block> all = blocks(answer);
        List<String> parts = new ArrayList<>();
        Block found = null;
        for (Block b : all)
            if (b.python()) {
                parts.add(b.body);
                found = b;
            }
        if (found == null)
            return all.isEmpty() && raw(answer) ? new Candidate(answer, "", false, parts) : null;
        if (all.size() > 1)
            return new Candidate(
                    "", "Несколько файлов или примеров. Точка входа неоднозначна.", true, parts);
        if (found.body.trim().isEmpty()) return new Candidate("", "Блок Python пуст.", true, parts);
        // Do not silently strip nested fences or duplicate language markers: both
        // occurred in real multi-provider repairs and can corrupt a runnable file.
        String cleanBody = found.body.trim();
        if (cleanBody.matches("(?s)^python\\s*\\n.*"))
            return new Candidate(found.body, "Внутри блока кода повторена метка python.", false, parts);
        for (String line : found.body.split("\\r?\\n")) {
            Matcher nested = FENCE.matcher(line);
            if (nested.matches() && !nested.group(2).trim().isEmpty())
                return new Candidate(found.body, "Внутри блока Python начинается ещё один блок кода.", false, parts);
        }
        return new Candidate(
                found.body, found.closed ? "" : "Не закрыт блок Python.", false, parts);
    }

    /** Stable export provenance; the actual source remains in answers[], not a duplicate blob. */
    static JSONObject artifact(Workflow.Run run) throws JSONException {
        if (!run.complete()) return null;
        int source = run.finalIndex();
        Candidate result = candidate(run.displayAnswer(source));
        if (result == null) return null;
        boolean usable = !result.ambiguous && result.issue.isEmpty() && !result.code.trim().isEmpty();
        JSONObject meta = new JSONObject()
                .put("source_step", source + 1)
                .put("source", "answers")
                .put("format_complete", usable)
                .put("verification_status", run.verification.status.name())
                .put("issue", result.issue);
        if (usable) {
            meta.put("file_name", "result.py")
                    .put("sha256", InputMaterial.sha256(
                            result.code.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
        }
        return meta;
    }

    static List<String> manualBlocks(String answer) {
        List<String> result = SandboxClient.pythonBlocks(answer);
        if (result.isEmpty()) {
            Candidate c = candidate(answer);
            if (c != null && c.issue.isEmpty()) result.add(c.code);
        }
        return result;
    }

    static JSONObject request(Workflow.Run run, String code) throws JSONException {
        String source = run.userTestTask();
        if (source.length() > Workflow.TASK_LIMIT)
            throw new JSONException("Слишком много исходных материалов.");
        JSONArray specs = new JSONArray();
        JSONObject files = new JSONObject();
        int start = source.indexOf(MATERIALS),
                end = start < 0 ? -1 : source.indexOf(END, start + MATERIALS.length());
        if (!run.materials.isEmpty() && start >= 0 && end >= 0) {
            JSONArray entries = new JSONArray(source.substring(start + MATERIALS.length(), end));
            if (entries.length() != run.materials.size())
                throw new JSONException("Состав исходных файлов изменился.");
            for (int i = 0; i < entries.length(); i++) {
                JSONObject entry = entries.getJSONObject(i);
                String name = entry.getString("name");
                if (!name.equals(run.materials.get(i).name))
                    throw new JSONException("Имя вложения не совпало.");
                if (!"TEXT".equals(entry.getString("type"))) continue;
                if (files.has(name)) throw new JSONException("Одинаковые имена вложений: " + name);
                if (name.equalsIgnoreCase("nexus-tests.json")) specs.put(entry.getString("text"));
                else files.put(name, entry.getString("text"));
            }
            source = source.substring(0, start) + "\n" + source.substring(end + END.length());
        }
        for (Block b : blocks(source))
            if (b.tag.equals("nexus-tests")) {
                if (!b.closed) throw new JSONException("Не закрыт блок nexus-tests.");
                specs.put(b.body);
            }
        return new JSONObject()
                .put("mode", "verify")
                .put("code", code)
                .put("files", files)
                .put("examples", source)
                .put("specs", specs);
    }
}
