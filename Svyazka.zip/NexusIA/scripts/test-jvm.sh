#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

out="$PWD/build/jvm-tests"
mkdir -p "$out"
json_jar="${JSON_JAR:-$out/json-20250107.jar}"
sha=85d4c1ab192d3117fd02c7fff1ec0fe63ade45cf56def7fe950ef060cf06e99f
verify_jar() {
    if command -v sha256sum >/dev/null; then
        sha256sum "$1" | awk '{print $1}'
    else
        shasum -a 256 "$1" | awk '{print $1}'
    fi
}
if [[ ! -f "$json_jar" ]]; then
    if [[ -n "${JSON_JAR:-}" ]]; then
        echo "Файл JSON_JAR не найден: $json_jar" >&2
        exit 1
    fi
    tmp="$(mktemp "$out/json.XXXXXX")"
    trap 'rm -f "$tmp"' EXIT
    curl --fail --silent --show-error --location --connect-timeout 15 --max-time 45 \
        https://repo.maven.apache.org/maven2/org/json/json/20250107/json-20250107.jar -o "$tmp"
    [[ "$(verify_jar "$tmp")" = "$sha" ]]
    mv "$tmp" "$json_jar"
fi
if [[ "$(verify_jar "$json_jar")" != "$sha" ]]; then
    echo "Ожидается org.json 20250107 с контрольной суммой $sha" >&2
    exit 1
fi
javac="${JAVA_HOME:+$JAVA_HOME/bin/}javac"
java="${JAVA_HOME:+$JAVA_HOME/bin/}java"
src="app/src/main/java/app/svyazka/mobile"
sources=("$src"/{Workflow,ModelClient,ModelCatalog,ModelPool,SandboxClient,WorkspaceStore,RequestFailure,ContinuationIntegrity,RequestExecutor,AttemptJournal,CredentialStore,PythonExecutor,TaskHistory,NexusState,NexusPythonReport,AttachmentProblem,AttachmentParser,InputMaterial,PythonInputs,PythonVerification,VerificationMemory}.java)
"$javac" -encoding UTF-8 -cp "$json_jar" -d "$out" "${sources[@]}" tests/jvm/*.java
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.WorkflowChecks tests/fixtures/openrouter-models.json
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.FeatureChecks
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.StabilityChecks
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.ReleaseChecks
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.HistoryChecks
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.VisualProtocolChecks
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.NexusStateChecks
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.AttachmentChecks
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.VerificationChecks
"$java" -ea -cp "$json_jar:$out" app.svyazka.mobile.RecoveryChecks
