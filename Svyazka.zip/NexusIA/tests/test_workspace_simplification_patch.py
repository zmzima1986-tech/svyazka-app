"""Source contracts for the November workspace and chat-layout patch.

An Android build and a device tap-through are still required for runtime validation.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "app/src/main/java/app/svyazka/mobile/ui"
JAVA = ROOT / "app/src/main/java/app/svyazka/mobile/MainActivity.java"


class WorkspaceSimplificationTests(unittest.TestCase):
    def test_plus_menu_keeps_all_four_chat_actions(self):
        chat = (UI / "NexusChat.kt").read_text()
        for action in ('attachAction()', 'nexusOpenArtifacts()', 'nexusSaveChat()',
                       'R.string.ws_create'):
            self.assertIn(action, chat)
        self.assertIn('chatActionsExpanded', chat)
        components = (UI / "NexusComponents.kt").read_text()
        self.assertNotIn('nexusSaveChat()', components)

    def test_navigation_returns_to_prior_tab_before_closing_workspace(self):
        ui = (UI / "NexusComposeUi.kt").read_text()
        drawers = (UI / "NexusDrawers.kt").read_text()
        self.assertIn('workspaceTabHistory = (workspaceTabHistory + workspaceTab).takeLast(12)', ui)
        self.assertIn('if (panel == Panel.RIGHT && backWorkspaceTab()) return true', ui)
        self.assertIn('ui.switchWorkspaceTab(tab)', drawers)
        self.assertIn('ui.backWorkspaceTab()', drawers)
        self.assertIn('ui.closePanel()', drawers)

    def test_saveable_tab_state_and_file_view(self):
        drawers = (UI / "NexusDrawers.kt").read_text()
        python = (UI / "NexusPythonWorkspace.kt").read_text()
        files = (UI / "NexusPythonProjectFiles.kt").read_text()
        self.assertIn('rememberSaveableStateHolder()', drawers)
        self.assertIn('tabState.SaveableStateProvider(ui.workspaceTab.name)', drawers)
        self.assertNotIn('if (tab == NexusComposeUi.WorkspaceTab.FILES)',
                         drawers.split('private fun WorkspaceTab(', 1)[1].split('@Composable', 1)[0])
        for setting in ('allowedPackage', 'extended', 'showArtifacts',
                        'resultExpanded'):
            self.assertIn(f'var {setting} by rememberSaveable', python)
        self.assertIn('var newName by rememberSaveable', files)

    def test_chat_link_is_local_refresh_and_footer(self):
        java = JAVA.read_text()
        ui = (UI / "NexusComposeUi.kt").read_text()
        python = (UI / "NexusPythonWorkspace.kt").read_text()
        for action_start, action_end in (
            ('public void nexusAttachArtifactToChat()', '/** Start a separate chat for this project'),
            ('public void nexusDetachArtifactFromChat()', 'public java.util.List<NexusArtifact> nexusArtifacts()'),
        ):
            action = java.split(action_start, 1)[1].split(action_end, 1)[0]
            self.assertIn('nexusUi.refreshChatProjectLink()', action)
            self.assertNotIn('nexusRender(', action)
            self.assertNotIn('selectPage(', action)
        self.assertIn('fun refreshChatProjectLink()', ui)
        self.assertIn('Modifier.align(Alignment.BottomCenter).fillMaxWidth()', python)
        self.assertIn('R.string.ws_chat_linked_status', python)
        self.assertIn('R.string.ws_chat_unlinked_status', python)
        self.assertIn('if (ui.pythonReport == null && !state.active &&', python)
        self.assertIn('if (resultExpanded) {\n                NexusOutlineActionButton(', python)


if __name__ == '__main__':
    unittest.main()
