package app.svyazka.mobile;

import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONObject;
import org.junit.Test;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 33)
public class PromptContextOptimizerTest {
    private static String longCode(String name) {
        StringBuilder text = new StringBuilder("# " + name + "\n");
        for (int i = 0; i < 80; i++) text.append("print('Привет").append(i).append("')\n");
        return text.toString();
    }

    private static JSONObject request(String task, String solution) throws Exception {
        return new JSONObject().put("task", task).put("inputs",
                new JSONObject().put("solution", new JSONObject().put("text", solution)));
    }

    @Test public void identicalLinkedFileIsReplacedByInRequestReference() throws Exception {
        String code = longCode("main.py");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Исправь проект", files, 100000);
        JSONObject payload = request(task, "```python file=main.py\n" + code + "```");
        int before = payload.toString().getBytes(StandardCharsets.UTF_8).length;
        PromptContextOptimizer.compact(payload);
        String optimized = payload.getString("task");
        assertTrue(optimized.contains("Exact copy of inputs.solution.text"));
        assertFalse(optimized.contains(code));
        assertTrue(payload.getJSONObject("inputs").getJSONObject("solution").getString("text").contains(code));
        assertTrue(before - payload.toString().getBytes(StandardCharsets.UTF_8).length > 512);
    }

    @Test public void changedLinkedFileMustRemainComplete() throws Exception {
        String code = longCode("first");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Исправь проект", files, 100000);
        JSONObject payload = request(task, "```python\n" + longCode("different") + "```");
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));
    }

    @Test public void preserveDifferentFileAndOnlyElideIdenticalOne() throws Exception {
        String first = longCode("first");
        String second = longCode("second");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", first.getBytes(StandardCharsets.UTF_8));
        files.put("module.py", second.getBytes(StandardCharsets.UTF_8));
        JSONObject payload = request(ChatProjectContext.append("Задача", files, 100000), first);
        PromptContextOptimizer.compact(payload);
        assertFalse(payload.getString("task").contains(first));
        assertTrue(payload.getString("task").contains(second));
    }

    @Test public void doNotElideTruncatedSource() throws Exception {
        String code = "print('x')\n".repeat(2000);
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Измени", files, 100000);
        JSONObject payload = request(task, code);
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));
        assertTrue(task.contains("truncated"));
    }

    @Test public void noProjectOrSolutionIsUnchanged() throws Exception {
        JSONObject payload = request("Простой вопрос", longCode("sample"));
        String before = payload.toString();
        PromptContextOptimizer.compact(payload);
        assertEquals(before, payload.toString());
        JSONObject withoutSolution = new JSONObject().put("task", "Задача").put("inputs", new JSONObject());
        assertEquals(withoutSolution.toString(), PromptContextOptimizer.compact(withoutSolution).toString());
    }

    @Test public void repairKeepsExactlyOneSourceAndEveryFilePath() throws Exception {
        String code = longCode("main");
        String extra = longCode("different module");
        JSONObject project = new JSONObject().put("main.py", code).put("utils.py", extra);
        JSONObject diagnostic = new JSONObject().put("python_code", code).put("complete_project", project);
        JSONObject payload = new JSONObject().put("task", "Исправь код")
                .put("inputs", new JSONObject().put("sandbox_result", diagnostic));
        String before = payload.toString();
        PromptContextOptimizer.compact(payload);
        assertEquals(code, diagnostic.getString("python_code"));
        assertTrue(project.getString("main.py").contains("Exact copy"));
        assertEquals(extra, project.getString("utils.py"));
        assertTrue(before.length() > payload.toString().length());
    }

    @Test public void repairDoesNotModifyNonidenticalProjectFile() throws Exception {
        String code = longCode("draft");
        JSONObject project = new JSONObject().put("main.py", longCode("different"));
        JSONObject diagnostic = new JSONObject().put("python_code", code).put("complete_project", project);
        String before = diagnostic.toString();
        PromptContextOptimizer.compact(new JSONObject().put("inputs",
                new JSONObject().put("sandbox_result", diagnostic)));
        assertEquals(before, diagnostic.toString());
    }

    @Test public void sameRequestCompactionIsIdempotent() throws Exception {
        String code = longCode("main.py");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        JSONObject payload = request(ChatProjectContext.append("Задача", files, 100000), code);
        PromptContextOptimizer.compact(payload);
        String once = payload.toString();
        PromptContextOptimizer.compact(payload);
        assertEquals(once, payload.toString());
    }

    @Test public void shortFileIsNeverReplacedWithLongReference() throws Exception {
        String code = "print('hello')\n";
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Задача", files, 100000);
        JSONObject payload = request(task, code);
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));
    }

    @Test public void unicodeMetadataUsesUtf8ByteOffsets() throws Exception {
        String code = "# ✅ 中文 Привет 🌍\n".repeat(50);
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        JSONObject payload = request(ChatProjectContext.append("Проверка", files, 100000), code);
        PromptContextOptimizer.compact(payload);
        assertTrue(payload.getString("task").contains("Exact copy of inputs.solution.text"));
        assertTrue(payload.getJSONObject("inputs").getJSONObject("solution").getString("text").contains(code));
    }

    @Test public void unknownProjectFormatIsUntouched() throws Exception {
        String malformed = "Задача\n\n<linked_python_project>\n--- main.py (not bytes) ---\nhello</linked_python_project>";
        JSONObject payload = request(malformed, "hello");
        PromptContextOptimizer.compact(payload);
        assertEquals(malformed, payload.getString("task"));
    }

    @Test public void followUpReusesExactSourceAlreadyInTask() throws Exception {
        String code = longCode("main.py");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append(
                "Предыдущий исходный файл Python:\n<previous_python_source>\n"
                        + code + "</previous_python_source>\nУточнение: добавь функцию",
                files, 100000);
        JSONObject payload = new JSONObject().put("task", task).put("inputs", new JSONObject());
        int before = payload.toString().getBytes(StandardCharsets.UTF_8).length;
        PromptContextOptimizer.compact(payload);
        String updated = payload.getString("task");
        assertEquals(1, updated.split(java.util.regex.Pattern.quote(code), -1).length - 1);
        assertTrue(updated.contains("Exact copy of earlier task text"));
        assertTrue(updated.contains("<previous_python_source>"));
        assertTrue(before - payload.toString().getBytes(StandardCharsets.UTF_8).length > 512);
    }

    @Test public void uniqueNewVersionRemainsFullyAvailable() throws Exception {
        String oldCode = longCode("before");
        String newCode = longCode("after");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", newCode.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Предыдущий код:\n" + oldCode + "\nНовый запрос", files, 100000);
        JSONObject payload = new JSONObject().put("task", task).put("inputs", new JSONObject());
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));
        assertTrue(payload.getString("task").contains(newCode));
    }

    @Test public void codeOnlyAfterSnapshotIsNotTreatedAsEarlierDuplicate() throws Exception {
        String code = longCode("main.py");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Задача", files, 100000) + "\n" + code;
        JSONObject payload = new JSONObject().put("task", task).put("inputs", new JSONObject());
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));
    }

    @Test public void repairCanReuseTheExactSandboxVerifiedFile() throws Exception {
        String code = longCode("main.py");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        JSONObject diagnostic = new JSONObject().put("python_code", code)
                .put("diagnostic", "ZeroDivisionError");
        JSONObject payload = new JSONObject().put("task", ChatProjectContext.append("Исправь", files, 100000))
                .put("inputs", new JSONObject().put("sandbox_result", diagnostic));
        PromptContextOptimizer.compact(payload);
        assertTrue(payload.getString("task").contains("Exact copy of inputs.sandbox_result.python_code"));
        assertEquals(code, diagnostic.getString("python_code"));
        assertEquals("ZeroDivisionError", diagnostic.getString("diagnostic"));
    }

    @Test public void repairKeepsDifferentSandboxCodeAndLinkedFile() throws Exception {
        String code = longCode("main.py");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Исправь", files, 100000);
        JSONObject payload = new JSONObject().put("task", task).put("inputs",
                new JSONObject().put("sandbox_result", new JSONObject()
                        .put("python_code", longCode("changed"))));
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));
    }

    @Test public void partialSnapshotAndShortFileAreNeverReplacedInFollowUp() throws Exception {
        String code = "print('ok')\n";
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        String task = ChatProjectContext.append("Предыдущий код:\n" + code, files, 100000);
        JSONObject payload = new JSONObject().put("task", task).put("inputs", new JSONObject());
        PromptContextOptimizer.compact(payload);
        assertEquals(task, payload.getString("task"));

        String largeCode = "print('very long')\n".repeat(1500);
        files.put("main.py", largeCode.getBytes(StandardCharsets.UTF_8));
        String truncated = ChatProjectContext.append("Предыдущий код:\n" + largeCode, files, 100000);
        JSONObject partial = new JSONObject().put("task", truncated).put("inputs", new JSONObject());
        PromptContextOptimizer.compact(partial);
        assertEquals(truncated, partial.getString("task"));
    }


    @Test public void followUpCanSaveASmallButRepeatedPythonFile() throws Exception {
        String code = "# main.py\n" + "def main():\n" + "    print('ШАГ 5 ПРОВЕРЕНО')\n"
                + ("# valid repeated source data\n".repeat(9)) + "main()\n";
        int bytes = code.getBytes(StandardCharsets.UTF_8).length;
        assertTrue(bytes >= 256 && bytes < 512);
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        JSONObject payload = new JSONObject().put("task", ChatProjectContext.append(
                "Предыдущий файл:\n" + code + "\nДобавь проверку", files, 100000))
                .put("inputs", new JSONObject());
        int before = payload.toString().getBytes(StandardCharsets.UTF_8).length;
        PromptContextOptimizer.compact(payload);
        int saved = before - payload.toString().getBytes(StandardCharsets.UTF_8).length;
        assertTrue(saved > 0);
        assertTrue(payload.getString("task").contains("Exact copy of earlier task text"));
    }

    @Test public void followUpCompactionIsIdempotent() throws Exception {
        String code = longCode("main.py");
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        JSONObject payload = new JSONObject().put("task", ChatProjectContext.append(
                "Предыдущий код:\n" + code, files, 100000))
                .put("inputs", new JSONObject());
        PromptContextOptimizer.compact(payload);
        String once = payload.toString();
        PromptContextOptimizer.compact(payload);
        assertEquals(once, payload.toString());
    }

}
