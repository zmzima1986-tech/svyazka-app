/** Run the shipped JS controller, worker, grader and WASM using Node worker_threads. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Worker as NodeWorker, MessageChannel, parentPort, workerData } from 'node:worker_threads';
import { spawnSync } from 'node:child_process';

const tests = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(tests);
if (parentPort) {
    let callback;
    parentPort.on('message', message => callback({data: message.data, ports: message.ports}));
    globalThis.self = {addEventListener(event, listener) {
        assert.equal(event, 'message');
        callback = listener;
        parentPort.postMessage('listening');
    }};
    const systemFetch = globalThis.fetch;
    globalThis.fetch = (url, ...options) => {
        if (url === './verify.py') return Promise.resolve(new Response(fs.readFileSync(path.join(workerData,'verify.py'))));
        if (/^https?:/.test(String(url))) throw Error('Unexpected external fetch');
        return systemFetch(url,...options);
    };
    await import(pathToFileURL(path.join(workerData,'worker.mjs')));
} else {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-python-'));
    const source = path.join(root,'app/src/main/assets/sandbox');
    const copy = path.join(tmp,'sandbox');
    fs.cpSync(source,copy,{recursive:true});
    const command = (name,args) => {
        const home = process.env.JAVA_HOME;
        const result = spawnSync(home ? path.join(home,'bin',name) : name,args,{encoding:'utf8'});
        assert.equal(result.status,0,result.error?.message || result.stderr);
    };
    const wasm = 'pyodide/pyodide.asm.wasm';
    fs.unlinkSync(path.join(copy,wasm));
    command('javac',['-d',tmp,path.join(tests,'jvm/CappedWasm.java'),path.join(root,'app/src/main/java/app/svyazka/mobile/VerificationMemory.java')]);
    command('java',['-cp',tmp,'app.svyazka.mobile.CappedWasm',path.join(source,wasm),path.join(copy,wasm)]);
    globalThis.Worker = class {
        constructor(script) {
            assert.equal(script,'worker.mjs');
            this.w = new NodeWorker(new URL(import.meta.url),{workerData:copy});
            this.w.on('error', error => {console.error(error); this.onerror?.(error);});
        }
        postMessage(data,ports) {this.w.once('message',()=>this.w.postMessage({data,ports},ports));}
        terminate() {this.w.terminate();}
    };
    let start;
    globalThis.window = {addEventListener(_,fn) {start=fn;}};
    await import(pathToFileURL(path.join(copy,'runner.js')));
    async function run(data) {
        const {port1,port2} = new MessageChannel(), events = [];
        return new Promise((resolve,reject) => {
            const timer=setTimeout(()=>reject(Error('outer deadline')),45000);
            port1.onmessage=({data: output})=>{
                const msg=JSON.parse(output);
                if(msg.progress) events.push(msg.progress);
                else {clearTimeout(timer);port1.close();resolve({msg,events});}
            };
            start({ports:[port2],data:JSON.stringify(data)});
        });
    }
    let count=0;
    async function verify(label,code,status,inputs={}) {
        const {msg,events}=await run({mode:'verify',code,...inputs});
        if(status==='TIMEOUT') assert.match(msg.status??'',/5 секунд/,JSON.stringify(msg));
        else assert.equal(msg.verification?.status,status,label+' '+JSON.stringify(msg));
        if(['PASSED','RAN'].includes(status)) {
            assert.equal(events[0].stage,'syntax');assert.equal(events.at(-1).stage,'executed');
        }
        count++;console.log(label,status);
        return msg.verification;
    }
    try {
        const specs=[JSON.stringify([{function:'diff',args:[0,-2],expected:2},{function:'diff',args:[3,0],expected:3}])];
        const good=await verify('independent boundary cases','def diff(a,b):\n return a-b','PASSED',{specs});
        assert.equal(good.passed,2);
        await verify('wrong result','def diff(a,b):\n return a+b','ERROR',{specs});
        await verify('syntax','def bad(:\n pass','ERROR');
        await verify('no oracle','print(3)','RAN');
        await verify('dependency','from neo4j import GraphDatabase','LIMITED');
        await verify('file boundary',"open('other.txt').read()",'LIMITED');
        await verify('attached data',"print(open('data.txt').read().strip())",'PASSED',
            {files:{'data.txt':'17\n'},specs:['[{"stdin":"","stdout":"17"}]']});
        await verify('incomplete','def f():\n ...','ERROR');
        await verify('memory',"a='x' * 150_000_000",'LIMITED');
        await verify('deadline','while True:\n pass','TIMEOUT');
        await verify('worker after timeout','print(int(input())+1)','PASSED',{examples:'Ввод: 0\nВывод: 1'});
        fs.copyFileSync(path.join(source,wasm),path.join(copy,wasm));
        const manual=await run({code:'print(int(input())+2)',stdin:'5',allow_matplotlib:false});
        assert.equal(manual.msg.code,0,JSON.stringify(manual.msg));assert.equal(manual.msg.stdout,'7\n');
        console.log(count+' automatic executions and manual run: PASS');
    } finally {fs.rmSync(tmp,{recursive:true,force:true});}
}
