package app.svyazka.mobile.ui

import app.svyazka.mobile.ResultSeverity

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.webkit.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import app.svyazka.mobile.PythonInputs
import app.svyazka.mobile.R
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream

private data class WebJob(val source: String, val kind: String, val render: Boolean)

@Composable
internal fun WebWorkspace(ui: NexusComposeUi) {
    val context = LocalContext.current
    val kinds = listOf("html", "javascript", "css")
    val detected = remember(ui.snapshot.result, ui.activity.nexusReadOnlyTurn()) {
        if (ui.activity.nexusReadOnlyTurn()) null else kinds.map { it to PythonInputs.webSource(ui.snapshot.result, it) }.firstOrNull { it.second.isNotBlank() }
    }
    val project = remember(ui.snapshot.result, ui.snapshot.complete, ui.activity.nexusReadOnlyTurn()) {
        if (!ui.snapshot.complete || ui.activity.nexusReadOnlyTurn()) emptyMap()
        else PythonInputs.webProjectFiles(ui.snapshot.result)
    }
    val projectSource = remember(project) { if (project.isEmpty()) "" else JSONObject(project).toString() }
    var replace by rememberSaveable { mutableStateOf(false) }
    var job by remember(ui.webCode, ui.webKind, projectSource) { mutableStateOf<WebJob?>(null) }
    var report by remember(job) { mutableStateOf("") }
    var reportSeverity by remember(job) { mutableStateOf(ResultSeverity.NEUTRAL) }
    // The visible WebView belongs to its own native window, not the animated drawer.
    var preview by remember { mutableStateOf<WebJob?>(null) }
    LaunchedEffect(detected, projectSource, ui.pendingGeneratedHtml, ui.pendingGeneratedWebKind) {
        if (projectSource.isEmpty() && detected != null && ui.webCanImportGenerated()) {
            ui.importGeneratedWeb(detected.first, detected.second)
        }
        if (ui.pendingGeneratedHtml.isNotBlank()) {
            preview = WebJob(ui.pendingGeneratedHtml, ui.pendingGeneratedWebKind, true)
            ui.consumeWebPreviewRequest()
        }
    }
    preview?.let { source ->
        DisposableEffect(source) {
            val dialog = openWebPreviewDialog(context, source.source, source.kind) {
                if (preview == source) preview = null
            }
            onDispose { if (dialog.isShowing) dialog.dismiss() }
        }
    }
    val name = when (ui.webKind) { "html" -> "index.html"; "javascript" -> "main.js"; else -> "style.css" }
    val save = rememberSaveResultAction(ui.webCode, name)
    val saveProject = rememberSaveResultAction(ui.snapshot.result)
    fun importSource() {
        detected?.let { (kind, source) ->
            ui.importGeneratedWeb(kind, source)
            if (kind == "html") preview = WebJob(source, kind, true)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        NexusLabel(stringResource(R.string.web_scope))
        if (projectSource.isNotEmpty()) {
            // Keep the previous single-file editor buffer intact and out of the current project's preview.
            NexusLabel(stringResource(R.string.web_project_files, project.size))
            Text(project.keys.joinToString("\n"), style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { preview = WebJob(projectSource, "web-project", true) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.web_preview))
            }
            TextButton(onClick = saveProject) { Text(stringResource(R.string.action_save_file)) }
            OutlinedButton(onClick = { job = WebJob(projectSource, "web-project", false) }) { Text(stringResource(R.string.web_check)) }
        } else {
            Row { kinds.forEach { kind ->
                TextButton(onClick = { ui.selectWebKind(kind) }, enabled = kind != ui.webKind) {
                    Text(if (kind == "javascript") "JS" else kind.uppercase())
                }
            } }
            if (detected != null) TextButton(onClick = {
                if (ui.webCode.isNotBlank() && ui.webCode != detected.second) replace = true else importSource()
            }) { Text(stringResource(R.string.load_answer)) }
            // Keep the launch control above long source files.
            if (ui.webCode.isNotBlank() && ui.webKind == "html") {
                OutlinedButton(onClick = { preview = WebJob(ui.webCode, "html", true) }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.web_preview))
                }
            }
            OutlinedTextField(ui.webCode, { if (it.length <= 160_000) ui.editWeb(it) }, Modifier.fillMaxWidth(),
                minLines = 4, maxLines = 12, label = { Text(name) },
                textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
            TextButton(onClick = save, enabled = ui.webCode.isNotBlank()) { Text(stringResource(R.string.action_save_file)) }
            if (ui.webCode.isNotBlank() && ui.webKind != "css") {
                OutlinedButton(onClick = { job = WebJob(ui.webCode, ui.webKind, false) }) { Text(stringResource(R.string.web_check)) }
            }
        }
        if (report.isNotEmpty()) SelectionContainer { ResultStatusLine(report, reportSeverity, MaterialTheme.typography.bodySmall) }
        job?.takeIf { !it.render }?.let { active -> key(active) {
            WebSurface(active, Modifier.fillMaxWidth().height(1.dp)) { message, severity ->
                report = message
                reportSeverity = severity
            }
        } }
        if (ui.snapshot.result.isNotBlank() && (detected == null || projectSource.isNotEmpty())) {
            SelectionContainer { NexusMarkdown(ui.snapshot.result) }
        }
    }
    if (replace) NexusFrostedAlertDialog(onDismissRequest = { replace = false }, title = { Text(stringResource(R.string.editor_replace)) },
        confirmButton = { TextButton(onClick = { replace = false; importSource() }) { Text(stringResource(R.string.action_continue)) } },
        dismissButton = { TextButton(onClick = { replace = false }) { Text(stringResource(R.string.action_cancel)) } })
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun WebSurface(job: WebJob, modifier: Modifier, onChecked: (String, ResultSeverity) -> Unit) {
    val callback by rememberUpdatedState(onChecked)
    AndroidView(modifier = modifier, factory = { context ->
        makeWebPreview(context, job.source, job.kind, job.render, null, {}) { message, severity -> callback(message, severity) }
    }, onRelease = { it.stopLoading(); it.destroy() }, update = {})
}

/** Native, visible preview independent of the Compose drawer's animation and scrolling.
 *  Uses the same isolated iframe and offline policy as the functional checks.
 */
fun openWebPreviewDialog(context: Context, source: String, onDismiss: () -> Unit): Dialog =
    openWebPreviewDialog(context, source, "html", onDismiss)

fun openWebPreviewDialog(context: Context, source: String, kind: String, onDismiss: () -> Unit): Dialog {
    val dialog = Dialog(context)
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val root = LinearLayout(dialog.context).apply { orientation = LinearLayout.VERTICAL }
    val status = TextView(dialog.context).apply {
        setText(R.string.status_loading)
        setCompoundDrawablesRelativeWithIntrinsicBounds(ResultSeverity.NEUTRAL.drawable(), 0, 0, 0)
        maxLines = 5
        val pad = (12 * resources.displayMetrics.density).toInt()
        setPadding(pad, pad, pad, pad)
    }
    val close = Button(dialog.context).apply {
        setText(R.string.action_close)
        setOnClickListener { dialog.dismiss() }
    }
    root.addView(close, LinearLayout.LayoutParams(-1, -2))
    root.addView(status, LinearLayout.LayoutParams(-1, -2))
    val handler = Handler(Looper.getMainLooper())
    var closed = false
    val defaultTextColor = status.currentTextColor
    val darkSurface = android.graphics.Color.luminance(defaultTextColor) >= .5f
    fun showStatus(message: String, severity: ResultSeverity) {
        status.text = message
        status.setTextColor(if (severity == ResultSeverity.NEUTRAL) defaultTextColor
            else if (darkSurface) severity.darkColor else severity.lightColor)
        status.setCompoundDrawablesRelativeWithIntrinsicBounds(severity.drawable(), 0, 0, 0)
        status.compoundDrawablePadding = (8 * status.resources.displayMetrics.density).toInt()
    }
    val timeout = Runnable { if (!closed) showStatus(context.getString(R.string.web_load_failed), ResultSeverity.WARNING) }
    val web = try {
        makeWebPreview(dialog.context, source, kind, true, null, {}) { message, severity ->
            if (!closed) {
                if (severity != ResultSeverity.NEUTRAL) handler.removeCallbacks(timeout)
                showStatus(message, severity)
            }
        }
    } catch (_: RuntimeException) {
        showStatus(context.getString(R.string.web_load_failed), ResultSeverity.ERROR)
        null
    }
    if (web != null) root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
    dialog.setContentView(root)
    dialog.setOnDismissListener {
        closed = true
        handler.removeCallbacks(timeout)
        // The renderer-gone callback may already have removed the failed view.
        if (web != null && web.parent === root) {
            root.removeView(web)
            web.stopLoading()
            web.destroy()
        }
        onDismiss()
    }
    dialog.show()
    dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    if (web != null) handler.postDelayed(timeout, 15_000L)
    return dialog
}

private const val PAGE = "https://nexus-workspace.invalid/shell.html"

@SuppressLint("SetJavaScriptEnabled")
fun createWebPreview(context: android.content.Context, source: String, kind: String, render: Boolean,
                     report: (String) -> Unit): WebView =
    makeWebPreview(context, source, kind, render, null, {}) { message, _ -> report(message) }

fun inspectWebFile(context: android.content.Context, source: String, kind: String,
                   required: JSONArray, onParsed: java.util.function.Consumer<JSONObject>): WebView =
    makeWebPreview(context, source, kind, false, required, { onParsed.accept(it) }, { _, _ -> })

private fun makeWebPreview(context: android.content.Context, source: String, kind: String, render: Boolean,
                           required: JSONArray?, onParsed: (JSONObject) -> Unit, report: (String, ResultSeverity) -> Unit): WebView {
    fun asset(name: String) = context.assets.open("web/$name").bufferedReader().use { it.readText() }
    val shell = asset("shell.html").replace("/*PARSER*/", asset("acorn.js")).replace("/*CONTROLLER*/", asset("controller.js"))
        .toByteArray(Charsets.UTF_8)
    return WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.domStorageEnabled = false
            settings.blockNetworkLoads = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.setGeolocationEnabled(false)
            settings.setSupportMultipleWindows(false)
            settings.javaScriptCanOpenWindowsAutomatically = false
            isLongClickable = false
            setDownloadListener { _, _, _, _, _ -> }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) { request.deny() }
                override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                    callback.invoke(origin, false, false)
                }
                override fun onJsAlert(view: WebView, url: String, message: String, response: JsResult): Boolean {
                    response.cancel(); return true
                }
                override fun onJsConfirm(view: WebView, url: String, message: String, response: JsResult): Boolean {
                    response.cancel(); return true
                }
                override fun onJsPrompt(view: WebView, url: String, message: String, defaultValue: String?, response: JsPromptResult): Boolean {
                    response.cancel(); return true
                }
            }
            webViewClient = object : WebViewClient() {
                private var loaded = false
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    return request.url.toString() != PAGE &&
                        (request.isForMainFrame || request.url.scheme != "about")
                }
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    if (request.isForMainFrame && request.url.toString() == PAGE && request.method == "GET")
                        return WebResourceResponse("text/html", "UTF-8", ByteArrayInputStream(shell))
                    if (request.url.scheme == "about" || request.url.scheme == "data") return null
                    return WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(byteArrayOf()))
                }
                override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                    report(context.getString(R.string.web_render_failed), ResultSeverity.ERROR)
                    if (required != null) onParsed(JSONObject().put("status","UNAVAILABLE"))
                    else {
                        (view.parent as? android.view.ViewGroup)?.removeView(view)
                        view.destroy()
                    }
                    return true
                }
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) report(context.getString(R.string.web_load_failed) + " (" + error.errorCode + ")", ResultSeverity.ERROR)
                }
                override fun onPageFinished(view: WebView, url: String) {
                    if (loaded || url != PAGE) return
                    loaded = true
                    val args = JSONObject.quote(source) + "," + JSONObject.quote(kind)
                    view.evaluateJavascript("inspectSource($args)") { raw ->
                        val data = runCatching { JSONObject(JSONTokener(raw).nextValue() as String) }.getOrNull()
                        if (data == null || data.optString("status") == "UNAVAILABLE") {
                            report(context.getString(R.string.web_check_error), ResultSeverity.WARNING)
                            onParsed(JSONObject().put("status", "UNAVAILABLE"))
                            return@evaluateJavascript
                        }
                        if (required != null && kind == "html" && data.getJSONArray("issues").length() == 0 && required.length() > 0) {
                            view.evaluateJavascript("startWidgetChecks(" + JSONObject.quote(source) + "," + required + ")") {
                                awaitTests(view, data, 0)
                            }
                        } else onParsed(data)
                        val lines = mutableListOf(context.getString(R.string.web_counts, data.getInt("checked"), data.getInt("external")))
                        val issues = data.getJSONArray("issues")
                        for (i in 0 until issues.length()) lines += issues.getString(i)
                        val names = data.optJSONArray("resources")
                        if (names != null) for (i in 0 until names.length()) lines += names.getString(i)
                        if (data.optBoolean("network")) lines += context.getString(R.string.web_offline)
                        if (data.optBoolean("bluetooth")) lines += context.getString(R.string.web_ble)
                        if (kind == "web-project") lines += context.getString(R.string.web_project_static_only)
                        val unsupportedProject = kind == "web-project" && !data.optBoolean("preview_supported")
                        if (unsupportedProject) lines += context.getString(R.string.web_project_preview_limited)
                        val summary = lines.joinToString("\n")
                        val restricted = data.optInt("external") > 0 || data.optBoolean("network") || data.optBoolean("bluetooth") || unsupportedProject
                        report(summary, if (issues.length() > 0) ResultSeverity.ERROR else if (render && !unsupportedProject) ResultSeverity.NEUTRAL else ResultSeverity.WARNING)
                        if (render && issues.length() == 0 && !unsupportedProject) {
                            view.evaluateJavascript("renderSource($args)") { created ->
                                if (created != "true") report(summary + "\n" + context.getString(R.string.web_render_failed), ResultSeverity.ERROR)
                                else awaitFrame(view, 0, summary, restricted)
                            }
                        }
                    }
                }

                private fun awaitTests(view: WebView, data: JSONObject, attempt: Int) {
                    view.postDelayed({
                        if (view.isAttachedToWindow) view.evaluateJavascript("window.nexusTestResult") { raw ->
                            val results = runCatching { JSONArray(raw) }.getOrNull()
                            when {
                                results != null -> onParsed(data.put("tests", results))
                                attempt < 44 -> awaitTests(view, data, attempt + 1)
                                else -> onParsed(data.put("tests_unavailable", true))
                            }
                        }
                    }, 200)
                }

                private fun awaitFrame(view: WebView, attempt: Int, summary: String, restricted: Boolean) {
                    view.postDelayed({
                        if (view.isAttachedToWindow) view.evaluateJavascript("window.previewLoaded === true") { loaded ->
                            when {
                                loaded == "true" -> report(summary + "\n" + context.getString(R.string.web_rendered), if (restricted) ResultSeverity.WARNING else ResultSeverity.SUCCESS)
                                attempt < 35 -> awaitFrame(view, attempt + 1, summary, restricted)
                                else -> report(summary + "\n" + context.getString(R.string.web_render_failed), ResultSeverity.ERROR)
                            }
                        }
                    }, 250)
                }
            }
            if (render) {
                addOnAttachStateChangeListener(object : android.view.View.OnAttachStateChangeListener {
                    override fun onViewAttachedToWindow(view: android.view.View) {
                        view.removeOnAttachStateChangeListener(this)
                        view.post { if (view.isAttachedToWindow) loadUrl(PAGE) }
                    }
                    override fun onViewDetachedFromWindow(view: android.view.View) = Unit
                })
            } else loadUrl(PAGE)
    }
}
