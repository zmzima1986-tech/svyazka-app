package app.svyazka.mobile;

/** Presentation only. Never changes the verification result or authorizes execution. */
public enum ResultSeverity {
    SUCCESS(0xFF176B34, 0xFF76E6A1), WARNING(0xFF785400, 0xFFFFD166),
    ERROR(0xFFB42318, 0xFFFF8181), NEUTRAL(0xFF515D6C, 0xFFB9C3D0);

    public final int lightColor, darkColor;
    ResultSeverity(int lightColor, int darkColor) {
        this.lightColor = lightColor;
        this.darkColor = darkColor;
    }

    public static ResultSeverity verification(String status, boolean hasPython) {
        switch (status) {
            case "PASSED": case "RAN": return SUCCESS;
            case "ERROR": return ERROR;
            case "LIMITED": case "STOPPED": return WARNING;
            case "NONE": return hasPython ? NEUTRAL : SUCCESS;
            default: return NEUTRAL;
        }
    }

    /** Legacy verifier wire text, not user-facing copy. Do not infer a pass from it. */
    public static int selfAssertCount(String status, String diagnostic) {
        if (!"RAN".equals(status) || diagnostic == null) return -1;
        java.util.regex.Matcher match = java.util.regex.Pattern.compile(
                "^Выполнено assert без ошибок: ([0-9]+)\\. Независимых контрольных примеров нет\\.$").matcher(diagnostic);
        if (!match.matches()) return -1;
        try { return Integer.parseInt(match.group(1)); }
        catch (NumberFormatException invalid) { return -1; }
    }

    /** Worker status can contain a pure test-count summary or extra warnings. */
    public static ResultSeverity executionNotice(Integer exitCode, boolean failedTests,
                                                 int tests, String status) {
        ResultSeverity outcome = execution(exitCode, failedTests);
        if (outcome != SUCCESS) return outcome;
        if (tests > 0 && ("Тесты: " + tests + "/" + tests + ".").equals(status)) return SUCCESS;
        return WARNING;
    }

    public static ResultSeverity execution(Integer exitCode, boolean failedTests) {
        if (failedTests || exitCode != null && exitCode != 0) return ERROR;
        return exitCode == null ? WARNING : SUCCESS;
    }

    public static ResultSeverity web(String status, boolean issues, boolean failed,
                                     boolean incomplete, boolean tested) {
        if (issues || failed || "SYNTAX_ERROR".equals(status)) return ERROR;
        if (!"SYNTAX_CHECKED".equals(status) || incomplete || !tested) return WARNING;
        return SUCCESS;
    }
}
