package app.svyazka.mobile.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.shadow
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Light-only reconstruction based on sampled pixels from the supplied 864x1536 PNG.
 *  Gradients, typeface, shadows and coordinates are estimations, not original Figma data.
 *  Dark theme must continue to use the existing unmodified styles.
 */
internal object NexusLightDesign {
    val ink = Color(0xFF080B17)
    val blue = Color(0xFF0A4FE6)
    val purple = Color(0xFF6237F6)
    val paleBlue = Color(0xFFE6F0FC)
    val border = Color(0xFFB6C9F2)
    val mint = Color(0xFFD5F0EB)
    val success = Color(0xFF00A83A)
    val folder = Color(0xFFFFBB00)
    val resultBackground = Color(0xFFEBF3FE)
    val console = Color(0xFFE9EAF3)
    val buttonShape = RoundedCornerShape(20.dp)
    val cardShape = RoundedCornerShape(20.dp)
    val actionGradient = Brush.horizontalGradient(listOf(
        Color(0xFF0D78FA), Color(0xFF6237F6), Color(0xFF9E36FC)))
}

@Composable
internal fun nexusLightMode(): Boolean = MaterialTheme.colorScheme.background != Color.Black

/** Decorative waves are drawn only behind content, and never intercept touches. */
@Composable
internal fun NexusLightBackdrop(modifier: Modifier = Modifier) {
    Box(modifier.background(Brush.verticalGradient(listOf(
        Color(0xFFFBFBFB), Color(0xFFFBFCFF), Color(0xFFF0F2FE))))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val foreground = Path().apply {
                moveTo(0f, h * .88f)
                quadraticBezierTo(w * .38f, h * .96f, w * .57f, h * .95f)
                quadraticBezierTo(w * .8f, h * .87f, w, h * .875f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(foreground, Color(0xFFE5EDFF).copy(alpha = .66f))
            val highlights = Path().apply {
                moveTo(w * .48f, h)
                quadraticBezierTo(w * .72f, h * .89f, w, h * .9f)
                lineTo(w, h)
                close()
            }
            drawPath(highlights, Color(0xFFEEE6FF).copy(alpha = .55f))
        }
    }
}

/** Project-only call to action; does not alter chat creation semantics. */
@Composable
internal fun NexusProjectNewChatButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    androidx.compose.material3.Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            .then(Modifier.shadow(2.dp, NexusLightDesign.buttonShape)),
        shape = NexusLightDesign.buttonShape,
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF5C98FF))
    ) {
        androidx.compose.material3.Text(
            text = text,
            modifier = Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(
                Color(0xFFE6F0FC), Color(0xFFD9EDFF)))).padding(horizontal = 8.dp, vertical = 12.dp),
            color = NexusLightDesign.blue,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            fontSize = 16.sp,
            maxLines = 1,
            softWrap = false,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
        )
    }
}

/** Ready ribbon uses the actual project state and existing localized resource. */
@Composable
internal fun NexusLightReadyRibbon(fileCount: Int) {
    androidx.compose.material3.Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        color = NexusLightDesign.mint
    ) {
        androidx.compose.foundation.layout.Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            androidx.compose.material3.Icon(
                androidx.compose.material.icons.Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = NexusLightDesign.success,
                modifier = Modifier.size(24.dp)
            )
            androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
            androidx.compose.material3.Text(
                androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.ws_easy_import_success, fileCount),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                fontSize = 12.sp,
                color = Color(0xFF0B2142),
                maxLines = 1,
                softWrap = false,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }
    }
}

/** Single light-only report layout. Dark rendering is still the original implementation. */
@Composable
internal fun NexusLightPythonReport(
    ui: NexusComposeUi,
    report: app.svyazka.mobile.NexusPythonReport,
    showArtifacts: Boolean,
    onToggleArtifacts: () -> Unit
) {
    val ok = report.exitCode == 0
    val accent = if (ok) NexusLightDesign.blue else MaterialTheme.colorScheme.error
    var showDiagnostics by androidx.compose.runtime.remember(report) {
        androidx.compose.runtime.mutableStateOf(false)
    }
    val tests = androidx.compose.runtime.remember(report.testsJson) {
        runCatching { org.json.JSONArray(report.testsJson) }.getOrNull()
    }
    val passed = if (tests != null) (0 until tests.length()).count {
        tests.optJSONObject(it)?.optBoolean("passed") == true
    } else 0
    val count = tests?.length() ?: 0
    val artifactCount = androidx.compose.runtime.remember(report.artifactsJson) {
        runCatching { org.json.JSONArray(report.artifactsJson).length() }.getOrDefault(0)
    }
    androidx.compose.material3.Surface(
        modifier = Modifier.fillMaxWidth().shadow(5.dp, NexusLightDesign.cardShape),
        shape = NexusLightDesign.cardShape,
        color = Color(0xFFF9FAFF),
        border = androidx.compose.foundation.BorderStroke(1.dp,
            if (ok) Color(0xFF5B9DFF) else MaterialTheme.colorScheme.error)
    ) {
        androidx.compose.foundation.layout.Column(
            Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(
                Color.White, NexusLightDesign.resultBackground, Color(0xFFF7F3FF))))
                .padding(14.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)
        ) {
            androidx.compose.foundation.layout.Row(
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                androidx.compose.material3.Icon(
                    if (ok) androidx.compose.material.icons.Icons.Filled.CheckCircle
                        else androidx.compose.material.icons.Icons.Outlined.ErrorOutline,
                    contentDescription = null,
                    modifier = Modifier.size(31.dp),
                    tint = if (ok) NexusLightDesign.success else accent
                )
                androidx.compose.foundation.layout.Spacer(Modifier.width(10.dp))
                androidx.compose.material3.Text(
                    androidx.compose.ui.res.stringResource(
                        if (ok) app.svyazka.mobile.R.string.ws_easy_run_ok
                        else app.svyazka.mobile.R.string.ws_easy_run_error
                    ),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    color = accent,
                    maxLines = 1,
                    softWrap = false,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            if (report.stdout.isNotBlank()) {
                androidx.compose.material3.Surface(
                    shape = RoundedCornerShape(13.dp),
                    color = NexusLightDesign.console,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFACB8D6))
                ) {
                    androidx.compose.foundation.layout.Column {
                        androidx.compose.foundation.layout.Row(
                            Modifier.fillMaxWidth().height(24.dp)
                                .background(Color(0xFFDCE0EC)).padding(horizontal = 12.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            repeat(3) {
                                Box(Modifier.padding(end = 5.dp).size(7.dp)
                                    .background(Color(0xFF9298B0), RoundedCornerShape(50)))
                            }
                            androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                            androidx.compose.material3.Text("›_", color = Color(0xFF66769A),
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                        androidx.compose.foundation.text.selection.SelectionContainer {
                            androidx.compose.material3.Text(report.stdout,
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                style = MaterialTheme.typography.bodyLarge,
                                color = NexusLightDesign.ink, maxLines = 8)
                        }
                    }
                }
            }
            if (ui.verification.total > 0) {
                androidx.compose.material3.Text(
                    androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.verify_count,
                        ui.verification.passed, ui.verification.total),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    color = if (ui.verification.passed == ui.verification.total)
                        NexusLightDesign.blue else MaterialTheme.colorScheme.error,
                    maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            if (count > 0) {
                androidx.compose.material3.Text(
                    androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.ws_easy_tests_summary,
                        passed, count),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF647491),
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            if (report.status.isNotBlank()) {
                androidx.compose.material3.Text(report.status,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (ok) Color(0xFF647491) else MaterialTheme.colorScheme.error)
            }
            if (artifactCount > 0) {
                androidx.compose.material3.TextButton(onClick = onToggleArtifacts) {
                    androidx.compose.material3.Text(
                        androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.ws_easy_artifacts, artifactCount))
                }
            }
            if (showArtifacts) PythonRunArtifacts(ui)
            if (report.stderr.isNotBlank()) {
                if (ok) {
                    androidx.compose.material3.TextButton(onClick = { showDiagnostics = !showDiagnostics }) {
                        androidx.compose.material3.Text(androidx.compose.ui.res.stringResource(
                            if (showDiagnostics) app.svyazka.mobile.R.string.ws_hide_run_diagnostics
                            else app.svyazka.mobile.R.string.ws_show_run_diagnostics))
                    }
                }
                if (!ok || showDiagnostics) {
                    androidx.compose.foundation.text.selection.SelectionContainer {
                        androidx.compose.material3.Text(report.stderr,
                            color = if (ok) MaterialTheme.colorScheme.onSurfaceVariant else accent,
                            maxLines = if (ok) 20 else 6)
                    }
                }
            }
            if (report.hasVisual) {
                androidx.compose.material3.TextButton(onClick = { ui.openVisual() }) {
                    androidx.compose.material3.Text(
                        androidx.compose.ui.res.stringResource(app.svyazka.mobile.R.string.action_show_result))
                }
            }
        }
    }
}
