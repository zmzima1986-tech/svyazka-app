package app.svyazka.mobile;

import androidx.activity.ComponentActivity;
import androidx.core.view.OneShotPreDrawListener;
import androidx.core.view.WindowCompat;
import app.svyazka.mobile.ui.NexusComposeUi;
import app.svyazka.mobile.ui.AttachmentMessages;
import app.svyazka.mobile.attachments.AttachmentStore;
import android.content.Context;
import android.app.UiModeManager;
import android.content.res.Configuration;
import java.util.Locale;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.Consumer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MainActivity extends ComponentActivity {
    private static final String PRIVACY_NO_TRAINING = "privacy_no_training";
    private static final String PRIVACY_NOTICE_ACKNOWLEDGED = "privacy_notice_acknowledged";
    private static final int BG = 0xff0e1520;
    private static final int SURFACE = 0xff172233;
    private static final int BORDER = 0xff2b3a4c;
    private static final int FG = 0xfff1f5fc;
    private static final int MUTED = 0xffa9b9ce;
    private static final int ACCENT = 0xff8ce5dc;
    private static final int ACCENT_INK = 0xff10232a;
    private static final int ACCENT_DARK = 0xff203a42;
    private static final int WARNING = 0xffffcb9b;
    private static final int DANGER = 0xffff6e72;
    private static final int EXPORT_REQUEST = 71;
    private static final String ACTIVE_TASK = TaskRepository.ACTIVE_ID;
    private static final String ACTIVE_ARTIFACT = "active_python_artifact_id";
    private static final int ANSWER_PREVIEW = 3500;
    private static final long CATALOG_TTL = 6 * 60 * 60 * 1000L;
    private static final String GROQ_RESERVE = "groq_reserve";
    private static final String QUOTA_GROQ_TPM = "quota_groq_tpm";
    private static final String QUOTA_GROQ_RPD = "quota_groq_rpd";
    private static final String QUOTA_GROQ_AT = "quota_groq_at";
    private static final String QUOTA_ROUTER_RPD = "quota_router_rpd";
    private static final String QUOTA_ROUTER_LIMIT = "quota_router_limit";
    private static final String QUOTA_ROUTER_AT = "quota_router_at";
    private static final long CHECKPOINT_INTERVAL = 2_500;
    private static WorkspaceStore sharedStore;

    // A cancelled HTTP call may keep its thread blocked briefly; retries must not queue behind it.
    private final ExecutorService worker = RequestExecutor.create();
    private NexusComposeUi nexusUi;
    private NexusLaunchView launchView;
    private View coveredChat;
    private int chatAccessibility;
    private final Runnable finishLaunch = this::dismissLaunch;
    private final Runnable openInitialChat = () -> {
        if (nexusUi == null && !isFinishing() && !isDestroyed()) restoreWorkspaceAndOpenChat(true);
    };
    private final ExecutorService cancellationWorker = Executors.newFixedThreadPool(2);
    private final ExecutorService catalogWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService sandboxWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService blackBoxWriter = Executors.newSingleThreadExecutor();
    private final ModelClient client = new ModelClient();
    private final ModelPool.Cooldowns cooldowns = new ModelPool.Cooldowns();
    private final SandboxClient sandboxClient = new SandboxClient();
    private final List<Consumer<String>> catalogListeners = new ArrayList<>();
    private SharedPreferences data;
    private TaskRepository repository;
    private ChatRunJournal blackBox;
    private String blackBoxRunId = "";
    private String blackBoxRecoveryShown = "";
    private boolean blackBoxRunCompleted;
    private boolean blackBoxWriteWarningShown;
    private long activeTaskId;
    private long activeArtifactId;
    private PythonArtifactRepository artifactRepository;
    private boolean workExpanded;
    private boolean historyVisible;
    private boolean historyReturnResults;
    private WorkspaceStore store;
    private long storeSession;
    private String taskDraft;
    private Workflow.Mode selectedMode;
    private ModelCatalog.Model quickModel;
    private String attemptHistory;
    private boolean clearing;
    private boolean checkpointPending;
    private CredentialStore vault;
    private ModelCatalog catalog;
    private long catalogTime;
    private ModelClient.Cancellation catalogRequest;
    private List<Workflow.Stage> stages;
    private Workflow.Run run;
    private boolean resultsVisible;
    private boolean active;
    private StagePool stagePool;
    private Attempt attempt;
    private SandboxJob sandboxJob;
    private LocalSandbox automaticPython;
    // In-memory execution evidence is reusable only for the same chat and exact project bytes.
    private SandboxClient.Result checkedProjectOutput;
    private long checkedProjectTask;
    private String checkedProjectIdentity = "";
    private String checkedProjectRequest = "";
    private long verificationGeneration;
    private ScrollView scroll;
    private LinearLayout content;
    private EditText taskInput;
    private final android.os.Handler progressHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable saveDraft = this::persistRun;
    private final Runnable checkpoint = this::persistRun;
    private TextView liveText;
    private TextView liveStatus;
    private SandboxClient.Result latestVisual;
    private Workflow.Run lastPythonRun;
    private int lastPythonStep;
    private String lastPythonCode = "";
    private String lastPythonStdin = "";
    private String lastPythonDiagnostic = "";

    private AutonomyQuotaGuard.Session autonomySession;

    private static final class StagePool {
        final List<ModelCatalog.Model> models;
        final EnumMap<Workflow.Provider, String> keys;
        final List<String> failures = new ArrayList<>();
        final EnumSet<Workflow.Provider> blockedProviders = EnumSet.noneOf(Workflow.Provider.class);
        final AutonomyQuotaGuard.Recovery recovery = new AutonomyQuotaGuard.Recovery();
        int next, dispatched;
        boolean quotaChecked;
        boolean catalogChecked;

        StagePool(List<ModelCatalog.Model> models, EnumMap<Workflow.Provider, String> keys) {
            this.models = models;
            this.keys = keys;
        }

    }

    private static final class Attempt {
        final Workflow.Run input;
        final ModelClient.Cancellation cancellation = new ModelClient.Cancellation();
        final long started = android.os.SystemClock.elapsedRealtime();
        final String journalAttemptId = ChatRunJournal.newId();
        String journalRunId;
        long journalTaskId;
        volatile String received = "";
        int checkpointLength;
        boolean timedOut;
        Future<?> future;
        Runnable deadline;

        Attempt(Workflow.Run input) { this.input = input; }
    }

    private static final class SandboxJob {
        final ModelClient.Cancellation cancellation = new ModelClient.Cancellation();
        final AlertDialog progress;
        final boolean automatic;
        final String editedPath;
        PythonExecutor local;
        Future<?> future;

        SandboxJob(AlertDialog progress, boolean automatic, String editedPath) {
            this.progress = progress;
            this.automatic = automatic;
            this.editedPath = editedPath;
        }
    }

    /** Prepared from the saved project after the AI answer has completed. */
    private static final class AutoPythonLaunch {
        final String entry;
        final String code;
        final JSONObject files;
        final int step;
        final String editedPath;

        AutoPythonLaunch(String entry, String code, JSONObject files, int step, String editedPath) {
            this.entry = entry;
            this.code = code;
            this.files = files;
            this.step = step;
            this.editedPath = editedPath;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_NexusIA);
        super.onCreate(savedInstanceState);
        data = getSharedPreferences("workspace", MODE_PRIVATE);
        client.setNoTrainingOnly(data.getBoolean(PRIVACY_NO_TRAINING, true));
        cooldowns.restore(data.getString("route_retry_times","{}"), System.currentTimeMillis());
        // Android 12+ uses the persisted application night mode before Activity
        // creation when drawing its native splash. Migrate existing preferences
        // here, then keep the platform choice updated whenever the user changes it.
        syncPlatformSplashTheme(data.getString("ui_theme", "system"));
        // Android's launch window must use the saved app preference, not the
        // device's light/dark setting once the Activity context is available.
        final boolean launchDark = isUserDarkTheme(getResources().getConfiguration(), nexusThemeChoice());
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                launchDark ? Color.BLACK : Color.WHITE));
        if (Build.VERSION.SDK_INT >= 31) {
            getSplashScreen().setOnExitAnimationListener(android.window.SplashScreenView::remove);
        }
        if (savedInstanceState == null && isTaskRoot()
                && (getIntent().getFlags() & Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) == 0) {
            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
            launchView = new NexusLaunchView(this);
            setContentView(launchView);
            // Decor installation applies theme defaults. Set the transparent bar
            // afterwards so its light contrast layer cannot cover the wave.
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= 28) getWindow().setNavigationBarDividerColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
            OneShotPreDrawListener.add(launchView, () -> progressHandler.post(openInitialChat));
        } else {
            restoreWorkspaceAndOpenChat(savedInstanceState == null);
            if (savedInstanceState != null) nexusUi.restoreNavigation(savedInstanceState);
        }
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        if (nexusUi != null) nexusUi.saveNavigation(state);
    }

    public void attachChatContent(View chat) {
        final NexusLaunchView cover = launchView;
        if (cover == null) {
            setContentView(chat);
            return;
        }
        ViewGroup host = findViewById(android.R.id.content);
        coveredChat = chat;
        chatAccessibility = chat.getImportantForAccessibility();
        chat.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
        host.addView(chat, 0, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // Posting from pre-draw lets this chat frame finish before the two-second hold starts.
        OneShotPreDrawListener.add(chat, () -> chat.post(() -> {
            if (launchView == cover) progressHandler.postDelayed(finishLaunch, 2000L);
        }));
    }

    private void dismissLaunch() {
        progressHandler.removeCallbacks(finishLaunch);
        if (launchView == null) return;
        ViewGroup parent = (ViewGroup) launchView.getParent();
        if (parent != null) parent.removeView(launchView);
        launchView = null;
        if (coveredChat != null) {
            coveredChat.setImportantForAccessibility(chatAccessibility);
            coveredChat = null;
        }
    }

    private void leaveLaunch() {
        if (launchView == null) return;
        dismissLaunch();
        // Home can be pressed before even the first frame of a fresh task.
        if (nexusUi == null) {
            progressHandler.removeCallbacks(openInitialChat);
            progressHandler.post(openInitialChat);
        }
    }

    private void restoreWorkspaceAndOpenChat(boolean offerRecovery) {
        vault = new KeyVault(getSharedPreferences("credentials", MODE_PRIVATE));
        catalog = restoreCatalog();
        catalogTime = data.getLong("catalog_time", 0);
        stages = restoreStages();
        selectedMode = "QUICK".equals(data.getString("selected_mode", "")) ? Workflow.Mode.QUICK : Workflow.Mode.TEAM;
        quickModel = restoreQuickModel();
        repository = new TaskRepository(this);
        repository.migrateLegacy(data);
        blackBox = new ChatRunJournal(repository);
        artifactRepository = new PythonArtifactRepository(this);
        migratePythonArtifacts();
        artifactRepository.recoverSavedFiles(pythonProjects());
        long preferred = repository.activeId();
        if (preferred == 0) preferred = data.getLong(ACTIVE_TASK, 0);
        TaskRepository.Entry restored = repository.load(preferred);
        if (restored == null) restored = repository.load(repository.legacyId());
        if (restored == null) {
            long created = repository.create("");
            restored = repository.load(created);
        }
        if (sharedStore == null) {
            WorkspaceStore.State previous = new WorkspaceStore.State(restored.id, restored.task,
                    restoreStoredRun(restored.runJson), restored.resultsVisible, restored.attemptLog);
            SharedPreferences preferences = data;
            TaskRepository taskDatabase = repository;
            sharedStore = new WorkspaceStore(previous, Executors.newSingleThreadExecutor(), changes -> {
                if (!taskDatabase.save(changes)) return false;
                // Legacy mirror is best-effort; the SQLite row is authoritative.
                writeWorkspace(preferences, changes);
                return true;
            });
        }
        store = sharedStore;
        storeSession = store.attach();
        WorkspaceStore.State previous = store.current();
        activeTaskId = previous.taskId;
        blackBoxRunId = blackBox.latestRunId(activeTaskId);
        // Chat-scoped files only. Never inherit the globally last viewed artifact
        // when an unrelated chat is opened after process recreation.
        activeArtifactId = isolatedArtifactForChat(activeTaskId);
        restoreVisualForArtifact();
        repository.select(activeTaskId);
        data.edit().putLong(ACTIVE_TASK, activeTaskId).commit();
        run = interrupted(previous.run);
        if (run != null) AttachmentStore.get(this).consume(activeTaskId, run.materials);
        taskDraft = previous.task;
        attemptHistory = previous.history;
        resultsVisible = previous.resultsVisible;
        if (resultsVisible) renderRun(false);
        else renderTask();
        refreshModels(false, problem -> {});
        if (offerRecovery) offerBlackBoxRecovery();
    }

    private ModelCatalog restoreCatalog() {
        String saved = data.getString("catalog", "");
        if (!saved.isEmpty()) {
            try {
                return ModelCatalog.fromCache(new JSONArray(saved));
            } catch (JSONException ignored) {
                // A missing or invalid cache can be rebuilt from the public catalog.
            }
        }
        return ModelCatalog.starter();
    }

    private void refreshModels(boolean force, Consumer<String> listener) {
        long age = System.currentTimeMillis() - catalogTime;
        if (!force && catalog.refreshed && age >= 0 && age < CATALOG_TTL) {
            listener.accept("");
            return;
        }
        catalogListeners.add(listener);
        if (catalogRequest != null) return;
        ModelClient.Cancellation stop = new ModelClient.Cancellation();
        catalogRequest = stop;
        catalogWorker.submit(() -> {
            try {
                ModelCatalog updated = client.models(stop);
                String cached = updated.cacheData().toString();
                runOnUiThread(() -> finishCatalog(updated, cached));
            } catch (IOException | JSONException | ModelClient.Problem e) {
                runOnUiThread(() -> finishCatalog(null, null));
            }
        });
    }

    private void finishCatalog(ModelCatalog updated, String cached) {
        if (isDestroyed()) return;
        catalogRequest = null;
        String problem = "";
        if (updated == null) {
            problem = "Каталог не обновился. Показан последний доступный список.";
        } else {
            catalog = updated;
            catalogTime = System.currentTimeMillis();
            data.edit().putString("catalog", cached).putLong("catalog_time", catalogTime).apply();
        }
        List<Consumer<String>> listeners = new ArrayList<>(catalogListeners);
        catalogListeners.clear();
        for (Consumer<String> listener : listeners) listener.accept(problem);
        if (nexusUi != null) nexusUi.render(nexusSnapshot(), null);
    }

    private List<Workflow.Stage> restoreStages() {
        try {
            return Workflow.stagesFromJson(new JSONArray(data.getString("stages", "[]")));
        } catch (JSONException e) {
            return Workflow.defaultStages();
        }
    }

    private ModelCatalog.Model restoreQuickModel() {
        String id = data.getString("quick_model", "");
        if (!id.isEmpty()) {
            try {
                return ModelCatalog.storedModel(id, data.getString("quick_model_label", ""));
            } catch (JSONException ignored) {
                // The architect remains the default when the saved selection is invalid.
            }
        }
        return null;
    }

    private ModelCatalog.Model quickModel() {
        return quickModel == null ? stages.get(0).model : quickModel;
    }

    private Workflow.Run restoreStoredRun(String saved) {
        if (saved == null || saved.isEmpty()) return null;
        try {
            return Workflow.Run.fromJson(new JSONObject(saved));
        } catch (JSONException e) {
            return null;
        }
    }

    private Workflow.Run interrupted(Workflow.Run value) {
        if (value != null && value.verification.busy()) return value.finishVerification(value.verification.stopped(getString(R.string.verify_interrupted)));
        if (value != null && !value.complete() && (value.note.isEmpty() || "Ответ ещё поступает.".equals(value.note))) {
            return value.withNote("Разбор прерван. Можно продолжить с незавершённого шага.");
        }
        return value;
    }

    private static boolean writeWorkspace(SharedPreferences preferences, Map<String, Object> changes) {
        SharedPreferences.Editor edit = preferences.edit();
        for (Map.Entry<String, Object> change : changes.entrySet()) {
            Object value = change.getValue();
            if (value == null) edit.remove(change.getKey());
            else if (value instanceof Boolean) edit.putBoolean(change.getKey(), (Boolean) value);
            else if (value instanceof Long) edit.putLong(change.getKey(), (Long) value);
            else edit.putString(change.getKey(), (String) value);
        }
        return edit.commit();
    }

    /** Black-box records use a dedicated serial disk queue; no extra model requests. */
    private void blackBoxEvent(long taskId, String runId, String attemptId, int step,
                               String eventType, String model) {
        if (blackBox == null || runId == null || runId.isEmpty()) return;
        blackBoxWriter.execute(() -> {
            if (!blackBox.event(taskId, runId, attemptId, step, eventType, model))
                blackBoxWarn(taskId);
        });
    }

    private void blackBoxCheckpoint(Attempt current, String text) {
        if (current == null || current.journalRunId == null || current.journalRunId.isEmpty()
                || text == null || text.isEmpty() || blackBox == null) return;
        final int step = current.input.nextIndex();
        final long taskId = current.journalTaskId;
        final String runId = current.journalRunId;
        final String attemptId = current.journalAttemptId;
        blackBoxWriter.execute(() -> {
            if (!blackBox.checkpoint(taskId, runId, attemptId, step, text))
                blackBoxWarn(taskId);
        });
    }

    private void blackBoxWarn(long owner) {
        runOnUiThread(() -> {
            if (owner == activeTaskId && !isDestroyed() && !blackBoxWriteWarningShown) {
                blackBoxWriteWarningShown = true;
                toast(getString(R.string.black_box_checkpoint_failed));
            }
        });
    }

    /** Read persisted state without a model request. The user chooses whether to resume. */
    private void offerBlackBoxRecovery() {
        final Workflow.Run expected = run;
        final long taskId = activeTaskId;
        final String runId = blackBoxRunId;
        final ChatRunJournal journal = blackBox;
        if (expected == null || expected.complete() || journal == null || active
                || runId == null || runId.isEmpty()) return;
        try {
            blackBoxWriter.execute(() -> {
                ChatRunJournal.Snapshot saved = journal.pendingSnapshot(taskId, runId);
                if (saved == null) return;
                final Workflow.Run restored = expected.restoreVerifiedCheckpoint(saved.text, saved.step);
                if (restored == null) return;
                final String recoveryKey = taskId + "/" + runId + "/" + saved.attemptId;
                runOnUiThread(() -> {
                    if (isDestroyed() || isFinishing() || clearing || active
                            || activeTaskId != taskId || run != expected
                            || blackBoxRecoveryShown.equals(recoveryKey)) return;
                    progressHandler.postDelayed(() -> {
                        if (isDestroyed() || isFinishing() || active || clearing
                                || activeTaskId != taskId || run != expected
                                || blackBoxRecoveryShown.equals(recoveryKey)) return;
                        blackBoxRecoveryShown = recoveryKey;
                        new AlertDialog.Builder(this)
                                .setTitle(R.string.black_box_recovery_title)
                                .setMessage(getString(R.string.black_box_recovery_message, saved.text.length()))
                                .setNegativeButton(R.string.black_box_recovery_later, null)
                                .setNeutralButton(R.string.black_box_recovery_view, (dialog, which) -> {
                                    if (activeTaskId != taskId || run != expected || active) return;
                                    run = restored;
                                    blackBoxEvent(taskId, runId, saved.attemptId, saved.step,
                                            "RUN_RESTORED", "");
                                    persistRun();
                                    renderRun(false);
                                    // Display the verified checkpoint itself; the results page
                                    // may not render an unfinished draft after process recovery.
                                    // Viewing never contacts the model or starts a new run.
                                    showText(getString(R.string.black_box_recovery_title), saved.text);
                                })
                                .setPositiveButton(R.string.black_box_recovery_continue, (dialog, which) -> {
                                    if (activeTaskId != taskId || run != expected || active) return;
                                    run = restored;
                                    blackBoxEvent(taskId, runId, saved.attemptId, saved.step,
                                            "RUN_RESTORED", "");
                                    persistRun();
                                    renderRun(false);
                                    resumeRun(); // The only recovery path that may start a network request.
                                })
                                .show();
                    }, launchView == null ? 100L : 2500L);
                });
            });
        } catch (RejectedExecutionException closed) {
            // Shutdown must not initiate a retry or block normal navigation.
        }
    }

    private void persistRun() {
        progressHandler.removeCallbacks(saveDraft);
        progressHandler.removeCallbacks(checkpoint);
        checkpointPending = false;
        if (clearing) return;
        Workflow.Run snapshot = run;
        Attempt current = attempt;
        if (current != null && !current.received.isEmpty()) {
            snapshot = current.input.receive(ModelClient.Reply.error(current.received, "Ответ ещё поступает."));
            blackBoxCheckpoint(current, current.received);
        }
        final long owner = activeTaskId;
        final List<InputMaterial.Ref> sent = snapshot == null ? java.util.Collections.emptyList() : snapshot.materials;
        store.save(storeSession, new WorkspaceStore.State(activeTaskId, taskDraft, snapshot, resultsVisible, attemptHistory),
                saved -> { if (saved && !sent.isEmpty()) AttachmentStore.get(this).consume(owner, sent);
                    if (!saved) runOnUiThread(() -> {
                    if (!isDestroyed() && !clearing) toast("Не удалось сохранить рабочие данные.");
                }); });
    }

    private void scheduleCheckpoint() {
        if (checkpointPending) return;
        checkpointPending = true;
        progressHandler.postDelayed(checkpoint, CHECKPOINT_INTERVAL);
    }

    private void makeScreen() {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        root.setFocusableInTouchMode(true);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();

        LinearLayout top = row();
        top.setPadding(dp(20), dp(8), dp(20), dp(8));
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.ic_nia_logo);
        top.addView(mark, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView name = text("Nexus AI", 21, FG, true);
        LinearLayout.LayoutParams nameLayout = weighted();
        nameLayout.leftMargin = dp(10);
        top.addView(name, nameLayout);
        Button models = button("Модели", false, view -> showKeys(""));
        models.setEnabled(!clearing);
        top.addView(models);
        root.addView(top);
        View rule = new View(this);
        rule.setBackgroundColor(BORDER);
        root.addView(rule, new LinearLayout.LayoutParams(-1, dp(1)));

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        content = column();
        content.setPadding(dp(20), dp(22), dp(20), dp(24));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        root.requestFocus();
    }

    private void renderTask() {
        historyVisible = false;
        if (resultsVisible) {
            resultsVisible = false;
            persistRun();
        }
        nexusRender(NexusComposeUi.Page.TASK);
    }

    private void selectMode(Workflow.Mode value) {
        if (active || clearing || selectedMode == value) return;
        selectedMode = value;
        data.edit().putString("selected_mode", value.name()).apply();
        // Changing the next-run mode must not discard the current conversation.
        if (run == null) renderTask();
        else nexusRender(NexusComposeUi.Page.TASK);
    }

    private void addTeamCards() {
        add(content, text("Команда", 19, FG, true), 22);
        for (int i = 0; i < stages.size(); i++) {
            Workflow.Stage stage = stages.get(i);
            LinearLayout item = row();
            item.setPadding(dp(13), dp(10), dp(14), dp(10));
            item.setMinimumHeight(dp(61));
            item.setBackground(ripple(SURFACE, BORDER, 14));
            item.addView(badge(i + 1));
            LinearLayout descriptions = column();
            descriptions.addView(text(stage.role, 16, FG, true));
            add(descriptions, text(stage.model.label + " · " + stage.model.provider.label,
                    13, MUTED, false), 3);
            LinearLayout.LayoutParams descriptionLayout = weighted();
            descriptionLayout.leftMargin = dp(12);
            descriptionLayout.rightMargin = dp(8);
            item.addView(descriptions, descriptionLayout);
            item.addView(text("›", 25, MUTED, false));
            int index = i;
            item.setFocusable(true);
            item.setOnClickListener(view -> editStage(index));
            item.setContentDescription("Шаг " + (i + 1) + ". " + stage.role + ". "
                    + stage.model.label + ". Изменить роль.");
            add(content, item, 8);
        }
    }

    private void renderRun(boolean keepPosition) {
        historyVisible = false;
        if (!resultsVisible) {
            resultsVisible = true;
            persistRun();
        }
        liveStatus = null;
        liveText = null;
        nexusRender(keepPosition ? null : NexusComposeUi.Page.RESULT);
    }

    /** Displays the authoritative finished answer; review details are collapsed by default. */
    private void showFinalAnswer() {
        final int finalStep = run.finalIndex();
        final String answer = run.displayAnswer(finalStep);
        LinearLayout card = column();
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(shape(SURFACE, ACCENT, 15));
        add(card, text("Готовый результат", 18, ACCENT, true), 0);
        Workflow.Artifact artifact = run.answerAt(finalStep);
        if (!artifact.warnings.isEmpty()) {
            add(card, selectable("⚠ Проверь продолжение ответа:\n"
                    + String.join("\n", artifact.warnings), 13, WARNING), 8);
        }
        TextView formatted = selectable("", 15, FG);
        formatted.setText(MarkdownText.render(preview(answer)));
        formatted.setLineSpacing(dp(4), 1f);
        add(card, formatted, 12);
        if (answer.length() > ANSWER_PREVIEW) {
            add(card, button("Открыть весь результат", false, view -> showFormattedText("Готовый результат", answer)), 8);
        }
        add(card, button("Копировать результат", false, view -> copyAnswer("Готовый результат", answer)), 10);
        List<String> blocks = PythonInputs.manualBlocks(answer);
        if (!blocks.isEmpty()) {
            Button execute = button("Запустить Python", false,
                    view -> nexusRunPython(finalStep));
            execute.setEnabled(!active);
            add(card, execute, 8);
        }
        add(content, card, 14);
    }

    private void copyAnswer(String title, String answer) {
        try {
            ClipboardManager clipboard = getSystemService(ClipboardManager.class);
            clipboard.setPrimaryClip(ClipData.newPlainText(title, answer));
            toast("Результат скопирован");
        } catch (RuntimeException e) {
            toast("Не удалось скопировать. Используй экспорт JSON.");
        }
    }

    private void showFormattedText(String title, String value) {
        LinearLayout form = dialogForm();
        TextView answer = selectable("", 15, FG);
        answer.setText(MarkdownText.render(value));
        answer.setLineSpacing(dp(4), 1f);
        add(form, answer, 0);
        new AlertDialog.Builder(this).setTitle(title).setView(dialogArea(form))
                .setNeutralButton("Копировать", (dialog, which) -> copyAnswer(title, value))
                .setPositiveButton("Закрыть", null).show();
    }

    private void askFollowUp() {
        if (active || clearing || run == null || !run.complete()) return;
        LinearLayout form = dialogForm();
        add(form, text("Создадим новую версию. Предыдущий результат останется в истории версий.",
                14, MUTED, false), 0);
        EditText clarification = field("", "Например: добавь экран настроек", 0, 4, false);
        add(form, clarification, 10);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Уточнить результат")
                .setView(dialogArea(form)).setPositiveButton("Отправить", null)
                .setNegativeButton("Отмена", null).show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String clarificationText = clarification.getText().toString().trim();
            if (clarificationText.isEmpty()) { clarification.setError(getString(R.string.field_required)); return; }
            dialog.dismiss();
            nexusFollowUp(clarificationText);
        });
    }

    private void showVersions() {
        List<TaskRepository.Version> versions = repository.versions(activeTaskId);
        if (versions.isEmpty()) {
            toast("Пока нет предыдущих версий.");
            return;
        }
        String[] labels = new String[versions.size()];
        for (int i = 0; i < labels.length; i++) {
            TaskRepository.Version item = versions.get(i);
            labels[i] = "Версия " + item.number + " · " + dateLabel(item.createdAt);
        }
        new AlertDialog.Builder(this).setTitle("Предыдущие версии")
                .setItems(labels, (dialog, index) -> {
                    TaskRepository.Version version = versions.get(index);
                    Workflow.Run snapshot = restoreStoredRun(version.runJson);
                    if (snapshot == null) {
                        toast("Не удалось прочитать сохранённую версию.");
                    } else if (snapshot.complete()) {
                        showFormattedText("Версия " + version.number,
                                snapshot.displayAnswer(snapshot.finalIndex()));
                    } else {
                        showFormattedText("Версия " + version.number,
                                snapshot.draft.text.isEmpty() ? snapshot.task : snapshot.draft.text);
                    }
                }).setNegativeButton("Закрыть", null).show();
    }

    private String dateLabel(long time) {
        return DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date(time));
    }

    private void renderHistory() {
        if (active || clearing) {
            toast("Заверши или останови запрос перед переключением задач.");
            return;
        }
        if (!historyVisible) historyReturnResults = resultsVisible;
        historyVisible = true;
        nexusRender(NexusComposeUi.Page.HISTORY);
    }

    private void returnFromHistory() {
        historyVisible = false;
        if (historyReturnResults && run != null) renderRun(false);
        else renderTask();
    }

    private void openHistoryTask(long id) {
        if (id == activeTaskId) {
            TaskRepository.Entry entry = repository.load(id);
            if (entry != null && !entry.runJson.isEmpty()) renderRun(false);
            else renderTask();
            return;
        }
        persistBeforeSwitch(() -> {
            TaskRepository.Entry entry = repository.load(id);
            if (entry == null) {
                toast("Задача не найдена.");
                renderHistory();
                return;
            }
            enterTask(entry);
        });
    }

    private void enterTask(TaskRepository.Entry entry) {
        Workflow.Run restored = interrupted(restoreStoredRun(entry.runJson));
        boolean showResult = restored != null;
        repository.select(entry.id);
        activeTaskId = entry.id;
        blackBoxRunId = blackBox.latestRunId(activeTaskId);
        blackBoxRunCompleted = false;
        selectArtifact(isolatedArtifactForChat(activeTaskId));
        storeSession = store.switchTo(new WorkspaceStore.State(entry.id, entry.task, restored,
                showResult, entry.attemptLog));
        data.edit().putLong(ACTIVE_TASK, entry.id).commit();
        taskDraft = entry.task;
        run = restored;
        if (restored != null) AttachmentStore.get(this).consume(activeTaskId, restored.materials);
        attemptHistory = entry.attemptLog;
        resultsVisible = showResult;
        workExpanded = false;
        historyVisible = false;
        if (showResult) renderRun(false);
        else renderTask();
        offerBlackBoxRecovery();
    }

    /** Await the last durable snapshot before changing the active task or its current cycle. */
    private void persistBeforeSwitch(Runnable next) {
        if (clearing || active || sandboxJob != null) return;
        nexusPythonFlushPending();
        clearing = true;
        progressHandler.removeCallbacks(saveDraft);
        progressHandler.removeCallbacks(checkpoint);
        checkpointPending = false;
        store.save(storeSession,
                new WorkspaceStore.State(activeTaskId, taskDraft, run, resultsVisible, attemptHistory),
                saved -> runOnUiThread(() -> {
                    if (isDestroyed()) return;
                    clearing = false;
                    if (!saved) {
                        toast("Не удалось сохранить текущую задачу. Переключение отменено.");
                        return;
                    }
                    next.run();
                }));
    }

    private void addAnswerCard(LinearLayout panel, int i) {
        Workflow.Stage stage = run.stages.get(i);
        boolean done = run.hasAnswer(i);
        boolean current = !run.complete() && i == run.nextIndex();
        boolean running = active && current;
        boolean hasDraft = current && !run.draft.text.isEmpty();
        boolean finalAnswer = run.complete() && i == run.finalIndex();
        boolean skipped = run.revisionSkipped() && i == Workflow.Step.REVISION.ordinal();
        String status = done ? (finalAnswer ? "Итог" : "Готово")
                : running ? hasDraft ? "Продолжает ответ" : "Готовит ответ"
                : current ? hasDraft ? "Сохранён черновик" : "Ждёт запуска"
                : skipped ? "Пропущен · ревью без замечаний" : "В очереди";
        LinearLayout card = column();
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(shape(SURFACE, finalAnswer ? ACCENT : running ? ACCENT_DARK : BORDER, 15));
        LinearLayout heading = row();
        heading.addView(badge(i + 1));
        LinearLayout description = column();
        description.addView(text(stage.role, 16, FG, true));
        String modelLabel = stage.model.label;
        if (done) modelLabel = contributorLabels(run.answerAt(i), stage.model);
        add(description, text(modelLabel + " · " + status, 13,
                running ? ACCENT : MUTED, false), 3);
        LinearLayout.LayoutParams item = weighted();
        item.leftMargin = dp(10);
        heading.addView(description, item);
        card.addView(heading);
        if (done || hasDraft) {
            String answer = done ? run.displayAnswer(i) : run.draft.text;
            if (hasDraft) {
                add(card, text("Черновик · " + contributorLabels(run.draft, stage.model),
                        13, WARNING, true), 12);
            }
            Workflow.Artifact artifact = done ? run.answerAt(i) : run.draft;
            if (!artifact.warnings.isEmpty()) {
                add(card, text("⚠ Проверь продолжение ответа:\n" + String.join("\n", artifact.warnings),
                        13, WARNING, false), 10);
            }
            TextView response = selectable(preview(answer), 15, FG);
            response.setLineSpacing(dp(4), 1f);
            add(card, response, 14);
            if (answer.length() > ANSWER_PREVIEW) {
                add(card, button("Открыть весь текст", false, view -> showText(stage.role, answer)), 10);
            }
            add(card, button("Копировать ответ", false, view -> {
                try {
                    ClipboardManager clipboard = getSystemService(ClipboardManager.class);
                    clipboard.setPrimaryClip(ClipData.newPlainText(stage.role, answer));
                    toast("Ответ скопирован");
                } catch (RuntimeException e) {
                    toast("Не удалось скопировать. Сохрани разбор в JSON.");
                }
            }), 10);
            List<String> blocks = PythonInputs.manualBlocks(answer);
            if (done && !blocks.isEmpty()) {
                Button execute = button("Запустить код", false, view -> nexusRunPython(i));
                execute.setEnabled(!active);
                add(card, execute, 10);
            }
        }
        if (running) {
            String waiting = stagePool != null && !stagePool.failures.isEmpty()
                    ? "Пробую резервную модель · попытка " + stagePool.next + " из " + stagePool.models.size()
                    : "Ожидание модели · максимум 60 секунд на попытку";
            liveStatus = text(waiting, 13, ACCENT, false);
            liveText = selectable("", 15, FG);
            add(card, liveStatus, 10);
            add(card, liveText, 10);
        }
        if (current && !active) {
            add(card, button("Сменить модель шага", false, view -> chooseModel(stage.model, model -> {
                run = run.withModel(model);
                persistRun();
                renderRun(true);
            })), 10);
        }
        add(panel, card, 10);
    }

    private String contributorLabels(Workflow.Artifact artifact, ModelCatalog.Model fallback) {
        List<String> names = new ArrayList<>();
        for (String id : artifact.models) {
            try {
                names.add(catalog.details(ModelCatalog.storedModel(id, "")).label);
            } catch (JSONException e) {
                names.add(id);
            }
        }
        return names.isEmpty() ? fallback.label : String.join(" + ", names);
    }

    private void choosePythonBlock(Workflow.Run source, int index, List<String> blocks) {
        if (blocks.size() == 1) {
            showSandboxInput(source, index, blocks.get(0), "", false);
            return;
        }
        String[] labels = new String[blocks.size()];
        for (int i = 0; i < labels.length; i++) {
            String firstLine = blocks.get(i).trim().split("\\R", 2)[0];
            labels[i] = "Блок " + (i + 1) + " · "
                    + (firstLine.length() > 70 ? firstLine.substring(0, 70) + "…" : firstLine);
        }
        new AlertDialog.Builder(this).setTitle("Выбрать блок Python").setItems(labels,
                (dialog, which) -> showSandboxInput(source, index, blocks.get(which), "", false))
                .setNegativeButton("Отмена", null).show();
    }

    private void showSandboxInput(Workflow.Run source, int index, String code, String previousInput,
                                  boolean usePiston) {
        LinearLayout form = dialogForm();
        add(form, text("Введи данные для input(), по одному ответу на строку. "
                + "Пустое поле означает конец ввода.", 14, MUTED, false), 0);
        EditText stdin = field(previousInput, "Ввод программы (stdin)", 0, 3, false);
        add(form, stdin, 8);
        String pistonKey = readPistonForEdit();
        CheckBox packages = new CheckBox(this);
        packages.setText("Разрешить загрузку Matplotlib и зависимостей с CDN Pyodide "
                + "(только для локального Python, нужен интернет)");
        packages.setChecked(false);
        add(form, packages, 8);
        CheckBox remote = new CheckBox(this);
        if (!pistonKey.isEmpty()) {
            remote.setText("Piston · Python " + SandboxClient.PISTON_VERSION + "\nКод и ввод отправятся в Piston.");
            remote.setChecked(usePiston);
            add(form, remote, 8);
        }
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Запустить код")
                .setView(dialogArea(form)).setPositiveButton("Запустить", null)
                .setNegativeButton("Отмена", null).show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String input = stdin.getText().toString();
            try {
                SandboxClient.validate(code, input);
            } catch (IllegalArgumentException e) {
                stdin.setError(e.getMessage());
                return;
            }
            dialog.dismiss();
            runSandbox(source, index, code, input, remote.isChecked() ? pistonKey : "",
                    packages.isChecked() && !remote.isChecked());
        });
    }

    private void runSandbox(Workflow.Run source, int index, String code, String stdin,
                            String pistonKey, boolean loadMatplotlib) {
        runSandbox(source, index, code, stdin, pistonKey, loadMatplotlib,
                null, "main.py", "", false);
    }

    private void runSandbox(Workflow.Run source, int index, String code, String stdin,
                            String pistonKey, boolean loadMatplotlib, JSONObject projectFiles,
                            String entryFile, String allowedPackage, boolean extended) {
        runSandbox(source, index, code, stdin, pistonKey, loadMatplotlib,
                projectFiles, entryFile, allowedPackage, extended, false, "");
    }

    private void runSandbox(Workflow.Run source, int index, String code, String stdin,
                            String pistonKey, boolean loadMatplotlib, JSONObject projectFiles,
                            String entryFile, String allowedPackage, boolean extended,
                            boolean automatic, String editedPath) {
        if (active || clearing || source != run || sandboxJob != null) return;
        final long resultProject = activeArtifactId;
        if (projectFiles != null) invalidatePythonReport(resultProject);
        final int reportEpoch;
        synchronized (pythonReportLock) {
            reportEpoch = pythonReportEpoch.getOrDefault(resultProject, 0);
        }
        boolean remote = !pistonKey.isEmpty();
        boolean compose = nexusUi != null;
        AlertDialog progress = compose ? null : new AlertDialog.Builder(this)
                .setTitle("Запускаю Python")
                .setMessage(remote ? "В песочнице Piston…"
                        : loadMatplotlib ? "Загружаю Matplotlib…" : "На телефоне…")
                .setNegativeButton("Остановить", null).show();
        SandboxJob job = new SandboxJob(progress, automatic, editedPath);
        sandboxJob = job;
        lastPythonRun = source;
        lastPythonStep = index;
        lastPythonCode = code;
        lastPythonStdin = stdin;
        lastPythonDiagnostic = "";
        if (compose) nexusUi.pythonStarted();
        if (progress != null) progress.setOnDismissListener(dialog -> {
            if (sandboxJob == job) cancelSandbox();
        });
        Consumer<SandboxClient.Result> result = rawOutput -> {
            if (sandboxJob != job || isDestroyed()) return;
            // A user-specified stdout contract is checked against the actual sandbox output.
            // A zero Python exit code does not override a failed expected-output test.
            SandboxClient.Result evaluatedOutput = rawOutput;
            if (job.automatic && source != null && !rawOutput.inputRequired) {
                String requirements = PythonInputs.withoutMaterials(ChatProjectContext.withoutInlineProject(
                        TaskHistory.currentUserTestRequest(source.task)));
                PythonAutoTests.Assessment check = PythonAutoTests.evaluate(requirements, rawOutput);
                if (check.checked) {
                    String note = check.passed ? getString(R.string.python_auto_test_passed)
                            : getString(R.string.python_auto_test_failed,
                                    PythonAutoTests.display(check.expected),
                                    PythonAutoTests.display(check.actual));
                    evaluatedOutput = check.report(note);
                }
            }
            final SandboxClient.Result output = evaluatedOutput;
            final boolean testFailed = PythonAutoTests.failed(output);
            sandboxJob = null;
            if (progress != null) progress.dismiss();
            if (compose) {
                String diagnostic = output.diagnostic();
                boolean waitingForInput = output.inputRequired && !testFailed && (output.exitCode == null || output.exitCode == 0);
                lastPythonDiagnostic = waitingForInput || PythonVerification.environmentalDiagnostic(diagnostic) || index < 0
                        || source == null ? "" : testFailed
                        ? PythonAutoTests.failureDiagnostic(output) : diagnostic;
                if (projectFiles != null) {
                    sandboxWorker.submit(() -> {
                        synchronized (pythonReportLock) {
                            if (!deletedPythonReportProjects.contains(resultProject)
                                    && pythonReportEpoch.getOrDefault(resultProject, 0) == reportEpoch) {
                                try { new PythonLastRunStore(getApplicationContext(), true).save(resultProject, output); }
                                catch (IOException ignored) { /* Still visible in the current UI. */ }
                            }
                        }
                    });
                }
                latestVisual = (!output.pngBase64.isEmpty() || !output.html.isEmpty()) ? output : null;
                if (latestVisual != null) nexusUi.cacheVisual(latestVisual.pngBase64, latestVisual.html);
                nexusUi.onVisualAvailable(latestVisual != null);
                nexusUi.pythonFinished(new NexusPythonReport(output.engine, output.stdout,
                        output.stderr, output.status, lastPythonDiagnostic,
                        output.exitCode, latestVisual != null,
                        output.artifacts.toString(), output.tests.toString(), output.snapshotSha256, output.inputRequired));
            } else showSandboxResult(source, index, code, stdin, remote, output);
            if (job.automatic) {
                if (output.inputRequired && !testFailed && (output.exitCode == null || output.exitCode == 0)) return;
                toast(getString(output.exitCode != null && output.exitCode == 0 && !testFailed
                        ? R.string.python_auto_run_success : R.string.python_auto_run_error));
                // Roll back only the project snapshot saved for this automatic launch.
                // The failing source is still available in the AI prompt and run logs.
                if ((testFailed || output.exitCode != null && output.exitCode != 0)
                        && !rollbackFailedAutoPython(source, resultProject, projectFiles, job.editedPath)) {
                    return; // Never overwrite an unconfirmed user edit or a missing backup.
                }
                forwardAutoPythonFailure(source, resultProject, reportEpoch, entryFile, code, output);
            }
        };
        Consumer<String> problem = message -> {
            if (sandboxJob != job || isDestroyed()) return;
            sandboxJob = null;
            if (progress != null) progress.dismiss();
            if (compose) nexusUi.pythonFailed(message);
            if (job.automatic) toast(getString(R.string.python_auto_run_error));
            if (!compose) new AlertDialog.Builder(this).setTitle("Запуск недоступен").setMessage(message)
                    .setNegativeButton("Закрыть", null)
                    .setPositiveButton("Повторить", (dialog, which) ->
                            showSandboxInput(source, index, code, stdin, false)).show();
        };
        if (remote) {
            job.future = sandboxWorker.submit(() -> {
                try {
                    SandboxClient.Result output = sandboxClient.execute(code, stdin, pistonKey, job.cancellation);
                    runOnUiThread(() -> result.accept(output));
                } catch (IOException e) {
                    String message = e.getMessage();
                    if (message == null || !message.startsWith("Piston"))
                        message = "Нет ответа от Piston. Можно повторить запуск на телефоне.";
                    String safe = message;
                    runOnUiThread(() -> problem.accept(safe));
                } catch (JSONException e) {
                    runOnUiThread(() -> problem.accept("Piston вернул неполный результат запуска."));
                }
            });
        } else {
            job.local = new AndroidPythonExecutor(this, result, problem);
            if (projectFiles == null) job.local.execute(code, stdin, loadMatplotlib);
            else if (hasWorkspaceUnittest(projectFiles)) job.local.executeProject(code, stdin, projectFiles, entryFile, allowedPackage, extended, true);
            else job.local.executeProject(code, stdin, projectFiles, entryFile, allowedPackage, extended);
        }
    }

    private static boolean hasWorkspaceUnittest(JSONObject files) {
        for (java.util.Iterator<String> keys = files.keys(); keys.hasNext();)
            if (PythonAutoStage.unittestPath(keys.next())) return true;
        return false;
    }

    private static boolean samePythonSnapshot(JSONObject expected, JSONObject current) {
        if (expected == null || current == null || expected.length() != current.length()) return false;
        for (java.util.Iterator<String> keys = expected.keys(); keys.hasNext();) {
            String key = keys.next();
            if (!current.has(key) || !expected.optString(key).equals(current.optString(key))) return false;
        }
        return true;
    }

    /** A failed auto-run must not destroy the last working project or its backup. */
    private boolean rollbackFailedAutoPython(Workflow.Run source, long projectId,
                                             JSONObject launchedFiles, String editedPath) {
        if (source != run || active || clearing || projectId <= 0
                || activeArtifactId != projectId || artifactRepository.forChat(activeTaskId) != projectId
                || launchedFiles == null || editedPath == null || editedPath.isEmpty()) return false;
        try {
            PythonProjectStore projects = pythonProjects();
            if (!samePythonSnapshot(launchedFiles, projects.snapshot(projectId))
                    || !projects.hasPrevious(projectId)) {
                stopAutoPythonRepair(source, getString(R.string.python_auto_repair_project_changed));
                return false;
            }
            projects.restorePrevious(projectId);
            artifactRepository.touch(projectId, editedPath);
            if (nexusUi != null) nexusUi.projectChanged("");
            return true;
        } catch (IOException | RuntimeException error) {
            stopAutoPythonRepair(source, getString(R.string.python_auto_repair_rollback_failed));
            return false;
        }
    }

    private void stopAutoPythonRepair(Workflow.Run source, String reason) {
        if (source == run && source.complete() && !active && !clearing) {
            run = source.withNote(reason);
            persistRun();
            renderRun(true);
        }
        toast(reason);
    }

    /** A confirmed Python failure starts or advances one bounded repair cycle. */
    private void forwardAutoPythonFailure(Workflow.Run source, long projectId, int epoch,
                                          String entry, String code, SandboxClient.Result output) {
        if (active || clearing || source == null || run != source || TaskHistory.readOnlyTurn(source.task) || !source.complete()
                || activeArtifactId != projectId || projectId <= 0
                || artifactRepository.forChat(activeTaskId) != projectId
                || !data.getBoolean(PRIVACY_NOTICE_ACKNOWLEDGED, false)) return;
        synchronized (pythonReportLock) {
            if (deletedPythonReportProjects.contains(projectId)
                    || pythonReportEpoch.getOrDefault(projectId, 0) != epoch) return;
        }
        String requirements = PythonInputs.withoutMaterials(ChatProjectContext.withoutInlineProject(
                TaskHistory.forRepair(source.task)));
        boolean failedTest = PythonAutoTests.failed(output);
        String diagnostic = failedTest ? PythonAutoTests.failureDiagnostic(output) : output.stderr;
        String prompt = failedTest
                ? PythonAutoFeedback.functionalTestPrompt(requirements, entry, code, diagnostic)
                : PythonAutoFeedback.prompt(requirements, entry, code,
                        output.exitCode, output.stderr, output.status);
        if (prompt.isEmpty()) return;

        sendOnePythonFeedback(source, projectId, prompt, entry, code, diagnostic);
    }

    /** Leave a visible reason when a checked error could not be forwarded. */
    private void pythonFeedbackUnavailable(Workflow.Run source) {
        if (run == source && source.complete() && !active && !clearing) {
            run = source.withNote(getString(R.string.python_auto_feedback_unavailable));
            persistRun();
            renderRun(true);
        }
        toast(getString(R.string.python_auto_feedback_unavailable));
    }

    /** The local verifier may find a real Python error before the file is saved. */
    private void forwardAutoPythonVerificationFailure(Workflow.Run source) {
        if (source == null || source != run || active || clearing || TaskHistory.readOnlyTurn(source.task) || !source.complete()
                || source.verification.status != PythonVerification.Status.ERROR) return;
        if (source.hasAnswer(source.verification.source)
                && (linkedSuiteRequired(source, source.verification.source)
                || !PythonInputs.multiPythonProject(source.displayAnswer(source.verification.source)).isEmpty())) return;
        PythonAutoRepair.State repair = PythonAutoRepair.parse(source.task);
        if (PythonAutoFeedback.isFeedback(source.task) && repair == null) return;
        // A deliberately independent task must not repair an older linked project.
        if (repair == null && !ChatProjectContext.hasInlineProject(source.task)) return;
        String userMessage = PythonInputs.withoutMaterials(ChatProjectContext.withoutInlineProject(
                repair == null ? TaskHistory.displayTask(source.task) : TaskHistory.forRepair(source.task)));
        if (!PythonAutoStage.requested(userMessage) || !PythonAutoStage.runAllowed(userMessage)) return;
        long linked = artifactRepository.forChat(activeTaskId);
        if (linked <= 0 || !artifactRepository.exists(linked)) {
            pythonFeedbackUnavailable(source);
            return;
        }
        int step = source.verification.source;
        if (!source.hasAnswer(step) || !source.answerAt(step).intactParts()) {
            pythonFeedbackUnavailable(source);
            return;
        }
        try {
            String requirements = PythonInputs.withoutMaterials(ChatProjectContext.withoutInlineProject(
                    TaskHistory.forRepair(source.task)));
            String answer = source.displayAnswer(step);
            String prompt = repair == null
                    ? PythonAutoFeedback.verifiedPrompt(userMessage, requirements,
                            answer, pythonProjects().paths(linked), source.verification)
                    : verifiedRepairPrompt(source, repair, userMessage, requirements,
                            answer, pythonProjects().paths(linked));
            if (prompt.isEmpty()) {
                if (repair != null) stopAutoPythonRepair(source,
                        getString(R.string.python_auto_repair_stopped));
                else pythonFeedbackUnavailable(source);
                return;
            }
            PythonInputs.Candidate candidate = PythonInputs.candidate(answer);
            sendOnePythonFeedback(source, linked, prompt, PythonAutoRepair.pathInFeedback(prompt),
                    candidate.code, source.verification.diagnostic);
        } catch (IOException problem) {
            pythonFeedbackUnavailable(source);
        }
    }

    /** The verifier fingerprint proves that the exact proposed repair failed. */
    private String verifiedRepairPrompt(Workflow.Run source, PythonAutoRepair.State repair,
                                        String userMessage, String requirements, String answer,
                                        String[] paths) {
        if (!repair.canContinue() || !source.answerAt(source.verification.source).intactParts()) return "";
        PythonAutoStage.Selection selected = PythonAutoStage.select(userMessage, answer, paths);
        if (selected == null || !repair.path.equals(selected.path)
                || !source.verification.matchesCheckedSource(selected.code, "")) return "";
        return PythonAutoFeedback.verificationPrompt(requirements, selected.path,
                selected.code, source.verification.diagnostic);
    }

    /** Only unattended repair requests are blocked by a recent quota-zero snapshot.
     * Explicit user requests remain possible, and unknown quotas are not guessed.
     */
    private boolean automaticRepairQuotaExhausted(Workflow.Provider provider) {
        long now = System.currentTimeMillis();
        if (provider == Workflow.Provider.GROQ) {
            return AutonomyQuotaGuard.groqExhausted(
                    data.getLong(QUOTA_GROQ_TPM, ProviderQuota.UNKNOWN),
                    data.getLong(QUOTA_GROQ_RPD, ProviderQuota.UNKNOWN),
                    data.getLong(QUOTA_GROQ_AT, 0), now);
        }
        if (provider == Workflow.Provider.OPENROUTER) {
            return AutonomyQuotaGuard.openRouterExhausted(
                    data.getLong(QUOTA_ROUTER_RPD, ProviderQuota.UNKNOWN),
                    data.getLong(QUOTA_ROUTER_AT, 0), now);
        }
        return false; // Gemini does not provide a dependable remaining quota here.
    }

    /** Each completed repair is versioned. The prompt carries a capped retry counter. */
    private void sendOnePythonFeedback(Workflow.Run source, long projectId, String prompt,
                                       String path, String failedCode, String diagnostic) {
        if (active || clearing || run != source || !source.complete()
                || projectId <= 0 || artifactRepository.forChat(activeTaskId) != projectId
                || !data.getBoolean(PRIVACY_NOTICE_ACKNOWLEDGED, false)) return;
        String next;
        try {
            String savedCode = pythonProjects().text(projectId, path);
            PythonAutoRepair.State previous = PythonAutoRepair.parse(source.task);
            if (PythonAutoFeedback.isFeedback(source.task) && previous == null) return;
            next = previous == null
                    ? PythonAutoRepair.first(prompt, path, failedCode, diagnostic, savedCode)
                    : PythonAutoRepair.next(previous, prompt, path, failedCode, diagnostic, savedCode);
        } catch (IOException | RuntimeException failure) {
            next = "";
        }
        if (next.isEmpty() || next.length() > Workflow.TASK_LIMIT) {
            stopAutoPythonRepair(source, getString(R.string.python_auto_repair_stopped));
            return;
        }
        Workflow.Run feedback = Workflow.Run.quick(next,
                source.stages.get(source.finalIndex()).model,
                stages.get(Workflow.Step.REVIEW.ordinal()))
                .withFallbackPolicy(false)
                .withUserTestTask(source.userTestTask());
        if (modelsFor(feedback).models.isEmpty()) {
            pythonFeedbackUnavailable(source);
            return;
        }
        if (automaticRepairQuotaExhausted(feedback.nextStage().selected.provider)) {
            stopAutoPythonRepair(source, getString(R.string.python_auto_repair_quota_stop));
            return;
        }
        final long taskId = activeTaskId;
        persistBeforeSwitch(() -> {
            if (active || clearing || run != source || activeTaskId != taskId
                    || artifactRepository.forChat(activeTaskId) != projectId) return;
            try {
                if (!repository.preserveVersion(taskId, source.toJson().toString())) {
                    pythonFeedbackUnavailable(source);
                    return;
                }
            } catch (JSONException | RuntimeException failure) {
                pythonFeedbackUnavailable(source);
                return;
            }
            workExpanded = false;
            toast(getString(R.string.python_auto_feedback_sent));
            begin(feedback, true);
        });
    }

    private void showSandboxResult(Workflow.Run source, int index, String code, String stdin,
                                   boolean usedPiston, SandboxClient.Result result) {
        latestVisual = (!result.pngBase64.isEmpty() || !result.html.isEmpty()) ? result : null;
        if (nexusUi != null) {
            if (latestVisual != null) nexusUi.cacheVisual(latestVisual.pngBase64, latestVisual.html);
            nexusUi.onVisualAvailable(latestVisual != null);
        }
        LinearLayout form = dialogForm();
        String header = result.engine;
        if (result.exitCode != null) header += " · код завершения " + result.exitCode;
        add(form, text(header, 14, MUTED, true), 0);
        if (!result.status.isEmpty()) add(form, selectable(result.status, 14, WARNING), 8);
        add(form, text("Вывод (stdout)", 14, MUTED, true), 12);
        add(form, consoleText(result.stdout.isEmpty() ? "Нет вывода." : result.stdout, FG), 6);
        if (!result.stderr.isEmpty()) {
            add(form, text("Ошибки (stderr)", 14, MUTED, true), 12);
            add(form, consoleText(result.stderr, WARNING), 6);
        }
        if (!result.pngBase64.isEmpty() || !result.html.isEmpty()) {
            add(form, button("Показать результат", true, view -> showVisualResult(result)), 12);
        }
        AlertDialog.Builder dialog = new AlertDialog.Builder(this).setTitle("Результат запуска")
                .setView(dialogArea(form)).setNegativeButton("Закрыть", null)
                .setNeutralButton("Повторить", (which, button) ->
                        showSandboxInput(source, index, code, stdin, usedPiston));
        String error = result.diagnostic();
        if (!error.isEmpty() && !PythonVerification.environmentalDiagnostic(error)) {
            add(form, text("Ревьюер получит код, ввод и сообщение об ошибке.", 13, MUTED, false), 12);
            dialog.setPositiveButton("Отправить ошибку Ревьюеру", (window, button) -> {
                if (active || run != source || !run.hasAnswer(index)) return;
                boolean wasComplete = run.complete();
                run = run.addRepair(new Workflow.RepairInput(index, code, stdin, error));
                persistRun();
                if (wasComplete) resumeRun();
                if (!active) {
                    if (!wasComplete) toast("Шаг исправления добавлен после текущих шагов.");
                    renderRun(true);
                }
            });
        }
        dialog.show();
    }

    /** Untrusted Python output: no keys, JS bridge, navigation, network, or file access. */
    private void showVisualResult(SandboxClient.Result result) {
        latestVisual = result;
        if (nexusUi != null) nexusUi.showVisual(result.pngBase64, result.html);
    }


    // The Java request/workflow/crypto/database implementation remains authoritative.
    // Compose receives a read-only snapshot without API keys or WebView internals.
    private void nexusRender(NexusComposeUi.Page page) {
        if (nexusUi == null) {
            nexusUi = new NexusComposeUi(this);
            nexusUi.mount();
        }
        nexusUi.render(nexusSnapshot(), page);
    }

    public PythonVerification nexusVerification() { return run == null ? PythonVerification.NONE : run.verification; }
    public int nexusFinalStep() { return run != null && run.complete() ? run.finalIndex() : -1; }

    public List<NexusState.Stage> nexusConfiguredStages() {
        List<NexusState.Stage> configured = new ArrayList<>();
        for (int i = 0; i < stages.size(); i++) {
            Workflow.Stage stage = stages.get(i);
            configured.add(new NexusState.Stage(i, stage.role, stage.instruction, stage.selected.id,
                    stage.selected.label, "", "", false, false, false));
        }
        return configured;
    }

    public boolean nexusAllowFallback() { return data.getBoolean("allow_fallback", true); }

    public boolean nexusSetFallback(boolean allow) {
        return data.edit().putBoolean("allow_fallback", allow).commit();
    }

    public boolean nexusPartsAvailable() {
        return !active && run != null && !run.complete() && !run.nextStage().numberedParts
                && run.nextStep() != Workflow.Step.REVIEW
                && (run.note.contains(getString(R.string.budget_short)) || run.draftMode == Workflow.DraftMode.CONTINUE
                    || run.draftMode == Workflow.DraftMode.RESTART);
    }

    public void nexusResumeInParts() {
        if (!nexusPartsAvailable()) return;
        run = run.permitParts();
        persistRun();
        resumeRun();
    }

    public void nexusChangePausedModel(String id) {
        if (active || clearing || run == null || run.complete()) return;
        ModelCatalog.Model replacement = nexusFindModel(id);
        if (replacement == null || !catalog.available(replacement)) { toast(getString(R.string.route_missing)); return; }
        run = run.withModel(replacement);
        persistRun();
        renderRun(false);
    }

    public boolean nexusReadOnlyTurn() { return run != null && TaskHistory.readOnlyTurn(run.task); }

    /** Presentation only: a model statement is not a measured browser result.
     * Keep provider text and source bytes untouched for export and recovery. */
    private String webEvidenceNotice(Workflow.Run owner, int step) {
        if (owner == null || !owner.hasAnswer(step) || TaskHistory.readOnlyTurn(owner.task)) return "";
        int sourceStep = owner.stepAt(step) == Workflow.Step.REVIEW ? 0 : step;
        if (!owner.hasAnswer(sourceStep)) return "";
        String answer = owner.displayAnswer(sourceStep);
        JSONObject evidence = owner.answerAt(sourceStep).webCheck;
        boolean web = evidence != null && !"python".equals(evidence.optString("language"))
                || !PythonInputs.webProjectFiles(answer).isEmpty()
                || !PythonInputs.webSource(answer, "html").isEmpty()
                || !PythonInputs.webSource(answer, "javascript").isEmpty();
        if (web) return getString(R.string.web_model_claims_unconfirmed);
        if (PythonInputs.hasPythonDelivery(answer)) {
            JSONObject execution = evidence == null ? null : evidence.optJSONObject("project_execution");
            JSONObject suite = execution == null ? null : execution.optJSONObject("generated_tests");
            boolean measured = evidence != null && evidence.optBoolean("ran") &&
                    (evidence.optInt("total") > 0 || suite != null && suite.optInt("ran") > 0);
            if (owner.verification.source == sourceStep && (owner.verification.generatedSuitePassed() > 0
                    || owner.verification.ran && owner.verification.total > 0)) measured = true;
            if (!measured) return getString(R.string.python_model_claims_unconfirmed);
        }
        return "";
    }

    public NexusState nexusSnapshot() {
        boolean question = nexusReadOnlyTurn();
        List<NexusState.Stage> stageViews = new ArrayList<>();
        List<Workflow.Stage> visible = run != null ? run.stages : stages;
        for (int i = 0; i < visible.size(); i++) {
            Workflow.Stage stage = visible.get(i);
            boolean done = run != null && run.hasAnswer(i);
            boolean current = run != null && !run.complete() && i == run.nextIndex();
            String answer = done ? run.displayAnswer(i)
                    : current ? run.draft.text : "";
            String warnings = "";
            if (run != null && done) {
                warnings = String.join("\n", run.answerAt(i).warnings);
                String evidenceNotice = webEvidenceNotice(run, i);
                if (!evidenceNotice.isEmpty()) warnings += (warnings.isEmpty() ? "" : "\n") + evidenceNotice;
                if (i == Workflow.Step.REVIEW.ordinal()) {
                    JSONObject evidence = run.answerAt(0).webCheck;
                    if (evidence != null && "python".equals(evidence.optString("language")) && !evidence.optBoolean("ran"))
                        warnings += (warnings.isEmpty() ? "" : "\n") + getString(R.string.review_execution_unconfirmed);
                }
            }
            if (run != null && current && !done) warnings = String.join("\n", run.draft.warnings);
            String modelLabel = done ? contributorLabels(run.answerAt(i), stage.model) : stage.model.label;
            if (!stage.selected.id.equals(stage.model.id) || done && run.answerAt(i).models.size() > 1)
                modelLabel = getString(R.string.route_actual, stage.selected.label, modelLabel)
                        + (stage.routeReason.isEmpty() ? "" : " · " + stage.routeReason);
            stageViews.add(new NexusState.Stage(i, stage.role, stage.instruction,
                    stage.selected.id, modelLabel, answer, warnings,
                    !question && !PythonInputs.manualBlocks(answer).isEmpty(), done, current,
                    run != null && run.revisionSkipped() && i == Workflow.Step.REVISION.ordinal()));
        }
        List<NexusState.Model> modelViews = new ArrayList<>();
        EnumMap<Workflow.Provider, Boolean> connected = new EnumMap<>(Workflow.Provider.class);
        for (Workflow.Provider provider : Workflow.Provider.values())
            connected.put(provider, !readForEdit(provider).isEmpty());
        for (ModelCatalog.Model model : catalog.choices()) {
            modelViews.add(new NexusState.Model(model.id, model.label, model.provider.label,
                    Boolean.TRUE.equals(connected.get(model.provider)), model.imageInput, model.context));
        }
        List<NexusState.Task> taskViews = new ArrayList<>();
        for (TaskRepository.Entry entry : repository.list()) {
            boolean selected = entry.id == activeTaskId;
            Workflow.Run saved = selected ? run : interrupted(restoreStoredRun(entry.runJson));
            taskViews.add(new NexusState.Task(entry.id, entry.title, entry.updatedAt, entry.versions,
                    saved != null && saved.complete(), saved != null, selected,
                    saved == null ? PythonVerification.Status.NONE : saved.verification.status,
                    entry.pinned, entry.task.trim().isEmpty() && saved == null ? "" :
                            TaskHistory.title(PythonInputs.withoutMaterials(saved == null ? entry.task : TaskHistory.displayTask(saved.task)))));
        }
        boolean complete = run != null && run.complete();
        int finalStep = complete ? run.finalIndex() : -1;
        String finalText = finalStep >= 0 ? run.displayAnswer(finalStep) : "";
        String warning = finalStep >= 0
                ? String.join("\n", run.answerAt(finalStep).warnings) : "";
        if (finalStep >= 0) {
            String evidenceNotice = webEvidenceNotice(run, finalStep);
            if (!evidenceNotice.isEmpty()) warning += (warning.isEmpty() ? "" : "\n") + evidenceNotice;
        }
        return new NexusState(taskDraft == null ? "" : taskDraft,
                selectedMode == Workflow.Mode.QUICK, active, clearing,
                run != null, complete, run == null ? 0 : run.nextIndex(),
                run == null ? (selectedMode == Workflow.Mode.QUICK ? 1 : 3) : run.stages.size(),
                run == null ? "" : run.note, finalText,
                finalStep >= 0 ? run.stages.get(finalStep).role : "", warning,
                !question && !PythonInputs.manualBlocks(finalText).isEmpty(), attemptHistory == null ? "" : attemptHistory,
                stageViews, modelViews, taskViews, data.getBoolean(GROQ_RESERVE, false),
                quickModel().id, quickModel().label,
                repository.versions(activeTaskId).size(), !question && latestVisual != null, nexusExchanges());
    }

    /** Project real saved run versions into a readable conversation without modifying SQLite. */
    private List<NexusState.Exchange> nexusExchanges() {
        List<NexusState.Exchange> messages = new ArrayList<>();
        List<TaskRepository.Version> versions = repository.versions(activeTaskId);
        String previousOriginal = "";
        // Oldest first. Keep the latest 40 versions in the chat; all remain in Versions.
        for (int i = Math.min(versions.size() - 1, 39); i >= 0; i--) {
            Workflow.Run archived = restoreStoredRun(versions.get(i).runJson);
            if (archived != null) {
                previousOriginal = appendNexusExchange(messages, archived, previousOriginal);
            }
        }
        if (run != null) appendNexusExchange(messages, run, previousOriginal);
        return messages;
    }

    private String appendNexusExchange(List<NexusState.Exchange> messages,
                                       Workflow.Run archived, String previousOriginal) {
        String fullPrompt = TaskHistory.visibleUserText(archived.userTestTask());
        String prompt = TaskHistory.chatUserMessage(archived.task, fullPrompt, previousOriginal);
        String answer = archived.complete() ? archived.displayAnswer(archived.finalIndex()) : "";
        messages.add(new NexusState.Exchange(prompt, answer, archived.complete(),
                archived.complete() ? webEvidenceNotice(archived, archived.finalIndex()) : ""));
        return fullPrompt.isEmpty() ? previousOriginal : fullPrompt;
    }

    /** Include every saved version, regardless of the main chat display limit. Called off the UI thread. */
    public List<NexusState.SearchMessage> nexusSearchMessages(long onlyTask) {
        List<NexusState.SearchMessage> rows = new ArrayList<>();
        List<TaskRepository.Entry> tasks = onlyTask == 0 ? repository.list() :
                java.util.Collections.singletonList(repository.load(onlyTask));
        for (TaskRepository.Entry entry : tasks) {
            if (entry == null) continue;
            List<TaskRepository.Version> versions = repository.versions(entry.id);
            for (int i = versions.size() - 1; i >= 0; i--)
                addSearchVersion(rows, entry, versions.get(i).runJson);
            if (entry.runJson.isEmpty()) rows.add(new NexusState.SearchMessage(entry.id, entry.title, entry.task, true));
            else addSearchVersion(rows, entry, entry.runJson);
        }
        return rows;
    }
    private void addSearchVersion(List<NexusState.SearchMessage> rows, TaskRepository.Entry entry, String json) {
        Workflow.Run saved = restoreStoredRun(json);
        if (saved == null) return;
        String question = PythonInputs.withoutMaterials(TaskHistory.displayTask(saved.task));
        rows.add(new NexusState.SearchMessage(entry.id, entry.title, question, true));
        if (saved.complete()) rows.add(new NexusState.SearchMessage(entry.id, entry.title,
                saved.displayAnswer(saved.finalIndex()), false));
    }

    public void nexusDraftChanged(String draft) {
        if (clearing) return;
        taskDraft = draft;
        progressHandler.removeCallbacks(saveDraft);
        progressHandler.postDelayed(saveDraft, 600);
    }

    public void nexusModeChanged(boolean quick) {
        selectMode(quick ? Workflow.Mode.QUICK : Workflow.Mode.TEAM);
    }

    public String nexusBuffer(String name) {
        return getSharedPreferences("chat_drafts", MODE_PRIVATE).getString(activeTaskId + "/" + name, "");
    }
    public void nexusBuffer(String name, String value) {
        SharedPreferences.Editor edit = getSharedPreferences("chat_drafts", MODE_PRIVATE).edit();
        String key = activeTaskId + "/" + name;
        if (value.isEmpty()) edit.remove(key); else edit.putString(key, value);
        edit.apply();
    }
    public boolean nexusNoTrainingOnly() {
        return data.getBoolean(PRIVACY_NO_TRAINING, true);
    }

    public void nexusNoTrainingChanged(boolean enabled) {
        data.edit().putBoolean(PRIVACY_NO_TRAINING, enabled).apply();
        client.setNoTrainingOnly(enabled);
    }

    public long nexusTaskId() { return activeTaskId; }
    public void nexusStart() { startRun(); }
    public void nexusSendAttachmentsOnly(String message) { if (!active && !clearing) startRun(message, false, true); }
    /** A paused chat may accept a new message without resuming the interrupted request.
     * startRun() archives the unfinished run as a separate version before starting
     * the new one; the archived draft stays available under Previous versions.
     */
    public void nexusStartPausedMessage(String message) {
        if (active || clearing || run == null || run.complete() || message == null) return;
        if (TaskHistory.retryOnly(message)) { resumeRun(); return; }
        Workflow.Run base = developmentBase(run, message);
        if (base != run && base.complete()) {
            if (askPythonTarget(message, TaskHistory.forRepair(base.task), this::nexusStartPausedMessage)) return;
            submitFollowUp(base, message, base.displayAnswer(base.finalIndex()), false);
        } else startRun(message.trim(), !TaskHistory.startsIndependentTask(run.task, message));
    }
    public void nexusStop() { if (active) stopRun(); }
    public void nexusResume() { resumeRun(); }
    /** Read the stored unfinished response without launching another model request. */
    public void nexusViewDraft() {
        if (active || clearing || run == null || run.complete() || run.draft.text.isEmpty()) return;
        showText(getString(R.string.black_box_recovery_title), run.draft.text);
    }
    public void nexusOpenTaskEditor() { renderTask(); }
    public void nexusOpenResults() { if (run != null) renderRun(false); }
    public void nexusOpenHistory() { renderHistory(); }

    /** The file store, not a possibly stale Compose editor, owns Python chat data. */
    public boolean nexusHasSavedPythonFiles() {
        if (activeArtifactId <= 0) return false;
        try { return pythonProjects().paths(activeArtifactId).length > 0; }
        catch (IOException e) { return true; } // Never reuse a workspace whose files cannot be checked.
    }

    public void nexusCreateTask() {
        if (clearing) return;
        if (active) stopRun();
        if (sandboxJob != null) { cancelSandbox(); if (nexusUi != null) nexusUi.pythonCancelled(); }
        if (run == null && taskDraft.trim().isEmpty() && nexusUi != null
                && !nexusUi.hasDraftContent() && !nexusHasSavedPythonFiles()
                && !repository.hasExplicitlySavedChat(activeTaskId)) {
            renderTask(); return;
        }
        persistBeforeSwitch(() -> {
            try {
                long id = repository.create("");
                TaskRepository.Entry entry = repository.load(id);
                if (entry == null) throw new IllegalStateException("Task not saved");
                enterTask(entry);
            } catch (RuntimeException e) { toast(getString(R.string.error_new_task)); }
        });
    }

    public void nexusOpenTask(long id) {
        if (id != activeTaskId && (active || sandboxJob != null)) {
            toast(getString(R.string.finish_before_switch)); return;
        }
        openHistoryTask(id);
    }

    public void nexusPinTask(long id, boolean pinned) {
        if (repository.pin(id, pinned)) nexusRender(null);
    }
    public void nexusRenameTask(long id, String name) {
        if (repository.rename(id, name)) nexusRender(null);
    }

    private void removeTaskFiles(long id) {
        AttachmentStore.get(this).deleteTask(id);
        // Chat deletion must not delete an independent Python artifact.
        artifactRepository.unlinkChat(id);
        new PythonProjectStore(this).deleteTask(id); // Old pre-migration chat copies only.
        synchronized (pythonReportLock) {
            deletedPythonReportChats.add(id);
            new PythonLastRunStore(this).deleteTask(id);
        }
        SharedPreferences prefs = getSharedPreferences("chat_drafts", MODE_PRIVATE);
        SharedPreferences.Editor edit = prefs.edit();
        for (String key : prefs.getAll().keySet()) if (key.startsWith(id + "/")) edit.remove(key);
        edit.apply();
    }

    public void nexusDeleteTask(long id) {
        if (active || clearing || sandboxJob != null) return;
        nexusPythonFlushPending();
        TaskRepository.Entry entry = repository.load(id);
        if (entry == null) return;
        if (id != activeTaskId) {
            if (repository.delete(id)) { removeTaskFiles(id); renderHistory(); }
            else toast(getString(R.string.error_delete_task));
            return;
        }
        persistBeforeSwitch(() -> {
            long replacement = repository.create("");
            if (replacement > 0 && repository.delete(id)) { removeTaskFiles(id); enterTask(repository.load(replacement)); }
            else toast(getString(R.string.error_delete_task));
        });
    }

    private ModelCatalog.Model nexusFindModel(String id) {
        for (ModelCatalog.Model model : catalog.choices()) if (model.id.equals(id)) return model;
        return null;
    }

    public void nexusChooseQuickModel(String id) {
        ModelCatalog.Model model = nexusFindModel(id);
        if (model == null || active || clearing) return;
        quickModel = model;
        data.edit().putString("quick_model", model.id)
                .putString("quick_model_label", model.label).apply();
        if (run == null) renderTask();
        else nexusRender(NexusComposeUi.Page.TASK);
    }

    public boolean nexusUpdateStage(int index, String role, String instruction, String modelId) {
        if (clearing || index < 0 || index >= stages.size()
                || role.trim().isEmpty() || role.trim().length() > 42
                || instruction.trim().isEmpty() || instruction.trim().length() > 1600) return false;
        ModelCatalog.Model model = nexusFindModel(modelId);
        if (model == null || !catalog.available(model)) { toast(getString(R.string.route_missing)); return false; }
        List<Workflow.Stage> updated = new ArrayList<>(stages);
        updated.set(index, new Workflow.Stage(role.trim(), instruction.trim(), model));
        try {
            if (!data.edit().putString("stages", Workflow.stagesToJson(updated).toString()).commit()) {
                toast(getString(R.string.role_save_error)); return false;
            }
            stages = updated;
            if (run == null) renderTask();
            else nexusRender(NexusComposeUi.Page.TASK);
            return true;
        } catch (JSONException e) { return false; }
    }

    public void nexusRefreshModels() {
        refreshModels(true, problem -> {
            if (!problem.isEmpty()) toast(problem);
            if (nexusUi != null) nexusUi.render(nexusSnapshot(), null);
        });
    }

    /** Secret values are only requested for the editing dialog, never put into NexusState. */
    public String[] nexusKeysForEditing() {
        return new String[] {readForEdit(Workflow.Provider.OPENROUTER),
                readForEdit(Workflow.Provider.GROQ), readForEdit(Workflow.Provider.GEMINI),
                readPistonForEdit()};
    }

    public boolean nexusSaveKeys(String router, String groq, String gemini,
                                 String piston, boolean reserve) {
        if (!validKey(router) || !validKey(groq) || !validKey(gemini) || !validKey(piston)) return false;
        try {
            boolean groqChanged = !groq.trim().equals(readForEdit(Workflow.Provider.GROQ));
            boolean routerChanged = !router.trim().equals(readForEdit(Workflow.Provider.OPENROUTER));
            vault.save(router.trim(), gemini.trim(), groq.trim(), piston.trim());
            SharedPreferences.Editor settings = data.edit()
                    .putBoolean(GROQ_RESERVE, reserve && !groq.trim().isEmpty());
            if (groqChanged) settings.remove(QUOTA_GROQ_TPM).remove(QUOTA_GROQ_RPD)
                    .remove(QUOTA_GROQ_AT);
            if (routerChanged) settings.remove(QUOTA_ROUTER_RPD).remove(QUOTA_ROUTER_LIMIT)
                    .remove(QUOTA_ROUTER_AT);
            settings.apply();
            if (nexusUi != null) nexusUi.render(nexusSnapshot(), null);
            return true;
        } catch (GeneralSecurityException | IOException e) { return false; }
    }

    private String quotaValue(long number) {
        return number >= 0 ? String.valueOf(number) : getString(R.string.quota_unknown);
    }

    /** No extra model requests: Groq is populated from ordinary reply headers. */
    public String nexusQuotaSummary() {
        StringBuilder result = new StringBuilder("Groq\n");
        result.append(getString(R.string.quota_groq_tokens,
                quotaValue(data.getLong(QUOTA_GROQ_TPM, ProviderQuota.UNKNOWN))));
        result.append("\n").append(getString(R.string.quota_groq_requests,
                quotaValue(data.getLong(QUOTA_GROQ_RPD, ProviderQuota.UNKNOWN))));
        long groqAt = data.getLong(QUOTA_GROQ_AT, 0);
        if (groqAt > 0) result.append("\n").append(getString(R.string.quota_updated_at,
                DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(groqAt))));
        result.append("\n\nOpenRouter\n");
        long routerRemaining = data.getLong(QUOTA_ROUTER_RPD, ProviderQuota.UNKNOWN);
        long routerLimit = data.getLong(QUOTA_ROUTER_LIMIT, ProviderQuota.UNKNOWN);
        String routerValue = quotaValue(routerRemaining)
                + (routerRemaining >= 0 && routerLimit >= 0 ? " / " + routerLimit : "");
        result.append(getString(R.string.quota_router_requests, routerValue));
        long routerAt = data.getLong(QUOTA_ROUTER_AT, 0);
        if (routerAt > 0) result.append("\n").append(getString(R.string.quota_updated_at,
                DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(routerAt))));
        result.append("\n\nGemini\n").append(getString(R.string.quota_gemini_unknown));
        result.append("\n\n").append(getString(R.string.quota_snapshot_notice));
        return result.toString();
    }

    /** This manual key-status GET does not request a model completion or consume model tokens. */
    public void nexusRefreshRouterQuota(Consumer<String> callback) {
        final String key = readForEdit(Workflow.Provider.OPENROUTER);
        if (key.isEmpty()) {
            callback.accept(nexusQuotaSummary() + "\n" + getString(R.string.quota_no_key));
            return;
        }
        try {
            catalogWorker.execute(() -> {
                ProviderQuota limits = null;
                try {
                    limits = client.routerFreeQuota(key, new ModelClient.Cancellation());
                } catch (IOException | JSONException | ModelClient.Problem ignored) {
                    // Unknown quota is not zero: never invent a balance after a failed request.
                }
                final ProviderQuota received = limits;
                runOnUiThread(() -> {
                    if (received != null && key.equals(readForEdit(Workflow.Provider.OPENROUTER))) {
                        data.edit().putLong(QUOTA_ROUTER_RPD, received.requestsPerDay)
                                .putLong(QUOTA_ROUTER_LIMIT, received.dailyLimit)
                                .putLong(QUOTA_ROUTER_AT, System.currentTimeMillis()).apply();
                    }
                    callback.accept(nexusQuotaSummary() + (received == null
                            ? "\n" + getString(R.string.quota_refresh_error) : ""));
                });
            });
        } catch (RejectedExecutionException closed) {
            callback.accept(nexusQuotaSummary() + "\n" + getString(R.string.quota_refresh_error));
        }
    }

    public void nexusRunPython(int step) {
        if (active || clearing || run == null || nexusReadOnlyTurn() || !run.hasAnswer(step)) return;
        java.util.Map<String,String> project = PythonInputs.multiPythonProject(run.displayAnswer(step));
        if (!project.isEmpty()) {
            long linked = artifactRepository.forChat(activeTaskId);
            try {
                if (linked > 0 && artifactRepository.exists(linked)) {
                    java.util.Map<String,byte[]> saved = pythonProjects().snapshotForChat(linked);
                    boolean same = saved.keySet().equals(project.keySet());
                    if (same) for (String path : project.keySet())
                        if (!java.util.Arrays.equals(saved.get(path), project.get(path).getBytes(StandardCharsets.UTF_8))) { same = false; break; }
                    if (same) {
                        nexusOpenChatPythonProject();
                        if (nexusUi != null) nexusUi.selectPage(NexusComposeUi.Page.PROJECT);
                        return;
                    }
                }
            } catch (IOException unavailable) { /* Do not execute an unconfirmed source. */ }
            toast(getString(R.string.python_auto_skipped));
            return;
        }
        List<String> blocks = PythonInputs.manualBlocks(run.displayAnswer(step));
        if (blocks.isEmpty()) return;
        if (nexusUi != null) nexusUi.requestPython(step, blocks.toArray(new String[0]),
                !readPistonForEdit().isEmpty());
        else choosePythonBlock(run, step, blocks);
    }

    public boolean nexusExecutePython(int step, String code, String stdin,
                                      boolean remote, boolean loadMatplotlib) {
        if (clearing || active || sandboxJob != null) return false;
        if (step >= 0 && (run == null || !run.hasAnswer(step))) return false;
        try { SandboxClient.validate(code, stdin); }
        catch (IllegalArgumentException e) { toast(e.getMessage()); return false; }
        String pistonKey = remote ? readPistonForEdit() : "";
        if (remote && pistonKey.isEmpty()) return false;
        runSandbox(run, step, code, stdin, pistonKey, loadMatplotlib && !remote);
        return true;
    }

    /** Resolves a real saved file, never a filename invented by an AI response. */
    public String nexusChatPythonTarget(int step, String code) {
        if (run == null || !run.hasAnswer(step) || code == null
                || !PythonInputs.manualBlocks(run.displayAnswer(step)).contains(code)) return "";
        long linked = artifactRepository.forChat(activeTaskId);
        if (linked <= 0 || !artifactRepository.exists(linked)) return "";
        try { return PythonChatFile.target(code, pythonProjects().paths(linked)); }
        catch (IOException | RuntimeException error) { return ""; }
    }

    /** A deliberate chat action: back up the linked project, apply code and run the saved snapshot. */
    public boolean nexusApplyChatPython(int step, String code, String stdin) {
        if (clearing || active || sandboxJob != null || run == null || !run.hasAnswer(step)) return false;
        if (code == null || !PythonInputs.manualBlocks(run.displayAnswer(step)).contains(code)) {
            toast(getString(R.string.python_linked_code_mismatch));
            return false;
        }
        long linked = artifactRepository.forChat(activeTaskId);
        if (linked <= 0 || !artifactRepository.exists(linked)) {
            toast(getString(R.string.python_linked_project_missing));
            return false;
        }
        try {
            SandboxClient.validate(code, stdin);
            nexusPythonFlushPending();
            String path = PythonChatFile.target(code, pythonProjects().paths(linked));
            if (path.isEmpty()) {
                toast(getString(R.string.python_linked_missing_target));
                return false;
            }
            pythonProjects().replaceTextWithBackup(linked, path, code);
            invalidatePythonReport(linked);
            if (!artifactRepository.touch(linked, path))
                throw new IOException("Файл сохранён, но каталог проекта недоступен.");
            selectArtifact(linked);
            JSONObject snapshot = pythonProjects().snapshot(linked);
            if (nexusUi != null) nexusUi.pythonAppliedFromChat(step, path, code);
            runSandbox(run, step, code, stdin, "", false, snapshot, path, "", false);
            return true;
        } catch (IOException | RuntimeException error) {
            toast(getString(R.string.python_linked_apply_error, error.getMessage()));
            return false;
        }
    }

    // Mini-projects have independent persistent artifact IDs, not chat IDs.
    private final android.os.Handler pythonSaveHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable pendingPythonSave;
    private PythonProjectStore pythonProjectStore;
    private final Object pythonReportLock = new Object();
    // Prevent a queued report from an older code version recreating stale output.
    private final Map<Long, Integer> pythonReportEpoch = new java.util.HashMap<>();
    private final java.util.Set<Long> deletedPythonReportChats = new java.util.HashSet<>();
    private final java.util.Set<Long> deletedPythonReportProjects = new java.util.HashSet<>();
    private PythonProjectStore pythonProjects() {
        if (pythonProjectStore == null) pythonProjectStore = new PythonProjectStore(this, true);
        return pythonProjectStore;
    }

    /** Non-destructive upgrade. Copy every saved legacy project into an independent artifact.
     * Repeated launches retry interrupted copies; a deleted artifact's tombstone blocks reimport.
     * Even a legacy file whose chat row is missing remains recoverable under Artifacts. */
    private void migratePythonArtifacts() {
        PythonProjectStore legacy = new PythonProjectStore(this);
        PythonLastRunStore legacyRuns = new PythonLastRunStore(this);
        PythonLastRunStore artifactRuns = new PythonLastRunStore(this, true);
        for (long chatId : legacy.savedTaskIds()) {
            try {
                String[] names = legacy.paths(chatId);
                if (names.length == 0) continue;
                String title = "Python · " + names[0];
                for (String name : names) {
                    if (!"main.py".equals(name)) { title = "Python · " + name; break; }
                }
                long projectId = artifactRepository.registerLegacy(chatId,
                        repository.load(chatId) != null, title);
                if (projectId <= 0) continue; // Previously deleted by the user.
                if (pythonProjects().paths(projectId).length == 0) {
                    legacy.copyTo(chatId, pythonProjects(), projectId);
                    if (!artifactRepository.touch(projectId, names[0]))
                        throw new IOException("Artifact catalog row is missing");
                }
                SandboxClient.Result report = legacyRuns.load(chatId);
                if (report != null && artifactRuns.load(projectId) == null)
                    artifactRuns.save(projectId, report);
            } catch (IOException | RuntimeException error) {
                android.util.Log.w("NexusArtifacts", "Legacy Python project migration failed for chat " + chatId, error);
                // Original chat-<id>.json is NEVER deleted on migration failure.
            }
        }
    }

    private SandboxClient.Result loadCurrentPythonReport() {
        if (activeArtifactId <= 0 || artifactRepository.pausedForOtherFormat(activeTaskId, activeArtifactId)) return null;
        SandboxClient.Result saved = new PythonLastRunStore(this, true).load(activeArtifactId);
        if (saved == null || saved.snapshotSha256.isEmpty()) return null;
        try {
            return saved.snapshotSha256.equals(PythonProjectStore.snapshotSha256(
                    pythonProjects().snapshotForChat(activeArtifactId))) ? saved : null;
        } catch (IOException | RuntimeException invalid) { return null; }
    }

    private void restoreVisualForArtifact() {
        // A stored report is evidence only for the precise current project bytes.
        SandboxClient.Result saved = loadCurrentPythonReport();
        latestVisual = saved != null && (!saved.pngBase64.isEmpty() || !saved.html.isEmpty())
                ? saved : null;
    }

    private void selectArtifact(long id) {
        activeArtifactId = id;
        restoreVisualForArtifact();
        if (!data.edit().putLong(ACTIVE_ARTIFACT, id).commit())
            toast("Не удалось запомнить выбранный проект. Он останется в Артефактах.");
    }

    public long nexusArtifactId() { return activeArtifactId; }
    public long nexusChatProjectId() { return artifactRepository.forChat(activeTaskId); }
    public long nexusAssignedChatProjectId() { return artifactRepository.assignedForChat(activeTaskId); }

    /** Upgrade old shared links before exposing a project's bytes in any chat.
     * A failed copy leaves the old link inaccessible, rather than sharing files. */
    private long isolatedArtifactForChat(long chatId) {
        try {
            return artifactRepository.ensureIsolatedForChat(chatId, pythonProjects());
        } catch (IOException | RuntimeException error) {
            android.util.Log.w("NexusArtifacts", "Could not isolate Python project for chat " + chatId, error);
            toast(getString(R.string.chat_private_copy_failed));
            return 0;
        }
    }

    /** Persist only the chat snapshot; do not create or modify a Python project. */
    public void nexusSaveChat() {
        if (clearing || active || sandboxJob != null) {
            toast("Сначала заверши текущую операцию."); return;
        }
        nexusPythonFlushPending();
        long chatId = activeTaskId;
        persistBeforeSwitch(() -> {
            try {
                boolean saved = repository.markSavedChat(chatId);
                if (saved) nexusRender(null);
                toast(saved ? "Чат сохранён в истории." : "Не удалось сохранить чат.");
            } catch (RuntimeException error) {
                toast("Не удалось сохранить чат: " + error.getMessage());
            }
        });
    }

    /** Explicit save confirms the actual editor bytes reached the artifact file store. */
    public void nexusSaveArtifact(String path, String code) {
        if (clearing || active || sandboxJob != null) {
            toast("Сначала заверши текущую операцию."); return;
        }
        nexusPythonFlushPending();
        try {
            long id = ensurePythonArtifact();
            pythonProjects().putText(id, path, code);
            savedPythonArtifact(id, path);
            if (nexusUi != null) nexusUi.pythonFileSaved(activeTaskId, path);
            toast("Артефакт сохранён отдельно от чата.");
        } catch (IOException | RuntimeException error) {
            toast("Не удалось сохранить артефакт: " + error.getMessage());
        }
    }

    /** Link a private snapshot to the current chat; never share writable source files. */
    public void nexusAttachArtifactToChat() {
        if (clearing || active || sandboxJob != null) {
            toast("Сначала заверши текущую операцию."); return;
        }
        nexusPythonFlushPending();
        if (activeTaskId <= 0 || repository.load(activeTaskId) == null) {
            toast("Активный чат не найден. Создай новый чат и повтори подключение."); return;
        }
        try {
            long separate = isolatedArtifactForChat(activeTaskId);
            if (separate > 0) {
                // Reconnect the ORIGINAL private project without creating another copy.
                if (!artifactRepository.setConnected(activeTaskId, true))
                    throw new IOException("Не удалось включить подключение.");
            } else {
                if (activeArtifactId <= 0 || !artifactRepository.exists(activeArtifactId)) {
                    toast("Сначала выбери проект или создай новый."); return;
                }
                pythonProjects().snapshotForChat(activeArtifactId);
                separate = artifactRepository.attachIsolatedCopy(
                        activeTaskId, activeArtifactId, pythonProjects());
            }
            if (artifactRepository.forChat(activeTaskId) != separate)
                throw new IOException("Связь с проектом не подтверждена.");
            selectArtifact(separate);
            if (nexusUi != null) {
                nexusUi.projectCreated(separate);
                nexusUi.refreshChatProjectLink();
                nexusUi.dismissPythonResult();
                nexusUi.projectChanged("");
            }
            toast(getString(R.string.chat_private_copy_connected));
        } catch (IOException | RuntimeException error) {
            toast("Не удалось подключить Python: " + error.getMessage());
        }
    }

    /** Start a separate chat for this project, preserving the original chat and all code. */
    public void nexusNewChatForArtifact() {
        if (clearing || active || sandboxJob != null) return;
        nexusPythonFlushPending();
        final long project = activeArtifactId;
        if (!artifactRepository.exists(project)) {
            toast("Сначала открой сохранённый проект."); return;
        }
        persistBeforeSwitch(() -> {
            long created = 0;
            long separate = 0;
            try {
                created = repository.create("");
                TaskRepository.Entry entry = repository.load(created);
                if (entry == null) throw new IOException("Не удалось сохранить новый чат.");
                separate = artifactRepository.attachIsolatedCopy(created, project, pythonProjects());
                if (artifactRepository.forChat(created) != separate)
                    throw new IOException("Не удалось привязать отдельную копию проекта.");
                enterTask(entry);
            } catch (IOException | RuntimeException error) {
                if (created > 0) {
                    artifactRepository.unlinkChat(created);
                    repository.delete(created);
                }
                if (separate > 0) {
                    artifactRepository.delete(separate);
                    pythonProjects().deleteTask(separate);
                }
                toast("Не удалось создать чат для проекта: " + error.getMessage());
            }
        });
    }

    public void nexusDetachArtifactFromChat() {
        if (clearing || active || sandboxJob != null) return;
        nexusPythonFlushPending();
        if (artifactRepository.forChat(activeTaskId) <= 0) return;
        try {
            if (!artifactRepository.setConnected(activeTaskId, false))
                throw new IOException("Не удалось отключить Python.");
            if (nexusUi != null) nexusUi.refreshChatProjectLink();
            toast("Python отключён. Проект остаётся за этим чатом.");
        } catch (IOException | RuntimeException error) {
            toast("Не удалось отключить Python: " + error.getMessage());
        }
    }

    /** First Python connection in a new chat: create one owned project, not two copies. */
    public void nexusCreateChatPythonProject() {
        if (clearing || active || sandboxJob != null) return;
        nexusPythonFlushPending();
        if (activeTaskId <= 0 || repository.load(activeTaskId) == null) {
            toast("Активный чат не найден."); return;
        }
        try {
            long project = isolatedArtifactForChat(activeTaskId);
            if (project == 0) project = artifactRepository.createEmptyForChat(activeTaskId, pythonProjects());
            if (!artifactRepository.setConnected(activeTaskId, true))
                throw new IOException("Не удалось подключить проект.");
            selectArtifact(project);
            if (nexusUi != null) {
                nexusUi.projectCreated(project);
                nexusUi.refreshChatProjectLink();
                nexusUi.projectChanged("");
            }
            toast("Python подключён к текущему чату.");
        } catch (IOException | RuntimeException error) {
            toast("Не удалось создать проект: " + error.getMessage());
        }
    }

    /** When browsing other artifacts, switch back without replacing this chat's project. */
    public void nexusOpenChatPythonProject() {
        if (clearing || active || sandboxJob != null) return;
        nexusPythonFlushPending();
        long own = isolatedArtifactForChat(activeTaskId);
        if (own <= 0 || !artifactRepository.exists(own)) return;
        selectArtifact(own);
        if (nexusUi != null) {
            nexusUi.projectCreated(own);
            nexusUi.refreshChatProjectLink();
            nexusUi.projectChanged("");
        }
    }
    public java.util.List<NexusArtifact> nexusArtifacts() {
        return artifactRepository == null ? new ArrayList<>() : artifactRepository.list(pythonProjects());
    }
    public void nexusOpenArtifacts() {
        if (active || clearing || sandboxJob != null) {
            toast("Заверши выполнение перед переключением проектов."); return;
        }
        nexusPythonFlushPending();
        nexusRender(null);
        if (nexusUi != null) nexusUi.selectPage(NexusComposeUi.Page.ARTIFACTS);
    }
    public void nexusOpenArtifact(long id) {
        if (active || clearing || sandboxJob != null) {
            toast("Заверши выполнение перед переключением проектов."); return;
        }
        nexusPythonFlushPending();
        if (!artifactRepository.exists(id)) { toast("Проект не найден."); return; }
        selectArtifact(id);
        nexusRender(null);
        if (nexusUi != null) nexusUi.selectPage(NexusComposeUi.Page.PROJECT);
    }
    public void nexusCreateArtifact() {
        if (active || clearing || sandboxJob != null) return;
        nexusPythonFlushPending();
        long old = activeArtifactId;
        try {
            long id = artifactRepository.createUnlinked();
            pythonProjects().putText(id, "main.py", "");
            if (!artifactRepository.touch(id, "main.py"))
                throw new IOException("Не удалось зарегистрировать проект.");
            selectArtifact(id);
            nexusRender(null);
            if (nexusUi != null) nexusUi.selectPage(NexusComposeUi.Page.PROJECT);
        } catch (IOException | RuntimeException error) {
            selectArtifact(old);
            toast("Не удалось создать проект: " + error.getMessage());
        }
    }
    public void nexusRenameArtifact(long id, String title) {
        if (!artifactRepository.rename(id, title)) toast("Не удалось переименовать проект.");
        if (nexusUi != null) nexusUi.refreshArtifacts();
    }
    public void nexusDeleteArtifact(long id) {
        if (active || clearing || sandboxJob != null) return;
        nexusPythonFlushPending();
        if (!artifactRepository.delete(id)) { toast("Не удалось удалить проект."); return; }
        pythonProjects().deleteTask(id);
        synchronized (pythonReportLock) {
            deletedPythonReportProjects.add(id);
            new PythonLastRunStore(this, true).deleteTask(id);
        }
        if (activeArtifactId == id) selectArtifact(0);
        nexusRender(null);
        if (nexusUi != null) nexusUi.selectPage(NexusComposeUi.Page.ARTIFACTS);
    }

    /** Allocate a project without requiring a message, model, or a title in chat history. */
    private long ensurePythonArtifact() throws IOException {
        try {
            if (activeArtifactId > 0) {
                if (!artifactRepository.exists(activeArtifactId))
                    throw new IOException("Проект удалён или недоступен.");
                return activeArtifactId;
            }
            long created = artifactRepository.createUnlinked();
            selectArtifact(created);
            return created;
        } catch (android.database.SQLException e) {
            throw new IOException("Не удалось создать запись артефакта.", e);
        }
    }

    private void invalidatePythonReport(long id) {
        if (id <= 0) return;
        synchronized (pythonReportLock) {
            pythonReportEpoch.put(id, pythonReportEpoch.getOrDefault(id, 0) + 1);
            new PythonLastRunStore(this, true).deleteTask(id);
        }
        if (activeArtifactId == id) {
            latestVisual = null;
            if (nexusUi != null) {
                nexusUi.dismissPythonResult();
                nexusUi.onVisualAvailable(false);
            }
        }
    }

    private void savedPythonArtifact(long id, String path) throws IOException {
        invalidatePythonReport(id);
        try {
            if (!artifactRepository.touch(id, path))
                throw new IOException("Файл сохранён, но запись проекта отсутствует.");
        } catch (android.database.SQLException error) {
            throw new IOException("Файл сохранён, но каталог проектов недоступен.", error);
        }
        if (nexusUi != null) nexusUi.projectCreated(id);
    }

    /** Identifiers only: no code, API keys, messages, or file contents are exposed. */
    public String nexusPythonHistoryDiagnostic() {
        StringBuilder report = new StringBuilder("Nexus AI 0.7.0 · Python chat history\n")
                .append("Activity chat ID: ").append(activeTaskId).append('\n');
        try {
            report.append("Compose chat ID: ").append(nexusUi == null ? "none" : nexusUi.getTaskId())
                    .append("\nSQLite selected chat ID: ").append(repository.activeId())
                    .append("\nPreferences chat ID: ").append(data.getLong(ACTIVE_TASK, 0))
                    .append("\nWorkspace chat ID: ").append(store == null ? 0 : store.current().taskId)
                    .append("\nActive artifact ID: ").append(activeArtifactId)
                    .append('\n');
            long[] projectIds = pythonProjects().savedTaskIds();
            try {
                report.append("Current Python file count: ")
                        .append(activeArtifactId <= 0 ? 0 : pythonProjects().paths(activeArtifactId).length).append('\n');
            } catch (IOException error) {
                report.append("Current Python files: unreadable\n");
            }
            List<TaskRepository.Entry> listed = repository.list();
            report.append("History entries: ").append(listed.size())
                    .append("\nArtifact catalog entries: ").append(nexusArtifacts().size())
                    .append("\nSaved Python project IDs: ").append(projectIds.length).append('\n');
            TaskRepository.Entry activeRow = repository.load(activeTaskId);
            report.append("Active SQLite row: ").append(activeRow == null ? "MISSING" : "present")
                    .append('\n');
            for (int i = 0; i < projectIds.length && i < 30; i++) {
                long id = projectIds[i];
                boolean visible = false;
                for (NexusArtifact candidate : nexusArtifacts())
                    if (candidate.id == id) { visible = true; break; }
                report.append("Artifact ").append(id)
                        .append(": catalog=").append(artifactRepository.exists(id))
                        .append(", artifactsScreen=").append(visible).append('\n');
            }
            if (projectIds.length > 30) report.append("More projects omitted: ")
                    .append(projectIds.length - 30).append('\n');
        } catch (RuntimeException error) {
            report.append("Diagnostic error: ").append(error.getClass().getSimpleName());
        }
        return report.toString();
    }

    public void nexusPythonStageFile(long taskId, String path, String text) {
        if (pendingPythonSave != null) pythonSaveHandler.removeCallbacks(pendingPythonSave);
        pendingPythonSave = () -> {
            pendingPythonSave = null;
            try {
                if (taskId != activeTaskId) return; // Stale Compose editor.
                long projectId = ensurePythonArtifact();
                pythonProjects().putText(projectId, path, text);
                savedPythonArtifact(projectId, path);
                if (nexusUi != null) nexusUi.pythonFileSaved(taskId, path);
            } catch (IOException error) { toast("Не удалось сохранить файл Python: " + error.getMessage()); }
        };
        pythonSaveHandler.postDelayed(pendingPythonSave, 650);
    }

    public void nexusPythonFlushPending() {
        if (pendingPythonSave != null) {
            pythonSaveHandler.removeCallbacks(pendingPythonSave);
            Runnable save = pendingPythonSave;
            pendingPythonSave = null;
            save.run();
        }
    }

    public NexusPythonReport nexusPythonRestoredReport() {
        SandboxClient.Result saved = loadCurrentPythonReport();
        if (saved == null) return null;
        return new NexusPythonReport(saved.engine, saved.stdout, saved.stderr, saved.status,
                "", saved.exitCode, !saved.pngBase64.isEmpty() || !saved.html.isEmpty(),
                saved.artifacts.toString(), saved.tests.toString(), saved.snapshotSha256, saved.inputRequired);
    }

    public String[] nexusPythonRestoredVisual() {
        SandboxClient.Result saved = loadCurrentPythonReport();
        return saved == null ? new String[]{"", ""} : new String[]{saved.pngBase64, saved.html};
    }

    public String[] nexusPythonPaths() {
        if (activeArtifactId <= 0) return new String[0];
        try { return pythonProjects().paths(activeArtifactId); }
        catch (IOException e) { toast(e.getMessage()); return new String[0]; }
    }

    public String nexusPythonRead(String path) {
        if (activeArtifactId <= 0) return "";
        try { return pythonProjects().text(activeArtifactId, path); }
        catch (IOException e) { toast(e.getMessage()); return ""; }
    }

    public byte[] nexusPythonBytes(String path) {
        if (activeArtifactId <= 0) return null;
        try { return pythonProjects().bytes(activeArtifactId, path); }
        catch (IOException e) { toast(e.getMessage()); return null; }
    }

    public String nexusPythonPut(String path, byte[] bytes) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().put(projectId, path, bytes);
            savedPythonArtifact(projectId, path);
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public String nexusPythonRemove(String path) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().remove(projectId, path);
            savedPythonArtifact(projectId, "main.py");
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public String nexusPythonRename(String from, String to) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().rename(projectId, from, to);
            savedPythonArtifact(projectId, to);
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public String nexusPythonImportZip(byte[] body) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().importZip(projectId, body);
            savedPythonArtifact(projectId, "main.py");
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public String nexusPythonReplaceZip(byte[] body) {
        if (sandboxJob != null) return "Завершите Python перед изменением проекта.";
        nexusPythonFlushPending();
        try {
            long projectId = ensurePythonArtifact();
            pythonProjects().replaceZip(projectId, body);
            savedPythonArtifact(projectId, "main.py");
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public boolean nexusPythonHasPreviousProject() {
        return activeArtifactId > 0 && pythonProjects().hasPrevious(activeArtifactId);
    }

    public String nexusPythonRestorePreviousProject() {
        if (sandboxJob != null) return "Завершите Python перед восстановлением проекта.";
        nexusPythonFlushPending();
        try {
            if (activeArtifactId <= 0) throw new IOException("Нет проекта для восстановления.");
            pythonProjects().restorePrevious(activeArtifactId);
            savedPythonArtifact(activeArtifactId, "main.py");
            return "";
        }
        catch (IOException e) { return e.getMessage(); }
    }

    public byte[] nexusPythonExportZip() {
        nexusPythonFlushPending();
        if (activeArtifactId <= 0) { toast("Сначала сохрани проект."); return null; }
        try { return pythonProjects().exportZip(activeArtifactId); }
        catch (IOException e) { toast(e.getMessage()); return null; }
    }

    public boolean nexusExecutePythonProject(String entry, String code, String stdin,
                                              String allowedPackage, boolean extended) {
        if (clearing || active || sandboxJob != null || !PythonProjectStore.validPath(entry)
                || !entry.endsWith(".py")) return false;
        try { SandboxClient.validate(code, stdin); }
        catch (IllegalArgumentException e) { toast(e.getMessage()); return false; }
        try {
            nexusPythonFlushPending();
            long projectId = ensurePythonArtifact();
            pythonProjects().putText(projectId, entry, code);
            savedPythonArtifact(projectId, entry);
            JSONObject snapshot = pythonProjects().snapshot(projectId);
            runSandbox(run, -1, code, stdin, "", !allowedPackage.isEmpty(),
                    snapshot, entry, allowedPackage, extended);
            return true;
        } catch (IOException e) { toast("Не удалось открыть проект: " + e.getMessage()); return false; }
    }

        public boolean nexusHasPiston() { return !readPistonForEdit().isEmpty(); }

    public void nexusCancelPython() { cancelSandbox(); }

    public void nexusSendPythonError() {
        if (active || clearing || lastPythonRun != run || run == null
                || !run.hasAnswer(lastPythonStep) || lastPythonDiagnostic.isEmpty()
                || PythonVerification.environmentalDiagnostic(lastPythonDiagnostic)) return;
        boolean complete = run.complete();
        run = run.addRepair(new Workflow.RepairInput(lastPythonStep,
                lastPythonCode, lastPythonStdin, lastPythonDiagnostic));
        persistRun();
        if (complete) resumeRun();
        else renderRun(true);
    }

    public void nexusExport() { if (run != null && !active) chooseExport(); }
    public void nexusOpenVersions() {
        if (nexusUi != null) nexusUi.requestVersions();
        else showVersions();
    }
    public String[] nexusVersionLabels() {
        List<TaskRepository.Version> versions = repository.versions(activeTaskId);
        String[] titles = new String[versions.size()];
        for (int i = 0; i < versions.size(); i++)
            titles[i] = "#" + versions.get(i).number + " · " + dateLabel(versions.get(i).createdAt);
        return titles;
    }
    public String nexusVersionAnswer(int index) {
        List<TaskRepository.Version> versions = repository.versions(activeTaskId);
        if (index < 0 || index >= versions.size()) return "";
        Workflow.Run snapshot = restoreStoredRun(versions.get(index).runJson);
        if (snapshot == null) return "";
        return snapshot.complete() ? snapshot.displayAnswer(snapshot.finalIndex()) :
                snapshot.draft.text.isEmpty() ? snapshot.task : snapshot.draft.text;
    }

    private boolean askPythonTarget(String text, String earlier, Consumer<String> submit) {
        if (!PythonInputs.asksPythonPort(text) || !PythonInputs.target(text).isEmpty()
                || !PythonInputs.target(earlier).isEmpty()) return false;
        String[] labels = {getString(R.string.target_desktop), getString(R.string.target_console), getString(R.string.target_android)};
        String[] ids = {"desktop", "console", "android"};
        new AlertDialog.Builder(this).setTitle(R.string.target_question).setItems(labels, (dialog, index) ->
                submit.accept(text + "\n" + labels[index] + " [" + ids[index] + "]"))
                .setNegativeButton(R.string.action_cancel, null).show();
        return true;
    }

    public void nexusFollowUp(String clarification) {
        if (active || clearing || run == null || !run.complete()) return;
        final Workflow.Run previous = developmentBase(run, clarification);
        boolean independent = TaskHistory.startsIndependentTask(previous.task, clarification);
        if (!TaskHistory.readOnlyQuestion(clarification) && askPythonTarget(clarification, independent ? "" : TaskHistory.forRepair(previous.task), this::nexusFollowUp)) return;
        submitFollowUp(previous, clarification, previous.displayAnswer(previous.finalIndex()), false);
    }

    /** Text-only turns do not replace the last completed development result.
     * Do not cross an intervening unfinished development task to an older project. */
    private Workflow.Run developmentBase(Workflow.Run current, String message) {
        if (!TaskHistory.readOnlyTurn(current.task) || TaskHistory.readOnlyQuestion(message)
                || TaskHistory.startsIndependentTask(current.task, message)) return current;
        for (TaskRepository.Version saved : repository.versions(activeTaskId)) {
            Workflow.Run prior = restoreStoredRun(saved.runJson);
            if (prior == null) break;
            if (TaskHistory.readOnlyTurn(prior.task)) continue;
            return prior.complete() ? prior : current;
        }
        return current;
    }

    public boolean nexusHasSourcePlan() {
        return !nexusBuffer("source_plan").isEmpty() && (run != null && !run.complete() && !active
                || !nexusBuffer("plan_visible").isEmpty());
    }

    private void saveSourcePlan(String intent, String original) {
        try {
            String digest = InputMaterial.sha256(original.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            nexusBuffer("source_plan", new JSONObject().put("change", intent).put("sha256", digest).toString());
        } catch (JSONException invalid) { throw new IllegalStateException(invalid); }
    }

    public void nexusOpenSourcePlan() {
        if (active || clearing || run == null) return;
        try {
            nexusBuffer("plan_visible","1");
            JSONObject plan = new JSONObject(nexusBuffer("source_plan"));
            String intent = plan.getString("change");
            String expected = plan.getString("sha256");
            List<Workflow.Run> versions = new ArrayList<>();
            versions.add(run);
            for (TaskRepository.Version saved : repository.versions(activeTaskId)) {
                Workflow.Run archived = restoreStoredRun(saved.runJson);
                if (archived != null) versions.add(archived);
            }
            for (Workflow.Run version : versions) {
                if (!version.complete()) continue;
                String answer = version.displayAnswer(version.finalIndex());
                String source = PythonInputs.singleSourceOrAnswer(answer);
                if (!expected.equals(InputMaterial.sha256(source.getBytes(java.nio.charset.StandardCharsets.UTF_8)))) continue;
                List<String> sections = TaskHistory.sections(source);
                String[] labels = new String[sections.size()];
                for (int i=0, offset=0; i<labels.length; i++) {
                    int end = offset + sections.get(i).length();
                    labels[i] = getString(R.string.source_range, i+1, labels.length, offset+1, end);
                    offset = end;
                }
                new AlertDialog.Builder(this).setTitle(R.string.source_plan).setItems(labels, (dialog,index) ->
                        submitFollowUp(version, intent + "\n" + labels[index] + ". Разбери только указанную часть. "
                                + "Остальные части и программа целиком не проверены.", sections.get(index), true))
                        .setNegativeButton(R.string.action_cancel,null).show();
                return;
            }
            toast(getString(R.string.error_save_version));
        } catch (JSONException invalid) { toast(getString(R.string.error_save_version)); }
    }

    /** Starting an independent task never writes to, or transmits, the old
     * project's private workspace. Keep the existing saved assignment. */
    private boolean disconnectPreviousProject() {
        try {
            if (artifactRepository.forChat(activeTaskId) <= 0) return true;
            nexusPythonFlushPending();
            if (artifactRepository.pauseForOtherFormat(activeTaskId)) {
                latestVisual = null;
                if (nexusUi != null) {
                    nexusUi.dismissPythonResult();
                    nexusUi.cacheVisual("", "");
                    nexusUi.onVisualAvailable(false);
                    nexusUi.refreshChatProjectLink();
                }
                return true;
            }
        } catch (RuntimeException error) { /* Preserve old workspace and stop. */ }
        toast(getString(R.string.error_save_version));
        return false;
    }

    /** Preserve old artifacts and select a new private workspace only when a connected
     * Python chat explicitly starts a different Python program. A disabled connection
     * remains disabled; new non-Python tasks keep the existing disconnect behavior. */
    private boolean switchIndependentProject(String task) {
        if (!PythonInputs.asksPythonPort(task))
            return disconnectPreviousProject();
        try {
            nexusPythonFlushPending();
            long fresh = artifactRepository.switchToEmptyForIndependentTask(activeTaskId, pythonProjects());
            if (fresh <= 0) return true; // The owner explicitly disconnected this chat.
            latestVisual = null;
            selectArtifact(fresh);
            if (nexusUi != null) {
                nexusUi.projectCreated(fresh);
                nexusUi.pythonAppliedFromChat(-1, "main.py", "");
                nexusUi.refreshChatProjectLink();
                nexusUi.dismissPythonResult();
                nexusUi.cacheVisual("", "");
                nexusUi.onVisualAvailable(false);
            }
            return true;
        } catch (IOException | RuntimeException error) {
            toast(getString(R.string.python_auto_failed, error.getMessage()));
            return false;
        }
    }

    /** Capture only the active chat's saved user turns, before archiving the current run.
     * Never use global search, selected artifact, or another task as a history source. */
    private List<String> questionHistory(long owner, Workflow.Run current) {
        if (owner <= 0 || owner != activeTaskId || current != run)
            throw new IllegalArgumentException("Chat changed before question preparation.");
        List<String> tasks = new ArrayList<>();
        if (current != null) tasks.add(current.task);
        for (TaskRepository.Version version : repository.versions(owner)) {
            if (tasks.size() >= TaskHistory.QUESTION_HISTORY_LIMIT) {
                tasks.add(null); // Mark older, unexamined history explicitly.
                break;
            }
            Workflow.Run archived = restoreStoredRun(version.runJson);
            tasks.add(archived == null ? null : archived.task);
        }
        return tasks;
    }

    private void submitFollowUp(Workflow.Run previous, String clarification, String source, boolean scoped) {
        final Workflow.Run versionToSave = run;
        final long owner = activeTaskId;
        String prompt;
        final boolean question = !scoped && TaskHistory.readOnlyQuestion(clarification);
        final boolean independent = !scoped && !question && TaskHistory.startsIndependentTask(previous.task, clarification);
        final AttachmentStore.Prepared materials;
        try {
            // Decide from the current delivery, not the persisted Python link alone.
            Workflow.Run contextBase = developmentBase(previous, "");
            String baseAnswer = contextBase.complete() ? contextBase.displayAnswer(contextBase.finalIndex()) : source;
            materials = prepareMessage(clarification, !independent
                    && TaskHistory.includeLinkedPythonForTurn(baseAnswer, clarification));
            prompt = question ? TaskHistory.questionPrompt(materials.getTask(), source,
                    questionHistory(owner, versionToSave))
                    : independent ? materials.getTask() : TaskHistory.followUp(PythonInputs.withoutMaterials(
                    ChatProjectContext.withoutInlineProject(TaskHistory.forRepair(previous.task))),
                    source, materials.getTask());
        } catch (AttachmentProblem e) {
            toast(AttachmentMessages.format(this, e.code, e.detail)); return;
        } catch (IllegalArgumentException e) {
            if (!question && !scoped && source.length() > 6000) {
                saveSourcePlan(clarification, PythonInputs.singleSourceOrAnswer(source));
                nexusRender(null);
                nexusOpenSourcePlan();
            } else toast(e.getMessage());
            return;
        }
        Workflow.Run next = (selectedMode == Workflow.Mode.QUICK
                ? Workflow.Run.quick(prompt, quickModel(), stages.get(Workflow.Step.REVIEW.ordinal())).withMaterials(materials.getRefs())
                : new Workflow.Run(prompt, stages).withMaterials(materials.getRefs()))
                .withUserTestTask(independent || question ? materials.getTask() :
                        ChatProjectContext.withoutInlineProject(previous.userTestTask())
                        + "\n\n" + ChatProjectContext.withoutInlineProject(materials.getTask()));
        if (modelsFor(next).models.isEmpty()) {
            toast(getString(R.string.error_no_models));
            return;
        }
        persistBeforeSwitch(() -> {
            if (activeTaskId != owner || run != versionToSave) return;
            try {
                if (!repository.preserveVersion(owner, versionToSave.toJson().toString())) {
                    toast(getString(R.string.error_save_version));
                    return;
                }
            } catch (JSONException | RuntimeException e) {
                toast(getString(R.string.error_save_version));
                return;
            }
            if (independent && !switchIndependentProject(clarification)) return;
            workExpanded = false;
            if (!scoped) {
                nexusBuffer("plan_visible", "");
                if (!independent && !question && source.length() > 6000) saveSourcePlan(clarification, PythonInputs.singleSourceOrAnswer(source));
                else nexusBuffer("source_plan", "");
            }
            begin(next.withFallbackPolicy(nexusAllowFallback()));
        });
    }

    private static boolean isUserDarkTheme(Configuration configuration, String preference) {
        if ("dark".equals(preference)) return true;
        if ("light".equals(preference)) return false;
        return (configuration.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }
    /** Keep Android 12+ native splash colors aligned with the user's app theme. */
    private void syncPlatformSplashTheme(String preference) {
        if (Build.VERSION.SDK_INT < 31) return;
        UiModeManager manager = getSystemService(UiModeManager.class);
        if (manager == null) return;
        final int mode;
        if ("dark".equals(preference)) mode = UiModeManager.MODE_NIGHT_YES;
        else if ("light".equals(preference)) mode = UiModeManager.MODE_NIGHT_NO;
        else {
            // For application-local mode, AUTO clears a package-specific night
            // override and restores the normal system-selected day/night mode.
            mode = UiModeManager.MODE_NIGHT_AUTO;
        }
        // Avoid repeated configuration changes when Android recreates Activity.
        if (data.getInt("splash_platform_night_mode", -1) == mode) return;
        if (!data.edit().putInt("splash_platform_night_mode", mode).commit()) return;
        try {
            manager.setApplicationNightMode(mode);
        } catch (RuntimeException ignored) {
            data.edit().remove("splash_platform_night_mode").apply();
            // A vendor ROM may reject this per-app API; Compose still applies
            // the saved preference and the UI remains usable.
        }
    }

    public String nexusThemeChoice() { return data.getString("ui_theme", "system"); }
    public String nexusLanguageChoice() { return data.getString("ui_language", "system"); }
    // User multiplier on top of the Android accessibility font scale (100% = unchanged).
    public int nexusTextScalePercent() {
        int stored = data.getInt("ui_text_scale_percent", 100);
        return stored >= 80 && stored <= 150 && stored % 10 == 0 ? stored : 100;
    }
    public void nexusTextScaleChanged(int percent) {
        if (percent < 80 || percent > 150 || percent % 10 != 0) return;
        if (percent == nexusTextScalePercent()) return;
        data.edit().putInt("ui_text_scale_percent", percent).apply();
        if (nexusUi != null) nexusUi.onTextScaleChanged(percent);
    }
    public void nexusThemeChanged(String theme) {
        if (!theme.equals("light") && !theme.equals("dark") && !theme.equals("system")) return;
        data.edit().putString("ui_theme", theme).apply();
        if (nexusUi != null) nexusUi.onThemeChanged(theme);
        // UI changes are Compose-only. Calling UiModeManager.setApplicationNightMode()
        // here can recreate Activity, blank the screen and interrupt the workspace.
        // The native splash preference is synchronized only on a later cold launch.
    }
    public void nexusLanguageChanged(String language) {
        if (active || clearing) { toast(getString(R.string.error_change_language_active)); return; }
        if (!language.equals("system") && !language.equals("ru") && !language.equals("en")
                && !language.equals("zh-CN") && !language.equals("ar") && !language.equals("ja")) return;
        if (language.equals(nexusLanguageChoice())) return;
        if (data.edit().putString("ui_language", language).commit()) recreate();
    }

    @Override protected void attachBaseContext(Context base) {
        SharedPreferences preferences = base.getSharedPreferences("workspace", Context.MODE_PRIVATE);
        String language = preferences.getString("ui_language", "system");
        String appearance = preferences.getString("ui_theme", "system");
        boolean customLanguage = language != null && !"system".equals(language);
        boolean customTheme = "light".equals(appearance) || "dark".equals(appearance);
        if (!customLanguage && !customTheme) { super.attachBaseContext(base); return; }
        Configuration configuration = new Configuration(base.getResources().getConfiguration());
        if (customLanguage) {
            Locale locale = Locale.forLanguageTag(language);
            configuration.setLocale(locale);
            configuration.setLayoutDirection(locale);
        }
        if (customTheme) {
            configuration.uiMode = (configuration.uiMode & ~Configuration.UI_MODE_NIGHT_MASK)
                    | ("dark".equals(appearance)
                    ? Configuration.UI_MODE_NIGHT_YES : Configuration.UI_MODE_NIGHT_NO);
        }
        super.attachBaseContext(base.createConfigurationContext(configuration));
    }

    private TextView consoleText(String value, int color) {
        TextView output = selectable(value, 14, color);
        output.setTypeface(Typeface.MONOSPACE);
        return output;
    }

    private void cancelSandbox() {
        SandboxJob job = sandboxJob;
        if (job == null) return;
        sandboxJob = null;
        if (job.local != null) job.local.cancel();
        if (job.future != null) {
            job.future.cancel(true);
            new Thread(job.cancellation::cancel, "cancel-sandbox").start();
        }
        if (job.progress != null) job.progress.dismiss();
        if (nexusUi != null) nexusUi.pythonCancelled();
    }

    private String preview(String text) {
        if (text.length() <= ANSWER_PREVIEW) return text;
        int end = Character.isLowSurrogate(text.charAt(ANSWER_PREVIEW))
                ? ANSWER_PREVIEW - 1 : ANSWER_PREVIEW;
        return text.substring(0, end) + "…";
    }

    private void showText(String title, String value) {
        LinearLayout form = dialogForm();
        TextView answer = selectable(value, 15, FG);
        answer.setLineSpacing(dp(4), 1f);
        add(form, answer, 0);
        ScrollView area = new ScrollView(this);
        area.addView(form);
        new AlertDialog.Builder(this).setTitle(title).setView(area)
                .setPositiveButton(R.string.action_close, null).show();
    }

    private AttachmentStore.Prepared prepareMessage(String task) throws AttachmentProblem {
        return prepareMessage(task, true);
    }

    private AttachmentStore.Prepared prepareMessage(String task, boolean includeLinkedProject) throws AttachmentProblem {
        AttachmentStore.Prepared materials = AttachmentStore.get(this).prepare(activeTaskId, task,
                run == null ? java.util.Collections.emptyList() : run.materials);
        // A linked project must be available to the AI, not just recorded in SQLite.
        // Only text files are included, with a strict request budget; project files stay local.
        long linked = includeLinkedProject && TaskHistory.includeLinkedPythonForTurn("", task)
                ? artifactRepository.forChat(activeTaskId) : 0;
        if (linked > 0) {
            try {
                String prepared = ChatProjectContext.append(materials.getTask(),
                        pythonProjects().snapshotForChat(linked), InputMaterial.MAX_REQUEST_TEXT_BYTES);
                materials = new AttachmentStore.Prepared(prepared, materials.getRefs());
            } catch (IOException problem) {
                throw new AttachmentProblem(AttachmentProblem.Code.IO, "Файлы подключённого проекта");
            } catch (IllegalArgumentException problem) {
                throw new AttachmentProblem(AttachmentProblem.Code.REQUEST_TEXT_SIZE,
                        "Файлы подключённого проекта");
            }
        }
        boolean hasImages = false;
        for (InputMaterial.Ref ref : materials.getRefs()) if (ref.isImage()) hasImages = true;
        if (hasImages) {
            List<ModelCatalog.Model> selected = new ArrayList<>();
            if (selectedMode == Workflow.Mode.QUICK) selected.add(quickModel());
            else for (Workflow.Stage stage : stages) selected.add(stage.model);
            for (ModelCatalog.Model chosen : selected) {
                ModelCatalog.Model details = catalog.details(chosen);
                if (details.provider != Workflow.Provider.OPENROUTER || !details.imageInput)
                    throw new AttachmentProblem(AttachmentProblem.Code.MODEL_IMAGES, details.label);
            }
        }
        return materials;
    }

    private void startRun() {
        if (active || clearing) return;
        startRun(taskDraft.trim());
    }

    private void startRun(String task) { startRun(task, true); }

    private void startRun(String task, boolean includeLinkedProject) {
        startRun(task, includeLinkedProject, TaskHistory.readOnlyQuestion(task));
    }

    private void startRun(String task, boolean includeLinkedProject, boolean question) {
        if (!question && askPythonTarget(task, "", value -> startRun(value, includeLinkedProject))) return;
        if (task.isEmpty()) {
            toast(getString(R.string.error_empty_task));
            return;
        }
        if (task.length() > Workflow.TASK_LIMIT) {
            toast(getString(R.string.error_task_too_long));
            return;
        }
        final long owner = activeTaskId;
        final Workflow.Run previous = run;
        AttachmentStore.Prepared materials;
        try {
            materials = prepareMessage(task, includeLinkedProject);
            if (question && !includeLinkedProject && materials.getRefs().isEmpty()) {
                toast(getString(R.string.error_empty_task)); return;
            }
        } catch (AttachmentProblem e) {
            toast(AttachmentMessages.format(this, e.code, e.detail));
            return;
        }
        InputMethodManager keyboard = getSystemService(InputMethodManager.class);
        if (keyboard != null && getWindow().getDecorView().getWindowToken() != null)
            keyboard.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
        String prompt = materials.getTask();
        if (question) {
            try { prompt = TaskHistory.questionPrompt(prompt, "", includeLinkedProject
                    ? questionHistory(owner, previous) : java.util.Collections.emptyList()); }
            catch (IllegalArgumentException tooLong) { toast(getString(R.string.error_task_too_long)); return; }
        }
        Workflow.Run next = (selectedMode == Workflow.Mode.QUICK
                ? Workflow.Run.quick(prompt, quickModel(), stages.get(Workflow.Step.REVIEW.ordinal())).withMaterials(materials.getRefs())
                : new Workflow.Run(prompt, stages).withMaterials(materials.getRefs()));
        if (question) next = next.withUserTestTask(materials.getTask());
        final Workflow.Run preparedRun = next;
        if (activeTaskId != owner || run != previous) return;
        if (previous == null) {
            begin(preparedRun.withFallbackPolicy(nexusAllowFallback()));
        } else {
            // Starting again never silently overwrites a completed (or partial) run.
            persistBeforeSwitch(() -> {
                if (activeTaskId != owner || run != previous) return;
                try {
                    if (!repository.preserveVersion(owner, previous.toJson().toString())) {
                        toast("Не удалось сохранить предыдущий разбор.");
                        return;
                    }
                } catch (JSONException | RuntimeException e) {
                    toast("Не удалось сохранить предыдущую версию.");
                    return;
                }
                if (!question && !includeLinkedProject && !switchIndependentProject(task)) return;
                workExpanded = false;
                begin(preparedRun.withFallbackPolicy(nexusAllowFallback()));
            });
        }
    }

    private void resumeRun() {
        if (active || clearing || run == null || run.complete()) return;
        if ((run.nextStep() == Workflow.Step.REVIEW || TaskHistory.readOnlyTurn(run.task)) && !run.draft.text.isEmpty()
                && !run.nextStage().numberedParts) {
            String note=run.note;
            run=run.restartForRecovery().withNote(note);
        }
        begin(run);
    }

    private StagePool modelsFor(Workflow.Run input) {
        EnumMap<Workflow.Provider, String> keys = new EnumMap<>(Workflow.Provider.class);
        for (Workflow.Provider provider : Workflow.Provider.values()) keys.put(provider, readForEdit(provider));
        List<ModelCatalog.Model> models = ModelPool.candidates(catalog, input.nextStep(), input.nextStage().selected,
                !keys.get(Workflow.Provider.OPENROUTER).isEmpty(), !keys.get(Workflow.Provider.GROQ).isEmpty(),
                data.getBoolean(GROQ_RESERVE, false), !keys.get(Workflow.Provider.GEMINI).isEmpty());
        Workflow.Stage stage = input.nextStage();
        if (!stage.allowFallback) models.removeIf(item -> !item.id.equals(stage.selected.id));
        StagePool pool = new StagePool(models, keys);
        if (!catalog.available(stage.selected)) pool.failures.add(getString(R.string.route_missing));
        else if (keys.get(stage.selected.provider).isEmpty()) pool.failures.add(keyMessage(stage));
        return pool;
    }

    private String keyMessage(Workflow.Stage stage) {
        return "Для шага «" + stage.role + "» нужен ключ " + stage.selected.provider.label + ".";
    }

    private void begin(Workflow.Run input) { begin(input, false); }

    private void begin(Workflow.Run input, boolean automatic) {
        if (automatic && autonomySession != null) {
            String limit = autonomySession.limit(android.os.SystemClock.elapsedRealtime(), 0);
            if (!limit.isEmpty()) {
                stopAutoPythonRepair(run, limit);
                return;
            }
        }
        StagePool pool = modelsFor(input);
        if (pool.models.isEmpty()) {
            if (!catalog.available(input.nextStage().selected)) toast(getString(R.string.route_missing));
            else showKeys(keyMessage(input.nextStage()) + " Подключи доступную модель для этого шага.");
            return;
        }
        // Informed consent applies to all AI routes, including retries, resume and follow-ups.
        // No user content leaves the device before the first explicit confirmation.
        if (!data.getBoolean(PRIVACY_NOTICE_ACKNOWLEDGED, false)) {
            if (automatic) { stopAutoPythonRepair(run, getString(R.string.python_auto_repair_stopped)); return; }
            final long owner = activeTaskId;
            final long generation = verificationGeneration;
            final Workflow.Run origin = run;
            new AlertDialog.Builder(this)
                    .setTitle(R.string.privacy_first_title)
                    .setMessage(R.string.privacy_first_message)
                    .setPositiveButton(R.string.privacy_first_accept, (dialog, which) -> {
                        if (active || clearing || isFinishing() || isDestroyed()
                                || owner != activeTaskId || generation != verificationGeneration || origin != run) return;
                        if (data.edit().putBoolean(PRIVACY_NOTICE_ACKNOWLEDGED, true).commit()) {
                            begin(input);
                        } else {
                            toast(getString(R.string.privacy_notice_save_error));
                        }
                    })
                    .setNegativeButton(R.string.action_cancel, null)
                    .show();
            return;
        }
        try {
            AttachmentStore.get(this).retain(activeTaskId, input.materials);
        } catch (IOException e) {
            toast(AttachmentMessages.format(this, AttachmentProblem.Code.IO, ""));
            return;
        }
        if (input != run) {
            attemptHistory = "";
            // The next AI request must not inherit stdout or a success badge from
            // a previous request, including when the new code fails before staging.
            if (!TaskHistory.readOnlyTurn(input.task)) invalidatePythonReport(artifactRepository.forChat(activeTaskId));
        }
        if (input != run || blackBoxRunId.isEmpty()) {
            blackBoxRunId = ChatRunJournal.newId();
            blackBoxRunCompleted = false;
            blackBoxWriteWarningShown = false;
            blackBoxEvent(activeTaskId, blackBoxRunId, null, -1, "RUN_STARTED", "");
        }
        if (!automatic || autonomySession == null)
            autonomySession = new AutonomyQuotaGuard.Session(android.os.SystemClock.elapsedRealtime());
        stagePool = pool;
        if (!TaskHistory.readOnlyTurn(input.task) && input.nextIndex() == 0 && input.draft.text.isEmpty()) {
            String goals = TaskHistory.forRepair(input.task);
            String target = PythonInputs.target(goals);
            if (target.equals("android") || target.equals("desktop")) toast(getString(R.string.widget_external));
            else if (PythonInputs.defaultWidget(goals)) toast(getString(R.string.widget_format));
        }
        active = true;
        run = input.withNote("");
        resultsVisible = true;
        requestNextModel(false);
    }

    private void requestNextModel(boolean keepPosition) {
        if (autonomySession == null) autonomySession = new AutonomyQuotaGuard.Session(android.os.SystemClock.elapsedRealtime());
        String limit = autonomySession.limit(android.os.SystemClock.elapsedRealtime(), 0);
        if (!limit.isEmpty()) { pause(limit); return; }
        String missing = run.missingInput();
        if (!missing.isEmpty()) {
            pause(missing);
            return;
        }
        int next = availableCandidate();
        if (next < 0) {
            pause(exhaustedNote(""));
            return;
        }
        ModelCatalog.Model model = stagePool.models.get(next);
        try {
            Workflow.Run routed = run.withExecutor(model, "");
            long estimate = ModelClient.estimatedInput(routed);
            long reserved = estimate + ModelClient.requestedOutput(routed, model, estimate);
            String budgetStop = autonomySession.limit(android.os.SystemClock.elapsedRealtime(), reserved);
            if (!budgetStop.isEmpty()) { pause(budgetStop); return; }
            if (!autonomySession.reserve(android.os.SystemClock.elapsedRealtime(), reserved)) {
                pause("Исчерпан общий бюджет работы команды."); return;
            }
        } catch (JSONException invalid) { pause(getString(R.string.verify_protocol)); return; }
        if (run.verification.status == PythonVerification.Status.REPAIRING) {
            if (run.verification.requests >= PythonVerification.MAX_REQUESTS) {
                pause(getString(R.string.verify_budget));
                return;
            }
            run = run.withVerification(run.verification.dispatch());
        }
        stagePool.next = next + 1;
        stagePool.dispatched++;
        String key = stagePool.keys.get(model.provider);
        StagePool pool = stagePool;
        String reason = "";
        if (!model.id.equals(run.nextStage().selected.id)) {
            reason = pool.failures.isEmpty() ? getString(R.string.route_busy) : pool.failures.get(pool.failures.size()-1);
        }
        run = run.withExecutor(model, reason);
        Attempt current = new Attempt(run);
        current.journalTaskId = activeTaskId;
        current.journalRunId = blackBoxRunId;
        attempt = current;
        blackBoxEvent(current.journalTaskId, current.journalRunId, current.journalAttemptId,
                current.input.nextIndex(), "MODEL_ATTEMPT_STARTED", model.id);
        persistRun();
        renderRun(keepPosition);
        current.deadline = () -> {
            if (attempt != current || clearing) return;
            current.timedOut = true;
            // Invalidate the old HTTP call before beginning a fallback; its late
            // callback is ignored because receive() clears the current attempt.
            if (current.future != null) current.future.cancel(true);
            disconnect(current.cancellation);
            receive(current, ModelClient.Reply.error(current.received,
                    "Превышено время ожидания модели. Получено символов: " + current.received.length(), 408));
        };
        progressHandler.postDelayed(current.deadline, ModelClient.REQUEST_TIMEOUT_MS);
        try {
            current.future = worker.submit(() -> {
                ModelClient.Reply reply;
                try {
                    reply = client.complete(current.input, model, key, current.cancellation, text -> {
                        current.received = text;
                        runOnUiThread(() -> {
                            if (attempt != current || isDestroyed() || clearing) return;
                            if (text.length() > current.checkpointLength) {
                                current.checkpointLength = text.length();
                                long remaining = 4L * ModelClient.REQUEST_TIMEOUT_MS - (android.os.SystemClock.elapsedRealtime() - current.started);
                                progressHandler.removeCallbacks(current.deadline);
                                progressHandler.postDelayed(current.deadline, Math.max(0, Math.min(remaining, ModelClient.REQUEST_TIMEOUT_MS)));
                            }
                            scheduleCheckpoint();
                            if (nexusUi != null) nexusUi.onStreaming(text);
                            if (liveText != null) {
                                int start = Math.max(0, text.length() - 3500);
                                liveText.setText(text.substring(start));
                            }
                            if (liveStatus != null) liveStatus.setText("Получено " + text.length() + " символов");
                        });
                    }, AttachmentStore.get(this).images(activeTaskId, current.input.materials));
                } catch (AttachmentProblem e) {
                    reply = ModelClient.Reply.error("", AttachmentMessages.format(this, e.code, e.detail), 400);
                } catch (ModelClient.Problem e) {
                    reply = ModelClient.Reply.error("", e.getMessage(), e.failure);
                } catch (IOException e) {
                    reply = ModelClient.Reply.error("", "Нет ответа по сети. Проверь соединение.");
                } catch (JSONException e) {
                    reply = ModelClient.Reply.error("", "Не удалось прочитать ответ модели.");
                }
                ModelClient.Reply finished = verifyRouterFailure(reply, model, key, current, pool);
                runOnUiThread(() -> receive(current, finished));
            });
        } catch (RejectedExecutionException busy) {
            progressHandler.removeCallbacks(current.deadline);
            attempt = null;
            pause("Сетевые потоки заняты отменяемыми запросами. "
                    + "Подожди освобождения соединений и нажми «Продолжить разбор».");
        }
    }

    private void disconnect(ModelClient.Cancellation cancellation) {
        cancellation.signal();
        try {
            cancellationWorker.execute(cancellation::cancel);
        } catch (RejectedExecutionException closed) {
            // New connections are already blocked by signal().
        }
    }

    private ModelClient.Reply verifyRouterFailure(ModelClient.Reply reply, ModelCatalog.Model model,
                                                 String key, Attempt current, StagePool pool) {
        if (model.provider != Workflow.Provider.OPENROUTER
                || reply.failure.reason != RequestFailure.Reason.UNKNOWN) return reply;
        try {
            if (reply.status == 429 && !pool.quotaChecked) {
                pool.quotaChecked = true;
                if (client.routerDailyQuotaExhausted(key, current.cancellation)) {
                    return ModelClient.Reply.error(reply.text,
                            "По данным OpenRouter, дневная квота моделей :free исчерпана.",
                            reply.failure.dailyQuota(System.currentTimeMillis()));
                }
            }
            if (reply.status == 404 && !pool.catalogChecked) {
                pool.catalogChecked = true;
                ModelCatalog updated = client.models(current.cancellation);
                if (updated.routerCount() > 0 && !updated.available(model)) {
                    return ModelClient.Reply.error(reply.text, "Этой модели больше нет в бесплатном каталоге.",
                            reply.failure.unavailable());
                }
            }
        } catch (IOException | JSONException | ModelClient.Problem ignored) {
            // Keep the actual provider error when the diagnostic query fails.
        }
        return reply;
    }

    private void receive(Attempt current, ModelClient.Reply reply) {
        if (attempt != current || isDestroyed()) return;
        progressHandler.removeCallbacks(current.deadline);
        attempt = null;
        String lastText = current.received.isEmpty() ? reply.text : current.received;
        blackBoxCheckpoint(current, lastText);
        blackBoxEvent(current.journalTaskId, current.journalRunId, current.journalAttemptId,
                current.input.nextIndex(), reply.finish == ModelClient.Finish.ERROR
                        ? "MODEL_ATTEMPT_FAILED" : "MODEL_ATTEMPT_COMPLETED", "");
        if (reply.finish == ModelClient.Finish.ERROR && reply.text.isEmpty() && !current.received.isEmpty()) {
            reply = ModelClient.Reply.error(current.received, reply.problem, reply.failure);
        }
        if (reply.failure.reason == RequestFailure.Reason.RESPONSE_LIMIT)
            reply = ModelClient.Reply.error(reply.text, getString(R.string.provider_response_limit), reply.failure);
        run = current.input.receive(reply);
        if (ModelPool.shouldTryNext(reply)) {
            ModelCatalog.Model attempted = current.input.nextStage().model;
            long now = System.currentTimeMillis();
            cooldowns.record(attempted, reply.failure, now);
            data.edit().putString("route_retry_times",cooldowns.snapshot(now)).apply();
            if (reply.failure.reason == RequestFailure.Reason.TOKEN_RATE_LIMIT || reply.failure.reason == RequestFailure.Reason.DAILY_QUOTA)
                stagePool.blockedProviders.add(attempted.provider);
            stagePool.failures.add(attempted.label + " · " + (current.timedOut ? getString(R.string.local_timeout) : reply.status == 0 ? getString(R.string.transport_error)
                    : "HTTP " + reply.status + " · " + reply.failure.reason.name()));
            // A new model is never asked to append to unverified code or review.
            if (!run.complete() && !run.nextStage().numberedParts && run.draft.intactParts())
                run = run.restartForRecovery();
            int next = availableCandidate();
            boolean retry = next >= 0 && !(run.verification.status == PythonVerification.Status.REPAIRING
                    && run.verification.requests >= PythonVerification.MAX_REQUESTS);
            recordAttempt(current, reply, retry ? stagePool.models.get(next) : null,
                    current.timedOut ? "TIMEOUT" : "");
            if (retry) {
                requestNextModel(true);
                return;
            }
            pause(next >= 0 ? getString(R.string.verify_budget) + "\n" + reply.problem : exhaustedNote(reply.problem));
            return;
        }
        if (!run.complete() && !run.note.isEmpty()
                && (reply.finish == ModelClient.Finish.LENGTH || reply.finish == ModelClient.Finish.STOP)
                && recoverIncompleteStage(current, reply)) return;
        recordAttempt(current, reply, null, current.timedOut ? "TIMEOUT" : "");
        if (!run.complete() && run.note.isEmpty() && run.nextStep() == Workflow.Step.REVIEW
                && (startWebCheck(current.input.nextIndex()) || startPythonPreReview(current.input.nextIndex()))) return;
        if (!run.complete() && run.note.isEmpty()) {
            stagePool = modelsFor(run);
            if (!stagePool.models.isEmpty()) requestNextModel(true);
            else pause(keyMessage(run.nextStage()));
            return;
        }
        if (!run.complete() && run.verification.status == PythonVerification.Status.REPAIRING) {
            pause(run.note);
            return;
        }
        if (run.complete()) {
            int resultStep = run.finalIndex();
            // Never execute the review text as the final source when revision was skipped.
            if (run.answerAt(resultStep).webCheck == null && startWebCheck(resultStep)) return;
            if ((PythonInputs.webSource(run.displayAnswer(resultStep), "html").isEmpty()
                    && PythonInputs.webProjectFiles(run.displayAnswer(resultStep)).isEmpty())
                    || PythonInputs.asksPythonPort(TaskHistory.currentUserTestRequest(run.task))) {
                if (startVerification(resultStep)) return;
            }
        }
        finishRunUi();
    }

    /** Retry only the current unfinished role; previous accepted stages are immutable.
     * Existing numbered parts retain their manual, checksum-verified continuation contract. */
    private boolean recoverIncompleteStage(Attempt current, ModelClient.Reply reply) {
        if (stagePool == null || run.nextIndex() != current.input.nextIndex()
                || run.nextStage().numberedParts || !run.draft.intactParts()) return false;
        if (run.verification.status == PythonVerification.Status.REPAIRING
                && run.verification.requests >= PythonVerification.MAX_REQUESTS) return false;
        String fingerprint = InputMaterial.sha256((reply.finish.name() + "\n" + reply.text)
                .getBytes(StandardCharsets.UTF_8));
        AutonomyQuotaGuard.Recovery.Action decision = stagePool.recovery.next(current.input.nextStage().model.id, fingerprint);
        String originalNote = run.note;
        if (decision == AutonomyQuotaGuard.Recovery.Action.STOP) {
            recordAttempt(current, reply, null, "INCOMPLETE");
            pause("Повторяется тот же неполный ответ. Работа остановлена.\n" + originalNote);
            return true;
        }
        stagePool.failures.add(originalNote);
        if (decision == AutonomyQuotaGuard.Recovery.Action.RETRY) stagePool.next = Math.max(0, stagePool.next - 1);
        int next = availableCandidate();
        if (next >= 0) run = run.recoverForModel(reply.finish, stagePool.models.get(next).id);
        recordAttempt(current, reply, next >= 0 ? stagePool.models.get(next) : null, "INCOMPLETE");
        if (next < 0) pause(exhaustedNote(originalNote));
        else requestNextModel(true);
        return true;
    }

    private boolean linkedSuiteProtected(Workflow.Run owner) {
        boolean savedTests = false;
        if (ChatProjectContext.hasInlineProject(owner.task)) {
            try {
                long linked = artifactRepository.forChat(activeTaskId);
                if (linked > 0) for (String path : pythonProjects().paths(linked))
                    if (PythonAutoStage.unittestPath(path)) { savedTests = true; break; }
            } catch (IOException | RuntimeException ignored) { /* Captured context remains the fallback. */ }
        }
        return PythonAutoStage.linkedSuiteProtected(owner.task, savedTests);
    }

    private boolean linkedSuiteRequired(Workflow.Run owner, int index) {
        return linkedSuiteProtected(owner) && PythonAutoStage.linkedSuiteRequired(owner.task,
                TaskHistory.projectExecutionRequest(owner.task), owner.displayAnswer(index), true);
    }

    private PythonAutoStage.LinkedCandidate linkedCandidate(Workflow.Run owner, int index) {
        try {
            long linked = artifactRepository.forChat(activeTaskId);
            if (linked > 0) return PythonAutoStage.linkedCandidate(owner.task,
                    TaskHistory.projectExecutionRequest(owner.task), owner.displayAnswer(index),
                    pythonProjects().snapshotForChat(linked));
        } catch (IOException | RuntimeException invalid) { /* Preserve the saved workspace. */ }
        return PythonAutoStage.LinkedCandidate.rejected("Active saved project unavailable");
    }

    private java.util.Map<String,String> linkedSuiteProject(Workflow.Run owner, int index) {
        return linkedCandidate(owner, index).files;
    }

    private JSONObject linkedSuiteSyntaxRequest(java.util.Map<String,String> files) throws JSONException {
        JSONObject sources = new JSONObject();
        for (java.util.Map.Entry<String,String> file : files.entrySet())
            if (file.getKey().endsWith(".py")) sources.put(file.getKey(), file.getValue());
        JSONObject protectedTests = new JSONObject();
        try {
            for (java.util.Map.Entry<String,byte[]> saved : pythonProjects().snapshotForChat(artifactRepository.forChat(activeTaskId)).entrySet()) {
                if (!PythonAutoStage.unittestPath(saved.getKey())) continue;
                String original = new String(saved.getValue(), StandardCharsets.UTF_8);
                if (!original.equals(files.get(saved.getKey()))) protectedTests.put(saved.getKey(), original);
            }
        } catch (IOException e) { throw new JSONException("Cannot read original project tests"); }
        return new JSONObject().put("mode", "verify").put("code", "").put("reason", "")
                .put("project_sources", sources).put("protected_tests", protectedTests);
    }

    private JSONObject linkedSuiteLimited() throws JSONException {
        return new JSONObject().put("status", "LIMITED").put("syntax", false).put("ran", false)
                .put("passed", 0).put("total", 0).put("signature", "").put("diagnostic", getString(R.string.python_linked_suite_unconfirmed));
    }

    private JSONObject linkedDeliveryLimited(boolean missing) throws JSONException {
        JSONObject report = linkedSuiteLimited().put("language", "python")
                .put("candidate_delivery", missing ? "NOT_DELIVERED" : "REJECTED")
                .put("category", missing ? "CANDIDATE_NOT_DELIVERED" : "CANDIDATE_REJECTED");
        report.put("diagnostic", getString(missing ? R.string.python_linked_candidate_missing
                : R.string.python_linked_candidate_rejected));
        return report;
    }

    private boolean linkedSuitePassed(Workflow.Run owner, int index, PythonVerification verification) {
        if (verification.generatedSuitePassed() <= 0 || checkedProjectOutput == null
                || checkedProjectTask != activeTaskId || !owner.task.equals(checkedProjectRequest)
                || !PythonInputs.projectFingerprint(owner.displayAnswer(index), PythonInputs.candidate(owner.displayAnswer(index))).equals(checkedProjectIdentity)) return false;
        java.util.Map<String,String> project = linkedSuiteProject(owner, index);
        if (project.isEmpty()) return false;
        java.util.Map<String,byte[]> bytes = new java.util.LinkedHashMap<>();
        for (java.util.Map.Entry<String,String> file : project.entrySet()) bytes.put(file.getKey(), file.getValue().getBytes(StandardCharsets.UTF_8));
        return checkedProjectOutput.snapshotSha256.equals(PythonProjectStore.snapshotSha256(bytes));
    }

    private static boolean completeSuite(JSONObject suite) {
        if (suite == null || !"PASSED".equals(suite.optString("status"))) return false;
        int size = suite.optInt("discovered", -1);
        return size > 0 && size <= 24 && suite.optInt("ran", -1) == size && suite.optInt("passed", -1) == size
                && suite.optInt("failed", -1) == 0 && suite.optInt("skipped", -1) == 0;
    }

    private void completeProjectCheck(Workflow.Run owner, int index, JSONObject syntax,
                                      java.util.function.BooleanSupplier current, Consumer<JSONObject> finish) {
        if (!current.getAsBoolean()) return;
        String answer = owner.displayAnswer(index);
        java.util.Map<String,String> project = PythonInputs.multiPythonProject(answer);
        String user = TaskHistory.projectExecutionRequest(owner.task);
        final boolean linkedSuite = linkedSuiteRequired(owner, index);
        if (linkedSuite) project = linkedSuiteProject(owner, index);
        boolean single = !linkedSuite && project.isEmpty() && syntax.optBoolean("workspace_eligible");
        PythonInputs.Candidate candidate = PythonInputs.candidate(answer);
        if (single && candidate != null && !candidate.ambiguous && candidate.issue.isEmpty()
                && PythonAutoStage.singleSuiteRunAllowed(user, candidate.code))
            project = java.util.Collections.singletonMap("main.py", candidate.code);
        if (project.isEmpty() || !syntax.optBoolean("syntax") || "ERROR".equals(syntax.optString("status"))
                || !owner.answerAt(index).warnings.isEmpty()
                || (!single && !(linkedSuite ? PythonAutoStage.linkedProjectRunAllowed(user, project)
                        : PythonAutoStage.projectRunAllowed(user, project)))) {
            if (linkedSuite && !"ERROR".equals(syntax.optString("status"))) {
                try { finish.accept(linkedSuiteLimited()); }
                catch (JSONException invalid) { throw new IllegalStateException(invalid); }
            } else finish.accept(syntax);
            return;
        }
        final long taskId = activeTaskId;
        final String identity = PythonInputs.projectFingerprint(answer, PythonInputs.candidate(answer));
        Consumer<String> limited = reason -> {
            if (!current.getAsBoolean()) return;
            try { syntax.put("status", "LIMITED").put("diagnostic", reason); }
            catch (JSONException invalid) { throw new IllegalStateException(invalid); }
            finish.accept(syntax);
        };
        try {
            java.util.Map<String,byte[]> bytes = new java.util.LinkedHashMap<>();
            JSONObject snapshot = new JSONObject();
            for (java.util.Map.Entry<String,String> file : project.entrySet()) {
                byte[] body = file.getValue().getBytes(StandardCharsets.UTF_8);
                bytes.put(file.getKey(), body);
                snapshot.put(file.getKey(), Base64.encodeToString(body, Base64.NO_WRAP));
            }
            final String expected = PythonProjectStore.snapshotSha256(bytes);
            Consumer<SandboxClient.Result> received = result -> {
                if (!current.getAsBoolean()) return;
                if (!expected.equals(result.snapshotSha256) || result.exitCode == null && !result.inputRequired) {
                    limited.accept(result.status.isEmpty() ? getString(R.string.verify_protocol) : result.status);
                    return;
                }
                try {
                    JSONObject manifest = new JSONObject();
                    for (java.util.Map.Entry<String,byte[]> file : bytes.entrySet())
                        manifest.put(file.getKey(), InputMaterial.sha256(file.getValue()));
                    JSONObject evidence = new JSONObject().put("snapshot_sha256", result.snapshotSha256)
                            .put("input_required", result.inputRequired)
                            .put("original_suite", syntax.optJSONObject("original_suite"))
                            .put("original_suite_sha256", syntax.optString("original_suite_sha256"))
                            .put("project_file_sha256", manifest)
                            .put("exit_code", result.exitCode).put("status", result.status)
                            .put("generated_tests", result.generatedTests)
                            .put("stdout", result.stdout.substring(0, Math.min(2400, result.stdout.length())))
                            .put("stderr", result.stderr.substring(0, Math.min(2400, result.stderr.length())));
                    boolean ok = result.exitCode != null && result.exitCode == 0;
                    String failure = result.diagnostic();
                    if (!ok && !result.stdout.isEmpty()) failure += "\nstdout (tail):\n"
                            + result.stdout.substring(Math.max(0,result.stdout.length()-1800));
                    JSONObject suite = result.generatedTests;
                    JSONObject originalSuite = syntax.optJSONObject("original_suite");
                    boolean suitePassed = completeSuite(suite) && (originalSuite == null
                            || suite.optInt("ran") >= originalSuite.optInt("ran"));
                    boolean waiting = result.inputRequired && result.exitCode == null;
                    boolean unconfirmed = waiting || linkedSuite && ok && !suitePassed;
                    syntax.put("status", unconfirmed ? "LIMITED" : ok ? "RAN" : "ERROR").put("ran", true)
                            .put("passed", 0).put("total", 0).put("project_execution", evidence)
                            .put("category", waiting ? "INPUT_REQUIRED" : unconfirmed ? "TESTS_UNCONFIRMED" : suitePassed && ok ? "EXECUTED_SELF_TESTS" : ok ? "EXECUTED_NO_TESTS" : "RUNTIME_ERROR")
                            .put("diagnostic", waiting ? result.status : unconfirmed ? getString(R.string.python_linked_suite_unconfirmed) : ok ? result.status : failure.substring(Math.max(0, failure.length()-2400)))
                            .put("signature", ok || waiting ? "" : "project-execution/" + PythonAutoRepair.errorSignature(failure));
                    checkedProjectOutput = result;
                    checkedProjectTask = taskId;
                    checkedProjectIdentity = identity;
                    checkedProjectRequest = owner.task;
                } catch (JSONException invalid) {
                    limited.accept(getString(R.string.verify_protocol)); return;
                }
                finish.accept(syntax);
            };
            // No external packages, network permission, Android files, or linked user data.
            // This disposable worker receives only the delivered project and the explicit test request.
            String entry = single ? "main.py" : PythonAutoStage.projectEntry(project);
            String entryCode = project.get(entry);
            Runnable candidateSuite = () -> {
                if (!current.getAsBoolean()) return;
                automaticPython = new LocalSandbox(received, limited);
                automaticPython.executeProject(this, entryCode, "", snapshot, entry, "", false, true);
            };
            java.util.Map<String,byte[]> baseline = new java.util.LinkedHashMap<>(bytes);
            boolean differentTests = false;
            if (linkedSuite) {
                for (java.util.Map.Entry<String,byte[]> old : pythonProjects().snapshotForChat(
                        artifactRepository.forChat(activeTaskId)).entrySet()) {
                    if (PythonAutoStage.unittestPath(old.getKey()) && !java.util.Arrays.equals(old.getValue(), bytes.get(old.getKey()))) {
                        baseline.put(old.getKey(), old.getValue());
                        differentTests = true;
                    }
                }
            }
            if (!differentTests) { candidateSuite.run(); return; }
            JSONObject baseFiles = new JSONObject();
            for (java.util.Map.Entry<String,byte[]> file : baseline.entrySet())
                baseFiles.put(file.getKey(), Base64.encodeToString(file.getValue(), Base64.NO_WRAP));
            String originalSuiteHash = PythonProjectStore.snapshotSha256(baseline);
            automaticPython = new LocalSandbox(result -> {
                if (!current.getAsBoolean()) return;
                try {
                    if (!originalSuiteHash.equals(result.snapshotSha256) || result.exitCode == null) {
                        limited.accept(getString(R.string.python_linked_suite_unconfirmed)); return;
                    }
                    syntax.put("original_suite_sha256", originalSuiteHash).put("original_suite", result.generatedTests);
                    if (result.exitCode == 0 && !completeSuite(result.generatedTests)) {
                        syntax.put("ran", true).put("category", "TESTS_UNCONFIRMED");
                        limited.accept(getString(R.string.python_linked_suite_unconfirmed)); return;
                    }
                    if (result.exitCode != 0) {
                        String reason = (result.stderr + "\n" + result.status).trim();
                        syntax.put("status", "ERROR").put("category", "ORIGINAL_SUITE_FAILED").put("ran", true)
                                .put("diagnostic", reason.isEmpty() ? getString(R.string.python_linked_suite_unconfirmed) : reason)
                                .put("signature","original-tests/" + originalSuiteHash);
                        finish.accept(syntax); return;
                    }
                    candidateSuite.run();
                } catch (JSONException error) { limited.accept(getString(R.string.verify_protocol)); }
            }, limited);
            automaticPython.executeProject(this, entryCode, "", baseFiles, entry, "", false, true);
        } catch (IOException | JSONException | RuntimeException invalid) { limited.accept(getString(R.string.verify_protocol)); }
    }

    private boolean startPythonPreReview(int index) {
        Workflow.Run owner = run;
        if (TaskHistory.readOnlyTurn(owner.task)) return false;
        PythonInputs.Candidate file = PythonInputs.candidate(owner.displayAnswer(index));
        if (file == null) {
            if (linkedSuiteRequired(owner, index)) {
                try { run = owner.withWebCheck(index, linkedDeliveryLimited(true)); }
                catch (JSONException malformed) { run = owner; }
            }
            return false;
        }
        final long taskId=activeTaskId;
        Consumer<JSONObject> finish = report -> {
            if (run!=owner || !active || clearing || isDestroyed() || activeTaskId!=taskId) return;
            automaticPython=null;
            try {
                String identity = PythonInputs.multiPythonProject(owner.displayAnswer(index)).isEmpty()
                        ? file.code : PythonInputs.projectFingerprint(owner.displayAnswer(index), file);
                report.put("language","python").put("sha256", InputMaterial.sha256(identity.getBytes(StandardCharsets.UTF_8)));
                run=owner.withWebCheck(index,report);
            } catch (JSONException malformed) { run=owner; }
            continueAfterCheck();
        };
        Consumer<String> limited = reason -> {
            try { finish.accept(new JSONObject().put("status","LIMITED").put("diagnostic",reason)); }
            catch (JSONException invalid) { throw new IllegalStateException(invalid); }
        };
        try {
            boolean multi = !PythonInputs.multiPythonProject(owner.displayAnswer(index)).isEmpty();
            boolean linkedSuite = linkedSuiteRequired(owner, index);
            PythonAutoStage.LinkedCandidate delivery = linkedSuite ? linkedCandidate(owner, index) : null;
            java.util.Map<String,String> merged = delivery == null ? java.util.Collections.emptyMap() : delivery.files;
            if (linkedSuiteProtected(owner) && (!linkedSuite || merged.isEmpty())) {
                finish.accept(delivery != null ? linkedDeliveryLimited(false).put("delivery_detail", delivery.reason) : linkedSuiteLimited()); return true;
            }
            JSONObject request=linkedSuite ? linkedSuiteSyntaxRequest(merged) : multi ? PythonInputs.projectSyntaxRequest(owner.displayAnswer(index), file)
                    : PythonInputs.request(owner,file.code);
            if (!multi && (file.ambiguous || !file.issue.isEmpty() || InputMaterial.utf8(file.code)>64_000)) {
                limited.accept(file.issue.isEmpty() ? getString(R.string.verify_source_limit) : file.issue);
            } else {
                persistRun();
                automaticPython = new LocalSandbox(null, limited::accept);
                automaticPython.verify(this,request,progress -> {},report -> {
                    if (linkedSuite || multi || report.optBoolean("workspace_eligible")) completeProjectCheck(owner, index, report,
                            () -> run == owner && active && !clearing && !isDestroyed() && activeTaskId == taskId, finish);
                    else finish.accept(report);
                });
            }
        } catch (JSONException | RuntimeException unavailable) { limited.accept(getString(R.string.verify_protocol)); }
        return true;
    }

    private void continueAfterCheck() {
        if (run.complete()) finishRunUi();
        else {
            persistRun();
            stagePool=modelsFor(run);
            if (stagePool.models.isEmpty()) pause(keyMessage(run.nextStage()));
            else requestNextModel(true);
        }
    }

    private android.webkit.WebView checkingWeb;
    private Runnable webDeadline;

    private boolean startWebCheck(int index) {
        Workflow.Run owner = run;
        if (TaskHistory.readOnlyTurn(owner.task)) return false;
        String answer = owner.displayAnswer(index);
        String html = PythonInputs.webSource(answer, "html");
        java.util.Map<String,String> webFiles = PythonInputs.webProjectFiles(answer);
        boolean project = !webFiles.isEmpty();
        String kind = project ? "web-project" : html.isEmpty() ? "javascript" : "html";
        String source = project ? new JSONObject(webFiles).toString()
                : html.isEmpty() ? PythonInputs.webSource(answer, kind) : html;
        String goals = TaskHistory.forRepair(owner.task);
        boolean missingHtml = source.isEmpty() && PythonInputs.defaultWidget(goals) && !PythonInputs.hasNamedFiles(answer);
        if (source.isEmpty() && !missingHtml) return false;
        if (PythonInputs.asksPythonPort(TaskHistory.currentUserTestRequest(owner.task))
                && PythonInputs.candidate(answer)!=null) return false;
        JSONArray required = PythonInputs.requiredFeatures(goals);
        if (goals.toLowerCase(java.util.Locale.ROOT).matches("(?s).*(calculator|\u043a\u0430\u043b\u044c\u043a\u0443\u043b\u044f\u0442\u043e\u0440).*")) required.put("calculator");
        String currentRequest = TaskHistory.currentUserTestRequest(owner.task);
        PythonInputs.addWebCases(required, currentRequest);
        boolean allowWebRun = PythonAutoStage.runAllowed(currentRequest);
        persistRun();
        final long taskId = activeTaskId;
        Consumer<JSONObject> finish = result -> {
            if (run != owner || activeTaskId != taskId || isDestroyed() || clearing) return;
            releaseWebCheck();
            try {
                JSONObject check = result == null ? new JSONObject().put("status","UNAVAILABLE") : result;
                if (result != null && !"UNAVAILABLE".equals(check.optString("status")))
                    check.put("status", result.getJSONArray("issues").length()==0 ? "SYNTAX_CHECKED" : "SYNTAX_ERROR");
                if (project) {
                    JSONObject manifest = new JSONObject();
                    for (java.util.Map.Entry<String,String> file : webFiles.entrySet())
                        manifest.put(file.getKey(), InputMaterial.sha256(file.getValue().getBytes(StandardCharsets.UTF_8)));
                    check.put("project_file_sha256", manifest).put("scope", "named_web_project").put("ran", false);
                }
                JSONArray tests = check.optJSONArray("tests");
                check.put("ran", false);
                if (tests != null) for (int i=0; i<tests.length(); i++) {
                    JSONObject probe = tests.optJSONObject(i);
                    if (probe != null && "page.startup".equals(probe.optString("id"))
                            && !"unverified".equals(probe.optString("status"))) check.put("ran", true);
                }
                boolean observed = false;
                if (tests != null) for (int i=0;i<tests.length();i++) {
                    JSONObject t=tests.optJSONObject(i);
                    if (t!=null && !"page.startup".equals(t.optString("id"))
                            && ("pass".equals(t.optString("status")) || "fail".equals(t.optString("status")))) observed=true;
                }
                check.put("language",missingHtml || project ? "html" : kind).put("functional_tests",observed)
                        .put("sha256", InputMaterial.sha256(source.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
                run = owner.withWebCheck(index, check);
                if (run.complete() && allowWebRun && PythonAutoStage.repairAllowed(TaskHistory.currentUserTestRequest(owner.task))
                        && (kind.equals("html") || project) && Workflow.Run.failedWeb(check)
                        && run.repairs.stream().noneMatch(r -> r.language.equals("html"))) {
                    // The existing repair protocol also carries complete_project with exact paths.
                    String repairSource = project ? answer : source;
                    run=run.addRepair(new Workflow.RepairInput(index,repairSource,"",check.toString(),"html"));
                }
            } catch (JSONException ignored) { run = owner; }
            continueAfterCheck();
        };
        if (missingHtml) {
            try { finish.accept(new JSONObject().put("issues",new JSONArray().put(getString(R.string.widget_missing)))); }
            catch (JSONException unexpected) { finish.accept(null); }
            return true;
        }
        try {
            checkingWeb = app.svyazka.mobile.ui.WebWorkspaceKt.inspectWebFile(this,source,kind,allowWebRun ? required : null,
                    parsed -> progressHandler.post(() -> finish.accept(parsed)));
            checkingWeb.setFocusable(false);
            checkingWeb.setImportantForAccessibility(android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            android.widget.FrameLayout content=findViewById(android.R.id.content);
            content.addView(checkingWeb,0,new android.widget.FrameLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
            webDeadline = () -> finish.accept(null);
            progressHandler.postDelayed(webDeadline, 12_000);
        } catch (RuntimeException unavailable) { finish.accept(null); }
        return true;
    }

    private void releaseWebCheck() {
        if (webDeadline != null) progressHandler.removeCallbacks(webDeadline);
        webDeadline = null;
        android.webkit.WebView view = checkingWeb;
        checkingWeb = null;
        if (view != null) {
            if (view.getParent() instanceof android.view.ViewGroup)
                ((android.view.ViewGroup)view.getParent()).removeView(view);
            view.stopLoading();
            view.destroy();
        }
    }

    public String nexusWebStatus() {
        if (run == null || !run.complete()) return "";
        JSONObject check = run.answerAt(run.finalIndex()).webCheck;
        // Python pre-review evidence shares this field, but belongs only to Python status.
        if (check == null || "python".equals(check.optString("language"))) return "";
        if (!"SYNTAX_CHECKED".equals(check.optString("status"))) {
            JSONArray issues = check.optJSONArray("issues");
            return issues != null && issues.length()>0 ? issues.optString(0) : getString(R.string.web_check_error);
        }
        String status = getString(R.string.web_counts, check.optInt("checked"), check.optInt("external"));
        if ("named_web_project".equals(check.optString("scope"))) {
            JSONObject manifest = check.optJSONObject("project_file_sha256");
            if (manifest != null) status += "\n" + getString(R.string.web_project_files, manifest.length());
            if (!check.optBoolean("functional_tests")) status += "\n" + getString(R.string.web_project_static_only);
            if (check.has("preview_supported") && !check.optBoolean("preview_supported"))
                status += "\n" + getString(R.string.web_project_preview_limited);
        }
        JSONArray tests=check.optJSONArray("tests");
        if (tests!=null) for (int i=0;i<tests.length();i++) {
            JSONObject t=tests.optJSONObject(i);
            if (t==null) continue;
            String id=t.optString("id");
            String[] ids={"clock.tick","calendar.current","calendar.december","calendar.january","calendar.leap","weather.current","weather.leap","weather.offline","bluetooth.device","calendar.nextyear"};
            String[] names=getResources().getStringArray(R.array.widget_tests);
            int n=java.util.Arrays.asList(ids).indexOf(id);
            int outcome="pass".equals(t.optString("status")) ? R.string.widget_pass : "fail".equals(t.optString("status")) ? R.string.widget_fail : R.string.widget_unverified;
            JSONObject detail = t.optJSONObject("detail");
            String name = n < 0 ? id : names[n];
            if ("page.startup".equals(id)) name = getString(R.string.web_probe_startup);
            else if ("interaction.coverage".equals(id)) name = getString(R.string.web_probe_controls);
            else if (id.startsWith("scenario.")) name = getString(R.string.web_probe_case, id.substring("scenario.".length()));
            else if (id.startsWith("arithmetic.") && detail != null && detail.has("input"))
                name = detail.optString("input").replace("*", "×").replace("/", "÷");
            status += "\n" + name + " · " + getString(outcome);
            if (detail != null && detail.has("expected") && detail.has("actual"))
                status += " · " + getString(R.string.web_probe_result, detail.isNull("actual") ? "—" : detail.optString("actual"), detail.optString("expected"));
        }
        if (run.finalIndex()!=run.nextIndex()-1 && !run.revisionSkipped()) status+="\n"+getString(R.string.widget_prior);
        if (check.optBoolean("network")) status += "\n" + getString(R.string.web_offline);
        if (check.optBoolean("bluetooth")) status += "\n" + getString(R.string.web_ble);
        return status;
    }

    public ResultSeverity nexusWebSeverity() {
        if (run == null || !run.complete()) return ResultSeverity.NEUTRAL;
        JSONObject check = run.answerAt(run.finalIndex()).webCheck;
        if (check == null || "python".equals(check.optString("language"))) return ResultSeverity.NEUTRAL;
        JSONArray issues = check.optJSONArray("issues"), tests = check.optJSONArray("tests");
        boolean incomplete = check.optBoolean("tests_unavailable") || check.optInt("external") > 0
                || check.has("preview_supported") && !check.optBoolean("preview_supported")
                || check.optBoolean("network") || check.optBoolean("bluetooth")
                || run.finalIndex() != run.nextIndex()-1 && !run.revisionSkipped();
        boolean failed = false, tested = false;
        if (tests != null) for (int i = 0; i < tests.length(); i++) {
            JSONObject test = tests.optJSONObject(i);
            String status = test == null ? "" : test.optString("status");
            if ("fail".equals(status)) failed = true;
            else if ("pass".equals(status)) { if (!"page.startup".equals(test.optString("id"))) tested = true; }
            else incomplete = true;
        }
        return ResultSeverity.web(check.optString("status"), issues != null && issues.length() > 0,
                failed, incomplete, tested);
    }

    private void installCheckedProject(long linked, int step, java.util.Map<String,String> files) throws IOException {
        java.util.Map<String,byte[]> before = pythonProjects().snapshotForChat(linked);
        boolean wasBlank = before.size() == 1 && before.containsKey("main.py") && before.get("main.py").length == 0;
        if (!run.verification.syntax || !pythonProjects().installGeneratedProject(linked, files)) {
            toast(getString(R.string.python_auto_skipped)); return;
        }
        if (!artifactRepository.touch(linked, "main.py")) {
            if (wasBlank) pythonProjects().restorePrevious(linked);
            throw new IOException("Запись проекта недоступна.");
        }
        invalidatePythonReport(linked);
        if (activeArtifactId != linked) selectArtifact(linked);
        if (nexusUi != null) {
            nexusUi.pythonAppliedFromChat(step, "main.py", files.get("main.py"));
            nexusUi.projectChanged("");
        }
        showCheckedProjectOutput(linked, step);
    }

    private boolean showCheckedProjectOutput(long linked, int step) throws IOException {
        String identity = PythonInputs.projectFingerprint(run.displayAnswer(step), PythonInputs.candidate(run.displayAnswer(step)));
        SandboxClient.Result output = checkedProjectOutput;
        if (output == null || checkedProjectTask != activeTaskId || !run.task.equals(checkedProjectRequest) || !identity.equals(checkedProjectIdentity)
                || !output.snapshotSha256.equals(PythonProjectStore.snapshotSha256(pythonProjects().snapshotForChat(linked)))) return false;
        // The report belongs to the exact installed bytes, not to another version.
        synchronized (pythonReportLock) { new PythonLastRunStore(this, true).save(linked, output); }
        latestVisual = (!output.pngBase64.isEmpty() || !output.html.isEmpty()) ? output : null;
        if (nexusUi != null) {
            if (latestVisual != null) nexusUi.cacheVisual(latestVisual.pngBase64, latestVisual.html);
            nexusUi.onVisualAvailable(latestVisual != null);
            nexusUi.pythonFinished(new NexusPythonReport(output.engine, output.stdout, output.stderr,
                    output.status, "", output.exitCode, latestVisual != null,
                    output.artifacts.toString(), output.tests.toString(), output.snapshotSha256, output.inputRequired));
        }
        lastPythonDiagnostic = ""; // Never start a single-file repair on a project suite.
        return true;
    }

    /** Stage 2: save a single unambiguous edit with a backup, then prepare one
     * local execution using the saved project snapshot. No AI retries here.
     */
    private AutoPythonLaunch autoStageChatPython() {
        if (clearing || run == null || TaskHistory.readOnlyTurn(run.task) || !run.complete() || !run.note.isEmpty()
                || PythonAutoFeedback.isFeedback(run.task) && PythonAutoRepair.parse(run.task) == null
                || sandboxJob != null
                || run.verification.status == PythonVerification.Status.ERROR
                || run.verification.status == PythonVerification.Status.STOPPED
                || run.verification.busy()) return null;
        long linked = artifactRepository.forChat(activeTaskId);
        if (linked <= 0 || !artifactRepository.exists(linked)) return null;
        int step = run.finalIndex();
        if (!run.hasAnswer(step) || !run.answerAt(step).warnings.isEmpty()
                || !run.answerAt(step).intactParts()) return null;
        boolean linkedSuite = linkedSuiteRequired(run, step);
        if (linkedSuiteProtected(run) && !linkedSuite) {
            toast(getString(R.string.python_linked_suite_unconfirmed)); return null;
        }
        if (linkedSuite && !linkedSuitePassed(run, step, run.verification)) {
            toast(getString(R.string.python_linked_suite_unconfirmed)); return null;
        }
        if (!linkedSuite && !run.repairs.isEmpty() && run.verification.status != PythonVerification.Status.PASSED) {
            // Only a newly generated project with an actually passing, unchanged
            // generated suite may be installed; installGeneratedProject itself
            // refuses to overwrite any nonblank existing workspace.
            java.util.Map<String,String> current=PythonInputs.multiPythonProject(run.displayAnswer(step));
            java.util.Map<String,String> previous=PythonInputs.multiPythonProject(run.displayAnswer(run.repairs.get(run.repairs.size()-1).sourceIndex));
            if (current.isEmpty() || previous.isEmpty() || run.verification.generatedSuitePassed() <= 0
                    || !PythonInputs.sameProjectTests(previous,current)) return null;
        }
        PythonAutoRepair.State repair = PythonAutoRepair.parse(run.task);
        if (repair == null && !ChatProjectContext.hasInlineProject(run.task)) {
            try {
                java.util.Map<String,byte[]> blank = pythonProjects().snapshotForChat(linked);
                if (!PythonInputs.asksPythonPort(run.task) || blank.size() != 1
                        || !blank.containsKey("main.py") || blank.get("main.py").length != 0) return null;
            } catch (IOException | RuntimeException invalid) { return null; }
        }
        String userMessage = repair == null ? TaskHistory.projectExecutionRequest(run.task)
                : PythonInputs.withoutMaterials(ChatProjectContext.withoutInlineProject(TaskHistory.forRepair(run.task)));
        if (!PythonAutoStage.requested(userMessage)) return null;
        if ((!PythonInputs.webSource(run.displayAnswer(step), "html").isEmpty()
                || !PythonInputs.webProjectFiles(run.displayAnswer(step)).isEmpty())
                && !PythonInputs.asksPythonPort(userMessage)) return null;
        try {
            nexusPythonFlushPending();
            if (linkedSuite && !linkedSuitePassed(run, step, run.verification)) {
                toast(getString(R.string.python_linked_suite_unconfirmed)); return null;
            }
            java.util.Map<String,String> project = PythonInputs.multiPythonProject(run.displayAnswer(step));
            if (!linkedSuite && !project.isEmpty()) {
                if (repair == null && run.verification.status != PythonVerification.Status.ERROR)
                    installCheckedProject(linked, step, project);
                return null;
            }
            if (linkedSuite) {
                java.util.Map<String,byte[]> base = pythonProjects().snapshotForChat(linked);
                java.util.Map<String,String> approved = PythonAutoStage.linkedSuiteProject(run.task, userMessage,
                        run.displayAnswer(step), base);
                String entry = PythonAutoStage.projectEntry(approved);
                if (entry.isEmpty() || checkedProjectOutput == null || !pythonProjects().replaceCheckedProject(linked,
                        PythonProjectStore.snapshotSha256(base), approved, checkedProjectOutput.snapshotSha256)) {
                    toast(getString(R.string.python_linked_suite_unconfirmed)); return null;
                }
                if (!artifactRepository.touch(linked, entry)) {
                    pythonProjects().restorePrevious(linked);
                    throw new IOException("Запись проекта недоступна.");
                }
                invalidatePythonReport(linked);
                if (activeArtifactId != linked) selectArtifact(linked);
                if (nexusUi != null) {
                    nexusUi.pythonAppliedFromChat(step, entry, approved.get(entry));
                    nexusUi.projectChanged("");
                }
                showCheckedProjectOutput(linked, step);
                return null;
            }
            String[] paths = pythonProjects().paths(linked);
            PythonAutoStage.Selection selected = PythonAutoStage.select(userMessage, run.displayAnswer(step), paths);
            if (selected == null && repair == null && run.verification.syntax && paths.length == 1 && "main.py".equals(paths[0])
                    && pythonProjects().text(linked, "main.py").isEmpty()) {
                PythonInputs.Candidate singleFile = PythonInputs.candidate(run.displayAnswer(step));
                if (singleFile != null && !singleFile.ambiguous && singleFile.issue.isEmpty()
                        && !singleFile.code.trim().isEmpty() && InputMaterial.utf8(singleFile.code) <= 64_000
                        && PythonInputs.hasPythonDelivery(run.displayAnswer(step)))
                    selected = new PythonAutoStage.Selection("main.py", singleFile.code);
            }
            if (selected == null) {
                if (repair != null) stopAutoPythonRepair(run, getString(R.string.python_auto_repair_stopped));
                else toast(getString(R.string.python_auto_skipped));
                return null;
            }
            String previousCode = pythonProjects().text(linked, selected.path);
            if (run.verification.status == PythonVerification.Status.LIMITED && !previousCode.trim().isEmpty()
                    && PythonAutoStage.runAllowed(userMessage)) {
                toast(getString(R.string.python_auto_skipped));
                return null;
            }
            // A no-op must not reuse an unrelated older backup on a failed run.
            if (selected.code.equals(previousCode)) {
                if (repair != null) stopAutoPythonRepair(run, getString(R.string.verify_no_change));
                else toast(getString(R.string.verify_no_change));
                return null;
            }
            if (repair != null) {
                // A runtime-only candidate may fill a previously empty file after a real run.
                // An existing program still requires independent tests before automatic replacement.
                boolean confirmed = run.verification.status == PythonVerification.Status.PASSED
                        || run.verification.status == PythonVerification.Status.RAN
                        && run.verification.syntax && run.verification.ran && run.verification.total == 0
                        && previousCode.trim().isEmpty();
                if (!confirmed && run.verification.status == PythonVerification.Status.RAN) {
                    stopAutoPythonRepair(run, getString(R.string.verify_repair_unproven));
                    return null;
                }
                if (!confirmed || !repair.path.equals(selected.path)
                        || repair.alreadyTried(selected.code)
                        || !run.verification.matchesCheckedSource(selected.code, "")
                        || !repair.unchangedProject(previousCode)) {
                    stopAutoPythonRepair(run, getString(R.string.python_auto_repair_stopped));
                    return null;
                }
                // Only a known entry point is eligible for unattended replacement.
                if (!selected.path.equals(PythonAutoStage.launchEntry(selected.path, paths))) {
                    stopAutoPythonRepair(run, getString(R.string.python_auto_repair_stopped));
                    return null;
                }
            }
            pythonProjects().replaceTextWithBackup(linked, selected.path, selected.code);
            if (!artifactRepository.touch(linked, selected.path)) {
                pythonProjects().restorePrevious(linked);
                throw new IOException("Запись проекта недоступна.");
            }
            // An old execution result must not be displayed as proof that the
            // newly saved version ran. Remove it even when autorun is skipped.
            invalidatePythonReport(linked);
            // Always display the project that the chat actually modified.
            if (activeArtifactId != linked) selectArtifact(linked);
            if (nexusUi != null) {
                nexusUi.dismissPythonResult();
                nexusUi.onVisualAvailable(false);
                nexusUi.projectChanged("");
            }

            if ((linkedSuite || "main.py".equals(selected.path)) && showCheckedProjectOutput(linked, step)) {
                if (nexusUi != null) nexusUi.pythonAppliedFromChat(step, selected.path, selected.code);
                return null;
            }
            String entry = PythonAutoStage.launchEntry(selected.path, paths);
            if (!PythonAutoStage.runAllowed(userMessage) || entry.isEmpty()) {
                toast(getString(R.string.python_auto_saved, selected.path));
                return null;
            }
            String code = pythonProjects().text(linked, entry);
            try {
                SandboxClient.validate(code, "");
            } catch (IllegalArgumentException invalid) {
                toast(getString(R.string.python_auto_saved, selected.path));
                return null; // Saving large source is allowed; executing it is not.
            }
            JSONObject snapshot = pythonProjects().snapshot(linked);
            return new AutoPythonLaunch(entry, code, snapshot, step, selected.path);
        } catch (IOException | RuntimeException error) {
            toast(getString(R.string.python_auto_failed, error.getMessage()));
            return null;
        }
    }

    private void finishRunUi() {
        active = false;
        stagePool = null;
        if (!blackBoxRunCompleted && run != null && run.complete()) {
            blackBoxRunCompleted = true;
            blackBoxEvent(activeTaskId, blackBoxRunId, null, -1, "RUN_COMPLETED", "");
        }
        AutoPythonLaunch launch = autoStageChatPython();
        persistRun();
        renderRun(true);
        if (nexusUi != null && run != null && run.complete() && run.note.isEmpty()
                && !TaskHistory.readOnlyTurn(run.task)) {
            int finalStep = run.finalIndex();
            String html = PythonInputs.webSource(run.displayAnswer(finalStep), "html");
            JSONObject check = run.answerAt(finalStep).webCheck;
            if (!html.isEmpty() && check != null && "SYNTAX_CHECKED".equals(check.optString("status"))
                    && !Workflow.Run.failedWeb(check)
                    && !PythonInputs.asksPythonPort(TaskHistory.forRepair(run.task))) {
                nexusUi.webAppliedFromChat(html);
            } else if (!PythonInputs.webProjectFiles(run.displayAnswer(finalStep)).isEmpty()
                    && check != null && "SYNTAX_CHECKED".equals(check.optString("status"))
                    && !Workflow.Run.failedWeb(check)
                    && !PythonInputs.asksPythonPort(TaskHistory.forRepair(run.task))) {
                nexusUi.webProjectAppliedFromChat();
            }
        }
        if (launch != null && !isFinishing() && !isDestroyed()) {
            runSandbox(run, launch.step, launch.code, "", "", false,
                    launch.files, launch.entry, "", false, true, launch.editedPath);
            if (sandboxJob != null) toast(getString(R.string.python_auto_running));
        }
    }

    private boolean startVerification(int index) {
        if (TaskHistory.readOnlyTurn(run.task)) return false;
        PythonVerification previous = run.verification;
        PythonInputs.Candidate candidate = PythonInputs.candidate(run.displayAnswer(index));
        if (candidate == null && linkedSuiteRequired(run, index)) {
            try {
                finishVerification(previous.start(index, run.displayAnswer(index)).report(linkedDeliveryLimited(true)));
            } catch (JSONException invalid) {
                finishVerification(previous.start(index, run.displayAnswer(index)).limited(getString(R.string.verify_protocol)));
            }
            return true;
        }
        if (candidate == null || candidate.ambiguous && previous.status == PythonVerification.Status.REPAIRING
                && PythonInputs.multiPythonProject(run.displayAnswer(index)).isEmpty()) {
            if (previous.status == PythonVerification.Status.NONE && candidate == null) return false;
            finishVerification(previous.stopped(getString(R.string.verify_no_code)));
            return true;
        }
        String fingerprintInput = PythonInputs.projectFingerprint(run.displayAnswer(index), candidate);
        if (previous.status == PythonVerification.Status.REPAIRING && previous.seenCode(fingerprintInput)) {
            finishVerification(previous.stopped(getString(R.string.verify_no_change) + "\n" + previous.diagnostic));
            return true;
        }
        run = run.withVerification(previous.start(index, fingerprintInput));
        active = true;
        stagePool = null;
        persistRun();
        renderRun(true);
        long generation = ++verificationGeneration;
        try {
            final boolean multi = !PythonInputs.multiPythonProject(run.displayAnswer(index)).isEmpty();
            final boolean linkedSuite = linkedSuiteRequired(run, index);
            PythonAutoStage.LinkedCandidate delivery = linkedSuite ? linkedCandidate(run, index) : null;
            java.util.Map<String,String> merged = delivery == null ? java.util.Collections.emptyMap() : delivery.files;
            if (linkedSuiteProtected(run) && (!linkedSuite || merged.isEmpty())) {
                acceptVerification(delivery != null ? linkedDeliveryLimited(false).put("delivery_detail", delivery.reason) : linkedSuiteLimited(), candidate.code); return true;
            }
            JSONObject previousCheck = run.answerAt(index).webCheck;
            if (checkedProjectOutput != null && checkedProjectTask == activeTaskId
                    && run.task.equals(checkedProjectRequest) && checkedProjectIdentity.equals(fingerprintInput) && previousCheck != null
                    && previousCheck.optJSONObject("project_execution") != null
                    && previousCheck.optString("sha256").equals(InputMaterial.sha256((multi ? fingerprintInput : candidate.code).getBytes(StandardCharsets.UTF_8)))) {
                acceptVerification(previousCheck, candidate.code);
                return true;
            }
            if (InputMaterial.utf8(candidate.code) > 64000) {
                finishVerification(run.verification.limited(getString(R.string.verify_source_limit)));
            } else if (!candidate.ambiguous && !candidate.issue.isEmpty()) {
                acceptVerification(new JSONObject().put("status", "ERROR").put("syntax", false).put("ran", false)
                        .put("passed", 0).put("total", 0).put("diagnostic", candidate.issue).put("signature","incomplete-fence").put("category","SYNTAX_ERROR"), candidate.code);
            } else {
                JSONObject request = linkedSuite ? linkedSuiteSyntaxRequest(merged) : candidate.ambiguous
                        ? PythonInputs.projectSyntaxRequest(run.displayAnswer(index), candidate)
                        : PythonInputs.request(run, candidate.code);
                automaticPython = new LocalSandbox(null, reason -> {
                    if (verificationCurrent(generation)) finishVerification(run.verification.limited(reason));
                });
                automaticPython.verify(this, request, event -> {
                    if (!verificationCurrent(generation)) return;
                    String phase = event.optString("stage");
                    int count = event.optInt("passed", -1), total = event.optInt("total", -1);
                    if (!(phase.equals("syntax") || phase.equals("executed")) || count < 0 || count > total || total > 24) {
                        finishVerification(run.verification.limited(getString(R.string.verify_protocol)));
                        return;
                    }
                    run = run.withVerification(run.verification.progress(true, phase.equals("executed"), count, total));
                    if (nexusUi != null) nexusUi.updateVerification();
                }, report -> {
                    if (!verificationCurrent(generation)) return;
                    Consumer<JSONObject> accept = result -> {
                        if (!verificationCurrent(generation)) return;
                        try { acceptVerification(result, candidate.code); }
                        catch (JSONException e) { finishVerification(run.verification.limited(getString(R.string.verify_protocol))); }
                    };
                    if (linkedSuite || multi || report.optBoolean("workspace_eligible")) completeProjectCheck(run, index, report, () -> verificationCurrent(generation), accept);
                    else accept.accept(report);
                });
            }
        } catch (JSONException | RuntimeException e) {
            finishVerification(run.verification.limited(getString(R.string.verify_protocol) + " " + e.getMessage()));
        }
        return true;
    }

    private boolean verificationCurrent(long generation) {
        return generation == verificationGeneration && active && !isDestroyed() && run != null
                && run.verification.status == PythonVerification.Status.CHECKING;
    }

    private void acceptVerification(JSONObject report, String code) throws JSONException {
        automaticPython = null;
        PythonVerification check = run.verification.report(report);
        if ("REQUIREMENTS_CHANGED".equals(check.category()) && !run.repairs.isEmpty()) {
            int before = run.repairs.get(run.repairs.size() - 1).sourceIndex;
            finishVerification(check.keepPrevious(before, check.diagnostic));
            return;
        }
        boolean multi = !PythonInputs.multiPythonProject(run.displayAnswer(check.source)).isEmpty();
        boolean checkedGeneratedRepair = multi && !run.repairs.isEmpty() && check.generatedSuitePassed() > 0
                && PythonInputs.sameProjectTests(PythonInputs.multiPythonProject(run.displayAnswer(run.repairs.get(run.repairs.size()-1).sourceIndex)),
                        PythonInputs.multiPythonProject(run.displayAnswer(check.source)));
        boolean checkedLinkedRepair = linkedSuiteRequired(run, check.source) && linkedSuitePassed(run, check.source, check);
        if (check.status == PythonVerification.Status.RAN && !run.repairs.isEmpty() && !checkedGeneratedRepair && !checkedLinkedRepair) {
            // Running without a crash does not establish that the AI preserved the task.
            // Keep the candidate in logs, but do not silently publish or apply it as a fix.
            String reason = getString(R.string.verify_repair_unproven);
            if (!run.repairs.isEmpty()) {
                int before = run.repairs.get(run.repairs.size() - 1).sourceIndex;
                finishVerification(check.keepPrevious(before, reason));
            } else {
                finishVerification(check.stopped(reason));
            }
            return;
        }
        if (multi && !run.repairs.isEmpty() && (check.status == PythonVerification.Status.STOPPED
                || check.status == PythonVerification.Status.LIMITED)) {
            finishVerification(check.keepPrevious(run.repairs.get(run.repairs.size()-1).sourceIndex, check.diagnostic));
            return;
        }
        if ((check.status != PythonVerification.Status.ERROR && !check.canRepairCompatibility()) || run.mode == Workflow.Mode.QUICK
                || !PythonAutoStage.repairAllowed(TaskHistory.projectExecutionRequest(run.task))) {
            finishVerification(check);
            return;
        }
        if (multi) {
            java.util.Map<String,String> files=PythonInputs.multiPythonProject(run.displayAnswer(check.source));
            // A repair receives the whole immutable snapshot in complete_project;
            // Use the same confirmed entry selection as the isolated execution.
            if (!PythonAutoStage.projectRunAllowed(TaskHistory.projectExecutionRequest(run.task),files)) {
                finishVerification(check); return;
            }
            code=files.get(PythonAutoStage.projectEntry(files));
        }
        if (code==null || code.trim().isEmpty()) { finishVerification(check); return; }
        run = run.addRepair(new Workflow.RepairInput(check.source, code, "", check.diagnostic)).withVerification(check.repair());
        stagePool = modelsFor(run);
        if (stagePool.models.isEmpty()) pause(keyMessage(run.nextStage()));
        else requestNextModel(true);
    }

    private void finishVerification(PythonVerification value) {
        verificationGeneration++;
        if (automaticPython != null) automaticPython.close();
        automaticPython = null;
        run = run.finishVerification(value);
        finishRunUi();
        if (value.status == PythonVerification.Status.ERROR && run.complete())
            forwardAutoPythonVerificationFailure(run);
        else if (run.complete() && PythonAutoRepair.parse(run.task) != null
                && value.status != PythonVerification.Status.RAN
                && value.status != PythonVerification.Status.PASSED)
            stopAutoPythonRepair(run, getString(R.string.python_auto_repair_stopped));
    }

    private int availableCandidate() {
        if (stagePool.dispatched >= ModelPool.MAX_ATTEMPTS) return -1;
        int candidate = cooldowns.next(stagePool.models, stagePool.next, System.currentTimeMillis());
        // Skip providers that already reported an exact per-minute token limit;
        // other providers remain eligible for their normal bounded fallback.
        while (candidate >= 0) {
            ModelCatalog.Model model = stagePool.models.get(candidate);
            if (autonomySession != null && autonomySession.unattended()
                    && automaticRepairQuotaExhausted(model.provider)) {
                String detail = model.label + " · " + getString(R.string.python_auto_repair_quota_stop);
                if (!stagePool.failures.contains(detail)) stagePool.failures.add(detail);
                candidate = cooldowns.next(stagePool.models, candidate + 1, System.currentTimeMillis());
                continue;
            }
            try {
                Workflow.Run routed = run.withExecutor(model, "");
                long estimate = ModelClient.estimatedInput(routed);
                int output = ModelClient.requestedOutput(routed, model, estimate);
                if (output < routed.minimumOutput()) {
                    String detail = model.label + " · " + getString(R.string.budget_short);
                    if (!stagePool.failures.contains(detail)) stagePool.failures.add(detail);
                    candidate = cooldowns.next(stagePool.models, candidate + 1, System.currentTimeMillis());
                    continue;
                }
            } catch (JSONException invalid) { return -1; }
            if (!stagePool.blockedProviders.contains(model.provider)
                    && (!run.hasImages() || model.provider == Workflow.Provider.OPENROUTER
                    && model.imageInput)) return candidate;
            if (run.hasImages() && !stagePool.blockedProviders.contains(model.provider)) {
                String skipped = AttachmentMessages.format(this, AttachmentProblem.Code.MODEL_IMAGES, model.label);
                if (!stagePool.failures.contains(skipped)) stagePool.failures.add(skipped);
            }
            candidate = cooldowns.next(stagePool.models, candidate + 1, System.currentTimeMillis());
        }
        return -1;
    }

    private String exhaustedNote(String reason) {
        long retry = cooldowns.firstRetry(stagePool.models, System.currentTimeMillis());
        String message = reason.isEmpty() ? (stagePool.failures.isEmpty() ? getString(R.string.route_busy)
                : stagePool.failures.get(stagePool.failures.size()-1)) : reason;
        if (retry > 0) message += "\n" + DateFormat.getDateTimeInstance().format(new Date(retry));
        message += "\n" + getString(run.draft.text.isEmpty() ? R.string.kept_task : R.string.kept_draft);
        message += "\n" + getString(R.string.retry_or_change);
        return message;
    }

    private void recordAttempt(Attempt current, ModelClient.Reply reply, ModelCatalog.Model next, String outcome) {
        if (clearing) return;
        try {
            JSONArray previous = attemptHistory.isEmpty() ? new JSONArray() : new JSONArray(attemptHistory);
            JSONArray journal = new JSONArray();
            for (int i = Math.max(0, previous.length() - 39); i < previous.length(); i++) journal.put(previous.get(i));
            ModelCatalog.Model model = current.input.nextStage().model;
            ModelClient.InputComparison input = ModelClient.compareInput(current.input);
            long inputEstimate = input.estimatedAfter;
            JSONObject entry = new JSONObject().put("time", System.currentTimeMillis())
                    .put("step", current.input.nextIndex() + 1).put("provider", model.provider.label)
                    .put("selected_model", current.input.nextStage().selected.id)
                    .put("reserve", !model.id.equals(current.input.nextStage().selected.id))
                    .put("model", model.id).put("ms", android.os.SystemClock.elapsedRealtime() - current.started)
                    .put("estimated_input_tokens", inputEstimate)
                    // Same task/model/continuation, before and after local prompt optimizations.
                    // This comparison is an estimate, not billed/actual provider usage.
                    .put("estimated_input_tokens_before_optimization", input.estimatedBefore)
                    .put("estimated_input_tokens_saved", input.estimatedBefore - input.estimatedAfter)
                    // Exact system+user UTF-8 text bytes (excludes unchanged images/HTTP framing).
                    .put("input_text_bytes_before_optimization", input.textBytesBefore)
                    .put("input_text_bytes_after_optimization", input.textBytesAfter)
                    .put("input_text_bytes_saved", input.textBytesBefore - input.textBytesAfter)
                    // Exact saved UTF-8 bytes, not a claimed provider token balance.
                    .put("duplicate_prompt_bytes_saved", current.input.duplicatePromptBytesSaved())
                    // Separate from duplicate-content savings. The byte count is exact
                    // for local system instructions; token saving is only a heuristic.
                    .put("console_instruction_bytes_saved", current.input.consoleInstructionBytesSaved())
                    .put("estimated_console_instruction_tokens_saved", current.input.estimatedConsoleInstructionTokensSaved())
                    .put("plain_text_instruction_bytes_saved", current.input.plainTextInstructionBytesSaved())
                    .put("estimated_plain_text_instruction_tokens_saved", current.input.estimatedPlainTextInstructionTokensSaved())
                    .put("safety_margin_tokens", 1024).put("provider_token_limit", JSONObject.NULL)
                    .put("model_context", model.context == 0 ? JSONObject.NULL : model.context).put("output_limit", ModelClient.requestedOutput(current.input, model, inputEstimate))
                    .put("status", AttemptJournal.status(reply, outcome))
                    .put("has_text", !current.received.isEmpty() || (reply != null && !reply.text.isEmpty()));
            if (autonomySession != null) entry.put("session_model_calls",autonomySession.calls)
                    .put("session_reserved_estimated_tokens",autonomySession.reservedTokens);
            entry.put("draft_mode",current.input.draftMode.name());
            if (reply != null) {
                if (reply.status > 0 && !current.timedOut) entry.put("code", reply.status);
                else entry.put("transport", current.timedOut ? "LOCAL_TIMEOUT" : "NO_HTTP_STATUS");
                entry.put("reason", reply.failure.reason.name());
                if (reply.failure.retryAt > 0) entry.put("retry_at", reply.failure.retryAt);
            }
            if (reply != null && reply.quota != null && model.provider == Workflow.Provider.GROQ
                    && reply.quota.available()) {
                SharedPreferences.Editor quotaSettings = data.edit();
                if (reply.quota.tokensPerMinute >= 0)
                    quotaSettings.putLong(QUOTA_GROQ_TPM, reply.quota.tokensPerMinute);
                if (reply.quota.requestsPerDay >= 0)
                    quotaSettings.putLong(QUOTA_GROQ_RPD, reply.quota.requestsPerDay);
                quotaSettings.putLong(QUOTA_GROQ_AT, System.currentTimeMillis()).apply();
                if (reply.quota.tokensPerMinute >= 0)
                    entry.put("groq_remaining_tokens_this_minute", reply.quota.tokensPerMinute);
                if (reply.quota.requestsPerDay >= 0)
                    entry.put("groq_remaining_requests_today", reply.quota.requestsPerDay);
            }
            if (next != null) entry.put("next_model", next.id);
            journal.put(entry);
            attemptHistory = journal.toString();
        } catch (JSONException ignored) {
            // A malformed diagnostic entry must not stop generation.
        }
    }

    private void showAttemptHistory() {
        try {
            showText("Журнал запросов", AttemptJournal.normalizeAll(new JSONArray(attemptHistory)).toString(2));
        } catch (JSONException e) {
            toast("Не удалось прочитать журнал запросов.");
        }
    }

    private void pause(String message) {
        active = false;
        stagePool = null;
        if (run.verification.busy()) {
            finishVerification(run.verification.stopped(message + "\n" + run.verification.diagnostic));
            return;
        }
        run = run.withNote(message);
        blackBoxEvent(activeTaskId, blackBoxRunId, null, -1, "RUN_INTERRUPTED", "");
        persistRun();
        renderRun(true);
    }

    private void stopRun() {
        cancelRequest();
        pause("Разбор остановлен. Полученные шаги и сохранённый черновик доступны.");
    }

    private void cancelRequest() {
        releaseWebCheck();
        Attempt current = attempt;
        attempt = null;
        stagePool = null;
        active = false;
        verificationGeneration++;
        if (automaticPython != null) automaticPython.close();
        automaticPython = null;
        if (current == null) {
            if (run != null && run.verification.busy()) { run = interrupted(run); persistRun(); }
            return;
        }
        progressHandler.removeCallbacks(current.deadline);
        recordAttempt(current, null, null, "CANCELLED");
        blackBoxCheckpoint(current, current.received);
        blackBoxEvent(current.journalTaskId, current.journalRunId, current.journalAttemptId,
                current.input.nextIndex(), "MODEL_ATTEMPT_CANCELLED", "");
        String partial = current.received;
        if (!partial.isEmpty()) {
            run = current.input.receive(ModelClient.Reply.error(partial, "Ответ прерван."));
        }
        if (run.verification.busy()) run = interrupted(run);
        persistRun();
        if (current.future != null) current.future.cancel(true);
        disconnect(current.cancellation);
    }

    private void editStage(int index) {
        Workflow.Stage current = stages.get(index);
        LinearLayout form = dialogForm();
        form.addView(text("Название роли", 14, MUTED, true));
        EditText title = field(current.role, "", 42, 1, false);
        add(form, title, 6);
        add(form, text("Что должен сделать ИИ", 14, MUTED, true), 14);
        EditText instructions = field(current.instruction, "", 1600, 3, false);
        add(form, instructions, 6);
        add(form, text("Модель", 14, MUTED, true), 14);
        ModelCatalog.Model[] selection = {current.model};
        Button choose = button(current.model.label + "  ▾", false, null);
        choose.setOnClickListener(view -> chooseModel(selection[0], model -> {
            selection[0] = model;
            choose.setText(model.label + "  ▾");
        }));
        add(form, choose, 6);
        AlertDialog dialog = dialog("Шаг " + (index + 1), form);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String role = title.getText().toString().trim();
            String instruction = instructions.getText().toString().trim();
            if (role.isEmpty()) {
                title.setError("Назови роль.");
                return;
            }
            if (instruction.isEmpty()) {
                instructions.setError("Добавь задание для этой роли.");
                return;
            }
            List<Workflow.Stage> updated = new ArrayList<>(stages);
            updated.set(index, new Workflow.Stage(role, instruction, selection[0]));
            try {
                data.edit().putString("stages", Workflow.stagesToJson(updated).toString()).apply();
                stages = updated;
                dialog.dismiss();
                renderTask();
            } catch (JSONException e) {
                toast("Не удалось сохранить роль.");
            }
        });
    }

    private void chooseModel(ModelCatalog.Model selected, Consumer<ModelCatalog.Model> onChoice) {
        List<ModelCatalog.Model> choices = catalog.choices();
        String[] labels = new String[choices.size()];
        int checked = -1;
        for (int i = 0; i < choices.size(); i++) {
            ModelCatalog.Model model = choices.get(i);
            labels[i] = model.label + " · " + model.provider.label;
            if (model.id.equals(selected.id)) checked = i;
        }
        AlertDialog picker = new AlertDialog.Builder(this).setTitle("Выбрать модель")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    dialog.dismiss();
                    onChoice.accept(choices.get(which));
                })
                .setNegativeButton("Отмена", null).setNeutralButton("Обновить", null).show();
        Button refresh = picker.getButton(AlertDialog.BUTTON_NEUTRAL);
        refresh.setOnClickListener(view -> {
            refresh.setEnabled(false);
            refresh.setText("Обновление…");
            refreshModels(true, problem -> {
                if (!picker.isShowing()) return;
                if (problem.isEmpty()) {
                    picker.dismiss();
                    chooseModel(selected, onChoice);
                } else {
                    refresh.setEnabled(true);
                    refresh.setText("Обновить");
                    toast(problem);
                }
            });
        });
    }

    private void showKeys(String message) {
        if (nexusUi != null) { nexusUi.requestKeys(); return; }
        LinearLayout form = dialogForm();
        if (!message.isEmpty()) add(form, text(message, 14, WARNING, false), 0);
        add(form, text("Команде по умолчанию нужен один ключ OpenRouter.", 15, FG, false),
                message.isEmpty() ? 0 : 10);
        add(form, text("OpenRouter", 14, MUTED, true), 14);
        EditText router = field(readForEdit(Workflow.Provider.OPENROUTER),
                "Вставь ключ OpenRouter", 512, 1, true);
        add(form, router, 5);
        add(form, button("Получить ключ OpenRouter", false,
                view -> openLink("https://openrouter.ai/settings/keys")), 6);
        TextView catalogStatus = text(catalogLabel(), 13, MUTED, false);
        add(form, catalogStatus, 11);
        Button refresh = button("Обновить бесплатные модели", false, null);
        refresh.setOnClickListener(view -> {
            refresh.setEnabled(false);
            catalogStatus.setText("Обновляю список OpenRouter…");
            refreshModels(true, problem -> {
                refresh.setEnabled(true);
                catalogStatus.setText(problem.isEmpty() ? catalogLabel() : problem);
            });
        });
        add(form, refresh, 5);
        add(form, text("Groq · Free Plan", 14, MUTED, true), 14);
        EditText groq = field(readForEdit(Workflow.Provider.GROQ),
                "Вставь ключ Groq", 512, 1, true);
        add(form, groq, 5);
        add(form, button("Получить ключ Groq", false,
                view -> openLink("https://console.groq.com/keys")), 6);
        CheckBox groqReserve = new CheckBox(this);
        groqReserve.setText("Использовать Groq Free в резерве");
        groqReserve.setChecked(data.getBoolean(GROQ_RESERVE, false));
        add(form, groqReserve, 5);
        add(form, text("Google Gemini · по желанию", 14, MUTED, true), 14);
        EditText gemini = field(readForEdit(Workflow.Provider.GEMINI),
                "Вставь ключ Gemini", 512, 1, true);
        add(form, gemini, 5);
        add(form, button("Получить ключ Gemini", false,
                view -> openLink("https://aistudio.google.com/api-keys")), 6);
        add(form, text("Для бесплатной работы Gemini нужен проект Google на Free Tier.",
                13, MUTED, false), 8);
        add(form, text("Песочница Piston · по желанию", 14, MUTED, true), 14);
        EditText piston = field(readPistonForEdit(), "Токен Piston", 512, 1, true);
        add(form, piston, 5);
        add(form, text("Для запуска Python на телефоне токен не нужен.", 13, MUTED, false), 6);
        add(form, text("Очисти поле, чтобы удалить сохранённый ключ.", 13, MUTED, false), 10);
        AlertDialog dialog = dialog("Подключение моделей", form);
        refreshModels(false, problem -> {
            if (dialog.isShowing()) catalogStatus.setText(problem.isEmpty() ? catalogLabel() : problem);
        });
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String routerValue = router.getText().toString().trim();
            String geminiValue = gemini.getText().toString().trim();
            String groqValue = groq.getText().toString().trim();
            String pistonValue = piston.getText().toString().trim();
            if (!validKey(routerValue)) {
                router.setError("Вставь ключ целиком, без пробелов.");
                return;
            }
            if (!validKey(geminiValue)) {
                gemini.setError("Вставь ключ целиком, без пробелов.");
                return;
            }
            if (!validKey(groqValue)) {
                groq.setError("Вставь ключ целиком, без пробелов.");
                return;
            }
            if (!validKey(pistonValue)) {
                piston.setError("Вставь токен целиком, без пробелов.");
                return;
            }
            try {
                vault.save(routerValue, geminiValue, groqValue, pistonValue);
                data.edit().putBoolean(GROQ_RESERVE, groqReserve.isChecked() && !groqValue.isEmpty()).apply();
                dialog.dismiss();
                toast("Настройки сохранены");
            } catch (GeneralSecurityException | IOException e) {
                toast("Не удалось сохранить ключи на телефоне.");
            }
        });
    }

    private String catalogLabel() {
        return catalog.refreshed ? "Бесплатных моделей OpenRouter: " + catalog.routerCount()
                : "Встроенный список бесплатных моделей OpenRouter";
    }

    private String readForEdit(Workflow.Provider provider) {
        try {
            return vault.read(provider);
        } catch (GeneralSecurityException | IOException e) {
            return "";
        }
    }

    private String readPistonForEdit() {
        try {
            return vault.readPiston();
        } catch (GeneralSecurityException | IOException e) {
            return "";
        }
    }

    private boolean validKey(String s) {
        return s.isEmpty() || s.length() >= 8 && s.matches("[\\x21-\\x7e]+");
    }

    private void openLink(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (android.content.ActivityNotFoundException e) {
            toast("На устройстве нет приложения для открытия ссылки.");
        }
    }

    private void chooseExport() {
        Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                .putExtra(Intent.EXTRA_TITLE, "nexus-ia-result.json");
        try {
            startActivityForResult(create, EXPORT_REQUEST);
        } catch (android.content.ActivityNotFoundException e) {
            toast("Не удалось открыть окно сохранения.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (requestCode != EXPORT_REQUEST || resultCode != RESULT_OK
                || result == null || result.getData() == null || run == null) return;
        try (OutputStream output = getContentResolver().openOutputStream(result.getData(), "w")) {
            if (output == null) throw new IOException("Output missing");
            output.write(run.toJson().toString(2).getBytes(StandardCharsets.UTF_8));
            toast("Разбор сохранён");
        } catch (IOException | JSONException e) {
            toast("Не удалось сохранить файл.");
        }
    }

    @Override public void onBackPressed() {
        if (clearing) return;
        if (nexusUi != null && nexusUi.navigateBack()) return;
        if (historyVisible) {
            returnFromHistory();
        } else if (!resultsVisible) {
            super.onBackPressed();
        } else if (active) {
            new AlertDialog.Builder(this).setMessage("Остановить текущий разбор?")
                    .setNegativeButton("Продолжить", null)
                    .setPositiveButton("Остановить", (dialog, which) -> stopRun()).show();
        } else {
            renderTask();
        }
    }

    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        leaveLaunch();
    }

    @Override protected void onStop() {
        nexusPythonFlushPending();
        leaveLaunch();
        if (store != null) persistRun();
        super.onStop();
    }

    @Override protected void onDestroy() {
        releaseWebCheck();
        progressHandler.removeCallbacks(openInitialChat);
        dismissLaunch();
        cancelRequest();
        cancelSandbox();
        blackBoxWriter.shutdown(); // Flush already queued checkpoints and events.
        sandboxWorker.shutdownNow();
        worker.shutdownNow();
        if (catalogRequest != null) {
            ModelClient.Cancellation stop = catalogRequest;
            disconnect(stop);
        }
        catalogWorker.shutdownNow();
        cancellationWorker.shutdown();
        catalogListeners.clear();
        super.onDestroy();
    }

    private AlertDialog dialog(String title, LinearLayout form) {
        ScrollView area = dialogArea(form);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title).setView(area).setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", null).create();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.show();
        area.requestFocus();
        return dialog;
    }

    private ScrollView dialogArea(LinearLayout form) {
        ScrollView area = new ScrollView(this);
        area.addView(form);
        area.setFocusableInTouchMode(true);
        return area;
    }

    private LinearLayout dialogForm() {
        LinearLayout panel = column();
        panel.setPadding(dp(20), dp(12), dp(20), dp(6));
        return panel;
    }

    private EditText field(String value, String hint, int limit, int lines, boolean protectedText) {
        EditText field = new EditText(this);
        field.setTextColor(FG);
        field.setHintTextColor(MUTED);
        field.setTextSize(16);
        field.setHint(hint);
        field.setPadding(dp(13), dp(11), dp(13), dp(11));
        field.setBackground(shape(SURFACE, BORDER, 13));
        field.setInputType(InputType.TYPE_CLASS_TEXT | (protectedText
                ? InputType.TYPE_TEXT_VARIATION_PASSWORD
                : lines > 1 ? InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES : 0));
        if (limit > 0) field.setFilters(new InputFilter[] { new InputFilter.LengthFilter(limit) });
        if (lines > 1) {
            field.setMinLines(lines);
            field.setMaxLines(lines + 2);
            field.setGravity(Gravity.TOP | Gravity.START);
        } else {
            field.setSingleLine(true);
            if (protectedText) field.setInputType(InputType.TYPE_CLASS_TEXT
                    | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        field.setText(value);
        return field;
    }

    private TextView badge(int number) {
        TextView view = text(String.valueOf(number), 15, ACCENT, true);
        view.setGravity(Gravity.CENTER);
        view.setBackground(shape(ACCENT_DARK, Color.TRANSPARENT, 10));
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(34)));
        return view;
    }

    private TextView selectable(String value, int size, int color) {
        TextView view = text(value, size, color, false);
        view.setTextIsSelectable(true);
        return view;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return view;
    }

    private Button button(String title, boolean primary, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(primary ? 16 : 14);
        b.setTextColor(primary ? ACCENT_INK : FG);
        b.setAllCaps(false);
        b.setLetterSpacing(0f);
        b.setMinWidth(0);
        b.setMinHeight(dp(primary ? 52 : 44));
        b.setMinimumWidth(0);
        b.setMinimumHeight(dp(primary ? 52 : 44));
        b.setPadding(dp(13), dp(6), dp(13), dp(6));
        b.setStateListAnimator(null);
        b.setBackground(ripple(primary ? ACCENT : SURFACE,
                primary ? Color.TRANSPARENT : BORDER, 12));
        b.setBackgroundTintList(null);
        b.setOnClickListener(action);
        return b;
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private void add(LinearLayout layout, View child, int top) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(top);
        layout.addView(child, params);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, -2, 1f);
    }

    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }

    private RippleDrawable ripple(int fill, int stroke, int radius) {
        return new RippleDrawable(ColorStateList.valueOf(0x2f8ce5dc),
                shape(fill, stroke, radius), shape(Color.WHITE, Color.TRANSPARENT, radius));
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
