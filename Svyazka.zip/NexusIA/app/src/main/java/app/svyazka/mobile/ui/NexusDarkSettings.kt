package app.svyazka.mobile.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.svyazka.mobile.R

/** Approved dark settings. The existing light settings implementation is unchanged. */
@Composable
internal fun NexusDarkSettingsScreen(ui: NexusComposeUi) {
    val themes = listOf("system" to R.string.theme_system, "dark" to R.string.theme_dark,
        "light" to R.string.theme_light)
    val languages = listOf("system" to R.string.language_system, "ru" to R.string.language_ru,
        "en" to R.string.language_en, "zh-CN" to R.string.language_zh,
        "ar" to R.string.language_ar, "ja" to R.string.language_ja)
    val language = ui.activity.nexusLanguageChoice()
    var languageOpen by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 15.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            NexusDarkSettingsCard {
                NexusDarkSettingsHeading(R.drawable.ic_nia_theme,
                    stringResource(R.string.settings_appearance), NexusDarkDesign.settingsMoon)
                Spacer(Modifier.height(16.dp))
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val themeWidth = (maxWidth - 16.dp) / 3
                    if (themeWidth >= 86.dp) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            themes.forEach { (id, label) ->
                                NexusDarkThemeChoice(
                                    label = stringResource(label),
                                    selected = ui.theme == id,
                                    onClick = { ui.activity.nexusThemeChanged(id) },
                                    modifier = Modifier.weight(1f))
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            themes.forEach { (id, label) ->
                                NexusDarkThemeChoice(
                                    label = stringResource(label),
                                    selected = ui.theme == id,
                                    onClick = { ui.activity.nexusThemeChanged(id) },
                                    modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }
        }
        item {
            NexusDarkSettingsCard {
                NexusDarkSettingsHeading(R.drawable.ic_nia_language,
                    stringResource(R.string.settings_language), NexusDarkDesign.settingsBlue)
                Spacer(Modifier.height(15.dp))
                Box {
                    Surface(onClick = { languageOpen = true },
                        shape = RoundedCornerShape(15.dp),
                        color = NexusDarkDesign.chatGlass,
                        border = BorderStroke(1.dp, NexusDarkDesign.chatBorder),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(languages.firstOrNull { it.first == language }?.second
                                ?: R.string.language_system),
                                color = Color.White, fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Icon(painterResource(R.drawable.ic_nia_chevron_down),
                                contentDescription = null, tint = Color.White,
                                modifier = Modifier.size(22.dp))
                        }
                    }
                    DropdownMenu(expanded = languageOpen,
                        onDismissRequest = { languageOpen = false },
                        containerColor = NexusDarkDesign.settingsGlass) {
                        languages.forEach { (id, label) ->
                            DropdownMenuItem(text = { Text(stringResource(label)) },
                                leadingIcon = { RadioButton(selected = language == id, onClick = null) },
                                onClick = {
                                    languageOpen = false
                                    ui.activity.nexusLanguageChanged(id)
                                })
                        }
                    }
                }
            }
        }
        item {
            NexusDarkSettingsCard(onClick = { ui.requestKeys() }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        NexusDarkSettingsHeading(R.drawable.ic_nia_key,
                            stringResource(R.string.settings_providers), NexusDarkDesign.settingsBlue)
                        Spacer(Modifier.height(11.dp))
                        Text(stringResource(R.string.keys_warning), fontSize = 14.sp,
                            lineHeight = 20.sp, color = NexusDarkDesign.secondaryText)
                    }
                    Spacer(Modifier.width(8.dp))
                    Icon(painterResource(R.drawable.ic_nia_chevron_down),
                        null, Modifier.size(22.dp), tint = Color.White)
                }
            }
        }
        item {
            NexusDarkSettingsCard {
                NexusDarkSettingsHeading(R.drawable.ic_nia_info,
                    stringResource(R.string.settings_about), NexusDarkDesign.settingsBlue)
                Spacer(Modifier.height(11.dp))
                Text(stringResource(R.string.settings_version), fontSize = 14.sp,
                    color = NexusDarkDesign.secondaryText, lineHeight = 20.sp)
                Spacer(Modifier.height(4.dp))
                Text(stringResource(R.string.settings_privacy), fontSize = 14.sp,
                    color = NexusDarkDesign.secondaryText, lineHeight = 20.sp)
            }
        }
    }
}

@Composable
private fun NexusDarkSettingsHeading(icon: Int, title: String, tint: Color) {
    Row(verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(painterResource(icon), contentDescription = null, tint = tint,
            modifier = Modifier.size(33.dp))
        Text(title, fontSize = 18.sp, lineHeight = 24.sp,
            color = Color.White, fontWeight = FontWeight.Bold,
            maxLines = 2)
    }
}

@Composable
private fun NexusDarkSettingsCard(
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    val contentBody: @Composable () -> Unit = {
        Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(
            Color.White.copy(alpha = .055f), Color.Transparent)))
            .padding(horizontal = 16.dp, vertical = 16.dp),
            content = content)
    }
    if (onClick == null) {
        Surface(modifier = Modifier.fillMaxWidth(), shape = shape,
            color = NexusDarkDesign.settingsGlass,
            border = BorderStroke(1.dp, NexusDarkDesign.settingsBorder),
            tonalElevation = 0.dp, content = contentBody)
    } else {
        Surface(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = shape,
            color = NexusDarkDesign.settingsGlass,
            border = BorderStroke(1.dp, NexusDarkDesign.settingsBorder),
            tonalElevation = 0.dp, content = contentBody)
    }
}

@Composable
private fun NexusDarkThemeChoice(label: String, selected: Boolean,
                                 onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(13.dp)
    Box(modifier.heightIn(min = 48.dp).clip(shape)
        .then(if (selected) Modifier.background(NexusDarkDesign.settingsSelection, shape)
            else Modifier.background(NexusDarkDesign.chatGlass, shape))
        .then(if (selected) Modifier else Modifier.border(
            1.dp, NexusDarkDesign.chatBorder, shape))
        .clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center) {
        Text(label, fontSize = 15.sp, lineHeight = 20.sp,
            color = Color.White, fontWeight = FontWeight.SemiBold,
            maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
    }
}
