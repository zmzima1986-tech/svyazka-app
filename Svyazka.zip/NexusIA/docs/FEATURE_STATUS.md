# Реестр функций — 24.11.2026

Снимок Svyazka.zip, 0.7.0 / versionCode 21. Все позиции ниже имеют реализацию в исходниках. Владелец подтвердил общую работоспособность приложения; отдельные строки не означают прохождение конкретных сценариев на телефоне. Обозначения: «код» — найдены связанные реализации; «тест» — тестовый файл присутствует, не обязательно успешно исполнен. Текущий прогон и блокеры: [VALIDATION_REPORT](VALIDATION_REPORT.md).

Пути Java/Kotlin в таблице относительны к `app/src/main/java/app/svyazka/mobile/`; JUnit/Robolectric — `app/src/test/java/app/svyazka/mobile/`.

| Возможность | Реализация / свидетельство | Граница |
| --- | --- | --- |
| Одна модель, три роли, резервы, отмена | Workflow.java, ModelClient.java, ModelPool.java, RequestExecutor.java, AttemptJournal.java | Реальные ответы, квоты и доступность провайдеров не проверены |
| История, версии, продолжение, черновики | TaskRepository.java, TaskHistory.java, WorkspaceStore.java, MainActivity.java, ui/MessageSearch.kt | Миграция и восстановление на Android не проверены |
| Чёрный ящик | ChatRunJournal.java, TaskRepository.java, MainActivity.java; ChatRunJournalTest.java, BlackBoxRecoveryTest.java | События и контрольные точки по task_id/run_id/attempt_id; валидация SHA-256 перед восстановлением; нет автоматической сетевой переотправки в журнале. Не полная трассировка всех ручных Python-запусков |
| Изоляция чатов | PythonArtifactRepository.java: assignedForChat, forChat, attachIsolatedCopy, createEmptyForChat, setConnected; MainActivity.java: enterTask, nexusCreateChatPythonProject, nexusOpenChatPythonProject, chat_drafts | Новый чат не обязан иметь проект до явного создания/подключения. Существующий артефакт копируется, назначение не переключается молча. Отключение сохраняет назначение, но не добавляет текущий снимок в запрос; старые сообщения могут содержать прежний контекст. Удаление чата разрывает связь, артефакт остаётся. Изоляция не доказана устройством |
| Экономия контекста | PromptContextOptimizer.java, TaskHistory.java, Workflow.java; PromptContextOptimizerTest.java, InputOptimizationMetricsTest.java, LongProseHistorySavingsTest.java | Точные дубли внутри одного запроса заменяются ссылками, не удаляются уникальные данные. Экономия байтов/оценка не равна измеренным токенам или стоимости API |
| Строгая проверка Python | PythonVerification.java, PythonInputs.java, LocalSandbox.java, assets/sandbox/verify.py (путь от app/src/main/) | Синтаксис, исполнение и прохождение независимых примеров различаются; ограничения среды не доказывают дефект программы |
| Автономная работа с проектом | PythonAutoStage.java, PythonChatFile.java, PythonAutoTests.java, PythonAutoFeedback.java, PythonAutoRepair.java, AutonomyQuotaGuard.java, MainActivity.java | Требуется подключённый проект, распознанное намерение, целый ответ, однозначный файл. Запрет запуска учитывается. Резервная копия, условный откат, контроль исходника/повтора; MAX_ATTEMPTS=3 в PythonAutoRepair (не гарантия ровно трёх HTTP-запросов). Нет бесконечного автономного агента |
| Ручной Python и файлы | PythonProjectStore.java, PythonLastRunStore.java, LocalSandbox.java, ui/NexusPythonWorkspace.kt, ui/PythonCodeEditor.kt; assets/sandbox/workspace.py, worker.mjs | Последний отчёт, не полная история; виртуальный FS; Piston отдельно и удалённо; Matplotlib/NumPy и кэш требуют проверки |
| Артефакты и копии | PythonArtifactRepository.java, ui/NexusArtifacts.kt, ui/NexusPythonProjectFiles.kt | Отдельный ID, атомарные записи, миграция; импорт/экспорт; не общий изменяемый проект нескольких чатов |
| Вложения | attachments/AttachmentStore.kt, attachments/PdfTextExtractor.kt, AttachmentParser.java, InputMaterial.java | PDF только текстовый слой; ограниченный ZIP; нет OCR |
| Визуальный просмотр | ui/WebWorkspace.kt, assets/web/controller.js (app/src/main/) | Эвристики и изолированный просмотр не доказывают работу произвольного сайта |
| Приватность | CredentialStore.java, KeyVault.java, MainActivity.java, ModelClient.java | OpenRouter data_collection=deny не ZDR; передача данных внешним ИИ происходит по согласию |
| UI и локализация | ui/NexusComposeUi.kt, ui/NexusChat.kt, ui/NexusPythonWorkspace.kt, res/values* | Ресурсная проверка обнаружила новые кириллические литералы; визуальное поведение и RTL не подтверждены |

## SHA-256: где используется

| Контур | Что именно |
| --- | --- |
| AttachmentStore / InputMaterial | Хеш байтов вложения, проверка размера и хеша при подготовке изображения |
| Workflow.Artifact | Хеш частей текста; intactParts проверяет целостность |
| ChatRunJournal | Хеш контрольной точки и проверка собранного текста перед восстановлением |
| PythonVerification / PythonAutoRepair | Хеш проверяемого кода и исходного состояния, сравнение предыдущих попыток и сигнатур ошибок |
| workspace.py / PythonLastRunStore | Хеш снимка проекта, сохранение в отчёте последнего запуска |
| PromptContextOptimizer | Ссылки на точно совпадающий текст внутри одного запроса с SHA-256 |

SHA-256 не заменяет тестирование, подпись APK, шифрование или доказательство авторства. Эталон файлов и инструкция сверки: [SOURCE_INTEGRITY](SOURCE_INTEGRITY.md).
