package app.svyazka.mobile;

/** Immutable presentation data for a saved Python artifact (not a chat). */
public final class NexusArtifact {
    public final long id;
    public final String title;
    public final long updatedAt;
    public final int fileCount;

    public NexusArtifact(long id, String title, long updatedAt, int fileCount) {
        this.id = id;
        this.title = title;
        this.updatedAt = updatedAt;
        this.fileCount = fileCount;
    }
}
