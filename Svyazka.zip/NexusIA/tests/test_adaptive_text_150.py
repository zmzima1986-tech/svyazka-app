"""Source-level contracts for text scale 80–150%; Android rendering still requires an APK."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "app/src/main/java/app/svyazka/mobile/ui"
LOCALES = ("values", "values-en", "values-ar", "values-ja", "values-zh-rCN")


def source(filename):
    return (UI / filename).read_text(encoding="utf-8")


class AdaptiveText150Tests(unittest.TestCase):
    def test_mode_is_always_single_dropdown_and_uses_existing_mode_handler(self):
        selected = source("NexusComponents.kt").split("private fun ModeSelector(", 1)[1].split("fun NexusTopBar(", 1)[0]
        self.assertIn("DropdownMenu(expanded = expanded", selected)
        self.assertIn("Text(if (quick) single else team", selected)
        self.assertIn("nexusModeChanged(mode)", selected)
        self.assertIn("enabled = enabled", selected)
        self.assertNotIn("ModeChip(", selected)

    def test_workspace_tabs_reflow_without_shrinking_fonts(self):
        tabs = source("NexusDrawers.kt").split("val lightTabs = nexusLightMode()", 1)[1].split("val tabState = rememberSaveableStateHolder()", 1)[0]
        self.assertIn("tabs.chunked(columns)", tabs)
        self.assertIn("required + 9.dp <= maxWidth", tabs)
        self.assertIn("widest * 2 + 3.dp <= maxWidth", tabs)
        self.assertIn("Modifier.weight(if (columns == 4)", tabs)
        self.assertNotIn("downTo 9", tabs)
        self.assertIn("Text(label, style = style", source("NexusDrawers.kt"))
        self.assertIn("ui.switchWorkspaceTab(tab)", source("NexusDrawers.kt"))

    def test_project_has_two_lines_and_correct_russian_plural(self):
        code = source("NexusPythonWorkspace.kt")
        self.assertIn("R.plurals.ws_easy_project_files", code)
        self.assertIn("R.string.ws_easy_project_entry", code)
        self.assertIn("Column(Modifier.weight(1f))", code)
        file = ROOT / "app/src/main/res/values/workbench.xml"
        tree = ET.parse(file)
        plurals = tree.getroot().find("./plurals[@name='ws_easy_project_files']")
        items = {el.attrib["quantity"]: el.text for el in plurals}
        self.assertEqual(items['one'], 'В проекте %d файл')
        self.assertEqual(items['few'], 'В проекте %d файла')
        self.assertEqual(items['many'], 'В проекте %d файлов')

    def test_chat_link_footer_compact_with_wrappable_action(self):
        code = source("NexusPythonWorkspace.kt")
        self.assertIn("modifier = Modifier.weight(1f).heightIn(min = 52.dp)", code)
        self.assertIn("Icon(Icons.Filled.Check, statusText", code)
        self.assertIn("nexusCreateChatPythonProject()", code)
        self.assertIn("nexusDetachArtifactFromChat()", code)
        self.assertIn(".padding(bottom = 108.dp)", code)

    def test_short_chat_hint_only_if_full_does_not_fit(self):
        code = source("NexusChat.kt")
        self.assertEqual(code.count("placeholder = { NexusAdaptiveMessageHint("), 2)
        self.assertIn("NexusAdaptiveMessageHint(if (light)", code)
        self.assertIn("if (fullWidth + 4.dp <= maxWidth) fullHint else shortHint", code)

    def test_every_locale_has_unique_resources(self):
        for locale in LOCALES:
            directory = ROOT / "app/src/main/res" / locale
            values = ET.parse(directory / "strings.xml").getroot()
            workbench = ET.parse(directory / "workbench.xml").getroot()
            self.assertEqual(len(values.findall("./string[@name='ui_message_hint_short']")), 1, locale)
            self.assertEqual(len(workbench.findall("./string[@name='ws_easy_project_entry']")), 1, locale)
            self.assertEqual(len(workbench.findall("./plurals[@name='ws_easy_project_files']")), 1, locale)
            self.assertIsNotNone(workbench.find("./plurals[@name='ws_easy_project_files']/item[@quantity='other']"), locale)


if __name__ == "__main__":
    unittest.main()
