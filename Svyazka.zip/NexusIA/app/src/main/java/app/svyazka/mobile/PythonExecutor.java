package app.svyazka.mobile;

/** One user-authorized Python invocation; callbacks are supplied by the platform adapter. */
interface PythonExecutor {
    void execute(String code, String stdin);
    /** Explicit user opt-in. Default keeps current sandbox behaviour. */
    default void execute(String code, String stdin, boolean loadMatplotlib) {
        execute(code, stdin);
    }
    default void executeProject(String code, String stdin, org.json.JSONObject files, String entry,
                                String allowedPackage, boolean extended) {
        throw new UnsupportedOperationException("Работа с проектами не поддерживается этим движком.");
    }
    void cancel();
}
