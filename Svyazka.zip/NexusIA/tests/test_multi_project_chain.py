"""Replay the captured provider response, parser and local project runner.
Pure parser methods are compiled unchanged, without Android or org.json.
The full Workflow/JSON handoff contract is in RecoveryChecks.java.
"""
from pathlib import Path
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'
FIXTURE = ROOT / 'tests/fixtures/recovery/observed-expenses-project.md'
COMMENT_FIXTURE = FIXTURE.with_name('observed-expenses-comment-header.md')
ASSETS = ROOT / 'app/src/main/assets/sandbox'


def asset(name):
    spec = importlib.util.spec_from_file_location('nexus_' + name, ASSETS / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def captured_files(fixture=FIXTURE):
    if fixture == COMMENT_FIXTURE:
        files = {path: body for body, path in re.findall(r'^```python\n((?:# file=([^\n]+)\n).*?)^```', fixture.read_text(), re.M | re.S)}
        assert set(files) == {'main.py', 'expenses.py', 'test_expenses.py'}
        return files
    files = {}
    for path, body in re.findall(r'^```file=([^\n]+)\n(.*?)^```', FIXTURE.read_text(), re.M | re.S):
        if body.strip():
            if path in files:
                assert files[path] == body
            files[path] = body
    assert set(files) == {'main.py', 'expenses.py', 'test_expenses.py'}
    return files


class MultiProjectChain(unittest.TestCase):
    @unittest.skipUnless(shutil.which('javac') and shutil.which('java'), 'JDK unavailable')
    def test_real_parser_with_captured_response(self):
        source = (JAVA / 'PythonInputs.java').read_text()
        # Extract the actual parser, not a second implementation of its rules.
        source = re.sub(r'^import org\.json\..*;\n', '', source, flags=re.M)
        start = source.index('    /** Same canonical complete project')
        end = source.index('    public static boolean hasNamedFiles(', start)
        source = source[:start] + source[end:source.index('    public static String copySource(', end)] + source[source.index('    static String withoutMaterials('):source.index('    /** Classify the user')] + '}\n'
        harness = r'''package app.svyazka.mobile;
import java.nio.file.*;
import java.util.*;
public class MultiCheck {
  static void check(boolean ok, String label) {if(!ok)throw new AssertionError(label);}
  static String file(String path,String code){return "```file="+path+"\n"+code+"```\n";}
  public static void main(String[] args)throws Exception {
    String raw=Files.readString(Path.of(args[0]));
    Map<String,String> got=PythonInputs.namedFiles(raw);
    check(got.size()==3,"captured file count");
    check(PythonInputs.hasPythonDelivery(raw),"accept complete package");
    check(PythonInputs.multiPythonProject(raw).equals(got),"same project at validation");
    check(PythonInputs.candidate(raw).parts.size()==3,"exactly three Python sources");
    check(PythonAutoStage.projectRunAllowed("Создай программу учёта расходов на Python из трёх файлов: main.py, expenses.py и test_expenses.py. Реализуй добавление расходов, подсчёт общей суммы и группировку по категориям. Добавь 10 автоматических тестов. Проверь работоспособность всего проекта.\nВ консоли [console]",got),"actual request permits whole-project test");
    check(!PythonAutoStage.projectRunAllowed("Создай программу на Python. Не запускай.",got),"execution prohibited by user");
    check(!PythonAutoStage.projectRunAllowed("Создай программу на Python с тестами.",got),"no inferred permission");
    check(PythonAutoStage.singleSuiteRunAllowed("Создай программу на Python и выполни проверку.","print(1)"),"explicit single suite permission");
    check(!PythonAutoStage.singleSuiteRunAllowed("Создай программу на Python, проверь, но не запускай.","print(1)"),"single suite respects opt out");
    check(!PythonAutoStage.singleSuiteRunAllowed("Создай программу на Python.","print(1)"),"single suite requires explicit run");
    for(var e:got.entrySet()) Files.writeString(Path.of(args[1],e.getKey()),e.getValue());
    String main=file("main.py","print(1)\n"), lib=file("lib.py","x=1\n");
    String project=main+lib;
    check(PythonInputs.namedFiles(project+project).size()==2,"identical duplicate");
    check(PythonInputs.namedFiles(project+file("main.py","")).size()==2,"empty old snapshot");
    check(PythonInputs.namedFiles(project+file("lib.py","x=2\n")).isEmpty(),"conflicting duplicate");
    check(PythonInputs.namedFiles(project+file("LIB.py","x=1\n")).isEmpty(),"case collision");
    check(PythonInputs.namedFiles(project+file("../outside.py","x=1\n")).isEmpty(),"unsafe path");
    check(PythonInputs.namedFiles(project+file("lib.py/child.py","x=1\n")).isEmpty(),"prefix collision");
    check(PythonInputs.namedFiles(project+file("missing.py","")).isEmpty(),"missing source");
    check(PythonInputs.namedFiles(project+"```file=more.py\nprint(2)\n").isEmpty(),"unfinished source");
    check(PythonInputs.namedFiles(project+"```bash\npython main.py\npython -m unittest lib.py\n```\n").size()==2,"launch docs");
    check(PythonInputs.namedFiles(project+"```bash\npython unknown.py\n```\n").isEmpty(),"unrelated commands");
    check(!PythonInputs.hasPythonDelivery("```file=index.html\n<html></html>\n```"),"wrong language");
    check(PythonInputs.candidate(main).code.equals("print(1)\n"),"single source still works");
    String comment="```python\n# file=lib.py\nx=1\n```\n";
    check(PythonInputs.namedFiles(main+comment).get("lib.py").equals("# file=lib.py\nx=1\n"),"comment preserved exactly");
    check(PythonInputs.namedFiles(main+"## `lib.py`\n\n```py\nx=1\n```\n").size()==2,"exact heading");
    check(PythonInputs.namedFiles(main+"```python\n#!/usr/bin/env python3\n# coding: utf-8\n# file: `lib.py`\nx=1\n```\n").size()==2,"header after shebang");
    check(PythonInputs.namedFiles(main+"```python file=lib.py\n# file=other.py\nx=1\n```\n").isEmpty(),"conflicting fence and comment");
    check(PythonInputs.namedFiles(main+"## lib.py\n```python\n# file=other.py\nx=1\n```\n").isEmpty(),"conflicting heading and comment");
    check(PythonInputs.namedFiles(main+"```python\n# file=../secret.py\nx=1\n```\n").isEmpty(),"unsafe comment path");
    check(!PythonInputs.hasPythonDelivery("```python\n# file=../secret.py\nx=1\n```"),"no unsafe single-file fallback");
    check(PythonInputs.candidate("```python\n# file=../secret.py\nx=1\n```").ambiguous,"no unsafe automatic execution");
    check(PythonInputs.namedFiles(main+"```python\nx=1\n# file=lib.py\n```\n").isEmpty(),"late comment is not metadata");
    check(PythonInputs.namedFiles(main+"## lib.py\nExample only:\n```python\nx=1\n```\n").isEmpty(),"heading must be adjacent");
    check(PythonInputs.namedFiles(main+"```python\n# file=lib.py\n# file=other.py\nx=1\n```\n").isEmpty(),"conflicting comments");
    check(PythonInputs.namedFiles(main+"```python\n# file=lib.py\nx=1\n").isEmpty(),"unclosed comment block");
    check(PythonInputs.namedFiles(main+comment+comment).size()==2,"identical commented duplicate");
    check(PythonInputs.namedFiles(main+comment+comment.replace("x=1","x=2")).isEmpty(),"different commented duplicate");
    check(PythonInputs.namedFiles(main+"```python\n# file=MAIN.py\nx=1\n```\n").isEmpty(),"case collision in comment");
    check(PythonInputs.namedFiles(main+comment+"```bash\npython lib.py\n```\n").size()==2,"launch after comment metadata");
    check(PythonInputs.namedFiles(main+"```python\n# file=lib.py\nx=1\n```\n```text\n# file=notes.py\n```\n").isEmpty(),"non-Python comment not delivery");
    String incomplete="```python file=lib.py\nx=";
    var plan=PythonInputs.recoveryPlan(main+incomplete);
    check(plan!=null && plan.complete.size()==1 && plan.unfinished.equals("lib.py"),"partial second file");
    check(PythonInputs.namedFiles(PythonInputs.recoveredDelivery(plan,lib)).equals(PythonInputs.namedFiles(project)),"preserve finished bytes, recover whole file");
    check(PythonInputs.recoveredDelivery(plan,file("lib.py","x=1\n")+file("main.py","print(2)\n")).isEmpty(),"reject changed complete file");
    check(PythonInputs.recoveredDelivery(plan,file("other.py","x=1\n")).isEmpty(),"missing unfinished file");
    check(PythonInputs.recoveredDelivery(plan,"1\n```\n").isEmpty(),"not a full file");
    var first=PythonInputs.recoveryPlan(incomplete);
    check(first!=null && first.complete.isEmpty() && first.unfinished.equals("lib.py"),"first file interrupted");
    check(PythonInputs.namedFiles(PythonInputs.recoveredDelivery(first,lib)).size()==1,"full first file recovered");
    String extended=PythonInputs.extendRecoveryDraft(main+incomplete,lib+"```python file=test_lib.py\nimport lib\n");
    var progress=PythonInputs.recoveryPlan(extended);
    check(progress!=null && progress.complete.size()==2 && progress.unfinished.equals("test_lib.py"),"retain new completed file on second interruption");
    check(PythonInputs.namedFiles(PythonInputs.recoveredDelivery(progress,file("test_lib.py","import lib\n"))).size()==3,"recover third without losing first two");
    check(PythonInputs.extendRecoveryDraft(main+incomplete,file("main.py","print(2)\n")).isEmpty(),"never change preserved bytes");
    check(PythonInputs.recoveryPlan(main+"```file=../secret.py\nx=")==null,"unsafe recovery path");
    String task="Создай программу из трёх файлов: main.py, lib.py и test_lib.py. Проверь.";
    check(PythonInputs.requestedPythonFiles(task).size()==3,"explicit requested paths");
    check(!PythonInputs.requestedFilesPresent(task,project),"missing requested test file");
    check(PythonInputs.requestedFilesPresent(task,project+file("test_lib.py","import lib\n")),"all requested files");
    check(!PythonInputs.sameProjectTests(PythonInputs.namedFiles(project+file("test_lib.py","assert True\n")),PythonInputs.namedFiles(project+file("test_lib.py","assert False\n"))),"frozen tests");
    check(PythonInputs.sameProjectTests(PythonInputs.namedFiles(project+file("test_lib.py","assert True\n")),PythonInputs.namedFiles(main+file("lib.py","x=2\n")+file("test_lib.py","assert True\n"))),"implementation changes permitted");
    String actualTask=Files.readString(Path.of(args[2]));
    check(TaskHistory.retryOnly(TaskHistory.currentUserTestRequest(actualTask).split("\n\n<linked_python_project>")[0]),"captured retry instruction");
    check(PythonAutoStage.projectRunAllowed(TaskHistory.projectExecutionRequest(actualTask),got),"captured retry preserves explicit execution permission");
    String noRun=TaskHistory.followUp("Создай Python программу. Не запускай.",raw,"попробуй ещё раз");
    check(!PythonAutoStage.projectRunAllowed(TaskHistory.projectExecutionRequest(noRun),got),"retry cannot override prohibition");
    String next=TaskHistory.followUp("Создай Python программу. Проверь.",raw,"Не запускай.");
    check(!PythonAutoStage.projectRunAllowed(TaskHistory.projectExecutionRequest(next),got),"new prohibition takes precedence");

    String mixed=Files.readString(Path.of(args[3]));
    String latest=Files.readString(Path.of(args[4]));
    String partial=Files.readString(Path.of(args[5]));
    check(TaskHistory.startsIndependentTask(mixed,latest),"observed same-language new task");
    check(TaskHistory.chatUserMessage(mixed, "", "").equals(latest),"show only latest user text, even without saved previous versions");
    check(TaskHistory.chatUserMessage(latest,latest,"old task").equals(latest),"separate independent message");
    check(TaskHistory.chatUserMessage("old",ChatProjectContext.append("old",Map.of("main.py",new byte[0]),100000),"").equals("old"),"do not show linked sources in user bubble");
    check(TaskHistory.startsIndependentTask(mixed,"Создай программу для сортировки чисел на Python."),"language after subject");
    check(TaskHistory.startsIndependentTask(mixed,"Создай HTML-страницу с часами."),"independent web task");
    check(!TaskHistory.startsIndependentTask(mixed,"Добавь в существующую программу поиск."),"edit remains related");
    check(!TaskHistory.startsIndependentTask(mixed,"Создай на Python тесты для этого проекта."),"component remains related");
    check(!TaskHistory.startsIndependentTask(mixed,"Создай на Python программу на основе предыдущей."),"explicit reference remains related");
    check(!TaskHistory.startsIndependentTask(mixed,"Попробуй ещё раз."),"retry remains related");
    check(TaskHistory.startsIndependentTask(mixed,"Новая задача: создай программу для предыдущего примера."),"explicit new task overrides heuristic");
    String requirements=PythonInputs.withoutMaterials(ChatProjectContext.withoutInlineProject(TaskHistory.forRepair(mixed)));
    check(PythonInputs.requestedPythonFiles(requirements).containsAll(List.of("main.py","expenses.py","test_expenses.py")),"old mixed request demands unrelated files");
    for (int i=6;i<=7;i++) {
      String fallback=Files.readString(Path.of(args[i]));
      String recovered=PythonInputs.recoveredDelivery(PythonInputs.recoveryPlan(partial),fallback);
      Map<String,String> recoveredFiles=PythonInputs.namedFiles(recovered);
      check(recoveredFiles.size()==2 && recoveredFiles.equals(PythonInputs.namedFiles(fallback)),"exact full replacement after first-file interruption");
      check(!PythonInputs.requestedFilesPresent(requirements,recovered),"reproduce rejection by stale file contract");
      check(PythonInputs.requestedFilesPresent(TaskHistory.forRepair(latest),recovered),"new task accepts complete fallback delivery");
      check(PythonInputs.hasPythonDelivery(recovered),"valid recovered source");
      check(PythonAutoStage.projectRunAllowed(latest,recoveredFiles),"explicit execution of alternative entry");
      check(PythonAutoStage.projectEntry(recoveredFiles).equals("password_generator.py"),"unique guarded entry");
      check(!PythonAutoStage.projectRunAllowed(latest+" Не запускай.",recoveredFiles),"prohibition preserved");
      check(!PythonAutoStage.validGeneratedProject(recoveredFiles),"do not replace old main-based saved workspace");
      Map<String,String> ambiguous=new LinkedHashMap<>(recoveredFiles); ambiguous.put("other.py","print(1)\n");
      check(PythonAutoStage.projectEntry(ambiguous).isEmpty(),"no guessed entry from ambiguous project");
    }
    String wrapped=TaskHistory.followUp("Создай проект на Python.",raw,"Добавь новые функции.");
    check(PythonInputs.namedFiles(wrapped).equals(got),"previous named source exact bytes");
    check(!wrapped.contains("```bash"),"previous launch documentation omitted");

  }
}'''
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)
            (p / 'PythonInputs.java').write_text(source)
            (p / 'MultiCheck.java').write_text(harness)
            # Compile the real permission/size gate, omitting only the unrelated
            # single-file edit selector. Use the actual feedback marker constant.
            stage = (JAVA/'PythonAutoStage.java').read_text()
            stage = stage[:stage.index('    static Selection select(')] + '}\n'
            (p/'PythonAutoStage.java').write_text(stage)
            marker = re.search(r'static final String MARKER = [^;]+;', (JAVA/'PythonAutoFeedback.java').read_text()).group()
            feedback=(JAVA/'PythonAutoFeedback.java').read_text()
            is_feedback=feedback[feedback.index('    static boolean isFeedback('):feedback.index('    /** A failed actual sandbox')]
            original=feedback[feedback.index('    static String originalRequirements('):feedback.index('    private static boolean unavailable(')]
            (p/'PythonAutoFeedback.java').write_text('package app.svyazka.mobile; final class PythonAutoFeedback {' + marker + is_feedback + original + '}')
            task_limit=re.search(r'static final int TASK_LIMIT = [^;]+;', (JAVA/'Workflow.java').read_text()).group()
            (p/'Workflow.java').write_text('package app.svyazka.mobile; final class Workflow {'+task_limit+'}')
            observed=json.loads((FIXTURE.parent/'observed-review-interruption.json').read_text())
            (p/'observed-task.txt').write_text(observed['task'])
            independent=json.loads((FIXTURE.parent/'observed-independent-password.json').read_text())
            (p/'mixed.txt').write_text(independent['task'])
            latest=independent['user_test_input'].split('\n\n')[-1]
            (p/'latest.txt').write_text(latest)
            (p/'partial.txt').write_text(independent['draft']['text'])
            for i, attempt in enumerate(independent['draft']['preceding_sources']):
                (p/f'fallback{i}.txt').write_text(attempt['text'])
            subprocess.run(['javac','-encoding','UTF-8','-d',tmp,str(p/'PythonInputs.java'),str(p/'MultiCheck.java'),str(p/'PythonAutoStage.java'),str(p/'PythonAutoFeedback.java'),str(JAVA/'PythonProjectPaths.java'),str(JAVA/'ContinuationIntegrity.java'),str(JAVA/'TaskHistory.java'),str(JAVA/'ChatProjectContext.java'),str(p/'Workflow.java')],check=True)
            for fixture in (FIXTURE, COMMENT_FIXTURE):
                with self.subTest(fixture=fixture.name):
                    subprocess.run(['java','-cp',tmp,'app.svyazka.mobile.MultiCheck',str(fixture),tmp,str(p/'observed-task.txt'),str(p/'mixed.txt'),str(p/'latest.txt'),str(p/'partial.txt'),str(p/'fallback0.txt'),str(p/'fallback1.txt')],check=True)
                    for name, body in captured_files(fixture).items():
                        self.assertEqual((p/name).read_bytes(),body.encode())

    def test_syntax_every_file_not_execution(self):
        grader = asset('verify')
        files = captured_files()
        def check(sources):
            return json.loads(grader.verify_request(json.dumps({'project_sources':sources,'reason':'syntax only'})))
        for fixture in (FIXTURE, COMMENT_FIXTURE):
            good = check(captured_files(fixture))
            self.assertEqual(good['status'],'LIMITED')
            self.assertTrue(good['syntax'])
            self.assertFalse(good['ran'])
            self.assertEqual(good['total'],0)
        bad = check(dict(files, **{'expenses.py':'def broken('}))
        self.assertEqual(bad['status'],'ERROR')
        self.assertIn('expenses.py',bad['diagnostic'])
        self.assertFalse(bad['ran'])

    def test_generated_suite_actual_and_failure(self):
        ws = asset('workspace')
        cwd, old_path = Path.cwd(), list(sys.path)
        with tempfile.TemporaryDirectory() as tmp:
            ws.ROOT = Path(tmp)/'workspace'
            try:
                for fixture in (FIXTURE, COMMENT_FIXTURE):
                    ws.reset_workspace({k:v.encode() for k,v in captured_files(fixture).items()})
                    result = ws.run_generated_tests()
                    self.assertEqual(result, dict(status='PASSED',discovered=10,ran=10,passed=10,failed=0,skipped=0))
                    for name,module in list(sys.modules.items()):
                        if str(getattr(module,'__file__','')).startswith(str(ws.ROOT)+'/'):
                            sys.modules.pop(name,None)
                ws.reset_workspace({'main.py':b'print(1)', 'test_bad.py':b'import unittest\nclass T(unittest.TestCase):\n def test_bad(self): self.assertEqual(1,2)\n'})
                result = ws.run_generated_tests()
                self.assertEqual((result['status'],result['failed'],result['passed']),('FAILED',1,0))
                ws.reset_workspace({'main.py':b'print(1)'})
                self.assertEqual(ws.run_generated_tests()['status'],'LIMITED')
            finally:
                os.chdir(cwd)
                sys.path[:] = old_path
                for name,module in list(sys.modules.items()):
                    if str(getattr(module,'__file__','')).startswith(str(ws.ROOT)+'/'):
                        sys.modules.pop(name,None)
