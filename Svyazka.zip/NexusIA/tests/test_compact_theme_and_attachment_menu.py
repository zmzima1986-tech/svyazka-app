"""Source contracts for matching 120% settings layouts and compact attachment menu."""
import unittest
from pathlib import Path

UI = Path(__file__).resolve().parents[1] / 'app/src/main/java/app/svyazka/mobile/ui'

class CompactThemeAndAttachmentMenuTest(unittest.TestCase):
    def test_theme_buttons_have_one_shared_layout_rule(self):
        shared = (UI / 'NexusSettingsLayout.kt').read_text(encoding='utf-8')
        self.assertIn('val buttonWidth = (availableWidth - 16.dp) / 3', shared)
        self.assertIn('buttonWidth >= 86.dp * fontScale', shared)
        for filename in ('NexusLightSettings.kt', 'NexusDarkSettings.kt'):
            source = (UI / filename).read_text(encoding='utf-8')
            self.assertIn('nexusThemeChoicesInOneRow(maxWidth, LocalDensity.current.fontScale)', source)
            self.assertIn('contentPadding = PaddingValues(horizontal = 15.dp', source)
            self.assertIn('Arrangement.spacedBy(8.dp)', source)
        self.assertNotIn('290.dp * LocalDensity.current.fontScale',
            (UI / 'NexusLightSettings.kt').read_text(encoding='utf-8'))

    def test_attachment_uses_first_menu_appearance_and_anchors_all_composers(self):
        chat = (UI / 'NexusChat.kt').read_text(encoding='utf-8')
        attachment = (UI / 'NexusAttachments.kt').read_text(encoding='utf-8')
        self.assertEqual(chat.count('attachAction.menu()'), 3)
        self.assertEqual(chat.count('val attachAction = rememberAttachFileAction(ui)'), 3)
        self.assertIn('onDismissRequest = { open = false }', attachment)
        self.assertNotIn('usePlatformDefaultWidth', attachment)
        self.assertIn('camera.launch(', attachment)
        self.assertIn('photos.launch(', attachment)
        self.assertIn('documents.launch(', attachment)
        self.assertIn('return NexusAttachFileAction(', attachment)

if __name__ == '__main__':
    unittest.main()
