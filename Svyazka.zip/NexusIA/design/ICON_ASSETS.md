# Ресурсы иконок Nexus AI 0.7.0 — Minimal Hi-Tech

- **Фирменный знак:** `app/src/main/res/drawable/ic_nia_logo.png`, `drawable-night/ic_nia_logo.png` — три цветных плоских слоя (циан, синий, фиолетовый).
- **Неизвестная модель:** `app/src/main/res/drawable/ic_nia_models.png` — тот же плоский символ, без устаревшей 3D-стопки.
- **Интерфейсные значки:** `drawable/ic_nia_*.xml` — лёгкие монохромные VectorDrawable, цвет задаёт тема Compose.
- **Бренды провайдеров:** `drawable-nodpi/ic_provider_*.png` и отдельные ночные варианты — сохранены и не перекрашиваются.
- **Системная иконка Android:** `mipmap-anydpi-v26/ic_launcher.xml`, `ic_launcher_round.xml`; для старых/альтернативных лаунчеров — `mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher*.png`.
- **Источник адаптивной иконки:** `drawable-nodpi/ic_nia_launcher_foreground.png` и `drawable/ic_nia_launcher_background.xml`.

`AndroidManifest.xml` ссылается на `@mipmap/ic_launcher` и `@mipmap/ic_launcher_round`. Иконка — цветной знак на чёрном фоне, **без надписи**. Доступность светлой и тёмной темы проверяется отдельно, фирменные цвета не меняются.

Исторические 3D-иконки, неиспользуемые PNG и листы иконок исключены из исходного ZIP. Прежний скрипт их нарезки удалён. Работающие логотипы внешних сервисов не удалялись.

Проверка без Android SDK: `python scripts/check-resources.py`. Полноценный рендер лаунчера и интерфейса нужно подтвердить сборкой APK на Android.

## Единое имя и варианты логотипа

- Официальная подпись для интерфейса, меню и launcher label: **Nexus AI**.
- `design/Nexus_AI_logo_dark.png` — логотип на чёрном фоне.
- `design/Nexus_AI_logo_light.png` — логотип на белом фоне.
- Рабочие значки Android остаются без текста: переименовывать идентификаторы `ic_nia_*`, `Theme.NexusIA` и пакет `app.svyazka.mobile` нельзя без миграции.
- Во время запуска Android 12+ использует системную заставку, затем Compose показывает брендированный экран в текущей теме приложения; системная тема управляет самым ранним кадром до чтения настроек.
