package app.svyazka.mobile.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Dark-only implementation tokens from Nexus_AI_4_Dark_Screens_Complete_TZ.zip.
 *  The supplied ARGB values are design targets reconstructed from reference PNGs.
 *  None of these tokens are applied to the light theme or legacy left drawer.
 */
internal object NexusDarkDesign {
    val background = Color(0xFF070D19)
    val chatBackground = Color(0xFF040D1E)
    val settingsBackground = Color(0xFF000E23)
    val surface = Color(0xD90E1727)
    val raised = Color(0xD91C2C43)
    val console = Color(0xE8060D19)
    val editor = Color(0xE8051120)
    val border = Color(0xFF7D8FA5)
    val subtleBorder = Color(0x647D8FA5)
    val focusBorder = Color(0xFF00B8D8)
    val text = Color.White
    val secondaryText = Color(0xFFC8CDD8)
    val mutedText = Color(0xFFC8CBD5)
    val cyan = Color(0xFF12DAEA)
    val blue = Color(0xFF078CFB)
    val purple = Color(0xFF7B30FC)
    val success = Color(0xFF0BEA21)
    val error = Color(0xFFFF5B65)
    val disabled = Color(0xFF263044)
    val disabledText = Color(0xFF9299A7)
    val folder = Color(0xFFFFD76B)
    val solidBlue = Color(0xFF087EFA)
    val plus = Color(0xFF00F020)
    val settingsMoon = Color(0xFFFFE000)
    val settingsBlue = Color(0xFF078CFB)
    val chatGlass = Color(0xB30C1A2C)
    val workspaceGlass = Color(0xD90E1727)
    val settingsGlass = Color(0xCA03152D)
    val modalGlass = Color(0xEC0B1425)
    val chatBorder = Color(0x647D8FA5)
    val settingsBorder = Color(0xB200B6DC)
    val workspaceBorder = Color(0x9900B8D8)
    val modalBorder = Color(0x6B2D83A6)

    val primaryGradient = Brush.horizontalGradient(
        0f to Color(0xFF2487FC), .5f to Color(0xFF6B51FA), 1f to Color(0xFF9D37FC))
    val runGradient = primaryGradient
    // For chat and workspace tabs the approved selected state is SOLID blue.
    val selectedGradient = Brush.horizontalGradient(listOf(solidBlue, solidBlue))
    val sendGradient = Brush.linearGradient(listOf(Color(0xFF00B7FD), Color(0xFF6543FC)))
    val settingsSelection = Brush.horizontalGradient(
        0f to Color(0xFF008AFD), .5f to Color(0xFF3766FE), 1f to Color(0xFF7B30FC))
}

internal enum class NexusDarkScene { CHAT, SETTINGS, WORKSPACE }

/** Subtle backgrounds do not cover or intercept the translucent glass layers. */
@Composable
internal fun NexusDarkBackdrop(
    modifier: Modifier = Modifier,
    scene: NexusDarkScene = NexusDarkScene.CHAT
) {
    val gradient = when (scene) {
        NexusDarkScene.CHAT -> Brush.verticalGradient(listOf(
            Color(0xFF040B19), NexusDarkDesign.chatBackground, Color(0xFF041026)))
        NexusDarkScene.SETTINGS -> Brush.verticalGradient(listOf(
            Color(0xFF000B1B), NexusDarkDesign.settingsBackground, Color(0xFF061123)))
        NexusDarkScene.WORKSPACE -> Brush.verticalGradient(listOf(
            Color(0xFF070D19), Color(0xFF080F20), Color(0xFF060C18)))
    }
    Box(modifier.background(gradient))
}
