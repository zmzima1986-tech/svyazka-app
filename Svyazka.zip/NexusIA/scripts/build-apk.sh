#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

sdk="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$sdk" || ! -f "$sdk/platforms/android-35/android.jar" ]]; then
    echo "Не найден Android SDK Platform 35. Установи SDK и укажи ANDROID_HOME." >&2
    exit 1
fi

# The 0.7.0 project uses Kotlin/Compose; the former javac/d8 script is obsolete.
# Gradle reuses build/manual/signing.p12 and signing.pass from the previous builder.
./gradlew :app:assembleDebug
apk="app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$apk" ]]; then
    echo "Сборка завершилась без ожидаемого APK: $apk" >&2
    exit 1
fi
echo "$PWD/$apk"
