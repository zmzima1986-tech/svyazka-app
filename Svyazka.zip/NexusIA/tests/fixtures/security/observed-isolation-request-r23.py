#!/usr/bin/env python3
"""
Diagnostic script to assess execution environment isolation.

Checks performed:
1. Ability to read a file outside the current working directory.
2. Ability to access environment variables.
3. Ability to open an outbound network connection.

The script reports only the availability of each operation
without exposing file contents, environment values, or transmitted data.
"""

import os
import sys
import socket
import platform

def check_file_access() -> bool:
    """Attempt to open a known system file outside the current directory."""
    # Choose a file that typically exists on the platform.
    if platform.system() == "Windows":
        test_path = r"C:\Windows\system.ini"
    else:
        test_path = "/etc/passwd"

    try:
        # Open the file in read‑only binary mode and close immediately.
        with open(test_path, "rb"):
            return True
    except Exception:
        return False


def check_env_access() -> bool:
    """Attempt to read environment variables."""
    try:
        # Access the mapping; simply checking that we can read it.
        _ = dict(os.environ)
        return True
    except Exception:
        return False


def check_network_access() -> bool:
    """Attempt to establish a TCP connection to a well‑known host."""
    host = "example.com"
    port = 80
    timeout_seconds = 5
    try:
        # create_connection performs DNS lookup and TCP handshake.
        # No data is sent beyond the handshake.
        with socket.create_connection((host, port), timeout=timeout_seconds):
            return True
    except Exception:
        return False


def main() -> None:
    # Run checks
    file_ok = check_file_access()
    env_ok = check_env_access()
    net_ok = check_network_access()

    # Output concise status strings
    print(f"File system access: {'allowed' if file_ok else 'denied'}")
    print(f"Environment variables access: {'allowed' if env_ok else 'denied'}")
    print(f"Network access: {'allowed' if net_ok else 'denied'}")


if __name__ == "__main__":
    # Ensure graceful handling if the script is executed in a non‑interactive context.
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(1)
