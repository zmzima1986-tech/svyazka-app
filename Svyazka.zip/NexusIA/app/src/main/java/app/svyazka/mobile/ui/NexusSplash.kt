package app.svyazka.mobile.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.svyazka.mobile.R

/**
 * A lightweight launch surface displayed only until Compose draws the first ready UI frame.
 * Progress is deliberately indeterminate: startup contains no measurable percentage.
 * The platform splash remains responsible for time spent restoring persisted state.
 */
@Composable
fun NexusSplashScreen() {
    val background = MaterialTheme.colorScheme.background
    val dark = background == Color.Black
    Box(Modifier.fillMaxSize().background(background)) {
        // The wave stays below the usable area, matching the approved logo concept.
        Canvas(Modifier.fillMaxWidth().height(220.dp).align(Alignment.BottomCenter)) {
            val w = size.width
            val h = size.height
            val rear = Path().apply {
                moveTo(0f, h * .42f)
                cubicTo(w * .18f, h * .08f, w * .31f, h * .88f, w * .52f, h * .52f)
                cubicTo(w * .72f, h * .18f, w * .84f, h * .56f, w, h * .22f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            val front = Path().apply {
                moveTo(0f, h * .70f)
                cubicTo(w * .18f, h * .40f, w * .35f, h * .99f, w * .59f, h * .70f)
                cubicTo(w * .82f, h * .42f, w * .90f, h * .70f, w, h * .48f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            val rearColors = if (dark) {
                listOf(NexusCyan.copy(alpha = .22f), NexusBlue.copy(alpha = .34f), NexusPurple.copy(alpha = .12f))
            } else {
                listOf(NexusCyan.copy(alpha = .12f), NexusBlue.copy(alpha = .20f), NexusPurple.copy(alpha = .06f))
            }
            val frontColors = if (dark) {
                listOf(NexusBlue.copy(alpha = .14f), NexusCyan.copy(alpha = .30f))
            } else {
                listOf(NexusBlue.copy(alpha = .13f), NexusCyan.copy(alpha = .09f))
            }
            drawPath(rear, Brush.linearGradient(rearColors, start = Offset.Zero, end = Offset(w, h)))
            drawPath(front, Brush.linearGradient(frontColors, start = Offset(0f, h), end = Offset(w, 0f)))
        }
        Column(Modifier.align(Alignment.Center).padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            NexusBrandMark(Modifier.size(132.dp))
            Spacer(Modifier.height(18.dp))
            Text(stringResource(R.string.app_name), color = MaterialTheme.colorScheme.onBackground,
                fontSize = 34.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            // There is intentionally no "ИИ-платформа" subtitle on the launch screen.
            Spacer(Modifier.height(54.dp))
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(.78f).height(6.dp).clip(RoundedCornerShape(10.dp)),
                color = if (dark) NexusCyan else NexusBlue,
                trackColor = if (dark) Color(0xFF233548) else Color(0xFFDCE5F0)
            )
            Spacer(Modifier.height(14.dp))
            Text(stringResource(R.string.ui_loading), color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium)
        }
    }
}
