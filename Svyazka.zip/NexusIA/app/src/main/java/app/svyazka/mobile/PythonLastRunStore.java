package app.svyazka.mobile;

import android.content.Context;
import android.util.AtomicFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.json.JSONException;
import org.json.JSONObject;

/** The most recent manual Python report. Files are private and keyed by chat ID. */
final class PythonLastRunStore {
    private final File root;
    PythonLastRunStore(Context context) { root = new File(context.getFilesDir(), "python-last-runs"); }
    private AtomicFile file(long taskId) {
        if (taskId <= 0) throw new IllegalArgumentException("Неверный чат.");
        return new AtomicFile(new File(root, "chat-" + taskId + ".json"));
    }
    synchronized void save(long taskId, SandboxClient.Result result) throws IOException {
        if (taskId <= 0) return;
        JSONObject json = new JSONObject();
        try {
            json.put("engine", result.engine).put("stdout", result.stdout)
                .put("stderr", result.stderr).put("status", result.status)
                .put("exit", result.exitCode == null ? JSONObject.NULL : result.exitCode)
                .put("html", result.html).put("png", result.pngBase64)
                .put("artifacts", result.artifacts).put("tests", result.tests)
                .put("sha256", result.snapshotSha256);
        } catch (JSONException e) { throw new IOException(e); }
        byte[] content = json.toString().getBytes(StandardCharsets.UTF_8);
        if (content.length > 2_600_000) throw new IOException("Отчёт превышает лимит.");
        if (!root.isDirectory() && !root.mkdirs()) throw new IOException("Не удалось открыть каталог отчётов.");
        AtomicFile target = file(taskId);
        FileOutputStream stream = null;
        try {
            stream = target.startWrite();
            stream.write(content);
            target.finishWrite(stream);
        } catch (IOException | RuntimeException e) {
            if (stream != null) target.failWrite(stream);
            throw new IOException("Не удалось сохранить отчёт.", e);
        }
    }
    synchronized SandboxClient.Result load(long taskId) {
        if (taskId <= 0) return null;
        File base = file(taskId).getBaseFile();
        if (!base.exists() && !new File(base.getPath() + ".bak").exists()) return null;
        try {
            byte[] bytes = file(taskId).readFully();
            if (bytes.length > 2_600_000) return null;
            JSONObject json = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
            return new SandboxClient.Result(json.optString("stdout"),json.optString("stderr"),
                json.optString("engine"),json.isNull("exit")?null:json.getInt("exit"),
                json.optString("status"),json.optString("html"),json.optString("png"),
                json.optJSONArray("artifacts"),json.optJSONArray("tests"),json.optString("sha256"));
        } catch (Exception e) { return null; }
    }
    synchronized void deleteTask(long taskId) { if (taskId > 0) file(taskId).delete(); }
}
