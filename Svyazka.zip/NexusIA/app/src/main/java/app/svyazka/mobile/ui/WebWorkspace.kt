package app.svyazka.mobile.ui

import android.annotation.SuppressLint
import android.webkit.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import app.svyazka.mobile.PythonInputs
import app.svyazka.mobile.R
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream

private data class WebJob(val source: String, val kind: String, val render: Boolean)

@Composable
internal fun WebWorkspace(ui: NexusComposeUi) {
    val context = LocalContext.current
    val kinds = listOf("html", "javascript", "css")
    val detected = remember(ui.snapshot.result) {
        kinds.map { it to PythonInputs.webSource(ui.snapshot.result, it) }.firstOrNull { it.second.isNotBlank() }
    }
    var replace by remember { mutableStateOf(false) }
    var job by remember(ui.webCode, ui.webKind) { mutableStateOf<WebJob?>(null) }
    var report by remember(job) { mutableStateOf("") }
    val name = when (ui.webKind) { "html" -> "index.html"; "javascript" -> "main.js"; else -> "style.css" }
    val save = rememberSaveResultAction(ui.webCode, name)
    fun importSource() { detected?.let { (kind, source) -> ui.selectWebKind(kind); ui.editWeb(source) } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        NexusLabel(stringResource(R.string.web_scope))
        Row { kinds.forEach { kind ->
            TextButton(onClick = { ui.selectWebKind(kind) }, enabled = kind != ui.webKind) {
                Text(if (kind == "javascript") "JS" else kind.uppercase())
            }
        } }
        if (detected != null) TextButton(onClick = {
            if (ui.webCode.isNotBlank() && ui.webCode != detected.second) replace = true else importSource()
        }) { Text(stringResource(R.string.load_answer)) }
        OutlinedTextField(ui.webCode, { if (it.length <= 160_000) ui.editWeb(it) }, Modifier.fillMaxWidth(),
            minLines = 4, maxLines = 12, label = { Text(name) },
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
        TextButton(onClick = save, enabled = ui.webCode.isNotBlank()) { Text(stringResource(R.string.action_save_file)) }
        if (ui.webCode.isNotBlank() && ui.webKind != "css") {
            OutlinedButton(onClick = { job = WebJob(ui.webCode, ui.webKind, false) }) { Text(stringResource(R.string.web_check)) }
            if (ui.webKind == "html") OutlinedButton(onClick = { job = WebJob(ui.webCode, ui.webKind, true) }) {
                Text(stringResource(R.string.web_preview))
            }
        }
        if (report.isNotEmpty()) SelectionContainer { Text(report, style = MaterialTheme.typography.bodySmall) }
        job?.let { active -> key(active) {
            WebSurface(active, Modifier.fillMaxWidth().height(if (active.render) 360.dp else 1.dp)) {
                report = it
            }
        } }
        if (ui.snapshot.result.isNotBlank() && detected == null) {
            SelectionContainer { NexusMarkdown(ui.snapshot.result) }
        }
    }
    if (replace) AlertDialog(onDismissRequest = { replace = false }, title = { Text(stringResource(R.string.editor_replace)) },
        confirmButton = { TextButton(onClick = { replace = false; importSource() }) { Text(stringResource(R.string.action_continue)) } },
        dismissButton = { TextButton(onClick = { replace = false }) { Text(stringResource(R.string.action_cancel)) } })
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun WebSurface(job: WebJob, modifier: Modifier, onChecked: (String) -> Unit) {
    val callback by rememberUpdatedState(onChecked)
    AndroidView(modifier = modifier, factory = { context ->
        createWebPreview(context, job.source, job.kind, job.render) { callback(it) }
    }, onRelease = { it.stopLoading(); it.destroy() }, update = {})
}

private const val PAGE = "https://nexus-workspace.invalid/shell.html"

@SuppressLint("SetJavaScriptEnabled")
fun createWebPreview(context: android.content.Context, source: String, kind: String, render: Boolean,
                     report: (String) -> Unit): WebView =
    makeWebPreview(context, source, kind, render, null, {}, report)

fun inspectWebFile(context: android.content.Context, source: String, kind: String,
                   required: JSONArray, onParsed: java.util.function.Consumer<JSONObject>): WebView =
    makeWebPreview(context, source, kind, false, required, { onParsed.accept(it) }, {})

private fun makeWebPreview(context: android.content.Context, source: String, kind: String, render: Boolean,
                           required: JSONArray?, onParsed: (JSONObject) -> Unit, report: (String) -> Unit): WebView {
    fun asset(name: String) = context.assets.open("web/$name").bufferedReader().use { it.readText() }
    val shell = asset("shell.html").replace("/*PARSER*/", asset("acorn.js")).replace("/*CONTROLLER*/", asset("controller.js"))
        .toByteArray(Charsets.UTF_8)
    return WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.domStorageEnabled = false
            settings.blockNetworkLoads = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.setGeolocationEnabled(false)
            settings.setSupportMultipleWindows(false)
            settings.javaScriptCanOpenWindowsAutomatically = false
            isLongClickable = false
            setDownloadListener { _, _, _, _, _ -> }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) { request.deny() }
                override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                    callback.invoke(origin, false, false)
                }
                override fun onJsAlert(view: WebView, url: String, message: String, response: JsResult): Boolean {
                    response.cancel(); return true
                }
                override fun onJsConfirm(view: WebView, url: String, message: String, response: JsResult): Boolean {
                    response.cancel(); return true
                }
                override fun onJsPrompt(view: WebView, url: String, message: String, defaultValue: String?, response: JsPromptResult): Boolean {
                    response.cancel(); return true
                }
            }
            webViewClient = object : WebViewClient() {
                private var loaded = false
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    return request.url.toString() != PAGE &&
                        (request.isForMainFrame || request.url.scheme != "about")
                }
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    if (request.isForMainFrame && request.url.toString() == PAGE && request.method == "GET")
                        return WebResourceResponse("text/html", "UTF-8", ByteArrayInputStream(shell))
                    if (request.url.scheme == "about" || request.url.scheme == "data") return null
                    return WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(byteArrayOf()))
                }
                override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                    report(context.getString(R.string.web_render_failed))
                    if (required != null) onParsed(JSONObject().put("status","UNAVAILABLE"))
                    else {
                        (view.parent as? android.view.ViewGroup)?.removeView(view)
                        view.destroy()
                    }
                    return true
                }
                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) report(context.getString(R.string.web_load_failed) + " (" + error.errorCode + ")")
                }
                override fun onPageFinished(view: WebView, url: String) {
                    if (loaded || url != PAGE) return
                    loaded = true
                    val args = JSONObject.quote(source) + "," + JSONObject.quote(kind)
                    view.evaluateJavascript("inspectSource($args)") { raw ->
                        val data = runCatching { JSONObject(JSONTokener(raw).nextValue() as String) }.getOrNull()
                        if (data == null) { report(context.getString(R.string.web_check_error)); return@evaluateJavascript }
                        if (required != null && kind == "html" && data.getJSONArray("issues").length() == 0 && required.length() > 0) {
                            view.evaluateJavascript("startWidgetChecks(" + JSONObject.quote(source) + "," + required + ")") {
                                awaitTests(view, data, 0)
                            }
                        } else onParsed(data)
                        val lines = mutableListOf(context.getString(R.string.web_counts, data.getInt("checked"), data.getInt("external")))
                        val issues = data.getJSONArray("issues")
                        for (i in 0 until issues.length()) lines += issues.getString(i)
                        val names = data.optJSONArray("resources")
                        if (names != null) for (i in 0 until names.length()) lines += names.getString(i)
                        if (data.optBoolean("network")) lines += context.getString(R.string.web_offline)
                        if (data.optBoolean("bluetooth")) lines += context.getString(R.string.web_ble)
                        val summary = lines.joinToString("\n")
                        report(summary)
                        if (render && issues.length() == 0) {
                            view.evaluateJavascript("renderSource($args)") { created ->
                                if (created != "true") report(summary + "\n" + context.getString(R.string.web_render_failed))
                                else awaitFrame(view, 0, summary)
                            }
                        }
                    }
                }

                private fun awaitTests(view: WebView, data: JSONObject, attempt: Int) {
                    view.postDelayed({
                        if (view.isAttachedToWindow) view.evaluateJavascript("window.nexusTestResult") { raw ->
                            val results = runCatching { JSONArray(raw) }.getOrNull()
                            when {
                                results != null -> onParsed(data.put("tests", results))
                                attempt < 44 -> awaitTests(view, data, attempt + 1)
                                else -> onParsed(data.put("tests_unavailable", true))
                            }
                        }
                    }, 200)
                }

                private fun awaitFrame(view: WebView, attempt: Int, summary: String) {
                    view.postDelayed({
                        if (view.isAttachedToWindow) view.evaluateJavascript("window.previewLoaded === true") { loaded ->
                            when {
                                loaded == "true" -> report(summary + "\n" + context.getString(R.string.web_rendered))
                                attempt < 35 -> awaitFrame(view, attempt + 1, summary)
                                else -> report(summary + "\n" + context.getString(R.string.web_render_failed))
                            }
                        }
                    }, 250)
                }
            }
            loadUrl(PAGE)
    }
}
