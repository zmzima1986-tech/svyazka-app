#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

out="$PWD/build/jvm-tests"
mkdir -p "$out"
json_jar="${JSON_JAR:-$out/json-20250107.jar}"
sha=85d4c1ab192d3117fd02c7fff1ec0fe63ade45cf56def7fe950ef060cf06e99f
verify_jar() {
    if command -v sha256sum >/dev/null; then
        sha256sum "$1" | awk '{print $1}'
    else
        shasum -a 256 "$1" | awk '{print $1}'
    fi
}
if [[ ! -f "$json_jar" ]]; then
    if [[ -n "${JSON_JAR:-}" ]]; then
        echo "Файл JSON_JAR не найден: $json_jar" >&2
        exit 1
    fi
    tmp="$(mktemp "$out/json.XXXXXX")"
    trap 'rm -f "$tmp"' EXIT
    curl --fail --silent --show-error --location --connect-timeout 15 --max-time 45 \
        https://repo.maven.apache.org/maven2/org/json/json/20250107/json-20250107.jar -o "$tmp"
    [[ "$(verify_jar "$tmp")" = "$sha" ]]
    mv "$tmp" "$json_jar"
fi
if [[ "$(verify_jar "$json_jar")" != "$sha" ]]; then
    echo "Ожидается org.json 20250107 с контрольной суммой $sha" >&2
    exit 1
fi
javac="${JAVA_HOME:+$JAVA_HOME/bin/}javac"
java="${JAVA_HOME:+$JAVA_HOME/bin/}java"
src="app/src/main/java/app/svyazka/mobile"
sources=("$src"/{Workflow,PlainTextPromptPolicy,ModelClient,ModelCatalog,ModelPool,SandboxClient,WorkspaceStore,RequestFailure,ContinuationIntegrity,RequestExecutor,AttemptJournal,CredentialStore,PythonExecutor,TaskHistory,NexusState,NexusPythonReport,AttachmentProblem,AttachmentParser,InputMaterial,PythonInputs,PythonVerification,VerificationMemory,AutonomyQuotaGuard,PromptContextOptimizer,ChatProjectContext,PythonAutoFeedback,PythonAutoTests,PythonAutoRepair,PythonAutoStage,PythonChatFile,PythonProjectPaths,ProviderQuota}.java)
"$javac" -encoding UTF-8 -cp "$json_jar" -d "$out" "${sources[@]}" tests/jvm/*.java tests/AutonomyQuotaGuardChecks.java app/src/androidTest/java/app/svyazka/fixture/ModelRecoveryProbe.java
status=0
run_check() {
    printf '\n=== %s ===\n' "$1"
    if "$java" -ea -cp "$json_jar:$out" "$@"; then
        printf '%s: PASS\n' "$1"
    else
        code=$?
        printf '%s: FAIL (exit %s)\n' "$1" "$code" >&2
        status=1
    fi
}
run_check app.svyazka.mobile.WorkflowChecks tests/fixtures/openrouter-models.json
run_check app.svyazka.mobile.FeatureChecks
run_check app.svyazka.mobile.StabilityChecks
run_check app.svyazka.mobile.ReleaseChecks
run_check app.svyazka.mobile.HistoryChecks
run_check app.svyazka.mobile.VisualProtocolChecks
run_check app.svyazka.mobile.NexusStateChecks
run_check app.svyazka.mobile.AttachmentChecks
run_check app.svyazka.mobile.VerificationChecks
run_check app.svyazka.mobile.RecoveryChecks
run_check app.svyazka.mobile.AutonomyQuotaGuardChecks
run_check app.svyazka.fixture.ModelRecoveryProbe
exit "$status"
