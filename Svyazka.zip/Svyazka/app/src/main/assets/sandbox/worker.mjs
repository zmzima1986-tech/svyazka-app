import { loadPyodide } from './pyodide/pyodide.mjs';

const outputLimit = 24000;
const pythonRunner = `
import sys, traceback

def _run(source):
    namespace = {"__name__": "__main__", "__file__": "main.py"}
    try:
        exec(compile(source, "main.py", "exec"), namespace)
    except SystemExit as error:
        if error.code is None:
            return 0
        if isinstance(error.code, int):
            return error.code % 256
        print(error.code, file=sys.stderr)
        return 1
    except BaseException as error:
        traceback.print_exception(type(error), error, error.__traceback__.tb_next)
        return 1
    return 0

_run
`;

self.addEventListener('message', async (event) => {
    const port = event.ports[0];
    try {
        const python = await loadPyodide({
            jsglobals: Object.create(null),
        });
        const engine = 'На телефоне · Python ' + python.runPython('import sys; sys.version.split()[0]');
        port.onmessage = ({ data }) => execute(python, data, port);
        port.postMessage({ kind: 'ready', engine });
    } catch (error) {
        port.postMessage({ kind: 'error', error: 'Ошибка запуска Python: ' + String(error).slice(0, 500) });
    }
}, { once: true });

function execute(python, { code, stdin }, port) {
    let stdout = '';
    let stderr = '';
    let truncated = false;
    let lastReport = 0;
    const outDecoder = new TextDecoder();
    const errDecoder = new TextDecoder();
    const lines = stdin === '' ? [] : stdin.replace(/\r\n/g, '\n').split('\n');
    if (lines.length && lines[lines.length - 1] === '' && stdin.endsWith('\n')) lines.pop();
    let line = 0;
    python.setStdin({ stdin: () => line < lines.length ? lines[line++] : null });

    function report() {
        const now = performance.now();
        if (now - lastReport < 200) return;
        lastReport = now;
        port.postMessage({ kind: 'output', stdout, stderr });
    }

    function append(value, buffer, decoder) {
        if (value.length >= outputLimit) {
            truncated = true;
            return value;
        }
        const text = value + decoder.decode(buffer, { stream: true });
        if (text.length > outputLimit) truncated = true;
        return text.slice(0, outputLimit);
    }

    python.setStdout({ write: (buffer) => {
        stdout = append(stdout, buffer, outDecoder);
        report();
        return buffer.length;
    } });
    python.setStderr({ write: (buffer) => {
        stderr = append(stderr, buffer, errDecoder);
        report();
        return buffer.length;
    } });

    let runner;
    let exit;
    try {
        runner = python.runPython(pythonRunner);
        exit = runner(code);
    } catch (error) {
        stderr = (stderr + '\n' + String(error)).slice(0, outputLimit);
        exit = 1;
    } finally {
        if (runner) runner.destroy();
    }
    port.postMessage({
        kind: 'done',
        stdout: (stdout + outDecoder.decode()).slice(0, outputLimit),
        stderr: (stderr + errDecoder.decode()).slice(0, outputLimit),
        code: exit,
        status: truncated ? 'Показано до 24 000 символов каждого потока.' : '',
    });
}
