"""Static contracts for the Android artifact probe; they do not execute Android."""
from pathlib import Path
import importlib.util
import tempfile
import sys
import os
import xml.etree.ElementTree as ET
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


class AndroidArtifactContract(unittest.TestCase):
    def test_android_probe_covers_python_only_artifact_lifecycle(self):
        source = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/PythonHistoryProbe.java').read_text()
        for required in (
            'startActivitySync', 'ui(activity)', 'compose.addPythonFile(FILE)',
            'compose.editPython(SOURCE)', 'nexusPythonFlushPending()',
            'activity.nexusCreateTask()', 'activity.nexusOpenArtifacts()',
            'activity.nexusOpenArtifact(firstProject.get())',
            'activity.nexusArtifactId()', 'compose.getPythonFileList()',
            'activity.nexusDeleteArtifact(first)', 'credentials',
            'hasArtifact(activity, first)', 'hasChat(activity, firstChat)',
        ):
            self.assertIn(required, source)

    def test_artifact_catalog_not_mistaken_for_chat_history(self):
        activity = (ROOT / 'app/src/main/java/app/svyazka/mobile/MainActivity.java').read_text()
        repo = (ROOT / 'app/src/main/java/app/svyazka/mobile/PythonArtifactRepository.java').read_text()
        history = (ROOT / 'app/src/main/java/app/svyazka/mobile/ui/NexusScreens.kt').read_text()
        self.assertIn('private long ensurePythonArtifact() throws IOException', activity)
        self.assertIn('savedPythonArtifact(projectId, path)', activity)
        self.assertIn('artifactRepository.unlinkChat(id)', activity)
        self.assertIn('statement.executeUpdateDelete() == 1', repo)
        self.assertIn('ui.activity.nexusPythonHistoryDiagnostic()', history)

    def test_probe_has_fresh_process_restart_and_tombstone_verification(self):
        fixture = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/UpgradeProbe.java').read_text()
        script = (ROOT / 'scripts/test-android-python-history.py').read_text()
        probe = (ROOT / 'app/src/androidTest/java/app/svyazka/fixture/PythonHistoryProbe.java').read_text()
        self.assertIn('PythonHistoryProbe.run(this, step)', fixture)
        for step in ('python_seed', 'python_verify', 'python_deleted'):
            self.assertIn(step, script)
            self.assertIn(step, probe)
        self.assertIn("am', 'force-stop'", script)
        for step in ('python_chat_context_seed', 'python_chat_context_verify'):
            self.assertIn(step, script)
            self.assertIn(step, probe)
        self.assertIn('getDeclaredMethod("questionHistory", long.class, runType)', probe)
        self.assertIn('!sent.contains(otherMarker)', probe)
        self.assertIn('collect.invoke(activity, other, current)', probe)


class AndroidRunnerBehavior(unittest.TestCase):
    def run_with_web_result(self, web_result):
        spec = importlib.util.spec_from_file_location(
            'android_history_runner', ROOT / 'scripts/test-android-python-history.py')
        runner = importlib.util.module_from_spec(spec)
        with patch.object(sys, "path", [str(ROOT / "scripts"), *sys.path]):
            spec.loader.exec_module(runner)
        steps = []

        def fake_adb(*args, **kwargs):
            if args == ('shell', 'getprop', 'ro.kernel.qemu'):
                return '1'
            if args[:3] == ('shell', 'am', 'instrument'):
                step = args[args.index('step') + 1]
                steps.append(step)
                if step == 'web':
                    return web_result
                return ('INSTRUMENTATION_RESULT: stream=NEXUS_PYTHON_HISTORY_'
                        + step.upper() + '\nINSTRUMENTATION_CODE: -1')
            return 'Success'

        with tempfile.TemporaryDirectory() as tmp:
            app, test = Path(tmp) / 'app.apk', Path(tmp) / 'test.apk'
            app.touch()
            test.touch()
            with patch.object(runner, 'adb', side_effect=fake_adb), patch('builtins.print'):
                runner.main(app, test)
        return steps

    def test_standard_android_run_includes_real_webview_probe(self):
        steps = self.run_with_web_result(
            'INSTRUMENTATION_RESULT: stream=NEXUS_WEBVIEW_TESTED\nINSTRUMENTATION_CODE: -1')
        self.assertEqual(steps.count('web'), 1)

    def test_webview_failure_or_missing_proof_fails_standard_run(self):
        for output in ('INSTRUMENTATION_CODE: -1',
                       'NEXUS_WEBVIEW_TESTED\nINSTRUMENTATION_CODE: 0',
                       'NEXUS_WEBVIEW_TESTED\nFAILURES\nINSTRUMENTATION_CODE: -1'):
            with self.subTest(output=output), self.assertRaisesRegex(RuntimeError, 'web failed'):
                self.run_with_web_result(output)


    def test_wrong_or_ambiguous_instrumentation_result_is_rejected(self):
        marker = 'INSTRUMENTATION_RESULT: stream=NEXUS_WEBVIEW_TESTED'
        for output in (marker + '\nINSTRUMENTATION_CODE: -10',
                       marker + '_EXTRA\nINSTRUMENTATION_CODE: -1',
                       'diagnostic: ' + marker + '\nINSTRUMENTATION_CODE: -1',
                       marker + '\nINSTRUMENTATION_CODE: 0\nINSTRUMENTATION_CODE: -1'):
            with self.subTest(output=output), self.assertRaisesRegex(RuntimeError, 'web failed'):
                self.run_with_web_result(output)

    def test_upgrade_probe_requires_success_code_and_exact_marker(self):
        spec = importlib.util.spec_from_file_location(
            'android_upgrade_runner', ROOT / 'scripts/test-android-upgrade.py')
        runner = importlib.util.module_from_spec(spec)
        with patch.object(sys, "path", [str(ROOT / "scripts"), *sys.path]):
            spec.loader.exec_module(runner)
        marker = 'INSTRUMENTATION_RESULT: stream=NEXUS_PROBE_RESTORED'
        with patch.object(runner, 'adb', return_value=marker + '\nINSTRUMENTATION_CODE: -1'):
            runner.fixture('verify')
        for output in (marker, marker + '\nINSTRUMENTATION_CODE: 0',
                       marker + '_EXTRA\nINSTRUMENTATION_CODE: -1',
                       marker + '\nFAILURES\nINSTRUMENTATION_CODE: -1'):
            with self.subTest(output=output), patch.object(runner, 'adb', return_value=output):
                with self.assertRaises(RuntimeError):
                    runner.fixture('verify')

    def test_report_marks_unexecuted_probes_skipped(self):
        spec = importlib.util.spec_from_file_location(
            'android_history_report', ROOT / 'scripts/test-android-python-history.py')
        runner = importlib.util.module_from_spec(spec)
        with patch.object(sys, 'path', [str(ROOT / 'scripts'), *sys.path]):
            spec.loader.exec_module(runner)
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {'NEXUS_ANDROID_REPORT_DIR': tmp}):
            with self.assertRaises(FileNotFoundError):
                runner.main(Path(tmp) / 'missing.apk', Path(tmp) / 'missing-test.apk')
            suite = ET.parse(Path(tmp) / 'android-probes.xml').getroot()
            self.assertEqual(suite.get('failures'), '1')
            self.assertEqual(suite.get('skipped'), str(len(runner.STEPS)))
            self.assertEqual(suite.get('tests'), str(len(runner.STEPS) + 1))

    def test_report_records_real_probe_results(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {'NEXUS_ANDROID_REPORT_DIR': tmp}):
            steps = self.run_with_web_result('INSTRUMENTATION_RESULT: stream=NEXUS_WEBVIEW_TESTED\nINSTRUMENTATION_CODE: -1')
            suite = ET.parse(Path(tmp) / 'android-probes.xml').getroot()
            self.assertEqual(suite.get('tests'), str(len(steps) + 1))
            self.assertEqual(suite.get('failures'), '0')
            self.assertEqual(suite.get('skipped'), '0')
            self.assertIn('NEXUS_WEBVIEW_TESTED', (Path(tmp) / 'web.txt').read_text())


if __name__ == '__main__':
    unittest.main()
