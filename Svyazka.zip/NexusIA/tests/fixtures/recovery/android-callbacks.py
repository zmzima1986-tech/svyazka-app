from android import permissions
from jnius import PythonJavaClass

class BluetoothWidget:
    def _request_permissions(self):
        permissions.request_permissions([], self._on_perms_result)
    def _on_perms_result(self, granted):
        return all(granted)

class ScanCallbackImpl(PythonJavaClass):
    __javainterfaces__ = ['android/bluetooth/le/ScanCallback']
class GattCallbackImpl(PythonJavaClass):
    __javainterfaces__ = ['android/bluetooth/BluetoothGattCallback']
