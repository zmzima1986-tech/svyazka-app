package app.svyazka.mobile.ui

import app.svyazka.mobile.ResultSeverity

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Check
import androidx.compose.foundation.text.selection.SelectionContainer
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.roundToInt
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.svyazka.mobile.R
import org.json.JSONArray
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Manual Python files belong to a durable artifact, independent of AI chat messages. */
@Composable
fun NexusPythonWorkspace(ui: NexusComposeUi) {
    // A chat's "Run Python" action must be explicitly confirmed before replacing
    // any linked project file. The normal workspace still shows the real output.
    if (ui.pythonCodeBlocks.isNotEmpty()) PythonDialogs(ui)
    val state = ui.snapshot
    val light = nexusLightMode()
    val save = rememberSaveResultAction(ui.pythonEditingCode, ui.pythonFileName)
    val blocks = ui.pythonCodeBlocks
    var selected by rememberSaveable(blocks, ui.pythonStep) { mutableIntStateOf(0) }
    var allowedPackage by rememberSaveable { mutableStateOf("") }
    var extended by rememberSaveable { mutableStateOf(false) }
    var confirmExtended by rememberSaveable { mutableStateOf(false) }
    var showArtifacts by rememberSaveable { mutableStateOf(false) }
    var toolPanel by remember { mutableStateOf<PythonToolPanel?>(null) }
    var retainedToolPanel by remember { mutableStateOf(PythonToolPanel.MENU) }
    var showProjectInfo by rememberSaveable { mutableStateOf(false) }
    var resultExpanded by rememberSaveable(ui.pythonReport) { mutableStateOf(false) }
    var toolDrag by remember { mutableFloatStateOf(0f) }
    val toolDragScope = rememberCoroutineScope()
    var toolDragReturn by remember { mutableStateOf<Job?>(null) }
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val dismissDirection = if (rtl) -1f else 1f

    fun settleToolDrag() {
        toolDragReturn?.cancel()
        val start = toolDrag
        toolDragReturn = toolDragScope.launch {
            animate(start, 0f, animationSpec = tween(170, easing = FastOutSlowInEasing)) {
                value, _ -> toolDrag = value
            }
        }
    }

    // While tools are visible, the outer workspace drawer must not steal the swipe.
    SideEffect { ui.pythonToolsOpen = toolPanel != null }
    DisposableEffect(ui) { onDispose { ui.pythonToolsOpen = false } }
    LaunchedEffect(toolPanel) {
        if (toolPanel != null) retainedToolPanel = toolPanel!!
        else {
            // Keep the last swipe offset until the slide-out completes.
            delay(280)
            toolDrag = 0f
        }
    }
    BackHandler(enabled = toolPanel != null) {
        toolPanel = if (toolPanel == PythonToolPanel.MENU) null else PythonToolPanel.MENU
        if (toolPanel != null) toolDrag = 0f
    }

    fun launch(confirmedExtended: Boolean = false) {
        if (!ui.pythonFileName.endsWith(".py")) return
        if ((!ui.pythonRemote || ui.pythonFileList.size > 1) && extended && !confirmedExtended) {
            confirmExtended = true
            return
        }
        val accepted = if (ui.pythonRemote && ui.pythonFileList.size <= 1) {
            ui.activity.nexusExecutePython(ui.pythonStep, ui.pythonEditingCode,
                ui.pythonStdin, true, false)
        } else ui.activity.nexusExecutePythonProject(ui.pythonFileName,
            ui.pythonEditingCode, ui.pythonStdin, allowedPackage, extended)
        if (accepted) showArtifacts = false
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val drawerWidth = maxWidth
        val dismissThreshold = with(LocalDensity.current) { drawerWidth.toPx() * .23f }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(bottom = 108.dp),
            verticalArrangement = Arrangement.spacedBy(if (light) 10.dp else 8.dp)) {
            val summaryShape = if (light) NexusLightDesign.cardShape else RoundedCornerShape(22.dp)
            Surface(
                modifier = if (light) Modifier.fillMaxWidth().shadow(3.dp, summaryShape)
                    else Modifier.fillMaxWidth(),
                shape = summaryShape,
                color = if (light) NexusLightDesign.glass else NexusDarkDesign.workspaceGlass,
                border = BorderStroke(1.dp, if (light) NexusLightDesign.glassHighlight
                    else NexusDarkDesign.chatBorder)
            ) {
                Row(Modifier.fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    if (light) {
                        Box(Modifier.size(23.dp), contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Folder, null, Modifier.size(23.dp),
                                tint = NexusLightDesign.ink)
                            Icon(Icons.Filled.Folder, null, Modifier.size(19.dp),
                                tint = NexusLightDesign.folder)
                        }
                    } else {
                        Icon(Icons.Filled.Folder, null, modifier = Modifier.size(20.dp),
                            tint = NexusDarkDesign.folder)
                    }
                    Spacer(Modifier.width(7.dp))
                    Column(Modifier.weight(1f)) {
                        Text(pluralStringResource(R.plurals.ws_easy_project_files,
                            ui.pythonFileList.size, ui.pythonFileList.size),
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (light) androidx.compose.ui.text.font.FontWeight.Bold
                                else androidx.compose.ui.text.font.FontWeight.Normal,
                            color = if (light) NexusLightDesign.ink
                                else MaterialTheme.colorScheme.onSurface)
                        Text(stringResource(R.string.ws_easy_project_entry, ui.pythonFileName),
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (light) NexusLightDesign.secondary
                                else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Box(Modifier.size(24.dp).clip(RoundedCornerShape(12.dp))
                        .clickable(role = Role.Button) { showProjectInfo = true },
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.Info, stringResource(R.string.ws_project_info),
                            modifier = Modifier.size(18.dp),
                            tint = if (light) NexusLightDesign.ink
                                else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Project import must be discoverable without tapping an unexplained
            // chevron. Rare actions (including save before running) live in Tools.
            PythonProjectFiles(ui)
            if (light && (ui.pythonFileList.size > 1 || ui.pythonEditingCode.isNotBlank()) &&
                ui.pythonProjectIssue.isBlank()) {
                NexusLightReadyRibbon(ui.pythonFileList.size)
            }

            val toolsShape = if (light) RoundedCornerShape(18.dp) else RoundedCornerShape(20.dp)
            OutlinedButton(
                onClick = { toolPanel = PythonToolPanel.MENU },
                modifier = Modifier.size(44.dp),
                shape = toolsShape,
                border = BorderStroke(1.dp, if (light) NexusLightDesign.blue
                    else NexusDarkDesign.chatBorder),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (light) NexusLightDesign.glass else NexusDarkDesign.chatGlass,
                    contentColor = if (light) NexusLightDesign.ink else NexusDarkDesign.cyan
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(Icons.Outlined.Handyman, stringResource(R.string.ws_easy_tools),
                    Modifier.size(18.dp))
            }

            NexusPrimaryButton(text = stringResource(R.string.ws_easy_run),
                enabled = !state.active && !state.clearing && !ui.pythonBusy &&
                    ui.pythonEditingCode.isNotBlank() && ui.pythonFileName.endsWith(".py"),
                onClick = { launch() }, modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Outlined.PlayArrow, null) }, glow = false,
                runStyling = true)

            if (ui.pythonBusy) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White.copy(alpha = .04f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .28f))
                ) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(21.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(9.dp))
                        Text(stringResource(R.string.status_processing), modifier = Modifier.weight(1f))
                        IconButton(onClick = { ui.activity.nexusCancelPython() }) {
                            Icon(Icons.Outlined.Stop, stringResource(R.string.action_stop))
                        }
                    }
                }
            }

            ui.pythonReport?.let { report ->
                val success = report.exitCode == 0 && !report.hasFailedTests()
                val artifactCount = remember(report.artifactsJson) {
                    runCatching { JSONArray(report.artifactsJson).length() }.getOrDefault(0)
                }
                Surface(
                    onClick = { resultExpanded = !resultExpanded },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = if (light) NexusLightDesign.glass else NexusDarkDesign.workspaceGlass,
                    border = BorderStroke(1.dp, if (light) NexusLightDesign.glassHighlight
                        else NexusDarkDesign.workspaceBorder)
                ) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        ResultStatusIcon(report.severity(), Modifier.size(23.dp))
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(if (success) R.string.ws_easy_run_ok
                                else if (report.exitCode == null && !report.hasFailedTests()) R.string.ws_not_finished
                                else R.string.ws_easy_run_error),
                                color = report.severity().textColor(),
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1, softWrap = false,
                                overflow = TextOverflow.Ellipsis)
                            if (!resultExpanded) {
                                if (report.stdout.isNotBlank()) Text(
                                    report.stdout.lineSequence().firstOrNull().orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (artifactCount > 0) Text(
                                    stringResource(R.string.ws_easy_artifacts, artifactCount),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Icon(if (resultExpanded) Icons.Outlined.ExpandLess
                            else Icons.Outlined.ExpandMore,
                            stringResource(if (resultExpanded) R.string.attachment_collapse
                                else R.string.action_show_result))
                    }
                }
                if (resultExpanded) {
                NexusOutlineActionButton(
                    text = stringResource(R.string.artifacts_save),
                    onClick = { ui.activity.nexusSaveArtifact(ui.pythonFileName, ui.pythonEditingCode) },
                    enabled = !state.active && !state.clearing && !ui.pythonBusy,
                    modifier = Modifier.fillMaxWidth(),
                    icon = { Icon(Icons.Outlined.SaveAlt, null, Modifier.size(17.dp)) }
                )
                if (light) {
                    NexusLightPythonReport(ui, report, showArtifacts) {
                        showArtifacts = !showArtifacts
                    }
                } else {
                var showRunDiagnostics by rememberSaveable(report) { mutableStateOf(false) }
                val success = report.exitCode == 0 && !report.hasFailedTests()
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = NexusDarkDesign.workspaceGlass,
                    border = BorderStroke(1.dp,
                        if (success) NexusDarkDesign.workspaceBorder
                        else report.severity().textColor())
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // The summary card above already announces the run result.
                        // Keep output, tests, diagnostics and artifacts here, without a duplicate title.
                        if (report.stdout.isNotBlank()) {
                            Surface(shape = RoundedCornerShape(16.dp), color = NexusDarkDesign.console,
                                border = BorderStroke(1.dp, NexusDarkDesign.chatBorder.copy(alpha = .6f))) {
                                Box(Modifier.fillMaxWidth().heightIn(max = 220.dp)
                                    .verticalScroll(rememberScrollState())) {
                                    SelectionContainer {
                                        Text(report.stdout,
                                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 16.sp, lineHeight = 22.sp))
                                    }
                                }
                            }
                        }
                        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            val tests = remember(report.testsJson) {
                                runCatching { JSONArray(report.testsJson) }.getOrNull()
                            }
                            if (tests != null && tests.length() > 0) {
                                val passed = (0 until tests.length()).count {
                                    tests.optJSONObject(it)?.optBoolean("passed") == true
                                }
                                Text(stringResource(R.string.ws_easy_tests_summary, passed, tests.length()),
                                    color = (if (passed == tests.length()) ResultSeverity.SUCCESS else ResultSeverity.ERROR).textColor(),
                                    fontSize = 15.sp,
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                            }
                            val artifacts = remember(report.artifactsJson) {
                                runCatching { JSONArray(report.artifactsJson).length() }.getOrDefault(0)
                            }
                            if (ui.verification.total > 0) {
                                Text(stringResource(R.string.verify_count, ui.verification.passed, ui.verification.total),
                                    color = ui.verification.severity().textColor(),
                                    fontSize = 14.sp)
                            }
                            if (artifacts > 0) {
                                TextButton(onClick = { showArtifacts = !showArtifacts }, contentPadding = PaddingValues(0.dp)) {
                                    Text(stringResource(R.string.ws_easy_artifacts, artifacts))
                                }
                            }
                        }
                        if (report.status.isNotBlank()) {
                            ResultStatusLine(report.status, report.noticeSeverity(), MaterialTheme.typography.bodySmall)
                        }
                        if (report.stderr.isNotBlank()) {
                            if (success) {
                                TextButton(onClick = { showRunDiagnostics = !showRunDiagnostics },
                                    modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
                                    Text(stringResource(if (showRunDiagnostics)
                                        R.string.ws_hide_run_diagnostics else R.string.ws_show_run_diagnostics),
                                        modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.bodyMedium,
                                        softWrap = true)
                                }
                            }
                            if (!success || showRunDiagnostics) {
                                SelectionContainer {
                                    Text(report.stderr, maxLines = if (success) 20 else 6,
                                        color = if (success) MaterialTheme.colorScheme.onSurfaceVariant
                                            else report.severity().textColor())
                                }
                            }
                        }
                        if (showArtifacts) PythonRunArtifacts(ui)
                        if (report.hasVisual) {
                            TextButton(onClick = { ui.openVisual() }, contentPadding = PaddingValues(0.dp)) {
                                Text(stringResource(R.string.action_show_result))
                            }
                        }
                    }
                }
                }
                }
            }
            ui.pythonError?.let {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.error.copy(alpha = .10f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = .25f))
                ) {
                    ResultStatusLine(it, ResultSeverity.ERROR, modifier = Modifier.padding(14.dp))
                }
            }
        }

        // Compact chat link control. Both targets use the existing verified
        // link/unlink actions; the check indicator reflects persisted state only.
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            color = if (light) NexusLightDesign.glass else NexusDarkDesign.workspaceGlass,
            shape = RoundedCornerShape(23.dp),
            border = BorderStroke(1.dp, if (light) NexusLightDesign.glassHighlight
                else NexusDarkDesign.workspaceBorder)
        ) {
            // Link state belongs to the current chat, not the last viewed artifact.
            val linkedHere = ui.linkedProjectId > 0L
            val statusText = stringResource(if (linkedHere) R.string.ws_chat_linked_status
                else R.string.ws_chat_unlinked_status)
            val actionText = stringResource(if (linkedHere)
                R.string.ws_chat_disconnect_action else R.string.ws_chat_connect_action)
            val canAct = !state.active && !state.clearing && !ui.pythonBusy
            val linkAction: () -> Unit = {
                if (linkedHere) ui.activity.nexusDetachArtifactFromChat()
                else ui.activity.nexusCreateChatPythonProject()
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier.size(52.dp)
                        .clip(CircleShape)
                        .background(if (linkedHere) {
                            if (light) NexusLightDesign.success else NexusDarkDesign.success
                        } else Color(0xFF707C8C))
                        .border(1.dp, if (light) NexusLightDesign.ink
                            else NexusDarkDesign.workspaceBorder, CircleShape)
                        .clickable(
                            enabled = canAct,
                            role = Role.Button,
                            onClickLabel = actionText,
                            onClick = linkAction
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Check, statusText, Modifier.size(28.dp),
                        tint = Color.White)
                }
                OutlinedButton(
                    onClick = linkAction,
                    enabled = canAct,
                    modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, if (light) NexusLightDesign.blue
                        else NexusDarkDesign.workspaceBorder),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (light) NexusLightDesign.glass
                            else NexusDarkDesign.chatGlass,
                        contentColor = if (light) NexusLightDesign.blue
                            else NexusDarkDesign.cyan
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Text(actionText, style = MaterialTheme.typography.labelLarge,
                        maxLines = 3, softWrap = true, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }

            }
        }

        // Nested tools occupy the entire workspace. A second animated dim layer
        // used to leave a visible gray rectangle when the tools sheet closed.
        // The parent workspace already owns the background and dimming.
        AnimatedVisibility(
            visible = toolPanel != null,
            modifier = Modifier.align(Alignment.CenterEnd).width(drawerWidth).fillMaxHeight()
                .offset { IntOffset(toolDrag.roundToInt(), 0) }
                .pointerInput(dismissDirection, dismissThreshold) {
                    detectHorizontalDragGestures(
                        onDragStart = {
                            toolDragReturn?.cancel()
                            toolDrag = 0f
                        },
                        onDragCancel = { settleToolDrag() },
                        onDragEnd = {
                            if (toolDrag * dismissDirection >= dismissThreshold) toolPanel = null
                            else settleToolDrag()
                        },
                        onHorizontalDrag = { change, amount ->
                            val next = (toolDrag + amount) * dismissDirection
                            if (next >= 0f) {
                                toolDrag = next.coerceAtMost(size.width.toFloat()) * dismissDirection
                                change.consume()
                            }
                        }
                    )
                },
            // Keep the opaque backing throughout the exit: slide the whole sheet
            // instead of hiding it instantly or fading a translucent rectangle.
            enter = fadeIn(tween(130)),
            exit = slideOutHorizontally(tween(240, easing = FastOutSlowInEasing)) { width ->
                (if (rtl) -width else width) - toolDrag.roundToInt()
            }
        ) {
            val panel = toolPanel ?: retainedToolPanel
            // The tools sheet is flush with the workspace bounds: no dangling
            // rounded corners, and no underlying controls bleeding through.
            NexusFrostedPanel(
                modifier = Modifier.fillMaxSize().background(
                    if (light) Color(0xFFF4F7FC) else Color(0xFF071425)),
                shape = RoundedCornerShape(0.dp),
                darkBackground = NexusDarkDesign.modalGlass.copy(alpha = .92f),
                darkBorder = NexusDarkDesign.modalBorder
            ) {
                Box(Modifier.fillMaxSize()) {
                // Parent drawer (or Scaffold page) already applied system insets.
                Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 10.dp)) {
                    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        if (panel != PythonToolPanel.MENU) {
                            IconButton(onClick = { toolPanel = PythonToolPanel.MENU }) {
                                Icon(Icons.Outlined.ArrowBack, stringResource(R.string.action_back))
                            }
                        }
                        Text(
                            text = stringResource(if (panel == PythonToolPanel.MENU)
                                R.string.ws_easy_tools_title else when (panel) {
                                PythonToolPanel.FILES -> R.string.ws_easy_files_tool
                                PythonToolPanel.EDITOR -> R.string.ws_easy_editor_tool
                                PythonToolPanel.SETTINGS -> R.string.ws_easy_run_settings_tool
                                else -> R.string.ws_easy_tools_title
                            }),
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { toolPanel = null }) {
                            Icon(Icons.Outlined.Close, stringResource(R.string.action_close))
                        }
                    }
                    HorizontalDivider(Modifier.padding(bottom = 10.dp))
                    when (panel) {
                        PythonToolPanel.MENU -> Column(
                            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            PythonToolRow(Icons.Outlined.Folder,
                                stringResource(R.string.ws_easy_files_tool)) {
                                toolPanel = PythonToolPanel.FILES
                            }
                            PythonToolRow(Icons.Outlined.Code,
                                stringResource(R.string.ws_easy_editor_tool)) {
                                toolPanel = PythonToolPanel.EDITOR
                            }
                            PythonToolRow(Icons.Outlined.Settings,
                                stringResource(R.string.ws_easy_run_settings_tool)) {
                                toolPanel = PythonToolPanel.SETTINGS
                            }
                            // Saving before the first run remains possible without
                            // a permanent secondary button on the Python screen.
                            if (ui.pythonReport == null && !state.active &&
                                !state.clearing && !ui.pythonBusy) {
                                PythonToolRow(Icons.Outlined.SaveAlt,
                                    stringResource(R.string.artifacts_save)) {
                                    ui.activity.nexusSaveArtifact(ui.pythonFileName, ui.pythonEditingCode)
                                    toolPanel = null
                                }
                            }
                        }
                        PythonToolPanel.FILES -> PythonProjectFileManager(ui)
                        PythonToolPanel.EDITOR -> PythonEditorTool(ui, save, blocks,
                            selected, onSelectBlock = { index, code ->
                                selected = index
                                ui.loadPython(ui.activity.nexusFinalStep(), code)
                            }, onRun = {
                                if (!ui.pythonBusy && !ui.snapshot.active &&
                                    ui.pythonEditingCode.isNotBlank() && ui.pythonFileName.endsWith(".py")) {
                                    launch()
                                    toolPanel = null
                                }
                            })
                        PythonToolPanel.SETTINGS -> PythonRunSettingsTool(ui, allowedPackage,
                            onAllowedPackage = { allowedPackage = it },
                            extended = extended, onExtended = { extended = it })
                    }
                }
                }
            }
        }

        if (showProjectInfo) {
            NexusFrostedAlertDialog(onDismissRequest = { showProjectInfo = false },
                title = {
                    Column {
                        Text(pluralStringResource(R.plurals.ws_easy_project_files,
                            ui.pythonFileList.size, ui.pythonFileList.size))
                        Text(stringResource(R.string.ws_easy_project_entry, ui.pythonFileName),
                            style = MaterialTheme.typography.bodySmall)
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.ws_project_info))
                        Text(stringResource(R.string.ws_project_scope))
                    }
                },
                confirmButton = { TextButton(onClick = { showProjectInfo = false }) {
                    Text(stringResource(R.string.action_close))
                } })
        }

        if (confirmExtended) {
            NexusFrostedAlertDialog(onDismissRequest = { confirmExtended = false },
                title = { Text(stringResource(R.string.ws_extended_title)) },
                text = { Text(stringResource(R.string.ws_extended_body)) },
                confirmButton = { TextButton(onClick = { confirmExtended = false; launch(confirmedExtended = true) }) {
                    Text(stringResource(R.string.ws_allow))
                } },
                dismissButton = { TextButton(onClick = { confirmExtended = false }) {
                    Text(stringResource(R.string.action_cancel))
                } })
        }
    }
}

private enum class PythonToolPanel { MENU, FILES, EDITOR, SETTINGS }

@Composable
private fun PythonToolRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    action: () -> Unit
) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
        .clickable(onClick = action)
        .heightIn(min = 50.dp).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(15.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun PythonEditorTool(
    ui: NexusComposeUi,
    save: () -> Unit,
    blocks: List<String>,
    selected: Int,
    onSelectBlock: (Int, String) -> Unit,
    onRun: () -> Unit
) {
    // The editor panel itself never scrolls. The code field uses the remaining height.
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (ui.snapshot.resultHasPython && ui.snapshot.complete && !ui.pythonBusy) {
            TextButton(onClick = { ui.activity.nexusRunPython(ui.activity.nexusFinalStep()) }) {
                Text(stringResource(R.string.load_answer), maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
        }
        if (blocks.size > 1 && !ui.pythonBusy) {
            var showBlocks by remember(blocks) { mutableStateOf(false) }
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { showBlocks = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.python_block, selected + 1),
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Outlined.ArrowDropDown, null)
                }
                DropdownMenu(expanded = showBlocks, onDismissRequest = { showBlocks = false }, containerColor = nexusFrostedColor()) {
                    blocks.forEachIndexed { index, code ->
                        DropdownMenuItem(text = {
                            Text(stringResource(R.string.python_block, index + 1), maxLines = 1)
                        }, onClick = {
                            showBlocks = false
                            onSelectBlock(index, code)
                        })
                    }
                }
            }
        }
        PythonProjectEditor(ui, save, Modifier.weight(1f), onRun)
    }
}

@Composable
private fun PythonRunSettingsTool(
    ui: NexusComposeUi,
    allowedPackage: String,
    onAllowedPackage: (String) -> Unit,
    extended: Boolean,
    onExtended: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        NexusLabel(stringResource(R.string.python_scope))
        OutlinedTextField(value = ui.pythonStdin,
            onValueChange = { if (it.length <= 16_000) ui.pythonStdin = it },
            modifier = Modifier.fillMaxWidth(), maxLines = 4,
            label = { Text(stringResource(R.string.python_input_hint)) })
        if (ui.pythonHasPiston) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = ui.pythonRemote, onCheckedChange = {
                    ui.pythonRemote = it
                    if (it) { onAllowedPackage(""); onExtended(false) }
                }, enabled = ui.pythonFileList.size <= 1)
                Text(stringResource(R.string.python_use_piston),
                    style = MaterialTheme.typography.bodySmall)
            }
            if (ui.pythonRemote && ui.pythonFileList.size <= 1) {
                NexusLabel(stringResource(R.string.python_warning_remote))
            }
            if (ui.pythonFileList.size > 1) {
                NexusLabel(stringResource(R.string.ws_remote_single))
            }
        }
        if (!ui.pythonRemote || ui.pythonFileList.size > 1) {
            Text(stringResource(R.string.ws_package),
                style = MaterialTheme.typography.labelMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = allowedPackage.isEmpty(),
                    onClick = { onAllowedPackage("") })
                Text(stringResource(R.string.ws_no_package),
                    style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = allowedPackage == "numpy",
                    onClick = { onAllowedPackage("numpy") })
                Text("NumPy 2.4.6",
                    style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = allowedPackage == "matplotlib",
                    onClick = { onAllowedPackage("matplotlib") })
                Text(stringResource(R.string.ws_matplotlib),
                    style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = extended, onCheckedChange = { onExtended(it) })
                Text(stringResource(R.string.ws_extended),
                    style = MaterialTheme.typography.bodySmall)
            }
            if (extended) NexusLabel(stringResource(R.string.ws_extended_body))
        }
    }
}

@Composable
private fun PythonProjectEditor(
    ui: NexusComposeUi, save: () -> Unit, modifier: Modifier = Modifier, onRun: () -> Unit
) {
    val code = ui.pythonEditingCode
    val context = LocalContext.current
    var editor by remember(ui.projectId, ui.pythonFileName) { mutableStateOf(TextFieldValue(code)) }
    var find by remember(ui.projectId, ui.pythonFileName) { mutableStateOf("") }
    var replace by remember(ui.projectId, ui.pythonFileName) { mutableStateOf("") }
    var targetLine by remember(ui.projectId, ui.pythonFileName) { mutableStateOf("") }
    var showSearchTools by remember(ui.projectId, ui.pythonFileName) { mutableStateOf(false) }
    LaunchedEffect(code) {
        if (editor.text != code) editor = editor.copy(text = code, selection = TextRange(0))
    }
    fun edit(next: TextFieldValue) {
        editor = next
        ui.editPython(next.text)
    }
    val cursor = editor.selection.start.coerceIn(0, editor.text.length)
    val isEditable = !ui.pythonBusy && !ui.snapshot.active

    Column(modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text((if (ui.pythonFileDirty) "● " else "") +
            stringResource(R.string.ws_editor_stats, ui.pythonFileName,
                code.count { it == '\n' } + 1,
                code.take(cursor).count { it == '\n' } + 1),
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1, overflow = TextOverflow.Ellipsis)

        // Only the code itself scrolls when it has more lines than fit on screen.
        PythonCodeEditor(value = editor,
            onValueChange = {
                val next = pythonAutoIndent(editor, it)
                if (next.text.length <= 75_000) edit(next)
            },
            modifier = Modifier.fillMaxWidth().weight(1f), enabled = isEditable,
            minLines = 1, label = stringResource(R.string.ui_code))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { edit(TextFieldValue("")) },
                modifier = Modifier.weight(1f),
                enabled = code.isNotEmpty() && isEditable,
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)) {
                Text(stringResource(R.string.editor_clear),
                    maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
            }
            OutlinedButton(onClick = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText(ui.pythonFileName, code))
            }, modifier = Modifier.weight(1f), enabled = code.isNotEmpty(),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)) {
                Text(stringResource(R.string.action_copy),
                    maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
            }
        }

        Button(onClick = save, modifier = Modifier.fillMaxWidth(),
            enabled = code.isNotBlank() && isEditable,
            colors = if (nexusLightMode()) ButtonDefaults.buttonColors() else ButtonDefaults.buttonColors(
                containerColor = NexusDarkDesign.cyan,
                contentColor = Color(0xFF03141D),
                disabledContainerColor = NexusDarkDesign.disabled,
                disabledContentColor = NexusDarkDesign.disabledText),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
            Icon(Icons.Outlined.Download, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.ws_download),
                maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
        }

        // Search and Run share one fixed row: neither action disappears below the screen.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { showSearchTools = true },
                modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.ws_find),
                    maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
            }
            Button(onClick = onRun, modifier = Modifier.weight(1f),
                enabled = isEditable && code.isNotBlank() && ui.pythonFileName.endsWith(".py"),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)) {
                Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(3.dp))
                Text(stringResource(R.string.ws_editor_run),
                    maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
            }
        }
    }

    // Search and replace live in a separate dialog, so opening them cannot
    // stretch the editor or introduce vertical/horizontal panel scrolling.
    if (showSearchTools) {
        NexusFrostedAlertDialog(onDismissRequest = { showSearchTools = false },
            title = { Text(stringResource(R.string.ws_find)) },
            text = {
                Column(Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = find, onValueChange = { find = it.take(200) },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text(stringResource(R.string.ws_find)) })
                    OutlinedTextField(value = replace, onValueChange = { replace = it.take(200) },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text(stringResource(R.string.ws_replace_with)) })
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(enabled = find.isNotEmpty(), onClick = {
                            val offset = code.indexOf(find, startIndex = cursor).takeIf { it >= 0 }
                                ?: code.indexOf(find)
                            if (offset >= 0) editor = editor.copy(
                                selection = TextRange(offset, offset + find.length))
                            showSearchTools = false
                        }, modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 3.dp)) {
                            Text(stringResource(R.string.ws_find_next), maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                        TextButton(enabled = find.isNotEmpty() && isEditable, onClick = {
                            if (code.contains(find)) edit(editor.copy(text = code.replace(find, replace)))
                            showSearchTools = false
                        }, modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 3.dp)) {
                            Text(stringResource(R.string.ws_replace_all), maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = targetLine,
                            onValueChange = { targetLine = it.take(7) },
                            modifier = Modifier.weight(1f), singleLine = true,
                            label = { Text(stringResource(R.string.ws_line), maxLines = 1) })
                        Spacer(Modifier.width(6.dp))
                        TextButton(onClick = {
                            val line = targetLine.toIntOrNull()?.coerceAtLeast(1) ?: 1
                            val offset = if (line == 1) 0 else {
                                var index = -1
                                repeat(line - 1) {
                                    index = code.indexOf('\n', index + 1)
                                        .takeIf { it >= 0 } ?: code.length
                                }
                                (index + 1).coerceAtMost(code.length)
                            }
                            editor = editor.copy(selection = TextRange(offset))
                            showSearchTools = false
                        }) {
                            Text(stringResource(R.string.ws_go), maxLines = 1)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSearchTools = false }) {
                    Text(stringResource(R.string.action_close))
                }
            })
    }
}

@Composable
private fun PythonRunOutput(ui: NexusComposeUi) {
    val report = ui.pythonReport
    if (report == null) { NexusLabel(stringResource(R.string.ws_output_empty)); return }
    HorizontalDivider()
    Text(stringResource(R.string.ui_result), style = MaterialTheme.typography.titleMedium)
    NexusLabel(report.engine + (report.exitCode?.let { stringResource(R.string.ws_exit_code, it) } ?:
        stringResource(R.string.ws_stopped)))
    ResultStatusLine(stringResource(R.string.ws_level) + when (report.severity()) {
        ResultSeverity.SUCCESS -> stringResource(R.string.ws_executed)
        ResultSeverity.ERROR -> stringResource(R.string.ws_error)
        else -> stringResource(R.string.ws_not_finished)
    }, report.severity())
    if (report.snapshotSha256.isNotBlank()) NexusLabel(stringResource(R.string.ws_sha, report.snapshotSha256))
    if (report.status.isNotBlank()) ResultStatusLine(report.status, report.noticeSeverity(), MaterialTheme.typography.bodySmall)
    Text(stringResource(R.string.python_stdout), style = MaterialTheme.typography.labelLarge)
    SelectionContainer { Text(report.stdout.ifBlank { stringResource(R.string.python_no_output) }) }
    if (report.stderr.isNotBlank()) {
        Text(stringResource(R.string.python_stderr), style = MaterialTheme.typography.labelLarge)
        SelectionContainer { Text(report.stderr, color = if (report.severity() == ResultSeverity.SUCCESS) ResultSeverity.WARNING.textColor() else report.severity().textColor(),
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)) }
        val location = Regex("""File "([^"]+)", line (\d+)""").find(report.stderr)
        if (location != null) TextButton(onClick = {
            val name = location.groupValues[1].substringAfterLast("/workspace/")
            if (ui.pythonFileList.contains(name)) ui.openPythonFile(name)
            // The editor provides an explicit line-number navigation field.
        }) { Text(stringResource(R.string.ws_goto_error)) }
    }
    if (report.hasVisual) TextButton(onClick = { ui.openVisual() }) {
        Text(stringResource(R.string.action_show_result))
    }
    if (report.stderr.isNotBlank()) TextButton(onClick = {
        ui.chatTextChanged("Проверь ошибку Python и предложи конкретное исправление. " +
            "Исходный код и секреты не отправляй автоматически. Диагностика:\n" +
            report.stderr.take(1600))
        ui.selectPage(NexusComposeUi.Page.TASK)
    }) { Text(stringResource(R.string.ws_ask_ai)) }
    if (report.diagnostic.isNotBlank()) TextButton(onClick = {
        ui.activity.nexusSendPythonError(); ui.dismissPythonResult()
    }) { Text(stringResource(R.string.python_error_to_review)) }
    OutlinedButton(onClick = { ui.dismissPythonResult() }) { Text(stringResource(R.string.action_close)) }
}
