package app.svyazka.mobile;

import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Test;

/** Compare exactly the same request before and after local context optimizations. */
public class InputOptimizationMetricsTest {
    private Workflow.Run run(String task) {
        return Workflow.Run.quick(task, ModelCatalog.GROQ_120B,
                Workflow.defaultStages().get(Workflow.Step.REVIEW.ordinal()));
    }

    @Test public void consoleRulesProduceMeasurableReduction() throws Exception {
        Workflow.Run request = run("Напиши программу на Python для консоли [console], выведи 40.");
        ModelClient.InputComparison comparison = ModelClient.compareInput(request);
        assertEquals(ModelClient.estimatedInput(request), comparison.estimatedAfter);
        assertTrue(comparison.textBytesBefore > comparison.textBytesAfter);
        assertTrue(comparison.estimatedBefore > comparison.estimatedAfter);
        assertEquals(request.consoleInstructionBytesSaved(),
                comparison.textBytesBefore - comparison.textBytesAfter);
        assertEquals(request.estimatedConsoleInstructionTokensSaved(),
                comparison.estimatedBefore - comparison.estimatedAfter);
    }

    @Test public void ordinaryChatIsNotClaimedToSaveAnything() throws Exception {
        Workflow.Run request = run("Привет! Как дела?");
        ModelClient.InputComparison comparison = ModelClient.compareInput(request);
        assertEquals(comparison.estimatedBefore, comparison.estimatedAfter);
        assertEquals(comparison.textBytesBefore, comparison.textBytesAfter);
        assertEquals(0, request.duplicatePromptBytesSaved());
    }

    @Test public void identicalLinkedSourceProducesByteAndEstimatedTokenSaving() throws Exception {
        StringBuilder source = new StringBuilder("# main.py\n");
        for (int i = 0; i < 80; i++) source.append("print('Строка ").append(i).append("')\n");
        String code = source.toString();
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", code.getBytes(StandardCharsets.UTF_8));
        Workflow.Run request = run(ChatProjectContext.append("Проверь этот исходник: \n" + code,
                files, 100000));
        ModelClient.InputComparison comparison = ModelClient.compareInput(request);
        assertTrue(request.duplicatePromptBytesSaved() > 0);
        assertTrue(comparison.textBytesBefore > comparison.textBytesAfter);
        assertTrue(comparison.estimatedBefore > comparison.estimatedAfter);
        assertTrue(request.prompt().contains("Exact copy of earlier task text"));
        assertTrue(request.unoptimizedPrompt().contains(code));
    }

    @Test public void changedLinkedSourceIsNeverRemoved() throws Exception {
        String original = "# old.py\n" + "print('old')\n".repeat(40);
        String changed = "# old.py\n" + "print('new')\n".repeat(40);
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("old.py", changed.getBytes(StandardCharsets.UTF_8));
        Workflow.Run request = run(ChatProjectContext.append("Проверь предыдущую версию: \n" + original,
                files, 100000));
        ModelClient.InputComparison comparison = ModelClient.compareInput(request);
        assertEquals(0, request.duplicatePromptBytesSaved());
        assertEquals(comparison.textBytesBefore, comparison.textBytesAfter);
        assertEquals(comparison.estimatedBefore, comparison.estimatedAfter);
        assertTrue(request.prompt().contains(changed));
    }

    @Test public void comparisonDoesNotModifyTaskOrSentPayload() throws Exception {
        Workflow.Run request = run("Программа для консоли [console] на Python. Выведи приветствие.");
        String task = request.task;
        String before = request.prompt();
        String rules = request.instructions();
        ModelClient.compareInput(request);
        assertEquals(task, request.task);
        assertEquals(before, request.prompt());
        assertEquals(rules, request.instructions());
    }
}
