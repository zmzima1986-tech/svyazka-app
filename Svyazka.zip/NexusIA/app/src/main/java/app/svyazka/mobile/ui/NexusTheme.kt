package app.svyazka.mobile.ui

import android.content.res.Configuration
import android.view.ContextThemeWrapper
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Typography as MaterialTypography
import androidx.compose.ui.text.TextStyle

val NexusCyan = Color(0xFF22E3FF)
val NexusBlue = Color(0xFF3B82F6)
val NexusIndigo = Color(0xFF6366F1)
val NexusNavy = Color.Black
val NexusSurface = Color(0xFF111216)
val NexusPurple = Color(0xFF8738F5)
val NexusLightBackground = Color.White
val NexusLightText = Color.Black

private val DarkPalette = darkColorScheme(
    primary = NexusCyan,
    onPrimary = Color(0xFF06161A),
    primaryContainer = Color(0xFF173439),
    onPrimaryContainer = Color(0xFFEDEFF2),
    secondary = NexusBlue,
    secondaryContainer = Color(0xFF14353B),
    onSecondaryContainer = NexusCyan,
    background = Color.Black,
    onBackground = Color.White,
    surface = NexusSurface,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF18191C),
    onSurfaceVariant = Color(0xFFC2C4CD),
    outline = Color(0xFF3D424B),
    error = Color(0xFFFF8992)
)

private val LightPalette = lightColorScheme(
    primary = NexusBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8F8FF),
    onPrimaryContainer = NexusLightText,
    secondary = NexusCyan,
    secondaryContainer = Color(0xFFD7F5FA),
    onSecondaryContainer = Color(0xFF0B596C),
    background = NexusLightBackground,
    onBackground = Color.Black,
    surface = Color.White,
    onSurface = NexusLightText,
    surfaceVariant = Color(0xFFE7EEF5),
    onSurfaceVariant = Color(0xFF4C6075),
    outline = Color(0xFFC4D1DF),
    error = Color(0xFFBF2533)
)

private val NexusTypography = MaterialTypography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 29.sp, lineHeight = 35.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 23.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp)
)

/** Application resources keep the device setting even when Activity overrides its uiMode. */
@Composable
fun NexusSystemIsDark(): Boolean =
    (LocalContext.current.applicationContext.resources.configuration.uiMode and
        Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

@Composable
fun NexusTheme(preference: String, content: @Composable () -> Unit) {
    val dark = when (preference) {
        "dark" -> true
        "light" -> false
        else -> NexusSystemIsDark()
    }
    val context = LocalContext.current
    val configuration = Configuration(LocalConfiguration.current).apply {
        uiMode = (uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or
            if (dark) Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO
    }
    val themedContext = remember(context, configuration) {
        ContextThemeWrapper(context, context.theme).apply { applyOverrideConfiguration(configuration) }
    }
    CompositionLocalProvider(LocalContext provides themedContext, LocalConfiguration provides configuration) {
        MaterialTheme(colorScheme = if (dark) DarkPalette else LightPalette,
            typography = NexusTypography) {
            CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onBackground) {
                content()
            }
        }
    }
}
