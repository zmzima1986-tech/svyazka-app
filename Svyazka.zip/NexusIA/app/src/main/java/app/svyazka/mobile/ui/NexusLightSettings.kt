package app.svyazka.mobile.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.svyazka.mobile.R

/** Light-only settings from the approved Frosted Glass reference.
 *  All controls keep the original NexusComposeUi behavior and localization.
 */
@Composable
internal fun NexusLightSettingsScreen(ui: NexusComposeUi) {
    val themes = listOf("system" to R.string.theme_system, "dark" to R.string.theme_dark,
        "light" to R.string.theme_light)
    val languages = listOf("system" to R.string.language_system, "ru" to R.string.language_ru,
        "en" to R.string.language_en, "zh-CN" to R.string.language_zh,
        "ar" to R.string.language_ar, "ja" to R.string.language_ja)
    val language = ui.activity.nexusLanguageChoice()
    var languageOpen by remember { mutableStateOf(false) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            NexusLightSettingCard {
                NexusLightSettingHeading(stringResource(R.string.settings_appearance),
                    R.drawable.ic_nia_theme, isSun = true)
                Spacer(Modifier.height(12.dp))
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    if (maxWidth >= 290.dp) {
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            themes.forEach { (key, res) ->
                                NexusLightThemeChip(stringResource(res), ui.theme == key,
                                    onClick = { ui.activity.nexusThemeChanged(key) },
                                    modifier = Modifier.weight(1f))
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            themes.forEach { (key, res) ->
                                NexusLightThemeChip(stringResource(res), ui.theme == key,
                                    onClick = { ui.activity.nexusThemeChanged(key) },
                                    modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            }
        }
        item {
            NexusLightSettingCard {
                NexusLightSettingHeading(stringResource(R.string.settings_language),
                    R.drawable.ic_nia_language)
                Spacer(Modifier.height(12.dp))
                Box {
                    // A single clipped glass layer: do not draw a separate bright
                    // stripe behind the text and chevron.
                    val languageShape = RoundedCornerShape(18.dp)
                    Row(Modifier.fillMaxWidth()
                            .shadow(1.dp, languageShape)
                            .clip(languageShape)
                            .background(NexusLightDesign.glass)
                            .border(1.dp, NexusLightDesign.border, languageShape)
                            .clickable(role = Role.Button) { languageOpen = true }
                            .padding(horizontal = 15.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(languages.firstOrNull { it.first == language }?.second
                                ?: R.string.language_system),
                                color = NexusLightDesign.ink, fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Icon(painterResource(R.drawable.ic_nia_chevron_down),
                                contentDescription = null,
                                tint = NexusLightDesign.ink, modifier = Modifier.size(22.dp))
                    }
                    DropdownMenu(expanded = languageOpen,
                        onDismissRequest = { languageOpen = false },
                        containerColor = Color(0xFFF9FAFF)) {
                        languages.forEach { (key, label) ->
                            DropdownMenuItem(text = { Text(stringResource(label)) },
                                leadingIcon = { RadioButton(selected = language == key, onClick = null) },
                                onClick = {
                                    languageOpen = false
                                    ui.activity.nexusLanguageChanged(key)
                                })
                        }
                    }
                }
            }
        }
        item {
            NexusLightSettingCard(onClick = { ui.requestKeys() }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        NexusLightSettingHeading(stringResource(R.string.settings_providers),
                            R.drawable.ic_nia_key)
                        Spacer(Modifier.height(10.dp))
                        Text(stringResource(R.string.keys_warning),
                            style = MaterialTheme.typography.bodyMedium,
                            color = NexusLightDesign.secondary)
                    }
                    Spacer(Modifier.width(8.dp))
                    Icon(painterResource(R.drawable.ic_nia_chevron_down),
                        contentDescription = null, tint = NexusLightDesign.ink,
                        modifier = Modifier.size(20.dp))
                }
            }
        }
        item {
            NexusLightSettingCard {
                NexusLightSettingHeading(stringResource(R.string.settings_about),
                    R.drawable.ic_nia_info)
                Spacer(Modifier.height(10.dp))
                Text(stringResource(R.string.settings_version),
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexusLightDesign.secondary)
                Spacer(Modifier.height(4.dp))
                Text(stringResource(R.string.settings_privacy),
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexusLightDesign.secondary)
                Spacer(Modifier.height(12.dp))
                var noTrainingOnly by remember { mutableStateOf(ui.activity.nexusNoTrainingOnly()) }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.privacy_no_training_label),
                            style = MaterialTheme.typography.bodyMedium)
                        Text(stringResource(R.string.privacy_no_training_hint),
                            style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = noTrainingOnly, onCheckedChange = { checked ->
                        noTrainingOnly = checked
                        ui.activity.nexusNoTrainingChanged(checked)
                    })
                }

            }
        }
        item { Spacer(Modifier.height(15.dp)) }
    }
}

@Composable
private fun NexusLightSettingCard(onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = NexusLightDesign.cardShape
    val modifier = Modifier.fillMaxWidth().shadow(5.dp, shape,
        ambientColor = Color(0x338291B4), spotColor = Color(0x338291B4))
    if (onClick == null) {
        Surface(modifier = modifier, shape = shape,
            color = NexusLightDesign.glass,
            border = BorderStroke(1.dp, NexusLightDesign.glassHighlight),
            tonalElevation = 0.dp) {
            Column(Modifier.fillMaxWidth().padding(16.dp), content = content)
        }
    } else {
        Surface(onClick = onClick, modifier = modifier, shape = shape,
            color = NexusLightDesign.glass,
            border = BorderStroke(1.dp, NexusLightDesign.glassHighlight),
            tonalElevation = 0.dp) {
            Column(Modifier.fillMaxWidth().padding(16.dp), content = content)
        }
    }
}

@Composable
private fun NexusLightSettingHeading(label: String, iconRes: Int, isSun: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (isSun) {
            Icon(Icons.Outlined.WbSunny, null, Modifier.size(30.dp),
                tint = Color(0xFFF7C400))
        } else {
            Icon(painterResource(iconRes), null, Modifier.size(30.dp),
                tint = NexusLightDesign.blue)
        }
        Text(label, style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold, color = NexusLightDesign.ink,
            maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun NexusLightThemeChip(label: String, selected: Boolean,
    onClick: () -> Unit, modifier: Modifier
) {
    val shape = RoundedCornerShape(18.dp)
    // Paint the translucent fill only once, including beneath the label.
    // This avoids a high-contrast horizontal band from stacked light surfaces.
    Box(modifier.heightIn(min = 44.dp)
            .shadow(if (selected) 3.dp else 1.dp, shape)
            .clip(shape)
            .background(if (selected) NexusLightDesign.actionGradient
                else Brush.horizontalGradient(listOf(
                    NexusLightDesign.glass, NexusLightDesign.glass)))
            .border(1.dp,
                if (selected) NexusLightDesign.blue else NexusLightDesign.border, shape)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center) {
        Text(label, modifier = Modifier.padding(horizontal = 5.dp, vertical = 11.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold, fontSize = 14.sp,
            color = if (selected) Color.White else NexusLightDesign.ink,
            maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
    }
}
