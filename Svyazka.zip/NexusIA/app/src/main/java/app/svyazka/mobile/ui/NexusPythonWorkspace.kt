package app.svyazka.mobile.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.svyazka.mobile.R
import org.json.JSONArray

/** A manual mini-project belongs to one chat. Automated verification has another engine. */
@Composable
fun NexusPythonWorkspace(ui: NexusComposeUi) {
    val state = ui.snapshot
    val clipboard = LocalClipboardManager.current
    val save = rememberSaveResultAction(ui.pythonEditingCode, ui.pythonFileName)
    val blocks = ui.pythonCodeBlocks
    var selected by remember(blocks, ui.pythonStep) { mutableIntStateOf(0) }
    var allowedPackage by remember { mutableStateOf("") }
    var extended by remember { mutableStateOf(false) }
    var confirmExtended by remember { mutableStateOf(false) }
    var showArtifacts by remember { mutableStateOf(false) }
    var toolPanel by remember { mutableStateOf<PythonToolPanel?>(null) }

    fun launch(confirmedExtended: Boolean = false) {
        if (!ui.pythonFileName.endsWith(".py")) return
        if ((!ui.pythonRemote || ui.pythonFileList.size > 1) && extended && !confirmedExtended) {
            confirmExtended = true
            return
        }
        val accepted = if (ui.pythonRemote && ui.pythonFileList.size <= 1) {
            ui.activity.nexusExecutePython(ui.pythonStep, ui.pythonEditingCode,
                ui.pythonStdin, true, false)
        } else ui.activity.nexusExecutePythonProject(ui.pythonFileName,
            ui.pythonEditingCode, ui.pythonStdin, allowedPackage, extended)
        if (accepted) showArtifacts = false
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val drawerWidth = minOf(344.dp, maxWidth - 4.dp)
        Column(Modifier.fillMaxSize().padding(vertical = 8.dp)
            .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.python_run_title), style = MaterialTheme.typography.titleMedium)
            PythonProjectFiles(ui)
            TextButton(onClick = { toolPanel = PythonToolPanel.MENU }) {
                Text(stringResource(R.string.ws_easy_tools))
            }
            NexusPrimaryButton(text = stringResource(R.string.ws_easy_run),
                enabled = !state.active && !state.clearing && !ui.pythonBusy &&
                    ui.pythonEditingCode.isNotBlank() && ui.pythonFileName.endsWith(".py"),
                onClick = { launch() }, modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Outlined.PlayArrow, null) }, glow = false)
            if (ui.pythonBusy) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(21.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(9.dp))
                    Text(stringResource(R.string.status_processing), modifier = Modifier.weight(1f))
                    IconButton(onClick = { ui.activity.nexusCancelPython() }) {
                        Icon(Icons.Outlined.Stop, stringResource(R.string.action_stop))
                    }
                }
            }
            ui.pythonReport?.let { report ->
                val success = report.exitCode == 0
                Text(stringResource(if (success) R.string.ws_easy_run_ok else R.string.ws_easy_run_error),
                    style = MaterialTheme.typography.titleMedium,
                    color = if (success) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                if (report.stdout.isNotBlank()) {
                    SelectionContainer { Text(report.stdout, maxLines = 8) }
                }
                if (report.stderr.isNotBlank()) {
                    SelectionContainer {
                        Text(report.stderr, maxLines = 6, color = MaterialTheme.colorScheme.error)
                    }
                }
                val tests = remember(report.testsJson) {
                    runCatching { JSONArray(report.testsJson) }.getOrNull()
                }
                if (tests != null && tests.length() > 0) {
                    val passed = (0 until tests.length()).count {
                        tests.optJSONObject(it)?.optBoolean("passed") == true
                    }
                    Text(stringResource(R.string.ws_easy_tests_summary, passed, tests.length()),
                        color = if (passed == tests.length()) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error)
                }
                val artifacts = remember(report.artifactsJson) {
                    runCatching { JSONArray(report.artifactsJson).length() }.getOrDefault(0)
                }
                if (artifacts > 0) {
                    TextButton(onClick = { showArtifacts = !showArtifacts }) {
                        Text(stringResource(R.string.ws_easy_artifacts, artifacts))
                    }
                    if (showArtifacts) PythonRunArtifacts(ui)
                }
                if (report.hasVisual) TextButton(onClick = { ui.openVisual() }) {
                    Text(stringResource(R.string.action_show_result))
                }
            }
            ui.pythonError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }

        toolPanel?.let { panel ->
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .52f))
                .clickable { toolPanel = null })
            val dark = MaterialTheme.colorScheme.background == Color.Black
            val surface = if (dark) Color(0xFF10121C).copy(alpha = .94f)
                else Color.White.copy(alpha = .94f)
            Surface(
                modifier = Modifier.align(Alignment.CenterEnd)
                    .width(drawerWidth).fillMaxHeight(),
                shape = RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp),
                color = surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f))
            ) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 10.dp)) {
                    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        if (panel != PythonToolPanel.MENU) {
                            IconButton(onClick = { toolPanel = PythonToolPanel.MENU }) {
                                Icon(Icons.Outlined.ArrowBack, stringResource(R.string.action_back))
                            }
                        }
                        Text(
                            text = stringResource(if (panel == PythonToolPanel.MENU)
                                R.string.ws_easy_tools_title else when (panel) {
                                PythonToolPanel.FILES -> R.string.ws_easy_files_tool
                                PythonToolPanel.EDITOR -> R.string.ws_easy_editor_tool
                                PythonToolPanel.SETTINGS -> R.string.ws_easy_run_settings_tool
                                else -> R.string.ws_easy_tools_title
                            }),
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { toolPanel = null }) {
                            Icon(Icons.Outlined.Close, stringResource(R.string.action_close))
                        }
                    }
                    HorizontalDivider(Modifier.padding(bottom = 10.dp))
                    when (panel) {
                        PythonToolPanel.MENU -> Column(
                            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            PythonToolRow(Icons.Outlined.Folder,
                                stringResource(R.string.ws_easy_files_tool)) {
                                toolPanel = PythonToolPanel.FILES
                            }
                            PythonToolRow(Icons.Outlined.Code,
                                stringResource(R.string.ws_easy_editor_tool)) {
                                toolPanel = PythonToolPanel.EDITOR
                            }
                            PythonToolRow(Icons.Outlined.Settings,
                                stringResource(R.string.ws_easy_run_settings_tool)) {
                                toolPanel = PythonToolPanel.SETTINGS
                            }
                        }
                        PythonToolPanel.FILES -> PythonProjectFileManager(ui)
                        PythonToolPanel.EDITOR -> PythonEditorTool(ui, clipboard, save, blocks,
                            selected, onSelectBlock = { index, code ->
                                selected = index
                                ui.loadPython(ui.activity.nexusFinalStep(), code)
                            })
                        PythonToolPanel.SETTINGS -> PythonRunSettingsTool(ui, allowedPackage,
                            onAllowedPackage = { allowedPackage = it },
                            extended = extended, onExtended = { extended = it })
                        null -> Unit
                    }
                }
            }
        }

        if (confirmExtended) {
            AlertDialog(onDismissRequest = { confirmExtended = false },
                title = { Text(stringResource(R.string.ws_extended_title)) },
                text = { Text(stringResource(R.string.ws_extended_body)) },
                confirmButton = { TextButton(onClick = { confirmExtended = false; launch(confirmedExtended = true) }) {
                    Text(stringResource(R.string.ws_allow))
                } },
                dismissButton = { TextButton(onClick = { confirmExtended = false }) {
                    Text(stringResource(R.string.action_cancel))
                } })
        }
    }
}

private enum class PythonToolPanel { MENU, FILES, EDITOR, SETTINGS }

@Composable
private fun PythonToolRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    action: () -> Unit
) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
        .clickable(onClick = action)
        .heightIn(min = 50.dp).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(15.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun PythonEditorTool(
    ui: NexusComposeUi,
    clipboard: androidx.compose.ui.platform.ClipboardManager,
    save: () -> Unit,
    blocks: List<String>,
    selected: Int,
    onSelectBlock: (Int, String) -> Unit
) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (ui.snapshot.resultHasPython && ui.snapshot.complete && !ui.pythonBusy) {
            TextButton(onClick = { ui.activity.nexusRunPython(ui.activity.nexusFinalStep()) }) {
                Text(stringResource(R.string.load_answer))
            }
        }
        if (blocks.size > 1 && !ui.pythonBusy) {
            Column {
                blocks.forEachIndexed { index, code ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = index == selected,
                            onClick = { onSelectBlock(index, code) })
                        Text(stringResource(R.string.python_block, index + 1),
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        PythonProjectEditor(ui)
        if (!ui.pythonBusy) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                TextButton(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 0.dp, vertical = 8.dp),
                    onClick = { clipboard.getText()?.text?.let {
                        if (it.length <= 75_000) ui.loadPython(-1, it)
                    } }
                ) {
                    Text(stringResource(R.string.editor_paste), fontSize = 14.sp,
                        maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                }
                TextButton(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 0.dp, vertical = 8.dp),
                    enabled = ui.pythonEditingCode.isNotBlank(),
                    onClick = { clipboard.setText(AnnotatedString(ui.pythonEditingCode)) }
                ) {
                    Text(stringResource(R.string.action_copy), fontSize = 14.sp,
                        maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                }
                TextButton(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 0.dp, vertical = 8.dp),
                    enabled = ui.pythonEditingCode.isNotBlank(),
                    onClick = save
                ) {
                    Text(stringResource(R.string.action_save), fontSize = 14.sp,
                        maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun PythonRunSettingsTool(
    ui: NexusComposeUi,
    allowedPackage: String,
    onAllowedPackage: (String) -> Unit,
    extended: Boolean,
    onExtended: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        NexusLabel(stringResource(R.string.python_scope))
        OutlinedTextField(value = ui.pythonStdin,
            onValueChange = { if (it.length <= 16_000) ui.pythonStdin = it },
            modifier = Modifier.fillMaxWidth(), maxLines = 4,
            label = { Text(stringResource(R.string.python_input_hint)) })
        if (ui.pythonHasPiston) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = ui.pythonRemote, onCheckedChange = {
                    ui.pythonRemote = it
                    if (it) { onAllowedPackage(""); onExtended(false) }
                }, enabled = ui.pythonFileList.size <= 1)
                Text(stringResource(R.string.python_use_piston),
                    style = MaterialTheme.typography.bodySmall)
            }
            if (ui.pythonRemote && ui.pythonFileList.size <= 1) {
                NexusLabel(stringResource(R.string.python_warning_remote))
            }
            if (ui.pythonFileList.size > 1) {
                NexusLabel(stringResource(R.string.ws_remote_single))
            }
        }
        if (!ui.pythonRemote || ui.pythonFileList.size > 1) {
            Text(stringResource(R.string.ws_package),
                style = MaterialTheme.typography.labelMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = allowedPackage.isEmpty() && !extended,
                    onClick = { onAllowedPackage(""); onExtended(false) })
                Text(stringResource(R.string.ws_no_package),
                    style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = allowedPackage == "numpy" && !extended,
                    onClick = { onAllowedPackage("numpy"); onExtended(false) })
                Text("NumPy 2.4.6",
                    style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = allowedPackage == "matplotlib" && !extended,
                    onClick = { onAllowedPackage("matplotlib"); onExtended(false) })
                Text(stringResource(R.string.ws_matplotlib),
                    style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = extended, onCheckedChange = {
                    onExtended(it)
                    if (it) onAllowedPackage("")
                })
                Text(stringResource(R.string.ws_extended),
                    style = MaterialTheme.typography.bodySmall)
            }
            if (extended) NexusLabel(stringResource(R.string.ws_extended_body))
        }
    }
}

@Composable
private fun PythonProjectEditor(ui: NexusComposeUi) {
    val code = ui.pythonEditingCode
    var editor by remember(ui.pythonFileName) { mutableStateOf(TextFieldValue(code)) }
    var find by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf("") }
    var targetLine by remember { mutableStateOf("") }
    var showSearchTools by remember(ui.pythonFileName) { mutableStateOf(false) }
    LaunchedEffect(code) {
        if (editor.text != code) editor = editor.copy(text = code, selection = TextRange(0))
    }
    fun edit(next: TextFieldValue) {
        editor = next
        ui.editPython(next.text)
    }
    val cursor = editor.selection.start.coerceIn(0, editor.text.length)
    Text((if (ui.pythonFileDirty) "● " else "") +
        stringResource(R.string.ws_editor_stats, ui.pythonFileName, code.count { it == '\n' } + 1,
            code.take(cursor).count { it == '\n' } + 1),
        style = MaterialTheme.typography.labelMedium)
    OutlinedTextField(value = editor, onValueChange = { if (it.text.length <= 75_000) edit(it) },
        modifier = Modifier.fillMaxWidth(), enabled = !ui.pythonBusy && !ui.snapshot.active,
        minLines = 6, maxLines = 10,
        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
        label = { Text(stringResource(R.string.ui_code)) })
    TextButton(onClick = { edit(TextFieldValue("")) },
        enabled = code.isNotEmpty() && !ui.pythonBusy && !ui.snapshot.active) {
        Text(stringResource(R.string.editor_clear))
    }
    TextButton(onClick = { showSearchTools = !showSearchTools }) {
        Text(stringResource(R.string.ws_find))
    }
    if (showSearchTools) {
    OutlinedTextField(value = find, onValueChange = { find = it.take(200) },
        modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.ws_find)) })
    OutlinedTextField(value = replace, onValueChange = { replace = it.take(200) },
        modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.ws_replace_with)) })
    Row {
        TextButton(enabled = find.isNotEmpty(), onClick = {
            val offset = code.indexOf(find, startIndex = cursor).takeIf { it >= 0 }
                ?: code.indexOf(find)
            if (offset >= 0) editor = editor.copy(selection = TextRange(offset,offset + find.length))
        }) { Text(stringResource(R.string.ws_find_next)) }
        TextButton(enabled = find.isNotEmpty(), onClick = {
            if (code.contains(find)) edit(editor.copy(text = code.replace(find, replace)))
        }) { Text(stringResource(R.string.ws_replace_all)) }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = targetLine, onValueChange = { targetLine = it.take(7) },
            modifier = Modifier.width(118.dp), singleLine = true,
            label = { Text(stringResource(R.string.ws_line)) })
        TextButton(onClick = {
            val line = targetLine.toIntOrNull()?.coerceAtLeast(1) ?: 1
            val offset = if (line == 1) 0 else {
                var index = -1
                repeat(line - 1) { index = code.indexOf('\n', index + 1).takeIf { it >= 0 } ?: code.length }
                (index + 1).coerceAtMost(code.length)
            }
            editor = editor.copy(selection = TextRange(offset))
        }) { Text(stringResource(R.string.ws_go)) }
    }
    }
}

@Composable
private fun PythonRunOutput(ui: NexusComposeUi) {
    val report = ui.pythonReport
    if (report == null) { NexusLabel(stringResource(R.string.ws_output_empty)); return }
    HorizontalDivider()
    Text(stringResource(R.string.ui_result), style = MaterialTheme.typography.titleMedium)
    NexusLabel(report.engine + (report.exitCode?.let { stringResource(R.string.ws_exit_code, it) } ?:
        stringResource(R.string.ws_stopped)))
    NexusLabel(stringResource(R.string.ws_level) + when {
        report.exitCode == null -> stringResource(R.string.ws_not_finished)
        report.exitCode == 0 -> stringResource(R.string.ws_executed)
        else -> stringResource(R.string.ws_error)
    })
    if (report.snapshotSha256.isNotBlank()) NexusLabel(stringResource(R.string.ws_sha, report.snapshotSha256))
    if (report.status.isNotBlank()) Text(report.status, style = MaterialTheme.typography.bodySmall)
    Text(stringResource(R.string.python_stdout), style = MaterialTheme.typography.labelLarge)
    SelectionContainer { Text(report.stdout.ifBlank { stringResource(R.string.python_no_output) }) }
    if (report.stderr.isNotBlank()) {
        Text(stringResource(R.string.python_stderr), style = MaterialTheme.typography.labelLarge)
        SelectionContainer { Text(report.stderr, color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)) }
        val location = Regex("""File "([^"]+)", line (\d+)""").find(report.stderr)
        if (location != null) TextButton(onClick = {
            val name = location.groupValues[1].substringAfterLast("/workspace/")
            if (ui.pythonFileList.contains(name)) ui.openPythonFile(name)
            // The editor provides an explicit line-number navigation field.
        }) { Text(stringResource(R.string.ws_goto_error)) }
    }
    if (report.hasVisual) TextButton(onClick = { ui.openVisual() }) {
        Text(stringResource(R.string.action_show_result))
    }
    if (report.stderr.isNotBlank()) TextButton(onClick = {
        ui.chatTextChanged("Проверь ошибку Python и предложи конкретное исправление. " +
            "Исходный код и секреты не отправляй автоматически. Диагностика:\n" +
            report.stderr.take(1600))
        ui.selectPage(NexusComposeUi.Page.TASK)
    }) { Text(stringResource(R.string.ws_ask_ai)) }
    if (report.diagnostic.isNotBlank()) TextButton(onClick = {
        ui.activity.nexusSendPythonError(); ui.dismissPythonResult()
    }) { Text(stringResource(R.string.python_error_to_review)) }
    OutlinedButton(onClick = { ui.dismissPythonResult() }) { Text(stringResource(R.string.action_close)) }
}
