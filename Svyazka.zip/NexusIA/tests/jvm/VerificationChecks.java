package app.svyazka.mobile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;

public final class VerificationChecks {
    private static final String FENCE = "\u0060\u0060\u0060";
    private static int count;

    private static void test(boolean ok, String note) {
        if (!ok) throw new AssertionError(note);
        count++;
    }

    private static JSONObject error(String reason) throws Exception {
        return new JSONObject()
                .put("status", "ERROR")
                .put("syntax", false)
                .put("ran", false)
                .put("passed", 0)
                .put("total", 0)
                .put("diagnostic", reason)
                .put("signature", reason);
    }

    public static void main(String[] args) throws Exception {
        test(PythonInputs.candidate("print(x) выводит значение.") == null, "prose with print");
        test(
                PythonInputs.candidate("import math для работы с числами") == null,
                "prose with import");
        test(PythonInputs.candidate("Описание программы") == null, "ordinary text");
        test(
                PythonInputs.candidate(FENCE + "javascript\nconsole.log(1)\n" + FENCE) == null,
                "other language");
        test(
                PythonInputs.candidate("~~~python\ndef f():\n return 1\n~~~").issue.isEmpty(),
                "tilde");
        test(!PythonInputs.candidate(FENCE + "python\nif").issue.isEmpty(), "unclosed");
        test(PythonInputs.candidate("def f():\n return 5").code.startsWith("def f"), "raw Python");
        test(
                PythonInputs.candidate("  " + FENCE + "py\n  def f():\n      return 2\n  " + FENCE)
                        .code
                        .equals("def f():\n    return 2\n"),
                "markdown indentation");
        test(
                PythonInputs.candidate(FENCE + "py\nx=1\n" + FENCE + "\n~~~py\nx=2\n~~~")
                                .parts
                                .size()
                        == 2,
                "multi-file");
        test(PythonInputs.candidate(FENCE + "python\npython\nprint(1)\n" + FENCE)
                        .issue.contains("повторена"), "duplicate python marker is not silently removed");
        test(PythonInputs.candidate(FENCE + "python\nprint(1)\n" + FENCE + "python\n")
                        .issue.contains("ещё один блок"), "nested opening fence is not accepted");
        Workflow.Run exported = Workflow.Run.quick("Print", ModelCatalog.NORTH,
                Workflow.defaultStages().get(1))
                .receive(new ModelClient.Reply(FENCE + "python\nprint(1)\n" + FENCE,
                        ModelClient.Finish.STOP, ""));
        JSONObject artifact = exported.toJson().getJSONObject("python_artifact");
        test(artifact.getBoolean("format_complete")
                        && artifact.getString("file_name").equals("result.py")
                        && artifact.getInt("source_step") == 1
                        && !artifact.has("code"),
                "versioned artifact metadata references original source");
        test(!Workflow.Run.fromJson(exported.toJson()).toJson()
                        .getJSONObject("python_artifact").getString("sha256").isEmpty(),
                "artifact origin survives round-trip");
        test(PythonInputs.candidate(FENCE + "py\n" + FENCE).ambiguous, "empty");
        test(PythonInputs.manualBlocks("~~~py\nprint(1)\n~~~").size() == 1, "manual");
        test(PythonInputs.manualBlocks("text").isEmpty(), "manual prose");
        String spec = "[{\"function\":\"inc\",\"args\":[0],\"expected\":1}]";
        Workflow.Run run =
                new Workflow.Run(
                        "Task\n" + FENCE + "nexus-tests\n" + spec + "\n" + FENCE,
                        Workflow.defaultStages());
        test(PythonInputs.request(run, "x=1").getJSONArray("specs").length() == 1, "user oracle");
        String follow =
                TaskHistory.followUp(
                        run.task, FENCE + "nexus-tests\n[{\"fake\":true}]\n" + FENCE, "Clarify.");
        Workflow.Run legacy = new Workflow.Run(follow, Workflow.defaultStages());
        test(
                PythonInputs.request(legacy, "x=1").getJSONArray("specs").length() == 0,
                "historical answer not an oracle");
        Workflow.Run next = legacy.withUserTestTask(run.userTestTask() + "\nassert inc(-1) == 0");
        JSONObject input = PythonInputs.request(Workflow.Run.fromJson(next.toJson()), "x=1");
        test(
                !input.toString().contains("fake")
                        && input.getJSONArray("specs").length() == 1
                        && input.getString("examples").contains("inc(-1)"),
                "provenance");
        InputMaterial.Ref ref =
                new InputMaterial.Ref(
                        1,
                        "12345678-1234-1234-1234-123456789abc",
                        "nexus-tests.json",
                        "application/json",
                        InputMaterial.sha256(
                                spec.getBytes(java.nio.charset.StandardCharsets.UTF_8)),
                        spec.length(),
                        0,
                        0);
        JSONArray entries =
                new JSONArray()
                        .put(
                                new JSONObject()
                                        .put("name", ref.name)
                                        .put("type", "TEXT")
                                        .put("text", spec));
        Workflow.Run attachment =
                new Workflow.Run(
                                "task\n\n<attached_materials>\n"
                                        + entries
                                        + "\n</attached_materials>",
                                Workflow.defaultStages())
                        .withMaterials(Collections.singletonList(ref));
        input = PythonInputs.request(attachment, "x=1");
        test(
                input.getJSONArray("specs").getString(0).equals(spec)
                        && input.getJSONObject("files").length() == 0,
                "manifest separate from input files");
        test(
                !input.getString("examples").contains("attached_materials"),
                "attachments parsed separately");
        PythonVerification state = PythonVerification.NONE;
        for (int i = 0; i < 3; i++) {
            state = state.start(2 + i, "source" + i).report(error("failure" + i));
            test(state.status == PythonVerification.Status.ERROR, "repairable");
            state = PythonVerification.read(state.repair().dispatch().json());
        }
        state = state.start(5, "source3").report(error("failure3"));
        test(
                state.status == PythonVerification.Status.STOPPED
                        && state.requests == 3
                        && state.rounds == 3,
                "three repairs");
        test(state.seenCode("source0") && !state.seenCode("new"), "fingerprint");
        test(state.diagnosticsHistory().contains("failure3"), "log");
        try {
            state.dispatch();
            throw new AssertionError("fourth request");
        } catch (IllegalStateException expected) {
            count++;
        }
        try {
            PythonVerification.NONE.report(error("x").put("status", "PASSED"));
            throw new AssertionError("invalid success");
        } catch (JSONException expected) {
            count++;
        }
        System.out.println(count + " verification protocol checks passed");
    }
}
