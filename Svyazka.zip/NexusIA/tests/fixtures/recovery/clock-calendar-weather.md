**Готовый файл `index.html`**  
В нём исправлены замеченные недочёты:

1. **Календарь** – правильное смещение ячеек, теперь недели начинаются с воскресенья (заголовок `['Вс','Пн','Вт','Ср','Чт','Пт','Сб']`).  
2. **Заголовок погоды** формируется динамически из константы `CITY_NAME`.  
3. **Обработка ошибок погоды** – выводится понятное сообщение, а не технический код ошибки.  
4. Добавлен небольшой индикатор «Обновлено …» для погоды (полезно при автоматическом обновлении).

```html
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Часы, Календарь и Погода</title>
    <style>
        body {font-family: Arial, sans-serif; margin: 20px; background:#f5f5f5; color:#333;}
        .widget {background:#fff; padding:15px; margin-bottom:20px; border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,.1);}
        h2 {margin-top:0; font-size:1.4em;}
        #clock {font-size:2em; font-weight:bold;}
        #date {font-size:1.2em; margin-bottom:10px;}
        table.calendar {border-collapse:collapse; width:100%;}
        table.calendar th,
        table.calendar td {border:1px solid #ddd; width:14.28%; text-align:center; padding:5px;}
        table.calendar th {background:#eaeaea;}
        .today {background:#ffeb3b;}
        #weather {font-size:1.1em;}
        .weather-icon {vertical-align:middle; margin-right:6px;}
        .weather-meta {font-size:0.9em; color:#666; margin-top:4px;}
    </style>
</head>
<body>

<div class="widget" id="clockWidget">
    <h2>Текущее время</h2>
    <div id="clock">--:--:--</div>
</div>

<div class="widget" id="calendarWidget">
    <h2>Календарь</h2>
    <div id="date">...</div>
    <table class="calendar" id="calendarTable"></table>
</div>

<div class="widget" id="weatherWidget">
    <h2 id="weatherTitle">Погода</h2>
    <div id="weather">Загрузка…</div>
    <div class="weather-meta" id="weatherMeta"></div>
</div>

<script>
/* ==================== 1. CLOCK ==================== */
function updateClock() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('ru-RU', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    document.getElementById('clock').textContent = timeStr;
}
setInterval(updateClock, 1000);
updateClock();   // первая отрисовка

/* ==================== 2. CALENDAR ==================== */
function renderCalendar() {
    const now = new Date();
    const month = now.getMonth();          // 0‑based
    const year = now.getFullYear();

    const monthNames = ['Январь','Февраль','Март','Апрель','Май','Июнь',
                        'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
    document.getElementById('date').textContent = `${monthNames[month]} ${year}`;

    const firstDay = new Date(year, month, 1).getDay(); // 0‑Sun … 6‑Sat
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const table = document.getElementById('calendarTable');
    table.innerHTML = '';

    // --- заголовок недели (воскресенье первым) ---
    const header = document.createElement('tr');
    const wdNames = ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'];
    wdNames.forEach(d => {
        const th = document.createElement('th');
        th.textContent = d;
        header.appendChild(th);
    });
    table.appendChild(header);

    // --- заполнение дней ---
    let tr = document.createElement('tr');

    // пустые ячейки перед первым числом
    for (let i = 0; i < firstDay; i++) {
        tr.appendChild(document.createElement('td'));
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const td = document.createElement('td');
        td.textContent = day;
        if (day === now.getDate()) td.classList.add('today');
        tr.appendChild(td);

        // переход на новую строку после субботы
        if ((firstDay + day) % 7 === 0) {
            table.appendChild(tr);
            tr = document.createElement('tr');
        }
    }

    // оставшиеся ячейки последней недели
    while (tr.children.length < 7) tr.appendChild(document.createElement('td'));
    table.appendChild(tr);
}
renderCalendar();

/* ==================== 3. WEATHER ==================== */
/*
   Open‑Meteo API (https://open-meteo.com)
   Пример запроса:
   https://api.open-meteo.com/v1/forecast?latitude=55.75&longitude=37.62&current_weather=true
   Коды погоды → эмодзи: https://open-meteo.com/en/docs#weathercode
*/
const LATITUDE  = 55.75;   // Москва
const LONGITUDE = 37.62;
const CITY_NAME = 'Москва';

document.getElementById('weatherTitle').textContent = `Погода в ${CITY_NAME}`;

async function loadWeather() {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${LATITUDE}&longitude=${LONGITUDE}&current_weather=true`;
    try {
        const resp = await fetch(url);
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const data = await resp.json();
        const w = data.current_weather;

        const temp = Math.round(w.temperature);
        const wind = Math.round(w.windspeed);
        const code = w.weathercode;

        // сопоставление кода погоды и эмодзи
        const codeMap = {
            0: "☀️", 1: "🌤", 2: "⛅️", 3: "☁️",
            45: "🌫", 48: "🌫", 51: "🌦", 53: "🌦",
            55: "🌦", 56: "🌨", 57: "🌨", 61: "🌧",
            63: "🌧", 65: "🌧", 66: "🌨", 67: "🌨",
            71: "❄️", 73: "❄️", 75: "❄️", 77: "❄️",
            80: "🌧", 81: "🌧", 82: "🌧", 85: "❄️",
            86: "❄️", 95: "⛈", 96: "⛈", 99: "⛈"
        };
        const icon = codeMap[code] || "❓";

        document.getElementById('weather').innerHTML =
            `<span class="weather-icon">${icon}</span>
             <strong>${temp}°C</strong>, ветром ${wind} м/с`;

        const now = new Date();
        document.getElementById('weatherMeta').textContent =
            `Обновлено: ${now.toLocaleTimeString('ru-RU', {hour:'2-digit', minute:'2-digit'})}`;
    } catch (e) {
        console.error('Weather fetch error:', e);
        document.getElementById('weather').textContent =
            'Не удалось загрузить погоду, проверьте подключение к интернету.';
        document.getElementById('weatherMeta').textContent = '';
    }
}
loadWeather();

// автообновление каждые 15 минут
setInterval(loadWeather, 15 * 60 * 1000);
</script>

</body>
</html>
```

### Как пользоваться
1. Скопируйте код в файл **`index.html`**.  
2. Откройте его двойным щелчком в любом современном браузере (Chrome, Edge, Firefox, Safari).  
3. Виджеты покажут текущее время, календарь текущего месяца и погоду в указанном городе (по умолчанию — Москва).  

**Смена города** – измените в скрипте три константы:
```javascript
const LATITUDE  = <широта>;
const LONGITUDE = <долгота>;
const CITY_NAME = '<название>';
```
Например, для Санкт‑Петербурга: `59.93`, `30.33`, `'Санкт‑Петербург'`.  

Все зависимости находятся в самом файле, никаких внешних библиотек не требуется.