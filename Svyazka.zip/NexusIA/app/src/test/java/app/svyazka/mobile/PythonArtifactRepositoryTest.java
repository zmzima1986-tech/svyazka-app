package app.svyazka.mobile;

import android.content.Context;
import androidx.test.core.app.ApplicationProvider;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class PythonArtifactRepositoryTest {
    private static boolean contains(List<NexusArtifact> artifacts, long id) {
        for (NexusArtifact item : artifacts) if (item.id == id) return true;
        return false;
    }

    @Test public void offlineFileCreatesArtifactNotChatHistory() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long chat = chats.create("");
            long project = artifacts.createUnlinked();
            assertEquals(0L, artifacts.forChat(chat));
            files.putText(project, "main.py", "print(1)");
            assertTrue(artifacts.touch(project, "main.py"));
            assertTrue(contains(artifacts.list(files), project));
            assertEquals("print(1)", files.text(project, "main.py"));
            assertFalse(chats.list().stream().anyMatch(item -> item.id == chat));
            long otherChat = chats.create("");
            assertEquals(0L, artifacts.forChat(otherChat));
            long otherProject = artifacts.createUnlinked();
            assertEquals(0L, artifacts.forChat(otherChat));
            assertNotEquals(project, otherProject);
            files.putText(otherProject, "main.py", "print(2)");
            assertTrue(artifacts.touch(otherProject, "main.py"));
            assertEquals("print(1)", files.text(project, "main.py"));
            assertEquals("print(2)", files.text(otherProject, "main.py"));
        }
    }

    @Test public void projectAndTitleSurviveReopeningBothDatabases() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        long project;
        long chat;
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            chat = chats.create("");
            project = artifacts.ensureForChat(chat);
            files.putText(project, "check.py", "assert 5 + 5 == 10");
            assertTrue(artifacts.touch(project, "check.py"));
            assertTrue(artifacts.rename(project, "Тестовый проект"));
        }
        try (PythonArtifactRepository reopened = new PythonArtifactRepository(context)) {
            assertEquals(project, reopened.forChat(chat));
            NexusArtifact saved = reopened.list(files).stream()
                    .filter(item -> item.id == project).findFirst().orElse(null);
            assertNotNull(saved);
            assertEquals("Тестовый проект", saved.title);
            assertEquals("assert 5 + 5 == 10", files.text(project, "check.py"));
        }
    }

    @Test public void chatDeletionDoesNotDeleteSeparateProject() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long chat = chats.create("");
            long project = artifacts.ensureForChat(chat);
            files.putText(project, "main.py", "print('safe')");
            assertTrue(artifacts.touch(project, "main.py"));
            assertTrue(chats.delete(chat));
            artifacts.unlinkChat(chat);
            assertEquals(0L, artifacts.forChat(chat));
            assertTrue(contains(artifacts.list(files), project));
            assertEquals("print('safe')", files.text(project, "main.py"));
        }
    }

    @Test public void standaloneProjectCanBeUsedBySeveralChatsWithoutCopyingFiles() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long project = artifacts.createUnlinked();
            files.putText(project, "script.py", "print('kept')");
            assertTrue(artifacts.touch(project, "script.py"));
            long firstChat = chats.create("");
            long secondChat = chats.create("");
            assertEquals(0L, artifacts.forChat(firstChat));
            assertTrue(artifacts.attachChat(firstChat, project));
            assertTrue(artifacts.attachChat(secondChat, project));
            assertEquals(project, artifacts.forChat(firstChat));
            assertEquals(project, artifacts.forChat(secondChat));
            files.putText(project, "script.py", "print('fixed with AI')");
            assertTrue(artifacts.touch(project, "script.py"));
            assertEquals("print('fixed with AI')", files.text(project, "script.py"));
            assertTrue(chats.delete(firstChat));
            artifacts.unlinkChat(firstChat);
            assertEquals(0L, artifacts.forChat(firstChat));
            assertEquals(project, artifacts.forChat(secondChat));
            assertTrue(contains(artifacts.list(files), project));
            assertEquals("print('fixed with AI')", files.text(project, "script.py"));
            artifacts.unlinkChat(secondChat);
            assertEquals(0L, artifacts.forChat(secondChat));
            assertTrue(contains(artifacts.list(files), project));
        }
    }

    @Test public void reassigningChatToAnotherArtifactDoesNotDeleteEarlierProject() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long chat = chats.create("");
            long first = artifacts.createUnlinked();
            long second = artifacts.createUnlinked();
            files.putText(first, "main.py", "first");
            files.putText(second, "main.py", "second");
            assertTrue(artifacts.touch(first, "main.py"));
            assertTrue(artifacts.touch(second, "main.py"));
            assertTrue(artifacts.attachChat(chat, first));
            assertTrue(artifacts.attachChat(chat, second));
            assertEquals(second, artifacts.forChat(chat));
            assertEquals("first", files.text(first, "main.py"));
            assertEquals("second", files.text(second, "main.py"));
            assertTrue(contains(artifacts.list(files), first));
            assertTrue(contains(artifacts.list(files), second));
            assertTrue(artifacts.delete(second));
            assertEquals(0L, artifacts.forChat(chat));
            assertFalse(artifacts.attachChat(chat, second));
            assertTrue(artifacts.attachChat(chat, first));
        }
    }

    @Test public void manuallySavedChatAppearsInHistoryWithoutAiOrProject() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository chats = new TaskRepository(context)) {
            long saved = chats.create("");
            long unsaved = chats.create("");
            assertFalse(chats.hasExplicitlySavedChat(saved));
            assertTrue(chats.markSavedChat(saved));
            assertTrue(chats.hasExplicitlySavedChat(saved));
            assertTrue(chats.list().stream().anyMatch(entry -> entry.id == saved));
            assertFalse(chats.list().stream().anyMatch(entry -> entry.id == unsaved));
            assertTrue(chats.delete(saved));
            assertFalse(chats.list().stream().anyMatch(entry -> entry.id == saved));
        }
    }

    @Test public void migrationPreservesOriginalAndDeletionPreventsResurrection() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore legacy = new PythonProjectStore(context);
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long chat = chats.create("");
            legacy.putText(chat, "script.py", "print('original')");
            long project = artifacts.registerLegacy(chat, true, "Python · script.py");
            legacy.copyTo(chat, files, project);
            assertTrue(artifacts.touch(project, "script.py"));
            assertEquals(project, artifacts.registerLegacy(chat, true, "Python · script.py"));
            assertEquals(project, artifacts.forChat(chat));
            assertEquals("print('original')", legacy.text(chat, "script.py"));
            assertEquals("print('original')", files.text(project, "script.py"));
            assertTrue(artifacts.delete(project));
            files.deleteTask(project);
            assertFalse(contains(artifacts.list(files), project));
            assertEquals(0L, artifacts.registerLegacy(chat, true, "Python · script.py"));
            assertEquals("print('original')", legacy.text(chat, "script.py"));
        }
    }

    @Test public void orphanedArtifactFilesRebuildCatalogButTombstonesRemainDeleted() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (PythonArtifactRepository catalog = new PythonArtifactRepository(context)) {
            long orphan = 9_000_000_000L + System.nanoTime() % 1_000_000;
            files.putText(orphan, "main.py", "print('found')");
            assertFalse(catalog.exists(orphan));
            catalog.recoverSavedFiles(files);
            assertTrue(catalog.exists(orphan));
            assertTrue(contains(catalog.list(files), orphan));
            assertTrue(catalog.delete(orphan));
            // Simulate file deletion failing: a durable tombstone still hides the file.
            catalog.recoverSavedFiles(files);
            assertFalse(catalog.exists(orphan));
            assertFalse(contains(catalog.list(files), orphan));
        }
    }

    @Test public void orphanLegacyFilesAreRecoverableWithoutChatResurrection() throws Exception {
        Context context = ApplicationProvider.getApplicationContext();
        PythonProjectStore legacy = new PythonProjectStore(context);
        PythonProjectStore files = new PythonProjectStore(context, true);
        try (TaskRepository chats = new TaskRepository(context);
             PythonArtifactRepository artifacts = new PythonArtifactRepository(context)) {
            long missingChat = 8_000_000_000L + System.nanoTime() % 1_000_000;
            legacy.putText(missingChat, "lost.py", "print('recovered')");
            assertNull(chats.load(missingChat));
            long project = artifacts.registerLegacy(missingChat, false, "Восстановленное");
            legacy.copyTo(missingChat, files, project);
            assertTrue(artifacts.touch(project, "lost.py"));
            assertTrue(contains(artifacts.list(files), project));
            assertEquals(0L, artifacts.forChat(missingChat));
            assertNull(chats.load(missingChat));
        }
    }
}
