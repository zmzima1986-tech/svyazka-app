"""Contracts for the simplified Python workspace; not a substitute for Android testing."""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'
UI = JAVA / 'ui'
RES = ROOT / 'app/src/main/res'


class EasyPythonWorkspaceTests(unittest.TestCase):
    def test_zip_replacement_and_backup_are_atomic_and_separate(self):
        store = (JAVA / 'PythonProjectStore.java').read_text()
        self.assertIn('replaceZip(long taskId, byte[] body)', store)
        self.assertIn('LinkedHashMap<String, byte[]> replacement = parseFullProjectZip(body)', store)
        self.assertIn('previous.finishWrite(out);', store)
        self.assertIn('write(taskId, replacement);', store)
        self.assertLess(store.index('previous.finishWrite(out);'), store.index('write(taskId, replacement);'))
        self.assertIn('restorePrevious(long taskId)', store)
        self.assertIn('previousFile(taskId).delete();', store)
        self.assertIn('if (!parsed.containsKey("main.py"))', store)

    def test_ui_shows_import_result_and_preserves_confirmation(self):
        code = (UI / 'NexusPythonProjectFiles.kt').read_text()
        self.assertIn('nexusPythonReplaceZip', code)
        self.assertIn('pendingProject = incoming.second', code)
        self.assertIn('finishImport(', code)
        self.assertIn('ws_easy_import_success', code)
        self.assertIn('ws_easy_replace_title', code)
        self.assertIn('nexusPythonRestorePreviousProject', code)

    def test_simple_entry_is_default_advanced_tools_are_hidden(self):
        code = (UI / 'NexusPythonWorkspace.kt').read_text()
        self.assertIn('var showAdvancedWorkspace by remember { mutableStateOf(false) }', code)
        self.assertIn('NexusPrimaryButton(text = stringResource(R.string.ws_easy_run)', code)
        self.assertIn('if (showAdvancedWorkspace)', code)
        self.assertIn('ws_easy_tests_summary', code)
        self.assertIn('PythonProjectFiles(ui)', code)

    def test_new_labels_exist_in_all_five_languages(self):
        required = {'ws_easy_choose_project','ws_easy_run','ws_easy_replace_title',
                    'ws_easy_import_success','ws_easy_run_ok','ws_easy_tests_summary',
                    'ws_easy_restore_previous','ws_easy_edit_settings'}
        for locale in ('values','values-en','values-ar','values-ja','values-zh-rCN'):
            root = ET.parse(RES / locale / 'workbench.xml').getroot()
            names = {s.attrib['name'] for s in root.findall('string')}
            self.assertTrue(required.issubset(names), locale)


if __name__ == '__main__':
    unittest.main()
