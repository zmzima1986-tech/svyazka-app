package app.svyazka.mobile;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import org.json.JSONObject;

final class RequestFailure {
    enum Reason { UNKNOWN, ROUTE, DAILY_QUOTA, MODEL_UNAVAILABLE, RESPONSE_REJECTED }

    final int status;
    final Reason reason;
    final long retryAt;

    RequestFailure(int status, Reason reason, long retryAt) {
        this.status = status;
        this.reason = reason;
        this.retryAt = retryAt;
    }

    static RequestFailure of(int status) { return new RequestFailure(status, Reason.UNKNOWN, 0); }

    static RequestFailure read(int status, JSONObject error, String retryAfter, long now) {
        String message = error == null ? "" : error.optString("message").toLowerCase(Locale.ROOT).trim();
        String code = error == null ? "" : error.optString("code");
        JSONObject metadata = error == null ? null : error.optJSONObject("metadata");
        Reason reason = Reason.UNKNOWN;
        if (status == 404 && ("model_not_found".equals(code)
                || message.startsWith("no endpoints found for ")
                || message.startsWith("no endpoint found for model "))) {
            reason = Reason.MODEL_UNAVAILABLE;
        } else if ((status == 429 || status == 503) && metadata != null
                && !metadata.isNull("provider_name")
                && !metadata.optString("provider_name", "").trim().isEmpty()) {
            reason = Reason.ROUTE;
        }
        return new RequestFailure(status, reason, parseRetryAfter(retryAfter, now));
    }

    RequestFailure dailyQuota(long now) {
        long reset = java.time.Instant.ofEpochMilli(now).atZone(ZoneOffset.UTC).toLocalDate()
                .plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
        return new RequestFailure(status, Reason.DAILY_QUOTA, Math.max(retryAt, reset));
    }

    RequestFailure unavailable() {
        return new RequestFailure(status, Reason.MODEL_UNAVAILABLE, retryAt);
    }

    static long parseRetryAfter(String value, long now) {
        if (value == null) return 0;
        String header = value.trim();
        try {
            long time = header.matches("[0-9]+")
                    ? Math.addExact(now, Math.multiplyExact(Long.parseLong(header), 1000))
                    : ZonedDateTime.parse(header, DateTimeFormatter.RFC_1123_DATE_TIME)
                            .toInstant().toEpochMilli();
            return time > now ? time : 0;
        } catch (java.time.DateTimeException | ArithmeticException | NumberFormatException e) {
            return 0;
        }
    }
}
