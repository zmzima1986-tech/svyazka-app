package app.svyazka.mobile.ui

import app.svyazka.mobile.ResultSeverity

import android.content.res.Configuration
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.Path
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.semantics.Role
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.annotation.DrawableRes
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import app.svyazka.mobile.R

@Composable
private fun ModeSelector(ui: NexusComposeUi, modifier: Modifier) {
    val quick = ui.snapshot.quick
    val enabled = !ui.snapshot.active && !ui.snapshot.clearing
    val single = stringResource(R.string.ui_quick)
    val team = stringResource(R.string.ui_team)
    var expanded by remember { mutableStateOf(false) }

    Box(modifier, contentAlignment = Alignment.Center) {
        TextButton(
            onClick = { expanded = true },
            enabled = enabled,
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) {
            Text(if (quick) single else team,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Outlined.ArrowDropDown, null, Modifier.size(18.dp))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false },
            containerColor = nexusFrostedColor()) {
            for ((label, mode) in listOf(single to true, team to false)) {
                DropdownMenuItem(
                    text = { Text(label) },
                    enabled = enabled,
                    onClick = {
                        expanded = false
                        if (quick != mode) ui.activity.nexusModeChanged(mode)
                    }
                )
            }
        }
    }
}
@Composable
fun NexusTopBar(ui: NexusComposeUi) {
    val chat = ui.page == NexusComposeUi.Page.TASK || ui.page == NexusComposeUi.Page.RESULT
    val title = when (ui.page) {
        NexusComposeUi.Page.TASK, NexusComposeUi.Page.RESULT -> stringResource(R.string.ui_chat)
        NexusComposeUi.Page.MODELS -> stringResource(R.string.models_title)
        NexusComposeUi.Page.HISTORY -> stringResource(R.string.history_title)
        NexusComposeUi.Page.ARTIFACTS -> stringResource(R.string.artifacts_title)
        NexusComposeUi.Page.PROJECT -> ui.artifacts.firstOrNull { it.id == ui.projectId }?.title
            ?: stringResource(R.string.artifacts_title)
        NexusComposeUi.Page.SETTINGS -> stringResource(R.string.settings_title)
    }
    val light = nexusLightMode()
    Surface(modifier = Modifier.statusBarsPadding(), color = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (chat) ui.openLeft() else ui.navigateBack() },
                modifier = Modifier.size(40.dp)) {
                Icon(if (chat) Icons.Outlined.Menu else Icons.Outlined.ArrowBack,
                    contentDescription = stringResource(if (chat) R.string.ui_open_menu else R.string.action_back),
                    tint = MaterialTheme.colorScheme.onBackground)
            }
            if (chat) {
                Surface(shape = RoundedCornerShape(26.dp),
                    color = if (light) NexusLightDesign.glass else NexusDarkDesign.chatGlass,
                    border = BorderStroke(1.dp, if (light) NexusLightDesign.border
                        else NexusDarkDesign.chatBorder),
                    modifier = Modifier.weight(1f).height(44.dp)) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        ModeSelector(ui, Modifier.fillMaxWidth().padding(horizontal = 4.dp))
                    }
                }
                Spacer(Modifier.width(5.dp))
                IconButton(onClick = { ui.searching = !ui.searching }, modifier = Modifier.size(38.dp)) {
                    Icon(Icons.Outlined.Search, stringResource(R.string.search_current))
                }
            } else {
                Text(title, modifier = Modifier.weight(1f),
                    style = if (light) MaterialTheme.typography.titleLarge.copy(
                        fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        else MaterialTheme.typography.headlineMedium.copy(fontSize = 24.sp, lineHeight = 30.sp),
                    maxLines = if (light) 1 else Int.MAX_VALUE, softWrap = !light,
                    overflow = if (light) TextOverflow.Ellipsis else TextOverflow.Clip,
                    color = MaterialTheme.colorScheme.onBackground)
            }
            if (chat) {
                if (ui.pythonBusy) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                IconButton(onClick = { ui.openRight() }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Outlined.Terminal,
                        contentDescription = stringResource(R.string.ui_open_workspace),
                        tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

/** Compact single-line actions; reduces text size before allowing a clipped label. */
@Composable
fun NexusOutlineActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: (@Composable () -> Unit)? = null
) {
    val light = nexusLightMode()
    val actionShape = if (light) RoundedCornerShape(19.dp) else RoundedCornerShape(20.dp)
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 44.dp)
            .then(if (light) Modifier.shadow(2.dp, actionShape,
                spotColor = Color(0x298291B4)) else Modifier),
        shape = actionShape,
        border = if (light) BorderStroke(1.dp, NexusLightDesign.border)
            else BorderStroke(1.dp, NexusDarkDesign.chatBorder),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = if (light) NexusLightDesign.glass else NexusDarkDesign.chatGlass,
            contentColor = if (light) NexusLightDesign.blue else Color.White,
            disabledContentColor = if (light) NexusLightDesign.disabledText
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .55f)
        ),
        contentPadding = PaddingValues(horizontal = 7.dp, vertical = 7.dp)
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val available = maxWidth - (if (icon != null) 27.dp else 0.dp)
            val measurer = rememberTextMeasurer()
            val density = LocalDensity.current
            val textStyle = MaterialTheme.typography.labelMedium
            val fontSize = (13 downTo 9).firstOrNull { size ->
                measurer.measure(AnnotatedString(text),
                    style = textStyle.copy(fontSize = size.sp),
                    softWrap = false).size.width <= with(density) { available.toPx() }
            } ?: 9
            val darkFontSize = (15 downTo 11).firstOrNull { size ->
                measurer.measure(AnnotatedString(text),
                    style = textStyle.copy(fontSize = size.sp),
                    softWrap = false).size.width <= with(density) { available.toPx() }
            } ?: 11
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    if (light) CompositionLocalProvider(LocalContentColor provides
                        (if (enabled) NexusLightDesign.ink else NexusLightDesign.disabledText)) { icon() }
                    else CompositionLocalProvider(LocalContentColor provides NexusDarkDesign.cyan) { icon() }
                    Spacer(Modifier.width(5.dp))
                }
                Text(text, fontSize = if (light) fontSize.sp else darkFontSize.sp,
                    color = if (light) (if (enabled) NexusLightDesign.blue
                        else NexusLightDesign.disabledText) else Color.White,
                    maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
                    fontWeight = if (light) FontWeight.Bold else FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun NexusSectionTitle(
    text: String,
    modifier: Modifier = Modifier,
    icon: (@Composable () -> Unit)? = null
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
            icon()
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary)
    }
}

/** Shared flat vectors follow Compose theme colors; branded images stay in their original colors. */
private val FlatNexusIcons = setOf(
    R.drawable.ic_nia_attach,
    R.drawable.ic_nia_back,
    R.drawable.ic_nia_chevron_down,
    R.drawable.ic_nia_chevron_up,
    R.drawable.ic_nia_code,
    R.drawable.ic_nia_copy,
    R.drawable.ic_nia_delete,
    R.drawable.ic_nia_document,
    R.drawable.ic_nia_download,
    R.drawable.ic_nia_folder,
    R.drawable.ic_nia_image,
    R.drawable.ic_nia_info,
    R.drawable.ic_nia_key,
    R.drawable.ic_nia_language,
    R.drawable.ic_nia_play,
    R.drawable.ic_nia_refresh,
    R.drawable.ic_nia_search,
    R.drawable.ic_nia_stop,
    R.drawable.ic_nia_success,
    R.drawable.ic_nia_task,
    R.drawable.ic_nia_theme,
    R.drawable.ic_nia_work
)

@Composable
fun NexusGlyph(@DrawableRes id: Int, description: String?, modifier: Modifier = Modifier.size(32.dp)) {
    val mirror = id == R.drawable.ic_nia_back && LocalLayoutDirection.current == LayoutDirection.Rtl
    // A manual theme switch must reload bitmaps even if the system theme did not change.
    key(LocalConfiguration.current.uiMode and Configuration.UI_MODE_NIGHT_MASK) {
        val iconModifier = modifier.graphicsLayer { scaleX = if (mirror) -1f else 1f }
        if (id in FlatNexusIcons) {
            Icon(painter = painterResource(id), contentDescription = description,
                modifier = iconModifier, tint = if (id == R.drawable.ic_nia_success)
                    Color(0xFF20B35B) else LocalContentColor.current)
        } else {
            // Keep provider logos and the three-color Nexus brand untinted.
            Image(painter = painterResource(id), contentDescription = description,
                modifier = iconModifier)
        }
    }
}

@Composable
fun NexusCard(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val isDark = !nexusLightMode()
    val shape = if (isDark) RoundedCornerShape(22.dp) else NexusLightDesign.cardShape
    val cardColor = if (isDark) NexusDarkDesign.workspaceGlass else NexusLightDesign.glass
    val stroke = BorderStroke(1.dp,
        if (isDark) NexusDarkDesign.chatBorder else NexusLightDesign.glassHighlight)
    val decorated = modifier.shadow(
        elevation = if (isDark) 0.dp else 3.dp,
        shape = shape,
        clip = false,
        ambientColor = if (isDark) Color.Black.copy(alpha = .3f) else Color(0xFF8D96A3).copy(alpha = .2f),
        spotColor = if (isDark) Color.Black.copy(alpha = .35f) else Color(0xFF8D96A3).copy(alpha = .24f)
    )
    if (onClick == null) {
        Surface(modifier = decorated, shape = shape, color = cardColor,
            contentColor = MaterialTheme.colorScheme.onSurface,
            tonalElevation = 0.dp, border = stroke) { Column(Modifier.padding(16.dp), content = content) }
    } else {
        Surface(onClick = onClick, modifier = decorated, shape = shape,
            color = cardColor, contentColor = MaterialTheme.colorScheme.onSurface,
            tonalElevation = 0.dp, border = stroke) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
fun NexusLabel(text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Text(text, color = color, style = MaterialTheme.typography.bodyMedium)
}

@Composable
fun StatusPill(label: String, success: Boolean = false) {
    val foreground = if (success) {
        if (nexusLightMode()) Color(0xFF087D3B) else Color(0xFF27D6A6)
    } else MaterialTheme.colorScheme.primary
    Surface(shape = RoundedCornerShape(50), color = foreground.copy(alpha = .15f), contentColor = foreground,
        border = BorderStroke(1.dp, foreground.copy(alpha = .38f))) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            if (success) ResultStatusIcon(ResultSeverity.SUCCESS, Modifier.size(17.dp))
            Text(label, color = foreground, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun KeyStatusPill(label: String, configured: Boolean) {
    val isDark = !nexusLightMode()
    val accent = if (configured) {
        if (isDark) Color(0xFF38E2AD) else Color(0xFF086E48)
    } else {
        if (isDark) Color(0xFFFF8B93) else Color(0xFFAC2634)
    }
    Surface(shape = RoundedCornerShape(50), color = accent.copy(alpha = .2f), contentColor = accent,
        border = BorderStroke(.8.dp, accent.copy(alpha = .35f))) {
        Text(label, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
            color = accent, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun NexusPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable () -> Unit)? = null,
    glow: Boolean = true,
    runStyling: Boolean = false
) {
    val light = nexusLightMode()
    val shape = if (light) NexusLightDesign.buttonShape else RoundedCornerShape(20.dp)
    val actionModifier = if (light) modifier.shadow(5.dp, shape, spotColor = Color(0xFF6F5DDF))
        else modifier
    BoxWithConstraints(actionModifier.clip(shape).background(
            if (light && !enabled) Brush.horizontalGradient(listOf(NexusLightDesign.disabled, NexusLightDesign.disabled))
            else if (light) NexusLightDesign.actionGradient
            else if (!enabled) Brush.horizontalGradient(listOf(NexusDarkDesign.disabled, NexusDarkDesign.disabled))
            else if (runStyling) NexusDarkDesign.runGradient
            else NexusDarkDesign.primaryGradient, shape)
        .then(if (light) Modifier.border(1.dp,
            if (enabled) NexusLightDesign.blue.copy(alpha = .65f) else NexusLightDesign.border,
            shape) else Modifier)
        .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
        .heightIn(min = if (light) 49.dp else 44.dp).padding(horizontal = 12.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center) {
        if (light && enabled) Canvas(Modifier.matchParentSize()) {
            val wave = Path().apply {
                moveTo(0f, size.height * .9f)
                quadraticBezierTo(size.width * .28f, size.height * .38f,
                    size.width * .65f, size.height * .69f)
                quadraticBezierTo(size.width * .85f, size.height * .88f,
                    size.width, size.height * .36f)
                lineTo(size.width, 0f)
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(wave, Color.White.copy(alpha = .09f))
        }
        val textRoom = maxWidth - (if (leadingIcon != null) (if (light) 35.dp else 29.dp) else 0.dp)
        val measurer = rememberTextMeasurer()
        val density = LocalDensity.current
        val textStyle = MaterialTheme.typography.labelLarge
        val size = ((if (light) 14 else 16) downTo 10).firstOrNull { candidate ->
            measurer.measure(AnnotatedString(text),
                style = textStyle.copy(fontSize = candidate.sp),
                softWrap = false).size.width <= with(density) { textRoom.toPx() }
        } ?: 10
        Row(verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center) {
            if (leadingIcon != null) {
                CompositionLocalProvider(LocalContentColor provides
                    (if (light && !enabled) NexusLightDesign.disabledText else Color.White)) { leadingIcon() }
                Spacer(Modifier.width(7.dp))
                if (light) {
                    Box(Modifier.width(1.dp).height(21.dp)
                        .background(Color.White.copy(alpha = .72f)))
                    Spacer(Modifier.width(7.dp))
                }
            }
            Text(text, color = if (!enabled) {
                if (light) NexusLightDesign.disabledText else NexusDarkDesign.disabledText
            } else Color.White,
                fontSize = size.sp, maxLines = 1, softWrap = false,
                fontWeight = FontWeight.Bold)
        }
    }
}

/** The same raster model artwork is used in the hero and model navigation. */
@Composable
fun NexusAiStack(modifier: Modifier = Modifier) {
    NexusGlyph(R.drawable.ic_nia_models, null, modifier)
}

/** No HTML rendering and no network. Plain text, headings, fences and common Markdown spans. */
internal data class MarkdownBlock(val kind: String, val value: String)

internal fun parseMarkdown(source: String): List<MarkdownBlock> {
    val out = ArrayList<MarkdownBlock>()
    val lines = source.replace("\r\n", "\n").split('\n')
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trimStart()
        if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
            val marker = trimmed.takeWhile { it == trimmed[0] }
            val code = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trimStart().startsWith(marker)) {
                if (code.isNotEmpty()) code.append('\n')
                code.append(lines[i]); i++
            }
            out.add(MarkdownBlock("code", code.toString()))
        } else if (trimmed.startsWith("#") && trimmed.takeWhile { it == '#' }.length in 1..6 &&
            trimmed.dropWhile { it == '#' }.startsWith(' ')) {
            out.add(MarkdownBlock("heading", trimmed.dropWhile { it == '#' }.trim()))
        } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ") ||
            Regex("^\\d+[.)] ").containsMatchIn(trimmed)) {
            out.add(MarkdownBlock("bullet", trimmed))
        } else if (line.isNotBlank()) {
            out.add(MarkdownBlock("body", line))
        } else if (out.isNotEmpty() && out.last().kind != "space") {
            out.add(MarkdownBlock("space", ""))
        }
        i++
    }
    return out
}

internal fun inlineMarkup(source: String) = buildAnnotatedString {
    val pattern = Regex("(`[^`\\n]+`|\\*\\*[^*\\n]+\\*\\*|\\*[^*\\n]+\\*)")
    var previous = 0
    pattern.findAll(source).forEach { match ->
        append(source.substring(previous, match.range.first))
        val word = match.value
        when {
            word.startsWith("**") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                append(word.drop(2).dropLast(2))
            }
            word.startsWith('`') -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace)) {
                append(word.drop(1).dropLast(1))
            }
            else -> withStyle(SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)) {
                append(word.drop(1).dropLast(1))
            }
        }
        previous = match.range.last + 1
    }
    append(source.substring(previous))
}

@Composable
fun NexusMarkdown(markdown: String) {
    val blocks = remember(markdown) { parseMarkdown(markdown) }
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            blocks.forEach { block ->
                when (block.kind) {
                    "code" -> Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.background,
                        contentColor = MaterialTheme.colorScheme.onBackground,
                        border = BorderStroke(.7.dp, MaterialTheme.colorScheme.outline.copy(alpha = .5f))
                    ) {
                        Text(block.value, Modifier.fillMaxWidth().padding(12.dp),
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    "heading" -> Text(inlineMarkup(block.value),
                        style = MaterialTheme.typography.titleLarge)
                    "bullet" -> Text(inlineMarkup(block.value),
                        style = MaterialTheme.typography.bodyMedium)
                    "space" -> Spacer(Modifier.height(4.dp))
                    else -> Text(inlineMarkup(block.value), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
