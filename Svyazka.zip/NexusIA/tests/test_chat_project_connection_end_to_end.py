"""Source-level regression contracts for actual project content in AI requests.

These contracts do not replace an Android emulator round-trip test.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'app/src/main/java/app/svyazka/mobile'


class ProjectChatConnectionTests(unittest.TestCase):
    def test_link_is_read_back_before_success(self):
        source = (BASE / 'MainActivity.java').read_text()
        action = source.split('public void nexusAttachArtifactToChat() {', 1)[1].split(
            '/** Start a separate chat for this project', 1)[0]
        self.assertIn('artifactRepository.attachIsolatedCopy(', action)
        self.assertIn('artifactRepository.forChat(activeTaskId) != separate', action)
        self.assertIn('pythonProjects().snapshotForChat(activeArtifactId)', action)
        self.assertIn('nexusUi.refreshChatProjectLink()', action)
        self.assertNotIn('nexusRender(', action)
        self.assertNotIn('nexusRender(NexusComposeUi.Page.TASK)', action)

    def test_linked_files_enter_ai_request_only_after_attach(self):
        source = (BASE / 'MainActivity.java').read_text()
        prepare = source.split('private AttachmentStore.Prepared prepareMessage(', 1)[1].split(
            'private void startRun()', 1)[0]
        self.assertIn('artifactRepository.forChat(activeTaskId)', prepare)
        self.assertIn('if (linked > 0)', prepare)
        self.assertIn('ChatProjectContext.append(materials.getTask()', prepare)
        self.assertIn('pythonProjects().snapshotForChat(linked)', prepare)
        self.assertIn('new AttachmentStore.Prepared(prepared, materials.getRefs())', prepare)
        self.assertIn('InputMaterial.MAX_REQUEST_TEXT_BYTES', prepare)

    def test_followups_replace_old_snapshot_and_detach_prevents_new_snapshot(self):
        activity = (BASE / 'MainActivity.java').read_text()
        self.assertIn('ChatProjectContext.withoutInlineProject(TaskHistory.forRepair(previous.task))', activity)
        self.assertIn('ChatProjectContext.withoutInlineProject(previous.userTestTask())', activity)
        self.assertIn('artifactRepository.setConnected(activeTaskId, false)', activity)
        context = (BASE / 'ChatProjectContext.java').read_text()
        self.assertIn('static String withoutInlineProject(String task)', context)

    def test_readonly_followup_never_runs_or_replaces_project(self):
        activity = (BASE / 'MainActivity.java').read_text()
        follow = activity.split('private void submitFollowUp(', 1)[1].split('private static boolean isUserDarkTheme', 1)[0]
        self.assertIn('question ? TaskHistory.questionPrompt(materials.getTask(), source,', follow)
        self.assertIn('questionHistory(owner, versionToSave)', follow)
        self.assertIn('independent || question ? materials.getTask()', follow)
        self.assertIn('!scoped && !question && TaskHistory.startsIndependentTask', follow)
        self.assertIn('if (independent && !switchIndependentProject(clarification))', follow)
        for method in ('startPythonPreReview', 'startWebCheck', 'startVerification', 'autoStageChatPython'):
            with self.subTest(method=method):
                body = activity.split('private '+ ('AutoPythonLaunch' if method == 'autoStageChatPython' else 'boolean')+' '+method+'(',1)[1][:500]
                self.assertIn('TaskHistory.readOnlyTurn(', body)
        self.assertIn('if (!TaskHistory.readOnlyTurn(input.task)) invalidatePythonReport', activity)
        self.assertIn('Workflow.Run previous = developmentBase(run, clarification)', activity)
        base = activity.split('private Workflow.Run developmentBase(',1)[1].split('public boolean nexusHasSourcePlan()',1)[0]
        self.assertIn('repository.versions(activeTaskId)', base)
        self.assertIn('if (TaskHistory.readOnlyTurn(prior.task)) continue;', base)
        self.assertIn('return prior.complete() ? prior : current;', base)
        self.assertIn('TaskHistory.readOnlyTurn(run.task)', (BASE / 'PythonInputs.java').read_text())
        self.assertIn('!TaskHistory.readOnlyTurn(run.task)', (BASE / 'ModelClient.java').read_text())

    def test_web_result_switches_workspace_without_overwriting_manual_edits(self):
        activity = (BASE / 'MainActivity.java').read_text()
        follow = activity.split('private void submitFollowUp(', 1)[1].split('private static boolean isUserDarkTheme', 1)[0]
        self.assertIn('prepareMessage(clarification, !independent', follow)
        self.assertIn('TaskHistory.includeLinkedPythonForTurn(baseAnswer, clarification)', follow)
        self.assertIn('independent ? materials.getTask()', follow)
        detach = activity.split('private boolean disconnectPreviousProject()', 1)[1].split('private boolean switchIndependentProject', 1)[0]
        self.assertLess(detach.index('nexusPythonFlushPending()'), detach.index('artifactRepository.setConnected(activeTaskId, false)'))
        finish = activity.split('private void finishRunUi()', 1)[1].split('private boolean startVerification', 1)[0]
        self.assertIn('!TaskHistory.readOnlyTurn(run.task)', finish)
        self.assertIn('"SYNTAX_CHECKED".equals(check.optString("status"))', finish)
        self.assertIn('!Workflow.Run.failedWeb(check)', finish)
        self.assertIn('nexusUi.webAppliedFromChat(html)', finish)
        ui = (BASE / 'ui/NexusComposeUi.kt').read_text()
        web = ui.split('fun webAppliedFromChat(', 1)[1].split('var pendingGeneratedHtml', 1)[0]
        self.assertIn('if (webCanImportGenerated()) importGeneratedWeb("html", source)', web)
        self.assertIn('switchWorkspaceTab(WorkspaceTab.CODE)', web)
        python = ui.split('fun pythonAppliedFromChat(', 1)[1].split('fun dismissPythonInput', 1)[0]
        self.assertIn('switchWorkspaceTab(WorkspaceTab.PYTHON)', python)

    def test_question_history_is_bound_to_active_chat(self):
        activity = (BASE / 'MainActivity.java').read_text()
        history = activity.split('private List<String> questionHistory(', 1)[1].split('private void submitFollowUp(', 1)[0]
        self.assertIn('owner != activeTaskId || current != run', history)
        self.assertIn('repository.versions(owner)', history)
        self.assertIn('tasks.add(current.task)', history)
        self.assertNotIn('repository.list(', history)
        self.assertNotIn('artifactRepository', history)
        repo = (BASE / 'TaskRepository.java').read_text()
        versions = repo.split('synchronized List<Version> versions(long taskId)', 1)[1].split('synchronized boolean rename', 1)[0]
        self.assertIn('WHERE task_id=? ORDER BY version_no DESC', versions)
        self.assertIn('String.valueOf(taskId)', versions)
        follow = activity.split('private void submitFollowUp(', 1)[1].split('private static boolean isUserDarkTheme', 1)[0]
        self.assertIn('if (activeTaskId != owner || run != versionToSave) return;', follow)
        start = activity.split('private void startRun(String task, boolean includeLinkedProject, boolean question)', 1)[1].split('private void resumeRun', 1)[0]
        self.assertIn('questionHistory(owner, previous)', start)
        self.assertIn('if (activeTaskId != owner || run != previous) return;', start)
        self.assertIn('independent ? materials.getTask()', follow)

    def test_web_evidence_notice_does_not_change_raw_source(self):
        activity = (BASE / 'MainActivity.java').read_text()
        self.assertIn('webEvidenceNotice(archived, archived.finalIndex())', activity)
        self.assertIn('webEvidenceNotice(run, i)', activity)
        ui = (BASE / 'ui/NexusChat.kt').read_text()
        answer = ui.split('private fun ChatAnswer(', 1)[1].split('if (!expanded', 1)[0]
        self.assertLess(answer.index('ResultStatusLine(evidenceNotice, ResultSeverity.WARNING)'), answer.index('NexusMarkdown('))
        self.assertIn('evidenceNotice = message.evidenceNotice', ui)
        self.assertIn('PythonInputs.copySource(message.answer)', ui)
        workflow = (BASE / 'Workflow.java').read_text()
        self.assertIn('Never state that you opened Chrome, Firefox', workflow)
        self.assertIn('Explicitly correct unsupported claims of Chrome, Firefox', workflow)
        self.assertIn('functional_tests=false means button behavior was not tested', workflow)

    def test_text_only_secret_exclusions_and_bounded_context(self):
        context = (BASE / 'ChatProjectContext.java').read_text()
        self.assertIn('MAX_CONTEXT_BYTES = 40_000', context)
        self.assertIn('MAX_SINGLE_FILE_BYTES = 12_000', context)
        self.assertIn('sensitive filename', context)
        self.assertIn('non-text or unsupported extension', context)
        self.assertIn('invalid UTF-8', context)
        self.assertIn('if (utf8(combined) > requestByteLimit)', context)


if __name__ == '__main__':
    unittest.main()
