package app.svyazka.mobile.attachments

import android.content.Context
import app.svyazka.mobile.AttachmentParser
import app.svyazka.mobile.AttachmentProblem
import app.svyazka.mobile.AttachmentProblem.Code
import app.svyazka.mobile.InputMaterial
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.io.Writer
import java.util.UUID

/** Text-layer extraction only. No rendering, network, OCR or PDF JavaScript execution. */
internal object PdfTextExtractor {
    @Synchronized fun read(context: Context, file: File, name: String): AttachmentParser.Result {
        PDFBoxResourceLoader.init(context.applicationContext)
        val scratch = File(context.cacheDir, "pdf-text/${UUID.randomUUID()}").apply { mkdirs() }
        try {
            val memory = MemoryUsageSetting.setupTempFileOnly(AttachmentParser.MAX_EXPANDED).setTempDir(scratch)
            PDDocument.load(file, memory).use { document ->
                if (document.isEncrypted || !document.currentAccessPermission.canExtractContent()) throw AttachmentProblem(Code.PDF_LOCKED, name)
                if (document.numberOfPages > 200) throw AttachmentProblem(Code.PDF_PAGES, name)
                val text = StringBuilder()
                val notes = ArrayList<AttachmentParser.Note>()
                var processed = 0
                val stripper = PDFTextStripper().apply { sortByPosition = true }
                for (page in 1..document.numberOfPages) {
                    val content = StringBuilder()
                    val writer = object : Writer() {
                        override fun write(chars: CharArray, offset: Int, length: Int) {
                            if (Thread.currentThread().isInterrupted) throw AttachmentProblem(Code.INTERRUPTED)
                            if (content.length + text.length + length > InputMaterial.MAX_TEXT_CHARS) throw AttachmentProblem(Code.TEXT_SIZE, name)
                            content.append(chars, offset, length)
                        }
                        override fun flush() = Unit
                        override fun close() = Unit
                    }
                    stripper.startPage = page; stripper.endPage = page
                    stripper.writeText(document, writer)
                    if (content.contains('\uFFFD')) throw AttachmentProblem(Code.ENCODING, name)
                    val label = "$name · $page"
                    if (content.isBlank()) notes.add(AttachmentParser.Note(label, Code.PDF_PAGE_EMPTY))
                    else {
                        if (text.length + content.length + 30 > InputMaterial.MAX_TEXT_CHARS) throw AttachmentProblem(Code.TEXT_SIZE, name)
                        text.append("\n[Page ").append(page).append("]\n").append(content)
                        notes.add(AttachmentParser.Note(label, null)); processed++
                    }
                }
                notes.add(AttachmentParser.Note(name, Code.PDF_SCOPE))
                return AttachmentParser.Result(text.toString(), notes, processed != document.numberOfPages,
                    processed, document.numberOfPages)
            }
        } catch (e: InvalidPasswordException) { throw AttachmentProblem(Code.PDF_LOCKED, name) }
        finally { scratch.deleteRecursively() }
    }
}
