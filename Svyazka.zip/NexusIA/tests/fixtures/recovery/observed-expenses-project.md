**Solution Overview**  
The project consists of three modules:

| File | Purpose |
|------|---------|
| `expenses.py` | Core library – `ExpenseTracker` class with methods `add_expense`, `total`, `group_by_category`. |
| `main.py` | Simple console UI that uses `ExpenseTracker`. All input operations are protected against `EOFError`. |
| `test_expenses.py` | 10 unit‑tests (using `unittest`) that verify correct behaviour of the tracker. |

The implementation makes the following **assumptions**:

* Amounts are stored as `float`. Negative amounts are **not allowed** – they raise `ValueError`.  
* Category is a non‑empty string; an empty category raises `ValueError`.  
* The tracker holds expenses only in memory (no persistence).  
* The console UI is intentionally minimal – it demonstrates usage but is not required for the tests.

Below are the complete source files.

---

```file=expenses.py
"""expenses.py – core expense‑tracking library."""

from collections import defaultdict
from dataclasses import dataclass
from typing import List, Dict


@dataclass(frozen=True)
class Expense:
    """Immutable representation of a single expense."""
    amount: float
    category: str
    description: str = ""


class ExpenseTracker:
    """Tracks a list of expenses and provides aggregation utilities."""

    def __init__(self) -> None:
        self._expenses: List[Expense] = []

    def add_expense(self, amount: float, category: str, description: str = "") -> None:
        """
        Add a new expense.

        Args:
            amount: Positive monetary amount.
            category: Non‑empty category name.
            description: Optional free‑form text.

        Raises:
            ValueError: If ``amount`` is not positive or ``category`` is empty.
        """
        if amount <= 0:
            raise ValueError("Amount must be a positive number")
        if not isinstance(category, str) or not category.strip():
            raise ValueError("Category must be a non‑empty string")
        expense = Expense(amount=float(amount), category=category.strip(), description=description)
        self._expenses.append(expense)

    def total(self) -> float:
        """Return the sum of all recorded expenses."""
        return sum(exp.amount for exp in self._expenses)

    def group_by_category(self) -> Dict[str, float]:
        """
        Return a dictionary mapping each category to the total amount spent
        in that category.
        """
        totals = defaultdict(float)
        for exp in self._expenses:
            totals[exp.category] += exp.amount
        return dict(totals)

    # Helper for tests – not part of public API but useful
    def _list_expenses(self) -> List[Expense]:
        """Return a shallow copy of the internal expenses list."""
        return list(self._expenses)
```

---

```file=main.py
"""main.py – simple console interface for the expense tracker."""

import sys
from expenses import ExpenseTracker


def _read_input(prompt: str) -> str:
    """Read a line from stdin, handling EOF gracefully."""
    try:
        return input(prompt)
    except EOFError:
        print("\nEOF received – exiting.")
        sys.exit(0)


def _add_expense_ui(tracker: ExpenseTracker) -> None:
    """Interactively ask the user for expense data and add it to the tracker."""
    while True:
        try:
            amount_str = _read_input("Enter amount (positive number): ").strip()
            amount = float(amount_str)
            if amount <= 0:
                raise ValueError
            break
        except ValueError:
            print("Invalid amount. Please try again.")

    while True:
        category = _read_input("Enter category (non‑empty): ").strip()
        if category:
            break
        print("Category cannot be empty.")

    description = _read_input("Enter description (optional): ").strip()
    try:
        tracker.add_expense(amount, category, description)
        print("Expense added.")
    except ValueError as e:
        print(f"Error adding expense: {e}")


def _show_total(tracker: ExpenseTracker) -> None:
    total = tracker.total()
    print(f"Total expenses: {total:.2f}")


def _show_grouped(tracker: ExpenseTracker) -> None:
    groups = tracker.group_by_category()
    if not groups:
        print("No expenses recorded yet.")
        return
    print("Expenses by category:")
    for cat, amt in sorted(groups.items()):
        print(f"  {cat}: {amt:.2f}")


def main() -> None:
    tracker = ExpenseTracker()
    menu = """\nExpense Tracker
1) Add expense
2) Show total
3) Show expenses grouped by category
4) Quit
Choose an option: """

    while True:
        choice = _read_input(menu).strip()
        if choice == "1":
            _add_expense_ui(tracker)
        elif choice == "2":
            _show_total(tracker)
        elif choice == "3":
            _show_grouped(tracker)
        elif choice == "4":
            print("Good bye!")
            break
        else:
            print("Invalid choice – please select 1‑4.")


if __name__ == "__main__":
    main()
```

---

```file=test_expenses.py
"""test_expenses.py – unit tests for the ExpenseTracker."""

import unittest
from expenses import ExpenseTracker, Expense


class TestExpenseTracker(unittest.TestCase):
    def setUp(self):
        self.tracker = ExpenseTracker()

    # 1. Adding a single valid expense
    def test_add_one_expense(self):
        self.tracker.add_expense(10.5, "Food")
        self.assertEqual(len(self.tracker._list_expenses()), 1)

    # 2. Total after multiple additions
    def test_total_multiple(self):
        self.tracker.add_expense(5, "Transport")
        self.tracker.add_expense(15.75, "Food")
        self.tracker.add_expense(9.25, "Entertainment")
        self.assertAlmostEqual(self.tracker.total(), 30.0)

    # 3. Grouping by category
    def test_group_by_category(self):
        self.tracker.add_expense(20, "Food")
        self.tracker.add_expense(7, "Food")
        self.tracker.add_expense(12, "Books")
        groups = self.tracker.group_by_category()
        self.assertDictEqual(groups, {"Food": 27.0, "Books": 12.0})

    # 4. Adding expense with description
    def test_add_with_description(self):
        self.tracker.add_expense(3, "Coffee", "Latte")
        exp = self.tracker._list_expenses()[0]
        self.assertEqual(exp.description, "Latte")

    # 5. Reject zero amount
    def test_zero_amount_raises(self):
        with self.assertRaises(ValueError):
            self.tracker.add_expense(0, "Misc")

    # 6. Reject negative amount
    def test_negative_amount_raises(self):
        with self.assertRaises(ValueError):
            self.tracker.add_expense(-5, "Misc")

    # 7. Reject empty category
    def test_empty_category_raises(self):
        with self.assertRaises(ValueError):
            self.tracker.add_expense(10, "")

    # 8. Whitespace in category is trimmed
    def test_category_trimming(self):
        self.tracker.add_expense(8, "  Travel  ")
        exp = self.tracker._list_expenses()[0]
        self.assertEqual(exp.category, "Travel")

    # 9. Grouping returns empty dict when no expenses
    def test_group_empty(self):
        self.assertEqual(self.tracker.group_by_category(), {})

    # 10. Total is zero when no expenses
    def test_total_empty(self):
        self.assertEqual(self.tracker.total(), 0.0)


if __name__ == "__main__":
    unittest.main()
```

---

### How to run the project (console)

```bash
# 1. Run the interactive program
python main.py

# 2. Execute the test suite
python -m unittest test_expenses.py
```

All tests should pass (`10 passed`). The console UI gracefully handles `EOFError`, making it safe for automated execution environments.**Original project snapshot (as received)**  

---  
```file=main.py
```
*(the file was empty – 0 bytes)*  
---  

---

**Completed source files**

```file=expenses.py
"""expenses.py – core expense‑tracking library."""

from collections import defaultdict
from dataclasses import dataclass
from typing import List, Dict


@dataclass(frozen=True)
class Expense:
    """Immutable representation of a single expense."""
    amount: float
    category: str
    description: str = ""


class ExpenseTracker:
    """Tracks a list of expenses and provides aggregation utilities."""

    def __init__(self) -> None:
        self._expenses: List[Expense] = []

    def add_expense(self, amount: float, category: str, description: str = "") -> None:
        """
        Add a new expense.

        Args:
            amount: Positive monetary amount.
            category: Non‑empty category name.
            description: Optional free‑form text.

        Raises:
            ValueError: If ``amount`` is not positive or ``category`` is empty.
        """
        if amount <= 0:
            raise ValueError("Amount must be a positive number")
        if not isinstance(category, str) or not category.strip():
            raise ValueError("Category must be a non‑empty string")
        expense = Expense(amount=float(amount), category=category.strip(), description=description)
        self._expenses.append(expense)

    def total(self) -> float:
        """Return the sum of all recorded expenses."""
        return sum(exp.amount for exp in self._expenses)

    def group_by_category(self) -> Dict[str, float]:
        """
        Return a dictionary mapping each category to the total amount spent
        in that category.
        """
        totals = defaultdict(float)
        for exp in self._expenses:
            totals[exp.category] += exp.amount
        return dict(totals)

    # Helper for tests – not part of public API but useful
    def _list_expenses(self) -> List[Expense]:
        """Return a shallow copy of the internal expenses list."""
        return list(self._expenses)
```

```file=main.py
"""main.py – simple console interface for the expense tracker."""

import sys
from expenses import ExpenseTracker


def _read_input(prompt: str) -> str:
    """Read a line from stdin, handling EOF gracefully."""
    try:
        return input(prompt)
    except EOFError:
        print("\nEOF received – exiting.")
        sys.exit(0)


def _add_expense_ui(tracker: ExpenseTracker) -> None:
    """Interactively ask the user for expense data and add it to the tracker."""
    while True:
        try:
            amount_str = _read_input("Enter amount (positive number): ").strip()
            amount = float(amount_str)
            if amount <= 0:
                raise ValueError
            break
        except ValueError:
            print("Invalid amount. Please try again.")

    while True:
        category = _read_input("Enter category (non‑empty): ").strip()
        if category:
            break
        print("Category cannot be empty.")

    description = _read_input("Enter description (optional): ").strip()
    try:
        tracker.add_expense(amount, category, description)
        print("Expense added.")
    except ValueError as e:
        print(f"Error adding expense: {e}")


def _show_total(tracker: ExpenseTracker) -> None:
    total = tracker.total()
    print(f"Total expenses: {total:.2f}")


def _show_grouped(tracker: ExpenseTracker) -> None:
    groups = tracker.group_by_category()
    if not groups:
        print("No expenses recorded yet.")
        return
    print("Expenses by category:")
    for cat, amt in sorted(groups.items()):
        print(f"  {cat}: {amt:.2f}")


def main() -> None:
    tracker = ExpenseTracker()
    menu = """\nExpense Tracker
1) Add expense
2) Show total
3) Show expenses grouped by category
4) Quit
Choose an option: """

    while True:
        choice = _read_input(menu).strip()
        if choice == "1":
            _add_expense_ui(tracker)
        elif choice == "2":
            _show_total(tracker)
        elif choice == "3":
            _show_grouped(tracker)
        elif choice == "4":
            print("Good bye!")
            break
        else:
            print("Invalid choice – please select 1‑4.")


if __name__ == "__main__":
    main()
```

```file=test_expenses.py
"""test_expenses.py – unit tests for the ExpenseTracker."""

import unittest
from expenses import ExpenseTracker, Expense


class TestExpenseTracker(unittest.TestCase):
    def setUp(self):
        self.tracker = ExpenseTracker()

    # 1. Adding a single valid expense
    def test_add_one_expense(self):
        self.tracker.add_expense(10.5, "Food")
        self.assertEqual(len(self.tracker._list_expenses()), 1)

    # 2. Total after multiple additions
    def test_total_multiple(self):
        self.tracker.add_expense(5, "Transport")
        self.tracker.add_expense(15.75, "Food")
        self.tracker.add_expense(9.25, "Entertainment")
        self.assertAlmostEqual(self.tracker.total(), 30.0)

    # 3. Grouping by category
    def test_group_by_category(self):
        self.tracker.add_expense(20, "Food")
        self.tracker.add_expense(7, "Food")
        self.tracker.add_expense(12, "Books")
        groups = self.tracker.group_by_category()
        self.assertDictEqual(groups, {"Food": 27.0, "Books": 12.0})

    # 4. Adding expense with description
    def test_add_with_description(self):
        self.tracker.add_expense(3, "Coffee", "Latte")
        exp = self.tracker._list_expenses()[0]
        self.assertEqual(exp.description, "Latte")

    # 5. Reject zero amount
    def test_zero_amount_raises(self):
        with self.assertRaises(ValueError):
            self.tracker.add_expense(0, "Misc")

    # 6. Reject negative amount
    def test_negative_amount_raises(self):
        with self.assertRaises(ValueError):
            self.tracker.add_expense(-5, "Misc")

    # 7. Reject empty category
    def test_empty_category_raises(self):
        with self.assertRaises(ValueError):
            self.tracker.add_expense(10, "")

    # 8. Whitespace in category is trimmed
    def test_category_trimming(self):
        self.tracker.add_expense(8, "  Travel  ")
        exp = self.tracker._list_expenses()[0]
        self.assertEqual(exp.category, "Travel")

    # 9. Grouping returns empty dict when no expenses
    def test_group_empty(self):
        self.assertEqual(self.tracker.group_by_category(), {})

    # 10. Total is zero when no expenses
    def test_total_empty(self):
        self.assertEqual(self.tracker.total(), 0.0)


if __name__ == "__main__":
    unittest.main()
```

---

**How to run**

```bash
# Interactive program
python main.py

# Test suite
python -m unittest test_expenses.py
```

All ten tests should pass (`10 passed`). The console UI handles `EOFError` gracefully, making it safe for automated environments.