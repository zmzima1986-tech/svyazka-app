"""Trusted grading harness. Only the candidate namespace is visible to submitted code."""

import ast
import __future__
import builtins
import collections
import copy
import calendar
import datetime
import time
import io
import json
import math
import re
import reprlib
import traceback
import tokenize
import types
import typing
import string
import secrets

MAX_SOURCE = 64_000
MAX_TESTS = 24
MAX_OUTPUT = 16_384


class Unavailable(BaseException):
    """Harness limitation, not a candidate exception: except Exception must not hide it."""


class InputRequired(Unavailable):
    pass


class Incomplete(Exception):
    pass


class WrongAnswer(Exception):
    pass


NODES = set(
    """
Module Expr Constant Name Load Store Del Assign AnnAssign AugAssign Delete NamedExpr FunctionDef
arguments arg Return Lambda If IfExp For While Break Continue Pass Assert Raise BinOp UnaryOp BoolOp
Compare Call keyword Attribute Subscript Slice Starred List Tuple Set Dict ListComp SetComp DictComp
GeneratorExp comprehension Add Sub Mult Div FloorDiv Mod Pow MatMult LShift RShift BitOr BitXor BitAnd
Invert Not UAdd USub And Or Eq NotEq Lt LtE Gt GtE Is IsNot In NotIn JoinedStr FormattedValue
Import ImportFrom alias With withitem Try ExceptHandler
""".split()
)
METHODS = set(
    """
append extend insert pop remove reverse sort index count clear copy get keys values items update
setdefault popitem add discard union intersection difference issubset issuperset join split rsplit
splitlines strip lstrip rstrip lower upper casefold capitalize title startswith endswith find rfind
replace partition rpartition isdigit isnumeric isalpha isalnum isspace islower isupper zfill is_integer
removeprefix removesuffix read readline readlines most_common appendleft popleft extendleft rotate
""".split()
)
SAFE = {
    name: getattr(builtins, name)
    for name in """
abs all any bin bool bytes bytearray chr dict divmod enumerate filter float frozenset int isinstance
hex len list map max min oct ord pow range reversed round set slice sorted str sum tuple zip
ArithmeticError AssertionError EOFError Exception IndexError KeyError NotImplementedError RuntimeError TypeError ValueError ZeroDivisionError
""".split()
}


def json_load(s, **options):
    if options:
        raise Unavailable("Параметры пользовательского декодера JSON недоступны.")
    return json.loads(s)


def json_dump(value, **options):
    if options.keys() - {"ensure_ascii", "indent", "sort_keys", "separators", "allow_nan", "skipkeys"}:
        raise Unavailable("Параметры пользовательского кодировщика JSON недоступны.")
    return json.dumps(value, **options)


class CandidateExit(BaseException):
    def __init__(self, code):
        self.code = code


def exit_candidate(code=None):
    raise CandidateExit(code)


# Capability tokens, never host system streams. No real sys object enters the candidate namespace.
STDOUT, STDERR = object(), object()
MODULES = {
    "sys": {"exit": exit_candidate, "stdout": STDOUT, "stderr": STDERR},
    "__future__": {"annotations": __future__.annotations},
    "typing": {k: getattr(typing, k) for k in ("Union", "Optional", "List", "Dict", "Tuple", "Set", "Iterable", "Sequence", "Any", "Callable")},
    "datetime": {k: getattr(datetime, k) for k in ("date", "time", "datetime", "timedelta")},
    "calendar": {k: getattr(calendar, k) for k in ("month", "monthcalendar", "monthrange", "weekday", "isleap")},
    "time": {k: getattr(time, k) for k in ("time", "localtime", "gmtime", "strftime")},
    "math": {k: getattr(math, k) for k in dir(math) if not k.startswith("_")},
    "collections": {k: getattr(collections, k) for k in ("deque", "Counter", "defaultdict")},
    "json": {"loads": json_load, "dumps": json_dump},
    "string": {k: getattr(string, k) for k in ("ascii_letters", "ascii_lowercase", "ascii_uppercase", "digits", "hexdigits", "octdigits", "punctuation", "printable", "whitespace")},
    "secrets": {"choice": secrets.choice, "randbelow": secrets.randbelow},
}
METHODS.update("now today strftime isoformat year month day hour minute second weekday".split())
METHODS.update(k for module in MODULES.values() for k in module)


def import_safe(name, globals=None, locals=None, fromlist=(), level=0):
    if level or name not in MODULES:
        raise Unavailable("Модуль недоступен в автоматической песочнице: " + name)
    return types.SimpleNamespace(**MODULES[name])


def validate(tree):
    nodes = list(ast.walk(tree))
    if len(nodes) > 6000:
        raise Unavailable("Превышен лимит сложности кода.")
    if not tree.body or all(
        isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str)
        for n in tree.body
    ):
        raise Incomplete("В блоке нет исполняемых инструкций.")
    # Permit literal templates with positional fields only. Do not expose the general format method.
    simple_format = set()
    for call in nodes:
        if (isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "format"
                and isinstance(call.func.value, ast.Constant) and isinstance(call.func.value.value, str)
                and not call.keywords):
            try:
                if all(field is None or (field == "" or field.isdecimal()) and not spec and not conversion
                       for _, field, spec, conversion in string.Formatter().parse(call.func.value.value)):
                    simple_format.add(call.func)
            except ValueError:
                pass
    for n in nodes:
        if type(n).__name__ not in NODES:
            raise Unavailable("Конструкция недоступна в автоматическом режиме: " + type(n).__name__)
        if (
            isinstance(n, (ast.Expr, ast.Return))
            and isinstance(n.value, ast.Constant)
            and n.value.value is Ellipsis
        ):
            raise Incomplete("В коде оставлено троеточие, строка " + str(n.lineno))
        if isinstance(n, ast.Name):
            if n.id.startswith("__") and not (n.id == "__name__" and isinstance(n.ctx, ast.Load)):
                raise Unavailable("Служебное имя недоступно: " + n.id)
            if (
                isinstance(n.ctx, ast.Load)
                and n.id in vars(builtins)
                and n.id not in SAFE
                and n.id not in {"__name__", "open", "print", "input"}
            ):
                raise Unavailable("Встроенная операция недоступна: " + n.id)
        if isinstance(n, ast.Attribute) and (not isinstance(n.ctx, ast.Load) or n.attr not in METHODS and n not in simple_format):
            raise Unavailable("Метод или атрибут недоступен: " + n.attr)
        if isinstance(n, ast.FunctionDef):
            if n.decorator_list or n.name.startswith("__") or getattr(n, "type_params", []):
                raise Unavailable("Эта форма объявления функции недоступна.")
            body = n.body[1:] if ast.get_docstring(n) is not None else n.body
            if not body or all(isinstance(s, ast.Pass) for s in body):
                raise Incomplete("Пустая реализация функции " + n.name)
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                mod = a.name if isinstance(n, ast.Import) else (n.module or "")
                if mod == "__future__" and not (isinstance(n, ast.ImportFrom) and a.name == "annotations"):
                    raise Unavailable("Импорт недоступен: " + mod + "." + a.name)
                if mod not in MODULES or getattr(n, "level", 0):
                    raise Unavailable("Модуль недоступен в автоматической песочнице: " + mod)
                if isinstance(n, ast.ImportFrom) and a.name not in MODULES[mod]:
                    raise Unavailable("Импорт недоступен: " + mod + "." + a.name)
                if (a.asname or a.name).startswith("__"):
                    raise Unavailable("Служебный псевдоним недоступен.")
        if isinstance(n, ast.ExceptHandler):
            types_seen = n.type.elts if isinstance(n.type, ast.Tuple) else [n.type]
            if any(
                not isinstance(t, ast.Name)
                or t.id not in SAFE
                or not isinstance(SAFE[t.id], type)
                or not issubclass(SAFE[t.id], Exception)
                for t in types_seen
            ):
                raise Unavailable("Этот обработчик исключений недоступен для автоматической проверки.")


def reference_cases(req):
    cases = []
    for manifest in req.get("specs", []):
        try:
            values = json.loads(manifest)
        except (ValueError, RecursionError) as e:
            raise Unavailable("Некорректный JSON тестов: " + str(e)) from e
        if not isinstance(values, list) or not values:
            raise Unavailable("nexus-tests должен содержать непустой массив.")
        cases.extend(values)
    source = req.get("examples", "")
    lines = source.splitlines()
    assertions = [s.strip() for s in lines if s.strip().startswith("assert ")]
    for i, line in enumerate(lines):
        if line.strip().startswith(">>> "):
            if i + 1 >= len(lines) or not lines[i + 1].strip():
                raise Unavailable("У примера >>> нет ожидаемого результата.")
            assertions.append("assert " + line.strip()[4:] + " == " + lines[i + 1].strip())
    for text in assertions:
        try:
            stmt = ast.parse(text).body[0]
            expr = stmt.test
            if not (
                isinstance(stmt, ast.Assert)
                and isinstance(expr, ast.Compare)
                and len(expr.ops) == 1
                and isinstance(expr.ops[0], ast.Eq)
                and isinstance(expr.left, ast.Call)
                and isinstance(expr.left.func, ast.Name)
                and not expr.left.keywords
            ):
                raise ValueError
            case = dict(
                function=expr.left.func.id,
                args=[ast.literal_eval(a) for a in expr.left.args],
                expected=ast.literal_eval(expr.comparators[0]),
            )
            if json.loads(json.dumps(case, allow_nan=False)) != case:
                raise ValueError
            cases.append(case)
        except (ValueError, TypeError, AttributeError, SyntaxError, RecursionError, IndexError) as e:
            raise Unavailable(
                "Нужен assert с вызовом функции и ожидаемым литералом либо nexus-tests.json."
            ) from e
    for m in re.finditer(
        r"(?im)^[ \t]*(?:ввод|input)[ \t]*:[ \t]*([^\n]+)\n[ \t]*(?:вывод|output)[ \t]*:[ \t]*([^\n]+)",
        source,
    ):
        cases.append(dict(stdin=m[1].strip() + "\n", stdout=m[2].strip()))
    for name in re.findall(r"(?im)^[ \t]*nexus-contract:[ \t]*(\S+)[ \t]*$", source):
        contracts = {
            "factorial": [([0], 1), ([1], 1), ([2], 2), ([5], 120), ([8], 40320)],
            "gcd": [([0, 0], 0), ([0, 7], 7), ([-12, 18], 6), ([17, 4], 1), ([36, 24], 12)],
        }
        if name not in contracts:
            raise Unavailable("Неизвестный контрольный контракт: " + name)
        cases.extend(dict(function=name, args=args, expected=v) for args, v in contracts[name])
    if len(cases) > MAX_TESTS:
        raise Unavailable("Максимум 24 теста.")
    for case in cases:
        if not isinstance(case, dict):
            raise Unavailable("Некорректный контрольный пример.")
        if set(case) == {"function", "args", "expected"}:
            if not (
                isinstance(case["function"], str)
                and case["function"].isidentifier()
                and not case["function"].startswith("__")
                and isinstance(case["args"], list)
            ):
                raise Unavailable("Тесту нужны имя функции и массив аргументов.")
        elif set(case) != {"stdin", "stdout"} or not all(isinstance(s, str) for s in case.values()):
            raise Unavailable("Укажите function/args/expected либо stdin/stdout.")
    return cases


class Output(io.StringIO):
    def write(self, text):
        if self.tell() + len(text) > MAX_OUTPUT:
            raise Unavailable("Вывод превысил 16 384 символа.")
        return super().write(text)


def matches(a, b):
    if type(a) is not type(b):
        return type(a) in (int, float) and type(b) in (int, float) and a == b
    if isinstance(b, list):
        return len(a) == len(b) and all(matches(x, y) for x, y in zip(a, b))
    if isinstance(b, dict):
        return a.keys() == b.keys() and all(matches(a[k], v) for k, v in b.items())
    return a == b


class SelfAssertions(ast.NodeTransformer):
    def visit_Assert(self, node):
        return [node, ast.copy_location(ast.Expr(ast.Call(ast.Name("__nexus_assert_passed", ast.Load()), [], [])), node)]


def execute(program, files, case):
    out, inp = Output(), io.StringIO(case.get("stdin", "") if case else "")

    missing_input = False
    errors = Output()
    def read(prompt=""):
        nonlocal missing_input
        if missing_input:
            raise InputRequired("Для input() нужен контрольный пример со stdin.")
        out.write(str(prompt))
        s = inp.readline()
        if not s:
            missing_input = True
            raise EOFError("Для input() нужен контрольный пример со stdin.")
        return s.removesuffix("\n").removesuffix("\r")

    def emit(*args, sep=" ", end="\n", flush=False, file=None):
        if file is not None and file is not STDOUT and file is not STDERR:
            raise Unavailable("Недоступный поток вывода.")
        builtins.print(*args, sep=sep, end=end, file=errors if file is STDERR else out)

    def open_read(name, mode="r", encoding="utf-8"):
        if (
            not isinstance(name, str)
            or name not in files
            or mode not in ("r", "rt")
            or encoding not in (None, "utf-8", "utf8")
        ):
            raise Unavailable("Доступно чтение только приложенных текстовых файлов по имени.")
        return io.StringIO(files[name])

    self_assertions = 0

    def count_assertion():
        nonlocal self_assertions
        self_assertions += 1

    env = {
        "__nexus_assert_passed": count_assertion,
        "__builtins__": dict(SAFE, __import__=import_safe, input=read, print=emit, open=open_read),
        "__name__": "nexus_candidate" if case and "function" in case else "__main__",
    }
    try:
        exec(program, env)
    except CandidateExit as stop:
        if stop.code is not None and not (isinstance(stop.code, int) and stop.code % 256 == 0):
            raise WrongAnswer("Программа завершилась с ошибкой: " + reprlib.repr(stop.code))
    if missing_input and (case is None or "stdin" not in case):
        note = "Для input() нужен контрольный пример со stdin."
        if self_assertions:
            note += f" Выполнено assert без ошибок: {self_assertions}."
        raise InputRequired(note)
    if case is None:
        return self_assertions
    if "stdin" in case:
        actual = out.getvalue().replace("\r\n", "\n").removesuffix("\n")
        expected = case["stdout"].replace("\r\n", "\n").removesuffix("\n")
    else:
        fn = env.get(case["function"])
        if not callable(fn):
            raise WrongAnswer("В решении отсутствует функция " + case["function"])
        actual, expected = fn(*copy.deepcopy(case["args"])), case["expected"]
    if not matches(actual, expected):
        raise WrongAnswer("ожидалось " + reprlib.repr(expected) + ", получено " + reprlib.repr(actual))


FEATURES = {
    "часы": {"clock", "strftime", "localtime", "update_clock", "update_time", "gethours"},
    "календарь": {"calendar", "monthrange", "monthcalendar", "rendercalendar", "render_calendar"},
    "погода": {"weather", "get_weather", "fetch_weather", "fetchweather", "update_weather", "openmeteo"},
    "Bluetooth": {"bleak", "bluetooth", "bleakclient", "bleakscanner", "requestdevice", "connect_ble"},
    "графический интерфейс": {"tkinter", "pyqt5", "pyqt6", "pyside6", "kivy", "pygame", "wx"},
}


def source_features(source):
    # Ignore comments and quoted prose. Tokenization also handles a damaged def line.
    names = set()
    try:
        for token in tokenize.generate_tokens(io.StringIO(source).readline):
            if token.type == tokenize.NAME:
                names.add(token.string.lower())
    except (tokenize.TokenError, IndentationError, SyntaxError):
        pass
    result = {feature for feature, markers in FEATURES.items() if names & markers}
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return result
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr in {"startScan", "connectGatt", "getBluetoothLeScanner"}:
                result.add("Bluetooth")
            if node.func.attr in {"monthrange", "monthcalendar", "itermonthdates", "monthdayscalendar"}:
                result.add("календарь")
        if isinstance(node, ast.ImportFrom) and node.module == "calendar":
            result.add("календарь")
    return result


def android_contract_issues(tree):
    """Resolved, literal uses only. Contract: Android API 35 and p4a 2024.1.21."""
    imports = {}
    for item in ast.walk(tree):
        if isinstance(item, ast.ImportFrom):
            for alias in item.names:
                imports[alias.asname or alias.name] = (item.module or "") + "." + alias.name
        elif isinstance(item, ast.Import):
            for alias in item.names:
                imports[alias.asname or alias.name.split(".")[0]] = alias.name if alias.asname else alias.name.split(".")[0]

    def qualified(node):
        if isinstance(node, ast.Name):
            return imports.get(node.id, node.id)
        if isinstance(node, ast.Attribute):
            return qualified(node.value) + "." + node.attr
        return ""

    issues = []
    classes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
    for cls in classes:
        if not any(qualified(b) == "jnius.PythonJavaClass" for b in cls.bases):
            continue
        for assign in cls.body:
            if not isinstance(assign, ast.Assign) or not any(isinstance(t, ast.Name) and t.id == "__javainterfaces__" for t in assign.targets):
                continue
            for value in getattr(assign.value, "elts", []):
                if not isinstance(value, ast.Constant) or not isinstance(value.value, str):
                    continue
                name = value.value.replace("/", ".")
                if name in {"android.bluetooth.le.ScanCallback", "android.bluetooth.BluetoothGattCallback"}:
                    issues.append((assign.lineno, name + " — абстрактный класс Android. PythonJavaClass поддерживает интерфейсы. Нужен подкласс в Java/Kotlin или совместимый мост."))

    for cls in classes:
        methods = {fn.name: fn for fn in cls.body if isinstance(fn, ast.FunctionDef)}
        for fn in methods.values():
            for call in ast.walk(fn):
                if not isinstance(call, ast.Call) or qualified(call.func) != "android.permissions.request_permissions":
                    continue
                callback = call.args[1] if len(call.args)>1 else next((kw.value for kw in call.keywords if kw.arg=="callback"), None)
                if not isinstance(callback, ast.Attribute) or not isinstance(callback.value, ast.Name):
                    continue
                if not fn.args.args or callback.value.id != fn.args.args[0].arg or callback.attr not in methods:
                    continue
                method = methods[callback.attr]
                if method.decorator_list:
                    continue
                args = method.args
                count = len(args.posonlyargs) + len(args.args) - 1
                if count - len(args.defaults) > 2 or (args.vararg is None and count < 2) or any(d is None for d in args.kw_defaults):
                    issues.append((method.lineno, method.name + ": callback python-for-android 2024.1.21 получает permissions и grants (два аргумента после self)."))

    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute) and qualified(node.value) == "android.permissions" and node.attr in {"BLUETOOTH_SCAN", "BLUETOOTH_CONNECT", "ACCESS_FINE_LOCATION"}:
            issues.append((node.lineno, "В python-for-android 2024.1.21 константа находится в android.permissions.Permission." + node.attr))
    return sorted(set(issues))


def android_permission_evidence(tree, configs):
    """Declarations are read from supplied build inputs; a runtime grant needs a device."""
    roots = {alias.name for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom)) for alias in n.names}
    roots.update(n.module or "" for n in ast.walk(tree) if isinstance(n, ast.ImportFrom))
    if not configs and not any(v.split(".")[0] in {"android","jnius"} for v in roots):
        return {}
    declarations = {}
    for path, body in configs.items():
        if not isinstance(body,str) or len(body)>64000:
            declarations[path] = None
            continue
        try:
            if path.split("/")[-1] == "AndroidManifest.xml":
                from xml.etree import ElementTree
                if "<!DOCTYPE" in body.upper() or "<!ENTITY" in body.upper():
                    raise ValueError("unsupported declaration")
                root = ElementTree.fromstring(body)
                if root.tag != "manifest":
                    raise ValueError("unexpected manifest")
                declarations[path]=sorted({node.get("{http://schemas.android.com/apk/res/android}name", "")
                    for node in root if node.tag in {"uses-permission","uses-permission-sdk-23"}} - {""})
            elif path == "buildozer.spec":
                import configparser
                spec=configparser.ConfigParser(interpolation=None)
                spec.read_string(body)
                raw=spec.get("app","android.permissions", fallback="")
                declarations[path]=sorted(set(re.findall(r"(?:android[.]permission[.])?[A-Z][A-Z_]+",raw)))
        except (ValueError, ImportError, SyntaxError):
            declarations[path]=None
        except Exception:
            declarations[path]=None
    runtime = any(isinstance(n,ast.Call) and (isinstance(n.func,ast.Name) and n.func.id=="request_permissions"
                  or isinstance(n.func,ast.Attribute) and n.func.attr in {"request_permissions","requestPermissions"}) for n in ast.walk(tree))
    return {"declarations":declarations,"runtime_request":"call_observed" if runtime else "not_identified","device_grant":"unverified"}


def environment(tree):
    """Inspect imports in the entire source before any candidate code is executed."""
    roots = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            roots.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            roots.add(node.module.split(".")[0])
    issues = []
    for names, category, reason in (
        ({"tkinter", "_tkinter", "PyQt5", "PyQt6", "PySide6", "wx", "kivy", "turtle", "pygame"},
         "ENVIRONMENT_UNSUPPORTED", "Графический интерфейс не проверен. Нужна целевая среда с графической библиотекой. Для Kivy на Android требуется отдельная сборка."),
        ({"bleak", "bluetooth", "bluepy", "dbus"}, "ENVIRONMENT_UNSUPPORTED",
         "Bluetooth не проверен. Нужны системный BLE-адаптер, разрешение и совместимое устройство."),
        ({"cv2", "picamera", "picamera2"}, "ENVIRONMENT_UNSUPPORTED", "Камера не проверена. Нужна среда с доступом к устройству."),
        ({"requests", "httpx", "aiohttp", "urllib", "http", "socket", "pyodide_http"}, "REQUIRES_EXTERNAL_SERVICE",
         "Сетевые операции не выполнены: локальная проверка не запускает код с этими сетевыми импортами."),
    ):
        matched = sorted(roots & names)
        if matched:
            issues.append((category, ", ".join(matched) + ": " + reason))
    return issues


def manual_limit(code):
    try:
        tree = ast.parse(code, "main.py")
    except SyntaxError:
        return ""  # The normal runner returns Python's line and traceback.
    return "\n".join(detail for _, detail in environment(tree))


def keeps_test_contract(original, updated):
    """Allow additional imports and test methods, preserving the saved module's executable statements."""
    def same(left, right):
        if type(left) is not type(right):
            return False
        if isinstance(left, (ast.Import, ast.ImportFrom)):
            if isinstance(left, ast.ImportFrom) and (left.level, left.module) != (right.level, right.module):
                return False
            return {(n.name, n.asname) for n in left.names} <= {(n.name, n.asname) for n in right.names}
        if isinstance(left, ast.ClassDef):
            if left.name != right.name:
                return False
            for field in ("bases", "keywords", "decorator_list", "type_params"):
                if [ast.dump(n) for n in getattr(left, field, [])] != [ast.dump(n) for n in getattr(right, field, [])]:
                    return False
            return sequence(left.body, right.body, True)
        return ast.dump(left) == ast.dump(right)

    def sequence(old, new, in_class=False):
        pos = 0
        names = {n.name for n in old if isinstance(n, (ast.ClassDef, ast.FunctionDef))}
        for node in new:
            if pos < len(old) and same(old[pos], node):
                pos += 1
            elif in_class:
                if not isinstance(node, ast.FunctionDef) or not node.name.startswith("test") or node.name in names:
                    return False
                names.add(node.name)
            elif not isinstance(node, (ast.Import, ast.ImportFrom)):
                if not isinstance(node, ast.ClassDef) or node.name in names:
                    return False
                names.add(node.name)
        return pos == len(old)

    return sequence(ast.parse(original).body, ast.parse(updated).body)


def verify_request(payload, notify=lambda stage, passed, total: None):
    req = json.loads(payload)
    syntax = ran = False
    passed = total = number = 0
    phase = "compile"
    features = {}
    permissions = {}
    workspace_eligible = False
    imports = set()

    def report(status, reason="", signature="", category="NOT_TESTED"):
        repairable = False
        user_console = req.get("console_request", "")
        if category == "DEPENDENCY_UNAVAILABLE" and user_console:
            absent = sorted(name for name in imports if name not in MODULES)
            repairable = bool(absent) and all(not re.search(r"(?<!\w)" + re.escape(name) + r"(?!\w)",
                    user_console, re.I) for name in absent)
            if repairable:
                signature = "console-dependency/" + ",".join(absent)
        return json.dumps(
            dict(
                status=status,
                category=category,
                feature_review=features,
                android_permissions=permissions,
                syntax=syntax,
                ran=ran,
                passed=passed,
                total=total,
                diagnostic=reason[:2400],
                signature=signature[:500],
                workspace_eligible=workspace_eligible,
                compatibility_repair=repairable,
            ),
            ensure_ascii=False,
        )

    try:
        if "project_sources" in req:
            # Named modules are compiled separately, never concatenated or imported
            # in the restricted verifier. Full execution uses the workspace runner.
            sources = req["project_sources"]
            if not isinstance(sources, dict) or not 2 <= len(sources) <= 64:
                raise Unavailable("Недопустимый состав Python-проекта.")
            if any(not isinstance(path, str) or not re.fullmatch(r"[A-Za-z0-9_-][A-Za-z0-9._-]*(/[A-Za-z0-9_-][A-Za-z0-9._-]*)*\.py", path)
                   or not isinstance(part, str) or not part.strip() for path, part in sources.items()):
                raise Unavailable("Недопустимый путь или пустой Python-файл.")
            if sum(len(part.encode("utf-8")) for part in sources.values()) > MAX_SOURCE:
                raise Unavailable("Материал пуст или превышает лимит 64 000 байт.")
            for path, part in sources.items():
                try:
                    compile(part, path, "exec", dont_inherit=True)
                except SyntaxError as e:
                    return report("ERROR", f"{path}, строка {e.lineno}: {e.msg}",
                                  signature=f"project-syntax/{path}/{e.lineno}/{e.msg}", category="SYNTAX_ERROR")
            syntax = True
            for path, original in req.get("protected_tests", {}).items():
                if path not in sources or not keeps_test_contract(original, sources[path]):
                    return report("ERROR", "Сохраните прежние тесты и ожидания в " + path + "; добавьте новые случаи отдельно.",
                                  signature="protected-tests/" + path, category="TEST_CONTRACT_CHANGED")
            notify("syntax", 0, 0)
            return report("LIMITED", req["reason"])
        if "syntax_only" in req:
            parts = req["syntax_only"]
            if not parts or sum(len(s.encode("utf-8")) for s in parts) > MAX_SOURCE:
                raise Unavailable("Материал пуст или превышает лимит 64 000 байт.")
            for i, part in enumerate(parts, 1):
                if not part.strip():
                    raise Unavailable("Блок Python пуст.")
                try:
                    compile(part, "block-" + str(i) + ".py", "exec", dont_inherit=True)
                except SyntaxError as e:
                    raise Unavailable(
                        "Блок " + str(i) + ", строка " + str(e.lineno) + ": " + e.msg
                    ) from e
            syntax = True
            return report("LIMITED", req["reason"])
        code = req["code"]
        if len(code.encode("utf-8")) > MAX_SOURCE:
            raise Unavailable("Код превышает 64 000 байт.")
        tree = ast.parse(code, "main.py")
        program = compile(tree, "main.py", "exec", dont_inherit=True)
        syntax = True
        notify("syntax", 0, 0)
        phase = "policy"
        permissions = android_permission_evidence(tree, req.get("android_config", {}))
        permission_note = ""
        if permissions:
            declarations=permissions["declarations"]
            permission_note = " Манифест / конфигурация: " + (", ".join(
                path + " (" + (", ".join(values) if values else "список не подтверждён") + ")"
                for path, values in declarations.items()) or "файл не предоставлен") + ". "
            permission_note += ("Найден вызов запроса разрешений. " if permissions["runtime_request"]=="call_observed"
                                else "Вызов запроса разрешений не подтверждён. ") + "Выдача разрешений и BLE на устройстве не проверены."
        contract = android_contract_issues(tree)
        if contract:
            message = "\n".join("Строка %d: %s" % item for item in contract)
            return report("ERROR", "Статическая проверка Android (без запуска):\n" + message + permission_note,
                          signature="android-contract/" + "|".join(item[1] for item in contract),
                          category="ANDROID_API_CONTRACT")
        detected = source_features(code)
        previous_web = req.get("previous_web", "")
        if previous_web:
            hints = {
                "часы": r"getHours\s*\(|updateClock\s*\(",
                "календарь": r"renderCalendar\s*\(|getDaysInMonth\s*\(",
                "погода": r"fetchWeather\s*\(|api\.openweathermap|api\.open-meteo",
                "Bluetooth": r"navigator\.bluetooth|requestDevice\s*\(",
            }
            origin = {label for label, pattern in hints.items() if re.search(pattern, previous_web, re.I)}
            features = {label: ("source_indicator" if label in detected else "not_identified") for label in sorted(origin)}
        for feature in req.get("required_features", []):
            if feature in FEATURES:
                features[feature] = "source_indicator" if feature in detected else "not_identified"
        baseline = req.get("previous_code", "")
        if baseline:
            baseline_features = source_features(baseline)
            for label in sorted(baseline_features):
                features[label] = "source_indicator" if label in detected else "not_identified"
            missing = sorted(baseline_features - detected)
            if missing:
                return report("LIMITED", "После исправления нужна ручная сверка реализации: " +
                              ", ".join(missing) + ". Предыдущий файл сохранён.",
                              category="REQUIREMENTS_CHANGED")
        imports = {a.name.split(".")[0] for node in ast.walk(tree) if isinstance(node, ast.Import) for a in node.names}
        imports.update(node.module.split(".")[0] for node in ast.walk(tree)
                       if isinstance(node, ast.ImportFrom) and node.module and not node.level)
        limitations = environment(tree)
        missing_web = [key for key, value in features.items() if value == "not_identified"]
        feature_note = (" Требуется функциональный тест: " + ", ".join(missing_web) + ".") if missing_web else ""
        if permissions and not limitations:
            limitations.append(("ENVIRONMENT_UNSUPPORTED", "Исполнение на Android требует отдельной сборки."))
        if limitations:
            return report("LIMITED", "\n".join(message for _, message in limitations) + feature_note + permission_note,
                          category=limitations[0][0])
        if missing_web:
            return report("LIMITED", feature_note.strip(), category="NOT_TESTED")
        # A single unittest script needs real class/module semantics. Only the
        # explicit offline project runner may execute it, without user files.
        # Never replace an independent oracle with program-authored tests.
        # Do not route unrelated code merely because it imports unittest.
        test_case_names = {"unittest.TestCase"}
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                test_case_names.update((a.asname or a.name) + ".TestCase" for a in node.names if a.name == "unittest")
            elif isinstance(node, ast.ImportFrom) and node.module == "unittest" and not node.level:
                test_case_names.update(a.asname or a.name for a in node.names if a.name == "TestCase")
        has_suite = any(isinstance(node, ast.ClassDef) and any(ast.unparse(base) in test_case_names for base in node.bases)
                        for node in ast.walk(tree))
        relative = any(isinstance(node, ast.ImportFrom) and node.level for node in ast.walk(tree))
        if (has_suite and not relative and "unittest" in imports and imports <= set(MODULES) | {"unittest", "random", "dataclasses", "sys", "argparse", "statistics", "decimal", "fractions", "itertools", "functools", "operator"}
                and not req.get("files") and not req.get("previous_code") and not req.get("previous_web")
                and not features and not permissions and not reference_cases(req)):
            workspace_eligible = True
            return report("LIMITED", "Встроенный unittest требует отдельного запуска в изолированной рабочей области.")
        validate(tree)
        cases = reference_cases(req)
        # Only the trusted harness can call the counter; validate rejects user dunder names.
        program = compile(ast.fix_missing_locations(SelfAssertions().visit(tree)), "main.py", "exec", dont_inherit=True, optimize=0)
        self_assertions = 0
        total = len(cases)
        phase = "execute"
        if total:
            notify("syntax", 0, total)
        for number, case in enumerate(cases or [None], 1):
            observed = execute(program, req.get("files", {}), case)
            if case is None:
                self_assertions = observed
            ran = True
            if case is not None:
                passed += 1
            notify("executed", passed, total)
        note = (f"Выполнено assert без ошибок: {self_assertions}. Независимых контрольных примеров нет."
                if not total and self_assertions else "")
        return report("PASSED" if total else "RAN", reason=note, category="TESTS_PASSED" if total else "EXECUTED_NO_TESTS")
    except (InputRequired, EOFError) as e:
        ran = phase == "execute"
        return report("LIMITED", str(e) or "Для input() нужен контрольный пример со stdin.", category="INPUT_REQUIRED")
    except (Unavailable, MemoryError, RecursionError) as e:
        reason = str(e) or type(e).__name__
        category = "DEPENDENCY_UNAVAILABLE" if "Модуль недоступен" in reason or "Импорт недоступен" in reason else "NOT_TESTED"
        return report("LIMITED", reason, category=category)
    except Exception as e:
        frames = [f for f in traceback.extract_tb(e.__traceback__) if f.filename == "main.py"]
        if not frames and not isinstance(e, (WrongAnswer, Incomplete, SyntaxError)):
            return report("LIMITED", "Ошибка механизма проверки: " + type(e).__name__ + ": " + str(e))
        line = e.lineno if isinstance(e, SyntaxError) else frames[-1].lineno if frames else None
        if isinstance(e, WrongAnswer):
            ran = True
        reason = e.msg if isinstance(e, SyntaxError) else str(e)
        label = (
            ("Тест " + str(number) + " " + reprlib.repr(cases[number - 1]) + ". ")
            if total and number
            else ""
        )
        label += type(e).__name__ + ": " + reason + (" (строка " + str(line) + ")" if line else "")
        signature = "/".join(
            (
                phase,
                type(e).__name__,
                str(number),
                "" if isinstance(e, (WrongAnswer, Incomplete)) else reason,
            )
        )
        category = "SYNTAX_ERROR" if isinstance(e, (SyntaxError, Incomplete)) else "TEST_FAILED" if isinstance(e, WrongAnswer) else "RUNTIME_ERROR"
        return report("ERROR", label, signature, category)
