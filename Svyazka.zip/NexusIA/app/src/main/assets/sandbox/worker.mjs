import { loadPyodide } from './pyodide/pyodide.mjs';

const OUTPUT_LIMIT = 24000;
self.addEventListener('message', async event => {
    const port = event.ports[0];
    try {
        const python = await loadPyodide({
            jsglobals: Object.create(null),
            packageBaseUrl: 'https://cdn.jsdelivr.net/pyodide/v314.0.8/full/',
        });
        const verifierSource = await fetch('./verify.py');
        if (!verifierSource.ok) throw new Error('Verifier unavailable');
        python.runPython(await verifierSource.text());
        const automatic = event.data?.verify === true;
        const verifier = automatic ? python.globals.get('verify_request') : null;
        if (!automatic) {
            const workspaceSource = await fetch('./workspace.py');
            if (!workspaceSource.ok) throw new Error('Workspace unavailable');
            python.runPython(await workspaceSource.text());
        }
        const engine = 'На телефоне · Python ' + python.runPython('import sys; sys.version.split()[0]');
        port.onmessage = ({data}) => {
            if (automatic) {
                try {
                    port.postMessage({kind: 'execution_start'});
                    const notify = (stage, passed, total) => port.postMessage({kind:'progress',progress:{stage,passed,total}});
                    port.postMessage({kind:'verified',report:JSON.parse(verifier(JSON.stringify(data),notify))});
                } catch (error) { port.postMessage({kind:'error',error:String(error).slice(0,500)}); }
                finally { verifier.destroy(); }
            } else {
                execute(python, data, port).catch(error => port.postMessage({
                    kind: 'error', error: 'Ошибка Python-песочницы: ' + String(error).slice(0,500),
                }));
            }
        };
        port.postMessage({kind:'ready',engine});
    } catch (error) {
        port.postMessage({kind:'error',error:'Ошибка запуска Python: ' + String(error).slice(0,500)});
    }
}, {once:true});

async function execute(python, data, port) {
    const code = String(data.code || '');
    const entry = String(data.entry || 'main.py');
    const stdin = String(data.stdin || '');
    const manualLimit = python.globals.get('manual_limit');
    try {
        const limitation = manualLimit(code);
        if (limitation) { port.postMessage({kind:'error',error:limitation}); return; }
    } finally { manualLimit.destroy(); }

    let files, tests, hash;
    try {
        python.globals.set('nexus_payload',JSON.stringify(data.files || {}));
        python.globals.set('nexus_entry', entry);
        python.globals.set('nexus_code',code);
        // Native Python validates paths again and never uses them as OS paths outside /workspace.
        python.runPython('nexus_files = decode_files(nexus_payload)');
        python.runPython(`
if not valid_path(nexus_entry) or not nexus_entry.endswith('.py'):
    raise ValueError('Главный файл должен иметь расширение .py')
nexus_files[nexus_entry] = nexus_code.encode('utf-8')
if sum(len(v) for v in nexus_files.values()) > MAX_TOTAL or len(nexus_files) > MAX_FILES:
    raise ValueError('Проект превышает лимит размера')
`);
        python.runPython('reset_workspace(nexus_files)');
        // A generated tests.json is not a user-supplied independent oracle.
        tests = data.project_tests === true ? [] : JSON.parse(python.runPython('json.dumps(tests_for_entry(nexus_files, nexus_entry))'));
        // The same preflight applies to every source, including manual projects.
        // A helper module is no less untrusted than the selected entry point.
        const limitation = python.runPython("'\\n'.join(name + ': ' + note for name, binary in nexus_files.items() if name.endswith('.py') for note in [manual_limit(binary.decode('utf-8'))] if note)");
        if (limitation) { port.postMessage({kind:'error',error:limitation}); return; }
        hash = python.runPython('snapshot_sha256(nexus_files)');
        files = true;
    } catch (error) {
        port.postMessage({kind:'error',error:'Проект отклонён: ' + String(error).slice(0,500)});
        return;
    }
    if (!files) return;

    const pack = String(data.package || (data.allow_matplotlib ? 'matplotlib' : ''));
    if (!['','matplotlib','numpy'].includes(pack)) {
        port.postMessage({kind:'error',error:'Пакет отсутствует в разрешённом реестре.'});
        return;
    }
    if (pack) {
        try {
            await python.loadPackage(pack);
            if (pack === 'matplotlib') {
                // First Agg draw and font-cache creation can exceed the 5s
                // execution budget on Android. Do it during package setup,
                // before execution_start. A failed draw is a real setup error.
                python.runPython('prepare_matplotlib()');
            }
        } catch (error) {
            port.postMessage({kind:'error',error:'Не удалось подготовить разрешённый пакет ' + pack + ': ' + String(error).slice(0,450)});
            return;
        }
    }
    port.postMessage({kind:'execution_start'});

    function runOnce(source, input, progress, generatedSuite = false) {
        let stdout = '';
        let stderr = '';
        let truncated = false;
        let lastReport = 0;
        const outDecoder = new TextDecoder();
        const errDecoder = new TextDecoder();
        const lines = input === '' ? [] : input.replace(/\r\n/g,'\n').split('\n');
        if (lines.length && lines.at(-1) === '' && input.endsWith('\n')) lines.pop();
        let nextLine = 0;
        python.setStdin({stdin: () => nextLine < lines.length ? lines[nextLine++] : null});
        function append(current, buffer, decoder) {
            if (current.length >= OUTPUT_LIMIT) { truncated = true; return current; }
            const updated = current + decoder.decode(buffer, {stream:true});
            if (updated.length > OUTPUT_LIMIT) truncated = true;
            return updated.slice(0,OUTPUT_LIMIT);
        }
        python.setStdout({write: buffer => {
            stdout = append(stdout,buffer,outDecoder);
            if (progress && performance.now() - lastReport > 200) {
                lastReport = performance.now();port.postMessage({kind:'output',stdout,stderr});
            }
            return buffer.length;
        }});
        python.setStderr({write: buffer => {
            stderr = append(stderr,buffer,errDecoder);
            if (progress && performance.now() - lastReport > 200) {
                lastReport = performance.now();port.postMessage({kind:'output',stdout,stderr});
            }
            return buffer.length;
        }});
        let exit, generatedTests = null, inputRequired = false;
        try {
            if (generatedSuite) {
                generatedTests = JSON.parse(python.runPython('json.dumps(run_generated_tests(nexus_entry) if len(nexus_files) == 1 else run_generated_tests())'));
                exit = generatedTests.status === 'FAILED' ? 1 : 0;
            } else {
                python.globals.set('nexus_code',source);
                const observed = JSON.parse(python.runPython('run_observed_script(nexus_code, nexus_entry)'));
                exit = observed.code;
                inputRequired = observed.input_required === true;
            }
        } catch (error) {
            stderr = (stderr + '\n' + String(error)).slice(0, OUTPUT_LIMIT);
            exit = 1;
        }
        return {stdout:(stdout + outDecoder.decode()).slice(0,OUTPUT_LIMIT),
            stderr:(stderr + errDecoder.decode()).slice(0,OUTPUT_LIMIT),code:exit,truncated,generatedTests,inputRequired};
    }

    const initial = runOnce(code,stdin,true);
    let artifacts = [];
    if (initial.code === 0 || initial.code === 1) {
        try { artifacts = JSON.parse(python.runPython('json.dumps(collect_artifacts(nexus_files))')); }
        catch (_) { artifacts = []; }
    }

    // Test the original saved bytes, not files mutated by main.py. These are
    // generated self-tests; they never populate the independent tests array.
    let generatedTests = null, finalCode = initial.code, generatedNote = '';
    if (data.project_tests === true && initial.code === 0) {
        try {
            python.runPython('reset_workspace(nexus_files)');
            const suite = runOnce('', '', false, true);
            generatedTests = suite.generatedTests;
            finalCode = suite.code;
            initial.stdout = (initial.stdout + '\n' + suite.stdout).slice(0, OUTPUT_LIMIT);
            initial.stderr = (initial.stderr + suite.stderr).slice(0, OUTPUT_LIMIT);
            initial.truncated = initial.truncated || suite.truncated;
            generatedNote = generatedTests
                ? `Встроенные unittest: ${generatedTests.passed}/${generatedTests.discovered}; выполнено ${generatedTests.ran}, пропущено ${generatedTests.skipped}.`
                : 'Встроенные тесты не завершены.';
        } catch (error) {
            finalCode = 1;
            initial.stderr = (initial.stderr + '\n' + String(error)).slice(0, OUTPUT_LIMIT);
            generatedNote = 'Не удалось выполнить встроенные тесты.';
        }
    }
    const testResults = [];
    // Independent test cases come from explicitly user-authored tests.json.
    // Each case restores the same source snapshot and reimports its own modules.
    if (tests.length && initial.code === 0) {
        for (let index = 0; index < tests.length; index++) {
            const test = tests[index];
            const started = performance.now();
            try {
                python.runPython('reset_workspace(nexus_files)');
                const actual = runOnce(code,test.stdin || '',false);
                const expected = test.stdout.replace(/\r\n/g,'\n');
                const observed = actual.stdout.replace(/\r\n/g,'\n');
                const passed = actual.code === 0 && observed.trimEnd() === expected.trimEnd();
                testResults.push({name:String(test.name || `Тест ${index+1}`).slice(0,80),passed,
                    stdin:String(test.stdin || '').slice(0,500), expected:expected.slice(0,1200),
                    actual:observed.slice(0,1200),duration_ms:Math.round(performance.now()-started)});
            } catch (error) {
                testResults.push({name:String(test.name || `Тест ${index+1}`).slice(0,80),passed:false,
                    actual:String(error).slice(0,300),expected:String(test.stdout).slice(0,1200)});
            }
        }
    }
    const png = artifacts.find(item=>item.mime==='image/png');
    const html = artifacts.find(item=>item.name === 'index.html' || item.name === 'output.html');
    const hint = !png && /\bBytesIO\s*\(/.test(code) && /\bsavefig\s*\(/.test(code)
        ? 'PNG в BytesIO нельзя автоматически извлечь. Сохраните chart.png.' : '';
    const passed = testResults.filter(item=>item.passed).length;
    const inputNote = initial.inputRequired ? 'Требуется ввод. Заполните поле stdin отдельной строкой для каждого ответа и повторите запуск.' : '';
    const checkedSuite = generatedTests && generatedTests.status === 'PASSED';
    const incompleteInput = initial.inputRequired && finalCode === 0 && !checkedSuite && !testResults.length;
    const status = [inputNote, initial.truncated ? 'Вывод ограничен 24 000 символами каждого потока.' : '',
        hint, generatedNote, testResults.length ? `Тесты: ${passed}/${testResults.length}.` :
            initial.inputRequired ? '' : finalCode === 0 ? 'Код выполнен; независимые контрольные тесты не предоставлены.' : 'Ошибка выполнения.'].filter(Boolean).join(' ');
    port.postMessage({kind:'done',stdout:initial.stdout,stderr:initial.stderr,
        code:incompleteInput ? null : finalCode, input_required:initial.inputRequired, status, generated_tests:generatedTests, image_png:png?.data || '',
        html:html ? new TextDecoder().decode(Uint8Array.from(atob(html.data), c => c.charCodeAt(0))) : '', artifacts, tests:testResults, snapshot_sha256:hash});
}
