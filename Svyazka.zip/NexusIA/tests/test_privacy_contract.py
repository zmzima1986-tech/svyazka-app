"""Security source contracts that supplement (not replace) JVM request-body tests."""
from pathlib import Path
from xml.etree import ElementTree as ET
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'app/src/main/java/app/svyazka/mobile'
RES = ROOT / 'app/src/main/res'


class PrivacySecurityContracts(unittest.TestCase):
    def test_explicit_consent_guards_all_ai_dispatches(self):
        source = (JAVA / 'MainActivity.java').read_text()
        begin = source.split('private void begin(Workflow.Run input) {', 1)[1]
        consent = begin.index('PRIVACY_NOTICE_ACKNOWLEDGED')
        dispatch = begin.index('requestNextModel(false)')
        self.assertLess(consent, dispatch)
        self.assertIn('.setNegativeButton(R.string.action_cancel, null)', begin[consent:dispatch])
        self.assertIn('.commit()', begin[consent:dispatch])
        self.assertIn('begin(input);', begin[consent:dispatch])

    def test_filter_applies_only_to_openrouter_requests(self):
        client = (JAVA / 'ModelClient.java').read_text()
        self.assertIn('if (noTrainingOnly) provider.put("data_collection", "deny")', client)
        self.assertIn('return chatBody(run, model, true, false)', client)
        self.assertIn('routerBody(run, model, noTrainingOnly)', client)
        self.assertIn('setNoTrainingOnly(boolean enabled)', client)

    def test_privacy_settings_exist_in_every_locale(self):
        required = {'settings_privacy', 'privacy_no_training_label', 'privacy_no_training_hint',
                    'privacy_first_title', 'privacy_first_message', 'privacy_first_accept',
                    'privacy_notice_save_error'}
        for folder in ('values', 'values-en', 'values-zh-rCN', 'values-ar', 'values-ja'):
            names = {node.attrib['name'] for node in ET.parse(RES / folder / 'strings.xml').getroot()
                     if node.tag == 'string'}
            self.assertTrue(required <= names, folder)

    def test_legacy_credentials_and_package_identity_unchanged(self):
        gradle = (ROOT / 'app/build.gradle').read_text()
        self.assertIn("applicationId 'app.svyazka.team'", gradle)
        self.assertIn('versionCode 21', gradle)
        self.assertIn("file('../build/manual/signing.p12')", gradle)


if __name__ == '__main__':
    unittest.main()
