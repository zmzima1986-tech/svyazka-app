package app.svyazka.mobile.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/** One lightweight, translucent surface for drawers and dialogs in both themes.
 *  It intentionally avoids expensive full-screen blur on older Android devices.
 */
@Composable
internal fun nexusFrostedColor(): Color =
    if (!nexusLightMode()) Color(0xFF0C1320).copy(alpha = .88f)
    else Color.White.copy(alpha = .88f)

@Composable
internal fun NexusFrostedPanel(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(0.dp),
    darkBackground: Color? = null,
    darkBorder: Color? = null,
    lightBackground: Color? = null,
    lightBorder: Color? = null,
    showBorder: Boolean = true,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier,
        shape = shape,
        color = if (nexusLightMode()) lightBackground ?: nexusFrostedColor()
            else darkBackground ?: nexusFrostedColor(),
        contentColor = MaterialTheme.colorScheme.onSurface,
        border = if (showBorder) BorderStroke(1.dp,
            if (nexusLightMode()) lightBorder ?: MaterialTheme.colorScheme.outline.copy(alpha = .34f)
            else darkBorder ?: MaterialTheme.colorScheme.outline.copy(alpha = .34f)) else null,
        tonalElevation = 0.dp,
        content = content
    )
}

/** Keep the existing dialog actions while using the same surface as the side menu. */
@Composable
internal fun NexusFrostedAlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: @Composable (() -> Unit)? = null,
    icon: @Composable (() -> Unit)? = null,
    title: @Composable (() -> Unit)? = null,
    text: @Composable (() -> Unit)? = null
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = confirmButton,
        modifier = modifier,
        dismissButton = dismissButton,
        icon = icon,
        title = title,
        text = text,
        shape = RoundedCornerShape(28.dp),
        containerColor = nexusFrostedColor(),
        tonalElevation = 0.dp
    )
}
