package app.svyazka.mobile;

import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 33)
public class NexusPhoneRegressionTest {
    private static ModelClient.Reply stop(String text) {
        return new ModelClient.Reply(text, ModelClient.Finish.STOP, "");
    }

    @Test public void truncatedMultiFileAnswerRejectsBogusTailAndRecovers() throws Exception {
        String partial = "Plan\n```python\n# file=src/expenses.py\nprint(1)\n```\n"
                + "```python\n# file=src/main.py\nprint(";
        Workflow.Run run = Workflow.Run.quick("Python project", ModelCatalog.NORTH,
                Workflow.defaultStages().get(1)).receive(stop(partial)).permitParts();
        String before = run.draft.parts.toString();
        Workflow.Run rejected = run.receive(stop("```python\n... ZIP) should be completed later.\n```"));
        assertFalse(rejected.complete());
        assertEquals(partial, rejected.draft.text);
        assertEquals(before, rejected.draft.parts.toString());
        assertTrue(rejected.draft.intactParts());
        assertTrue(rejected.draft.preceding.size() > 0);
        Workflow.Run restored = Workflow.Run.fromJson(rejected.toJson());
        String full = partial + "2)\n```";
        Workflow.Run done = restored.receive(stop(full));
        assertTrue(done.complete());
        assertEquals(full, done.displayAnswer(0));
        assertTrue(done.answerAt(0).intactParts());
    }

    @Test public void repairTaskIsLatestClarificationNotFirstTask() throws Exception {
        String prior = "Create a Python program printing 250.";
        String latest = "Fix the division.\nExpected output: 5.0";
        String task = TaskHistory.followUp(prior, "```python\nprint(250)\n```", latest);
        String code = "a = 10\nb = 0\nprint(a / b)\n";
        Workflow.Run run = new Workflow.Run(task, Workflow.defaultStages())
                .receive(stop("```python\n" + code + "```"))
                .receive(stop("Review complete.\n[[REVIEW: PASS]]"));
        assertTrue(run.revisionSkipped());
        run = run.addRepair(new Workflow.RepairInput(0, code, "", "ZeroDivisionError"));
        JSONObject prompt = new JSONObject(run.unoptimizedPrompt());
        assertEquals(latest, prompt.getString("task"));
        assertTrue(prompt.getJSONObject("inputs").getString("prior_user_requirements_context_only").contains(prior));
        assertEquals(code, prompt.getJSONObject("inputs").getJSONObject("sandbox_result").getString("python_code"));
        JSONObject verification = PythonInputs.request(run, code);
        JSONArray specs = verification.getJSONArray("specs");
        assertEquals("5.0", new JSONArray(specs.getString(specs.length()-1)).getJSONObject(0).getString("stdout"));
    }

    @Test public void reportFingerprintMatchesWorkspaceAndChangesWithFile() {
        Map<String, byte[]> files = new LinkedHashMap<>();
        files.put("main.py", "print(5)\n".getBytes(StandardCharsets.UTF_8));
        String before = PythonProjectStore.snapshotSha256(files);
        assertEquals("7cdcb41b32b22badcad58f805caa2a04e39dc615430712b2ac75c3da6c54bd53", before);
        files.put("main.py", "print(250)\n".getBytes(StandardCharsets.UTF_8));
        assertNotEquals(before, PythonProjectStore.snapshotSha256(files));
    }

    @Test public void expectedOutputIgnoresFencedExampleAndRejectsConflict() {
        assertEquals("5.0", PythonAutoTests.expectedOutput("```text\nExpected output: 250\n```\nExpected output: 5.0"));
        assertNull(PythonAutoTests.expectedOutput("Expected output: 250\nExpected output: 5.0"));
    }
}
