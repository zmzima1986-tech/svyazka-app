package app.svyazka.mobile.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.StopCircle
import androidx.compose.material.icons.outlined.SaveAlt
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.PythonVerification
import app.svyazka.mobile.R
import app.svyazka.mobile.attachments.AttachmentStore

/** Identical flat, three-layer mark in the dark and light themes. */
@Composable
fun NexusBrandMark(modifier: Modifier = Modifier.size(36.dp)) {
    Canvas(modifier) {
        val unit = size.minDimension / 100f
        fun segment(x1: Float, y1: Float, x2: Float, y2: Float, color: Color) {
            drawLine(color, Offset(x1 * unit, y1 * unit), Offset(x2 * unit, y2 * unit),
                strokeWidth = 8f * unit, cap = StrokeCap.Round)
        }
        segment(18f, 24f, 50f, 8f, NexusCyan)
        segment(50f, 8f, 82f, 24f, NexusCyan)
        segment(82f, 24f, 50f, 40f, NexusCyan)
        segment(50f, 40f, 18f, 24f, NexusCyan)
        segment(19f, 49f, 50f, 65f, NexusBlue)
        segment(50f, 65f, 81f, 49f, NexusBlue)
        segment(18f, 67f, 50f, 83f, NexusPurple)
        segment(50f, 83f, 82f, 67f, NexusPurple)
    }
}

@Composable
fun NexusChatScreen(ui: NexusComposeUi) {
    val state = ui.snapshot
    if (ui.searching) { MessageSearch(ui, false); return }
    val attachments = rememberAttachmentTask(ui)
    val attachAction = rememberAttachFileAction(ui)
    val context = LocalContext.current
    val saveResult = rememberSaveResultAction(state.result)
    val currentStage = state.stages.firstOrNull { it.current }
    val saveDraft = rememberSaveResultAction(currentStage?.answer.orEmpty(), "draft-incomplete-unverified.txt")
    var changeModel by remember(ui.taskId) { mutableStateOf(false) }
    if (changeModel && currentStage != null) ModelPicker(ui, currentStage.modelId, { changeModel = false }) {
        ui.activity.nexusChangePausedModel(it)
        changeModel = false
    }
    val list = rememberLazyListState()
    var attachmentsExpanded by rememberSaveable(ui.taskId) { mutableStateOf(false) }
    val exchangeCount = state.exchanges.size
    LaunchedEffect(ui.taskId, exchangeCount, state.complete, state.finished) {
        if (exchangeCount > 0) {
            val lastIndex = list.layoutInfo.totalItemsCount - 1
            if (lastIndex >= 0) list.animateScrollToItem(lastIndex)
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            NexusOutlineActionButton(
                text = stringResource(R.string.artifacts_save_chat),
                onClick = { ui.activity.nexusSaveChat() },
                enabled = !state.active && !state.clearing && !ui.pythonBusy,
                modifier = Modifier.weight(1f),
                icon = { Icon(Icons.Outlined.SaveAlt, null, Modifier.size(18.dp)) }
            )
            NexusOutlineActionButton(
                text = stringResource(R.string.artifacts_open_project),
                onClick = {
                    if (ui.projectId > 0L) ui.activity.nexusOpenArtifact(ui.projectId)
                    else ui.activity.nexusOpenArtifacts()
                },
                enabled = !state.active && !state.clearing && !ui.pythonBusy,
                modifier = Modifier.weight(1f),
                icon = { Icon(Icons.Outlined.FolderOpen, null, Modifier.size(18.dp)) }
            )
        }
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            // Preview uses a fraction of the available height so the keyboard cannot hide the input.
            val attachmentListLimit = (maxHeight * .42f).coerceAtMost(244.dp)
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (state.exchanges.isEmpty()) {
                        Column(Modifier.align(Alignment.Center).padding(horizontal = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            NexusBrandMark(Modifier.size(46.dp))
                            Text(stringResource(R.string.ui_welcome),
                                fontSize = 23.sp, maxLines = 1, softWrap = false,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onBackground)
                        }
                    } else {
                        LazyColumn(state = list, modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            state.exchanges.forEachIndexed { index, message ->
                                if (message.prompt.isNotBlank()) {
                                    item(key = "user-$index") {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                            Surface(modifier = Modifier.widthIn(max = 335.dp),
                                                shape = RoundedCornerShape(17.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                border = BorderStroke(.7.dp,
                                                    MaterialTheme.colorScheme.outline.copy(alpha = .35f))) {
                                                SelectionContainer {
                                                    Text(message.prompt,
                                                        Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                                                        style = MaterialTheme.typography.bodyLarge)
                                                }
                                            }
                                        }
                                    }
                                }
                                if (message.answer.isNotBlank()) {
                                    item(key = "answer-$index") {
                                        ChatAnswer(message.answer, index == state.exchanges.lastIndex && state.complete,
                                            onCopy = {
                                                val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                manager.setPrimaryClip(ClipData.newPlainText("Nexus AI", app.svyazka.mobile.PythonInputs.copySource(message.answer)))
                                                Toast.makeText(context, R.string.status_copied, Toast.LENGTH_SHORT).show()
                                            }, onSave = if (index == state.exchanges.lastIndex) saveResult else null)
                                    }
                                }
                            }
                            if (state.active || (state.hasRun && !state.complete)) {
                                item(key = "progress") {
                                    Column(Modifier.fillMaxWidth().padding(horizontal = 3.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (state.active) CircularProgressIndicator(Modifier.size(17.dp), strokeWidth = 2.dp)
                                            Spacer(Modifier.width(9.dp))
                                            Text(stringResource(R.string.result_progress, state.finished, state.total),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            if (state.active) {
                                                Spacer(Modifier.weight(1f))
                                                IconButton(onClick = { ui.activity.nexusStop() }) {
                                                    Icon(Icons.Outlined.StopCircle, stringResource(R.string.action_stop))
                                                }
                                            }
                                        }
                                        state.stages.filter { it.done || it.current }.forEach { stage ->
                                            Text("${stage.index + 1}. " + roleTitle(stage.role, stage.index) + " · " + stage.modelLabel,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        if (state.active && ui.streaming.isNotBlank()) {
                                            SelectionContainer {
                                                Text(ui.streaming.takeLast(1200),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                        if (!state.active) {
                                            TextButton(onClick = { ui.activity.nexusResume() }) {
                                                Text(stringResource(R.string.action_resume))
                                            }
                                            TextButton(onClick = { changeModel = true }) { Text(stringResource(R.string.select_model)) }
                                            if (ui.activity.nexusPartsAvailable()) TextButton(onClick = { ui.activity.nexusResumeInParts() }) {
                                                Text(stringResource(R.string.resume_parts))
                                            }
                                            if (!currentStage?.answer.isNullOrBlank()) TextButton(onClick = saveDraft) {
                                                Text(stringResource(R.string.save_partial))
                                            }
                                        }
                                    }
                                }
                            }
                            if (!state.active && ui.activity.nexusHasSourcePlan()) {
                                item(key = "source-plan") {
                                    TextButton(onClick = { ui.activity.nexusOpenSourcePlan() }) { Text(stringResource(R.string.source_plan)) }
                                }
                            }
                            if (state.note.isNotBlank()) {
                                item(key = "notice") {
                                    Text(state.note, color = MaterialTheme.colorScheme.error,
                                        style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            if (state.complete) {
                                item(key = "actions") {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                        if (state.resultHasPython) TextButton(onClick = {
                                            ui.activity.nexusRunPython(ui.activity.nexusFinalStep())
                                        }) { Text(stringResource(R.string.action_python)) }
                                        if (state.versionCount > 0) TextButton(onClick = { ui.requestVersions() }) {
                                            Text(stringResource(R.string.action_versions))
                                        }
                                        if (state.visualAvailable) TextButton(onClick = { ui.openVisual() }) {
                                            Text(stringResource(R.string.action_show_result))
                                        }
                                    }
                                }
                                item(key = "verification-summary") {
                                    val check = ui.verification
                                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                                        verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        val webStatus = ui.activity.nexusWebStatus()
                                        if (webStatus.isNotEmpty()) Text(webStatus, style = MaterialTheme.typography.bodySmall)
                                        if (webStatus.isEmpty() || state.resultHasPython) Text(verificationOutcomeLabel(check, state.resultHasPython),
                                            color = if (check.status == PythonVerification.Status.STOPPED ||
                                                check.status == PythonVerification.Status.ERROR)
                                                MaterialTheme.colorScheme.error
                                            else MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.bodySmall)
                                        if (check.status != PythonVerification.Status.NONE) {
                                            Text(stringResource(R.string.ui_verify_details),
                                                modifier = Modifier.clickable {
                                                    ui.workspaceTab = NexusComposeUi.WorkspaceTab.LOGS
                                                    ui.openRight()
                                                }.padding(vertical = 5.dp),
                                                color = MaterialTheme.colorScheme.primary,
                                                style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if ((!state.hasRun || state.complete) && (!attachments.loaded || attachments.busy ||
                        attachments.items.isNotEmpty() || attachments.notice != null)) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { AttachmentSummary(attachments) }
                            if (attachments.items.isNotEmpty()) {
                                TextButton(onClick = { attachmentsExpanded = !attachmentsExpanded },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)) {
                                    Text(stringResource(if (attachmentsExpanded) R.string.attachment_collapse
                                        else R.string.attachment_expand), maxLines = 1)
                                }
                            }
                        }
                        if (attachmentsExpanded) {
                            Column(Modifier.fillMaxWidth().heightIn(max = attachmentListLimit)
                                .verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                attachments.items.forEach { item ->
                                    key(item.id) { AttachmentCard(ui, item, compact = true) }
                                }
                            }
                        }
                    }
                }
            }
        }
        val canSend = !state.active && !state.clearing && ui.chatText.isNotBlank() &&
            (!state.hasRun || state.complete) && attachments.loaded && !attachments.busy &&
            attachments.items.none { it.status == AttachmentStore.Status.ADDING ||
                it.status == AttachmentStore.Status.PROCESSING }
        Surface(modifier = Modifier.fillMaxWidth().navigationBarsPadding()
            .padding(horizontal = 8.dp, vertical = 6.dp),
            color = Color.White.copy(alpha = .04f),
            shape = RoundedCornerShape(21.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .55f))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 3.dp),
                verticalAlignment = Alignment.Bottom) {
                IconButton(onClick = {
                    if (!state.active && !state.clearing && (!state.hasRun || state.complete)) attachAction()
                    else Toast.makeText(context, R.string.attach_after_reply, Toast.LENGTH_SHORT).show()
                },
                    modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Outlined.Add, stringResource(R.string.action_attach_file))
                }
                TextField(value = ui.chatText, onValueChange = { if (it.length <= 16000) ui.chatTextChanged(it) },
                    modifier = Modifier.weight(1f),
                    enabled = !state.active && !state.clearing && (!state.hasRun || state.complete),
                    placeholder = { Text(stringResource(R.string.ui_message_hint), maxLines = 1) },
                    textStyle = MaterialTheme.typography.bodyMedium,
                    minLines = 1, maxLines = 5,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent))
                Box(Modifier.size(43.dp).clip(RoundedCornerShape(22.dp))
                    .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(NexusCyan, NexusBlue, NexusPurple)))
                    .clickable(enabled = canSend, onClick = { ui.submitChat() }),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Send, stringResource(R.string.action_send), tint = Color.White)
                }
            }
        }
    }
}

@Composable
internal fun ModeChip(selected: Boolean, label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    if (selected) {
        Box(Modifier.clip(shape)
            .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(NexusBlue, NexusCyan)), shape)
            .clickable(onClick = onClick)) {
            Text(label, Modifier.padding(horizontal = 9.dp, vertical = 9.dp),
                color = Color.White, maxLines = 1, softWrap = false,
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp))
        }
    } else {
        Surface(onClick = onClick, shape = shape, color = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant) {
            Text(label, Modifier.padding(horizontal = 9.dp, vertical = 9.dp),
                maxLines = 1, softWrap = false, style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.sp))
        }
    }
}

@Composable
private fun ChatAnswer(answer: String, latest: Boolean, onCopy: () -> Unit, onSave: (() -> Unit)?) {
    var expanded by remember(answer) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NexusBrandMark(Modifier.size(24.dp))
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.labelLarge)
        }
        NexusMarkdown(if (expanded || answer.length <= 9000) answer else answer.take(9000))
        if (!expanded && answer.length > 9000) {
            TextButton(onClick = { expanded = true }) { Text(stringResource(R.string.action_show_result)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = onCopy) {
                Icon(Icons.Outlined.ContentCopy, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.action_copy))
            }
            if (latest && onSave != null) TextButton(onClick = onSave) {
                Text(stringResource(R.string.action_save_file))
            }
        }
    }
}
