package app.svyazka.mobile;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public final class FeatureChecks {
    private static int passed;

    private static void check(boolean pass, String name) {
        if (!pass) throw new AssertionError(name);
        passed++;
    }

    private static ModelClient.Reply stop(String text) {
        return new ModelClient.Reply(text, ModelClient.Finish.STOP, "");
    }

    private static ModelClient.Reply event(String events) {
        return ModelClient.parseRouterStream(new BufferedReader(new StringReader(events)));
    }

    public static void main(String[] args) throws Exception {
        check(ModelClient.REQUEST_TIMEOUT_MS == 60_000, "one request has a 60 second timeout");
        Workflow.Run run = new Workflow.Run("Python message manager", Workflow.defaultStages());
        Workflow.Run started = run.receive(stop("Solution"));
        Workflow.Run reviewed = started.receive(stop("Checked.\n[[REVIEW: PASS]]"));
        check(reviewed.complete() && reviewed.revisionSkipped() && reviewed.finalIndex() == 0,
                "PASS preserves the original solution");
        check(reviewed.answers.size() == 2 && reviewed.displayAnswer(0).equals("Solution"), "no third request");
        Workflow.Run finalized = started.receive(stop("- Fix the actual bug.\n[[REVIEW: FIX]]"))
                .receive(stop("Corrected final answer"));
        check(finalized.complete() && finalized.answers.size() == 3 && finalized.finalIndex() == 2,
                "FIX still completes all three stages");

        Workflow.RepairInput issue = new Workflow.RepairInput(0,
                "raise ValueError('bad')\n", "send\n", "ValueError: bad\n");
        Workflow.Run stored = finalized.addRepair(issue);
        check(stored.stages.size() == 4 && stored.nextIndex() == 3
                && stored.nextStep() == Workflow.Step.REPAIR && !stored.complete(), "repair appended as step 4");
        check(stored.nextStage().model == finalized.stages.get(1).model, "send to reviewer by default");
        JSONObject input = new JSONObject(stored.prompt()).getJSONObject("inputs").getJSONObject("sandbox_result");
        check(input.getString("python_code").equals(issue.code)
                && input.getString("console_error").equals(issue.diagnostic) && input.getString("stdin").equals(issue.stdin),
                "exact test input and failure");
        check(stored.missingInput().isEmpty(), "repair can begin");
        Workflow.Run repaired = stored.receive(stop("Full corrected code"));
        check(repaired.complete() && repaired.finalIndex() == 3
                && repaired.displayAnswer(3).equals("Full corrected code") && repaired.hasAnswer(2),
                "repair follows completed third stage");
        Workflow.Run restored = Workflow.Run.fromJson(repaired.toJson());
        check(restored.displayAnswer(3).equals(repaired.displayAnswer(3))
                && restored.repairs.get(0).sourceIndex == 0 && !restored.revisionSkipped()
                && restored.answers.size() == 4, "new run format restores all four steps");
        Workflow.Run repairedAgain = restored.addRepair(new Workflow.RepairInput(3, "print(1)", "", "oops"))
                .receive(stop("Fixed again"));
        JSONObject secondRepair = repairedAgain.toJson();
        check(repairedAgain.complete() && repairedAgain.finalIndex() == 4
                && secondRepair.getJSONArray("answers").getJSONObject(4).getInt("step") == 5
                && secondRepair.getJSONArray("repairs").getJSONObject(1).getInt("source_step") == 4,
                "follow-up repair references earlier repair card");

        Workflow.Run queued = started.addRepair(issue);
        check(queued.nextStep() == Workflow.Step.REVIEW && queued.stages.size() == 4,
                "repair never skips a paused original review");
        Workflow.Run queueRestored = Workflow.Run.fromJson(queued.toJson());
        Workflow.Run afterFix = queueRestored.receive(stop("- fix a bug\n[[REVIEW: FIX]]"))
                .receive(stop("Revision")).receive(stop("Fixed after execution"));
        check(afterFix.complete() && afterFix.displayAnswer(2).equals("Revision")
                && afterFix.displayAnswer(3).equals("Fixed after execution"), "revision and queued repair both run");

        JSONObject previousVersion = finalized.toJson().put("version", 2);
        previousVersion.remove("repairs");
        Workflow.Run old = Workflow.Run.fromJson(previousVersion);
        check(old.finalIndex() == 2 && old.complete() && old.answers.size() == 3,
                "old format can restore completed third stage");
        JSONObject legacySkipped = reviewed.toJson().put("version", 2);
        legacySkipped.remove("repairs");
        Workflow.Run historical = Workflow.Run.fromJson(legacySkipped);
        check(historical.revisionSkipped() && historical.complete() && historical.finalIndex() == 0,
                "previously skipped PASS remains readable as historical result");
        JSONObject emptyLegacy = run.toJson().put("version", 2);
        emptyLegacy.remove("repairs");
        check(Workflow.Run.fromJson(emptyLegacy).nextIndex() == 0, "0.2.1 unfinished run retained");
        JSONObject savedTeam = ModelCatalog.GROQ_20B.id.equals("openai/gpt-oss-20b")
                ? new Workflow.Stage("Роль", "Проверить", ModelCatalog.GROQ_20B).toJson() : new JSONObject();
        check(Workflow.Stage.fromJson(savedTeam).model.provider == Workflow.Provider.GROQ, "Groq model survives restore");

        ModelCatalog catalog = ModelCatalog.starter();
        List<ModelCatalog.Model> pool = ModelPool.forStep(catalog, run.nextStep(), ModelCatalog.GEMMA,
                true, true, true, false);
        check(pool.get(0) == ModelCatalog.GEMMA && pool.get(1) == ModelCatalog.GROQ_120B,
                "selected first, then independent provider");
        check(pool.size() == 4 && pool.stream().map(model -> model.id).distinct().count() == pool.size(),
                "maximum four distinct attempts");
        List<ModelCatalog.Model> withoutGroq = ModelPool.forStep(catalog, run.nextStep(), ModelCatalog.GEMMA,
                true, true, false, false);
        check(withoutGroq.stream().allMatch(model -> model.provider == Workflow.Provider.OPENROUTER
                && ModelCatalog.isFreeId(model.id)), "Groq only with reserve explicitly enabled");
        check(ModelPool.forStep(catalog, run.nextStep(), ModelCatalog.LING,
                false, true, false, false).isEmpty(), "no requests to unconfigured providers");
        check(ModelPool.forStep(catalog, run.nextStep(), ModelCatalog.GROQ_20B,
                false, true, false, false).get(0) == ModelCatalog.GROQ_20B, "explicit Groq choice");
        ModelClient.Reply limited = event("data: {\"choices\":[{\"delta\":{\"content\":\"Partial \"}}]}\n\n"
                + "data: {\"error\":{\"code\":429,\"message\":\"Provider limit\"}}\n\n");
        check(ModelPool.shouldTryNext(limited) && limited.text.equals("Partial "), "stream 429 preserves draft");
        check(ModelPool.shouldTryNext(event("data: {\"error\":{\"code\":503}}\n\n")), "503 used for fallback");
        for (int status : List.of(0, 408, 504)) {
            check(ModelPool.shouldTryNext(ModelClient.Reply.error("Partial ", "Network error", status)),
                    "network failure " + status + " starts reserve");
        }
        check(ModelPool.shouldTryNext(event("data: {\"error\":{\"type\":\"rate_limit_error\"}}\n\n")),
                "Groq stream rate-limit type used");
        check(!ModelPool.shouldTryNext(ModelClient.Reply.error("", "Unauthenticated", 401))
                && !ModelPool.shouldTryNext(new ModelClient.Reply("", ModelClient.Finish.LENGTH, "")),
                "other failures and output limits stop");
        ModelClient.Reply filtered = event("data: {\"choices\":[{\"finish_reason\":\"content_filter\"}]}\n\n");
        check(filtered.finish == ModelClient.Finish.ERROR && !ModelPool.shouldTryNext(filtered),
                "explicit content filter does not start a reserve");
        Workflow.Run continuation = run.withModel(pool.get(0)).receive(limited).withModel(pool.get(1));
        Workflow.Run timedOut = run.withModel(pool.get(0))
                .receive(ModelClient.Reply.error("Partial ", "Timeout", 408)).withModel(pool.get(1));
        check(timedOut.draft.text.equals("Partial ")
                && timedOut.draftMode == Workflow.DraftMode.CONTINUE
                && timedOut.nextStep() == Workflow.Step.SOLUTION,
                "timeout preserves draft for next provider on same step");
        JSONObject groq = ModelClient.groqBody(continuation, pool.get(1));
        JSONArray messages = groq.getJSONArray("messages");
        check(groq.getString("model").equals("openai/gpt-oss-120b") && groq.getBoolean("stream")
                && !groq.has("provider") && groq.getInt("max_completion_tokens") <= 8000
                && groq.getString("reasoning_effort").equals("medium")
                && groq.getString("reasoning_format").equals("hidden"),
                "Groq wire request and bounded output reservation");
        check(messages.getJSONObject(2).getString("content").equals("Partial "),
                "next provider receives existing draft, not a restart");
        Workflow.Run completed = continuation.receive(stop("answer"));
        check(completed.answerAt(0).models.equals(List.of(ModelCatalog.GEMMA.id, ModelCatalog.GROQ_120B.id))
                && completed.displayAnswer(0).equals("Partial answer"), "record the authors of both pieces");

        String block = "  ```python\r\n  def f():\r\n      return 42\r\n  ```\r\n";
        check(SandboxClient.pythonBlocks(block).equals(List.of("def f():\r\n    return 42\r\n")),
                "fenced Python preserved including indentation and CRLF");
        check(SandboxClient.pythonBlocks("```text\n```python\nprint(1)\n```").isEmpty(),
                "ignore nested Python text in a different block");
        check(SandboxClient.pythonBlocks("```python\nprint(1)").isEmpty(), "unclosed code not run");
        check(SandboxClient.pythonBlocks("```python\nprint(1)\n```\n```python\nprint(2)\n```").size() == 2,
                "multiple blocks available separately");
        JSONObject piston = SandboxClient.pistonBody(issue.code, issue.stdin);
        check(piston.getString("language").equals("python") && piston.getString("version").equals("3.10.0")
                && piston.getJSONArray("files").getJSONObject(0).getString("content").equals(issue.code)
                && piston.getString("stdin").equals("send\n"), "Piston request Python 3.10.0");
        SandboxClient.Result success = SandboxClient.parsePiston(new JSONObject(
                "{\"version\":\"3.10.0\",\"run\":{\"stdout\":\"42\\n\",\"stderr\":\"\",\"code\":0,\"signal\":null}}"));
        check(success.stdout.equals("42\n") && success.diagnostic().isEmpty(), "success has no repair button");
        SandboxClient.Result failed = SandboxClient.parsePiston(new JSONObject(
                "{\"run\":{\"stdout\":\"before\\n\",\"stderr\":\"ValueError\",\"code\":1}}"));
        check(failed.stderr.equals("ValueError") && failed.diagnostic().contains("ValueError"),
                "Piston stderr and exit code returned");
        check(!new SandboxClient.Result("", "Warning\n", "Python", 0, "").diagnostic().isEmpty(),
                "nonempty stderr exposed even when exit code is 0");

        System.out.println(passed + " regression checks passed");
    }
}
