package app.svyazka.mobile;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.test.core.app.ApplicationProvider;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35)
public class ChatRunJournalTest {
    @Test public void incrementalSnapshotsSurviveDatabaseReopenAndDoNotDuplicateChunks() {
        Context context = ApplicationProvider.getApplicationContext();
        long chat;
        String run = ChatRunJournal.newId();
        String attempt = ChatRunJournal.newId();
        try (TaskRepository repo = new TaskRepository(context)) {
            chat = repo.create("Проверка потока");
            ChatRunJournal journal = new ChatRunJournal(repo);
            assertTrue(journal.event(chat, run, null, -1, "RUN_STARTED", ""));
            assertTrue(journal.event(chat, run, attempt, 0, "MODEL_ATTEMPT_STARTED", "gpt-test"));
            assertTrue(journal.checkpoint(chat, run, attempt, 0, "Начало 🐱"));
            assertTrue(journal.checkpoint(chat, run, attempt, 0, "Начало 🐱"));
            assertTrue(journal.checkpoint(chat, run, attempt, 0, "Начало 🐱 и конец"));
            assertEquals(2, rows(repo.getReadableDatabase(), "chat_stream_chunks"));
            assertEquals(2, rows(repo.getReadableDatabase(), "chat_checkpoints"));
            assertEquals("Начало 🐱 и конец", journal.latestSnapshot(chat, attempt).text);
        }
        try (TaskRepository reopened = new TaskRepository(context)) {
            ChatRunJournal journal = new ChatRunJournal(reopened);
            assertEquals(run, journal.latestRunId(chat));
            assertEquals("Начало 🐱 и конец", journal.latestSnapshot(chat, attempt).text);
            assertNotNull(reopened.load(chat));
        }
    }

    @Test public void refusesRewrittenStreamAndCrossChatAttempts() {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository repo = new TaskRepository(context)) {
            long owner = repo.create("Владелец");
            long outsider = repo.create("Чужой чат");
            ChatRunJournal journal = new ChatRunJournal(repo);
            String run = ChatRunJournal.newId();
            String attempt = ChatRunJournal.newId();
            assertTrue(journal.event(owner, run, attempt, 1, "MODEL_ATTEMPT_STARTED", "test"));
            assertTrue(journal.checkpoint(owner, run, attempt, 1, "ABC"));
            assertFalse(journal.checkpoint(owner, run, attempt, 1, "AXCDEF"));
            assertFalse(journal.checkpoint(outsider, run, attempt, 1, "ABCDEF"));
            assertEquals("ABC", journal.latestSnapshot(owner, attempt).text);
            assertNull(journal.latestSnapshot(outsider, attempt));
        }
    }

    @Test public void corruptedChunkIsNotRestoredAsAValidDraft() {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository repo = new TaskRepository(context)) {
            long chat = repo.create("Corrupt case");
            ChatRunJournal journal = new ChatRunJournal(repo);
            String run = ChatRunJournal.newId();
            String attempt = ChatRunJournal.newId();
            assertTrue(journal.event(chat, run, attempt, 0, "MODEL_ATTEMPT_STARTED", ""));
            assertTrue(journal.checkpoint(chat, run, attempt, 0, "correct"));
            repo.getWritableDatabase().execSQL("UPDATE chat_stream_chunks SET text='broken' WHERE task_id=?",
                    new Object[]{chat});
            assertNull(journal.latestSnapshot(chat, attempt));
            assertFalse(journal.checkpoint(chat, run, attempt, 0, "correct extra"));
        }
    }

    @Test public void deletingChatCascadesToAllJournalTables() {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository repo = new TaskRepository(context)) {
            long chat = repo.create("Delete case");
            ChatRunJournal journal = new ChatRunJournal(repo);
            String run = ChatRunJournal.newId();
            String attempt = ChatRunJournal.newId();
            assertTrue(journal.event(chat, run, attempt, 0, "MODEL_ATTEMPT_STARTED", ""));
            assertTrue(journal.checkpoint(chat, run, attempt, 0, "draft"));
            assertTrue(repo.delete(chat));
            assertEquals(0, rows(repo.getReadableDatabase(), "chat_run_events"));
            assertEquals(0, rows(repo.getReadableDatabase(), "chat_stream_chunks"));
            assertEquals(0, rows(repo.getReadableDatabase(), "chat_checkpoints"));
            assertNull(journal.latestSnapshot(chat, attempt));
            assertFalse(journal.checkpoint(chat, run, attempt, 0, "late reply"));
        }
    }

    @Test public void upgradingVersionThreePreservesChatAndHistory() {
        Context context = ApplicationProvider.getApplicationContext();
        try (SQLiteDatabase db = context.openOrCreateDatabase("svyazka_tasks.db", 0, null)) {
            db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY, title TEXT NOT NULL, "
                    + "task TEXT NOT NULL DEFAULT '', run_json TEXT NOT NULL DEFAULT '', "
                    + "attempt_log TEXT NOT NULL DEFAULT '', results_visible INTEGER NOT NULL DEFAULT 0, "
                    + "created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, "
                    + "custom_title TEXT, pinned INTEGER NOT NULL DEFAULT 0, "
                    + "saved_in_history INTEGER NOT NULL DEFAULT 0)");
            db.execSQL("CREATE TABLE versions(id INTEGER PRIMARY KEY, task_id INTEGER "
                    + "REFERENCES tasks(id) ON DELETE CASCADE, version_no INTEGER, run_json TEXT, created_at INTEGER)");
            db.execSQL("CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT)");
            db.execSQL("INSERT INTO tasks(id,title,task,run_json,attempt_log,created_at,updated_at,saved_in_history) "
                    + "VALUES(7,'Старый чат','Старое сообщение','{\"old\":1}','OLDLOG',10,20,1)");
            db.execSQL("INSERT INTO versions VALUES(3,7,1,'{\"version\":1}',10)");
            db.setVersion(3);
        }
        try (TaskRepository repo = new TaskRepository(context)) {
            assertEquals(4, repo.getReadableDatabase().getVersion());
            assertEquals("{\"old\":1}", repo.load(7).runJson);
            assertEquals("OLDLOG", repo.load(7).attemptLog);
            assertEquals(1, repo.versions(7).size());
            assertTrue(repo.hasExplicitlySavedChat(7));
            assertEquals(0, rows(repo.getReadableDatabase(), "chat_run_events"));
            assertTrue(new ChatRunJournal(repo).event(7, ChatRunJournal.newId(), null,
                    -1, "RUN_STARTED", ""));
        }
    }

    @Test public void offersOnlyLastUnfinishedAttemptAndNeverCompletedWork() {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository repo = new TaskRepository(context)) {
            long chat = repo.create("Recovery");
            ChatRunJournal journal = new ChatRunJournal(repo);
            String run = ChatRunJournal.newId();
            String first = ChatRunJournal.newId();
            String second = ChatRunJournal.newId();
            assertTrue(journal.event(chat, run, null, -1, "RUN_STARTED", ""));
            assertTrue(journal.event(chat, run, first, 0, "MODEL_ATTEMPT_STARTED", "model"));
            assertTrue(journal.checkpoint(chat, run, first, 0, "earlier step"));
            assertEquals("earlier step", journal.pendingSnapshot(chat, run).text);
            assertTrue(journal.event(chat, run, first, 0, "MODEL_ATTEMPT_COMPLETED", ""));
            assertNull(journal.pendingSnapshot(chat, run));
            assertTrue(journal.event(chat, run, second, 1, "MODEL_ATTEMPT_STARTED", "model"));
            assertTrue(journal.checkpoint(chat, run, second, 1, "unfinished"));
            assertEquals("unfinished", journal.pendingSnapshot(chat, run).text);
            assertTrue(journal.event(chat, run, second, 1, "MODEL_ATTEMPT_FAILED", ""));
            assertNull(journal.pendingSnapshot(chat, run));
        }
    }

    @Test public void corruptedOrInterruptedOrRestoredRunIsNotOfferedAgain() {
        Context context = ApplicationProvider.getApplicationContext();
        try (TaskRepository repo = new TaskRepository(context)) {
            long chat = repo.create("Recovery safety");
            ChatRunJournal journal = new ChatRunJournal(repo);
            String run = ChatRunJournal.newId();
            String attempt = ChatRunJournal.newId();
            assertTrue(journal.event(chat, run, null, -1, "RUN_STARTED", ""));
            assertTrue(journal.event(chat, run, attempt, 0, "MODEL_ATTEMPT_STARTED", "model"));
            assertTrue(journal.checkpoint(chat, run, attempt, 0, "saved"));
            assertEquals("saved", journal.pendingSnapshot(chat, run).text);
            repo.getWritableDatabase().execSQL("UPDATE chat_stream_chunks SET text='changed' WHERE task_id=?",
                    new Object[]{chat});
            assertNull(journal.pendingSnapshot(chat, run));
            repo.getWritableDatabase().execSQL("UPDATE chat_stream_chunks SET text='saved' WHERE task_id=?",
                    new Object[]{chat});
            assertEquals("saved", journal.pendingSnapshot(chat, run).text);
            assertTrue(journal.event(chat, run, attempt, 0, "RUN_RESTORED", ""));
            assertNull(journal.pendingSnapshot(chat, run));
            assertNull(journal.pendingSnapshot(chat + 1000, run));
        }
    }

    private static int rows(SQLiteDatabase db, String table) {
        try (Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + table, null)) {
            assertTrue(cursor.moveToFirst());
            return cursor.getInt(0);
        }
    }
}
