package app.svyazka.fixture;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.os.Bundle;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/** Seed a new test install and verify real Android SQLite and Keystore across two APKs. */
public final class UpgradeProbe extends Instrumentation {
    private static final String MARKER = "nexus-android-upgrade-fixture";
    private String step;

    @Override public void onCreate(Bundle args) {
        super.onCreate(args);
        step = args.getString("step", "");
        start();
    }

    private Object construct(String name, Class<?> type, Object arg) throws Exception {
        Class<?> cls = getTargetContext().getClassLoader().loadClass("app.svyazka.mobile." + name);
        Constructor<?> constructor = cls.getDeclaredConstructor(type);
        constructor.setAccessible(true);
        return constructor.newInstance(arg);
    }

    private Object call(Object target, String method, Class<?>[] types, Object... args) throws Exception {
        Method m = target.getClass().getDeclaredMethod(method, types);
        m.setAccessible(true);
        return m.invoke(target, args);
    }

    private static void check(boolean success, String condition) {
        if (!success) throw new IllegalStateException(condition);
    }

    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            check(Build.FINGERPRINT.contains("generic") || Build.MODEL.contains("SDK")
                    || Build.HARDWARE.startsWith("ranchu"), "Use a disposable emulator");
            if (step.startsWith("project_") || step.startsWith("runtime_")) {
                if (step.startsWith("project_")) ProjectArchiveProbe.run(this, step);
                else PythonSecurityProbe.runtime(this, step);
                result.putString("stream", "NEXUS_PYTHON_HISTORY_" + step.toUpperCase(java.util.Locale.ROOT));
                finish(Activity.RESULT_OK, result);
                return;
            }
            if (step.equals("model_recovery")) {
                ModelRecoveryProbe.run(getTargetContext().getClassLoader());
                result.putString("stream", "NEXUS_PYTHON_HISTORY_MODEL_RECOVERY");
                finish(Activity.RESULT_OK, result);
                return;
            }
            if (step.equals("python_linked_candidate")) {
                LinkedCandidateProbe.run(this);
                result.putString("stream", "NEXUS_PYTHON_HISTORY_PYTHON_LINKED_CANDIDATE");
                finish(Activity.RESULT_OK, result);
                return;
            }
            if (step.equals("python_security")) {
                PythonSecurityProbe.run(this);
                result.putString("stream", "NEXUS_PYTHON_HISTORY_PYTHON_SECURITY");
                finish(Activity.RESULT_OK, result);
                return;
            }
            if (step.startsWith("python_")) {
                PythonHistoryProbe.run(this, step);
                result.putString("stream", "NEXUS_PYTHON_HISTORY_" + step.toUpperCase(java.util.Locale.ROOT));
                finish(Activity.RESULT_OK, result);
                return;
            }
            if (step.equals("web")) {
                WebPreviewCheck.run(this);
                result.putString("stream", "NEXUS_WEBVIEW_TESTED");
                finish(Activity.RESULT_OK, result);
                return;
            }
            Context app = getTargetContext();
            SharedPreferences prefs = app.getSharedPreferences("credentials", 0);
            Object vault = construct("KeyVault", SharedPreferences.class, prefs);
            Class<?> provider = app.getClassLoader().loadClass("app.svyazka.mobile.Workflow$Provider");
            java.lang.reflect.Field enumField = provider.getField("OPENROUTER");
            enumField.setAccessible(true);
            Object router = enumField.get(null);
            String version;
            try (java.util.Scanner input = new java.util.Scanner(getContext().getAssets().open("upgrade-run.json"), "UTF-8")) {
                version = input.useDelimiter("\\A").next();
            }
            try (SQLiteOpenHelper helper = (SQLiteOpenHelper) construct("TaskRepository", Context.class, app)) {
                SQLiteDatabase db = helper.getWritableDatabase();
                if (step.equals("seed")) {
                    check((db.getVersion() >= 1 && db.getVersion() <= 4) && prefs.getAll().isEmpty(), "Expected a disposable empty installation");
                    call(vault, "save", new Class<?>[]{String.class, String.class, String.class, String.class},
                         MARKER, "", "", "");
                    long id = (Long) call(helper, "create", new Class<?>[]{String.class}, MARKER);
                    call(helper, "select", new Class<?>[]{long.class}, id);
                    check(Boolean.TRUE.equals(call(helper, "preserveVersion", new Class<?>[]{long.class, String.class},
                            id, version)), "Version write failed");
                    result.putString("stream", "NEXUS_PROBE_SEEDED");
                } else if (step.equals("verify")) {
                    check(db.getVersion() == 4, "Incorrect migrated schema");
                    try (Cursor table = db.rawQuery(
                            "SELECT name FROM sqlite_master WHERE type='table' AND name='chat_run_events'", null)) {
                        check(table.moveToFirst(), "Missing event history table");
                    }
                    check(MARKER.equals(call(vault, "read", new Class<?>[]{provider}, router)), "Encrypted fixture mismatch");
                    try (Cursor row = db.rawQuery("SELECT tasks.task,versions.run_json,tasks.pinned FROM tasks JOIN versions "
                            + "ON versions.task_id=tasks.id WHERE tasks.id=(SELECT value FROM metadata WHERE key='active_task_id')",null)) {
                        check(row.moveToFirst() && MARKER.equals(row.getString(0)) &&
                                version.equals(row.getString(1)) && row.getInt(2)==0, "History mismatch");
                    }
                    result.putString("stream", "NEXUS_PROBE_RESTORED");
                } else throw new IllegalArgumentException("Select seed or verify");
            }
            finish(Activity.RESULT_OK, result);
        } catch (Throwable problem) {
            result.putString("stream", "Upgrade fixture failed: " + android.util.Log.getStackTraceString(problem));
            finish(Activity.RESULT_CANCELED, result);
        }
    }
}
