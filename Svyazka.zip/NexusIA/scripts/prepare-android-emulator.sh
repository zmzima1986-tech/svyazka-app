#!/usr/bin/env bash
# Disposable GitHub-hosted runner only. Never change device/app permissions.
set -euo pipefail
if [[ -c /dev/kvm ]]; then
    ls -l /dev/kvm
    if [[ ! -r /dev/kvm || ! -w /dev/kvm ]]; then
        if ! sudo chmod a+rw /dev/kvm; then
            echo '::warning::Cannot change KVM access; emulator runner will select software acceleration.'
        fi
    fi
fi
if [[ -c /dev/kvm && -r /dev/kvm && -w /dev/kvm ]]; then
    echo 'KVM accessible; emulator runner will select acceleration.'
else
    echo '::warning::KVM unavailable; attempting real Android with software emulation (not a test PASS).'
fi
