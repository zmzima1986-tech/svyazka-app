"""Source-level regression contracts for actual project content in AI requests.

These contracts do not replace an Android emulator round-trip test.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'app/src/main/java/app/svyazka/mobile'


class ProjectChatConnectionTests(unittest.TestCase):
    def test_link_is_read_back_before_success(self):
        source = (BASE / 'MainActivity.java').read_text()
        action = source.split('public void nexusAttachArtifactToChat() {', 1)[1].split(
            '/** Start a separate chat for this project', 1)[0]
        self.assertIn('artifactRepository.attachChat(activeTaskId, activeArtifactId)', action)
        self.assertIn('artifactRepository.forChat(activeTaskId) != activeArtifactId', action)
        self.assertIn('pythonProjects().snapshotForChat(activeArtifactId)', action)
        self.assertIn('nexusUi.refreshChatProjectLink()', action)
        self.assertNotIn('nexusRender(', action)
        self.assertNotIn('nexusRender(NexusComposeUi.Page.TASK)', action)

    def test_linked_files_enter_ai_request_only_after_attach(self):
        source = (BASE / 'MainActivity.java').read_text()
        prepare = source.split('private AttachmentStore.Prepared prepareMessage(', 1)[1].split(
            'private void startRun()', 1)[0]
        self.assertIn('artifactRepository.forChat(activeTaskId)', prepare)
        self.assertIn('if (linked > 0)', prepare)
        self.assertIn('ChatProjectContext.append(materials.getTask()', prepare)
        self.assertIn('pythonProjects().snapshotForChat(linked)', prepare)
        self.assertIn('new AttachmentStore.Prepared(prepared, materials.getRefs())', prepare)
        self.assertIn('InputMaterial.MAX_REQUEST_TEXT_BYTES', prepare)

    def test_followups_replace_old_snapshot_and_detach_prevents_new_snapshot(self):
        activity = (BASE / 'MainActivity.java').read_text()
        self.assertIn('ChatProjectContext.withoutInlineProject(TaskHistory.forRepair(previous.task))', activity)
        self.assertIn('ChatProjectContext.withoutInlineProject(previous.userTestTask())', activity)
        self.assertIn('artifactRepository.unlinkChat(activeTaskId)', activity)
        context = (BASE / 'ChatProjectContext.java').read_text()
        self.assertIn('static String withoutInlineProject(String task)', context)

    def test_text_only_secret_exclusions_and_bounded_context(self):
        context = (BASE / 'ChatProjectContext.java').read_text()
        self.assertIn('MAX_CONTEXT_BYTES = 40_000', context)
        self.assertIn('MAX_SINGLE_FILE_BYTES = 12_000', context)
        self.assertIn('sensitive filename', context)
        self.assertIn('non-text or unsupported extension', context)
        self.assertIn('invalid UTF-8', context)
        self.assertIn('if (utf8(combined) > requestByteLimit)', context)


if __name__ == '__main__':
    unittest.main()
