package app.svyazka.mobile;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebMessage;
import android.webkit.WebMessagePort;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import org.json.JSONException;
import org.json.JSONObject;

final class LocalSandbox {
    private static final String HOST = "svyazka-python.invalid";
    private static final String ORIGIN = "https://" + HOST;
    private static final String PAGE = ORIGIN + "/index.html";
    private static final String CSP = "default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; "
            + "connect-src 'self'; worker-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Consumer<SandboxClient.Result> result;
    private final Consumer<String> problem;
    private final Runnable deadline = () -> fail("Запуск Python на телефоне не завершился за 40 секунд.");
    private WebView view;
    private WebMessagePort port;

    LocalSandbox(Consumer<SandboxClient.Result> result, Consumer<String> problem) {
        this.result = result;
        this.problem = problem;
    }

    void execute(Context context, String code, String stdin) {
        String message;
        try {
            message = new JSONObject().put("code", code).put("stdin", stdin).toString();
            view = new WebView(context);
        } catch (JSONException | RuntimeException e) {
            fail("Не удалось запустить Python. Проверь Android System WebView.");
            return;
        }

        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setDomStorageEnabled(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        view.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView page, WebResourceRequest request) {
                return bundledAsset(context, request);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView page, WebResourceRequest request) {
                return true;
            }

            @Override public void onPageFinished(WebView page, String url) {
                if (view != page || port != null || !PAGE.equals(url)) return;
                WebMessagePort[] channel = page.createWebMessageChannel();
                port = channel[0];
                port.setWebMessageCallback(new WebMessagePort.WebMessageCallback() {
                    @Override public void onMessage(WebMessagePort sender, WebMessage output) {
                        if (port == sender) accept(output.getData());
                    }
                }, handler);
                page.postWebMessage(new WebMessage(message, new WebMessagePort[] {channel[1]}),
                        Uri.parse(ORIGIN));
            }

            @Override public void onReceivedError(WebView page, WebResourceRequest request,
                                                  WebResourceError error) {
                if (view == page && request.isForMainFrame()) fail("Не удалось открыть локальную песочницу.");
            }

            @Override public boolean onRenderProcessGone(WebView page, RenderProcessGoneDetail detail) {
                if (view == page) fail("Песочница завершилась. Проверь объём памяти, который использует код.");
                return true;
            }
        });
        handler.postDelayed(deadline, 40_000);
        view.loadUrl(PAGE);
    }

    private static WebResourceResponse bundledAsset(Context context, WebResourceRequest request) {
        Uri url = request.getUrl();
        String path = url.getEncodedPath();
        if (!"GET".equals(request.getMethod()) || !"https".equals(url.getScheme())
                || !HOST.equals(url.getEncodedAuthority()) || path == null) {
            return denied();
        }
        String type;
        switch (path) {
            case "/index.html": type = "text/html"; break;
            case "/runner.js":
            case "/worker.mjs":
            case "/pyodide/pyodide.mjs":
            case "/pyodide/pyodide.asm.mjs": type = "application/javascript"; break;
            case "/pyodide/pyodide.asm.wasm": type = "application/wasm"; break;
            case "/pyodide/pyodide-lock.json": type = "application/json"; break;
            case "/pyodide/python_stdlib.zip": type = "application/zip"; break;
            default: return denied();
        }
        try {
            Map<String, String> headers = new HashMap<>();
            headers.put("Content-Security-Policy", CSP);
            headers.put("X-Content-Type-Options", "nosniff");
            headers.put("Cache-Control", "no-store");
            return new WebResourceResponse(type, null, 200, "OK", headers,
                    context.getAssets().open("sandbox" + path));
        } catch (IOException e) {
            return denied();
        }
    }

    private static WebResourceResponse denied() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden",
                java.util.Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    private void accept(String message) {
        SandboxClient.Result output;
        try {
            JSONObject json = new JSONObject(message);
            if (json.has("error")) {
                fail(json.getString("error"));
                return;
            }
            Integer code = json.isNull("code") ? null : json.getInt("code");
            output = new SandboxClient.Result(json.getString("stdout"),
                    json.getString("stderr"), json.getString("engine"), code, json.optString("status"));
        } catch (JSONException | RuntimeException e) {
            fail("Не удалось прочитать вывод локальной песочницы.");
            return;
        }
        close();
        result.accept(output);
    }

    private void fail(String message) {
        close();
        problem.accept(message);
    }

    void close() {
        handler.removeCallbacks(deadline);
        if (port != null) {
            port.close();
            port = null;
        }
        if (view != null) {
            WebView previous = view;
            view = null;
            previous.destroy();
        }
    }
}
