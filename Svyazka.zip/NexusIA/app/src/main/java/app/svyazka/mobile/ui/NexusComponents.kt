package app.svyazka.mobile.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import app.svyazka.mobile.R

@Composable
fun NexusTopBar(ui: NexusComposeUi) {
    val title = when (ui.page) {
        NexusComposeUi.Page.TASK -> stringResource(R.string.app_name)
        NexusComposeUi.Page.RESULT -> stringResource(R.string.result_title)
        NexusComposeUi.Page.MODELS -> stringResource(R.string.models_title)
        NexusComposeUi.Page.HISTORY -> stringResource(R.string.history_title)
        NexusComposeUi.Page.SETTINGS -> stringResource(R.string.settings_title)
    }
    Surface(modifier = Modifier.statusBarsPadding(),
        color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
        Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically) {
            if (ui.page == NexusComposeUi.Page.TASK) {
                Image(painterResource(R.drawable.ic_nexus), null, Modifier.size(43.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    "Nexus IA",
                    style = MaterialTheme.typography.titleLarge.copy(
                        brush = Brush.horizontalGradient(
                            listOf(MaterialTheme.colorScheme.onBackground, NexusCyan)
                        )
                    )
                )
            } else {
                IconButton(onClick = { ui.navigateBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.action_back))
                }
                Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            }
            if (ui.page == NexusComposeUi.Page.TASK) {
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { ui.open(NexusComposeUi.Page.SETTINGS) }) {
                    Icon(Icons.Outlined.Settings, stringResource(R.string.settings_title))
                }
            }
        }
    }
}

@Composable
fun NexusCard(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    val isDark = MaterialTheme.colorScheme.background == NexusNavy
    val borderColor = NexusCyan.copy(alpha = if (highlighted) .7f else if (isDark) .3f else .22f)
    val decorated = modifier.shadow(
        elevation = if (highlighted) 9.dp else 4.dp,
        shape = shape,
        ambientColor = if (highlighted) NexusCyan.copy(alpha = .15f) else Color.Black.copy(alpha = .14f),
        spotColor = if (highlighted) NexusCyan.copy(alpha = .18f) else Color.Black.copy(alpha = .16f)
    )
    val stroke = BorderStroke(if (highlighted) 1.2.dp else .8.dp, borderColor)
    if (onClick == null) {
        Surface(modifier = decorated, shape = shape, color = MaterialTheme.colorScheme.surface,
            border = stroke) { Column(Modifier.padding(16.dp), content = content) }
    } else {
        Surface(onClick = onClick, modifier = decorated, shape = shape,
            color = MaterialTheme.colorScheme.surface, border = stroke) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
fun NexusLabel(text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Text(text, color = color, style = MaterialTheme.typography.bodyMedium)
}

@Composable
fun StatusPill(label: String, success: Boolean = false) {
    val foreground = if (success) Color(0xFF27D6A6) else MaterialTheme.colorScheme.primary
    Surface(shape = RoundedCornerShape(50), color = foreground.copy(alpha = .15f),
        border = BorderStroke(1.dp, foreground.copy(alpha = .38f))) {
        Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            color = foreground, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun KeyStatusPill(label: String, configured: Boolean) {
    val isDark = MaterialTheme.colorScheme.background == NexusNavy
    val accent = if (configured) {
        if (isDark) Color(0xFF38E2AD) else Color(0xFF086E48)
    } else {
        if (isDark) Color(0xFFFF8B93) else Color(0xFFAC2634)
    }
    Surface(shape = RoundedCornerShape(50), color = accent.copy(alpha = .2f),
        border = BorderStroke(.8.dp, accent.copy(alpha = .35f))) {
        Text(label, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
            color = accent, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun NexusPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable () -> Unit)? = null
) {
    val shape = RoundedCornerShape(18.dp)
    val colors = if (enabled) listOf(NexusCyan, NexusBlue)
        else listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline)
    val ink = if (enabled) Color(0xFF061824) else MaterialTheme.colorScheme.onSurfaceVariant
    Box(modifier = modifier
        .shadow(if (enabled) 8.dp else 0.dp, shape,
            ambientColor = NexusCyan.copy(alpha = if (enabled) .25f else 0f),
            spotColor = NexusBlue.copy(alpha = if (enabled) .22f else 0f))
        .background(Brush.horizontalGradient(colors), shape)
        .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
        .heightIn(min = 54.dp)
        .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center) {
        Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            if (leadingIcon != null) {
                androidx.compose.runtime.CompositionLocalProvider(LocalContentColor provides ink) {
                    leadingIcon()
                }
                Spacer(Modifier.width(8.dp))
            }
            Text(text, color = ink, style = MaterialTheme.typography.labelLarge)
        }
    }
}

/** Three isometric AI layers, rendered by Canvas with no bitmap dependency. */
@Composable
fun NexusAiStack(modifier: Modifier = Modifier) {
    Box(modifier = modifier) {
        Canvas(Modifier.fillMaxSize()) {
        val unit = size.minDimension
        fun diamond(y: Float, w: Float, h: Float): Path = Path().apply {
            moveTo(size.width / 2f, y - h / 2f)
            lineTo(size.width / 2f + w / 2f, y)
            lineTo(size.width / 2f, y + h / 2f)
            lineTo(size.width / 2f - w / 2f, y)
            close()
        }
        for (layer in 0..2) {
            val y = unit * (.68f - layer * .18f)
            val w = unit * (if (layer == 2) .68f else .8f)
            val h = unit * .25f
            val top = diamond(y, w, h)
            val side = Path().apply {
                moveTo(size.width / 2f - w / 2f, y)
                lineTo(size.width / 2f, y + h / 2f)
                lineTo(size.width / 2f + w / 2f, y)
                lineTo(size.width / 2f + w / 2f, y + unit * .11f)
                lineTo(size.width / 2f, y + h / 2f + unit * .11f)
                lineTo(size.width / 2f - w / 2f, y + unit * .11f)
                close()
            }
            drawPath(side, Brush.verticalGradient(listOf(NexusBlue.copy(alpha = .62f),
                NexusCyan.copy(alpha = .36f))))
            drawPath(top, Brush.linearGradient(listOf(Color(0xFF2262AA), NexusBlue, NexusCyan)))
            drawPath(top, NexusCyan.copy(alpha = .78f), style = Stroke(width = unit * .012f))
        }
        drawCircle(brush = Brush.radialGradient(listOf(Color.White.copy(alpha = .8f),
            NexusCyan.copy(alpha = .43f), Color.Transparent)),
            radius = unit * .16f, center = Offset(size.width / 2f, unit * .32f))
        }
        Text("AI", modifier = Modifier.align(Alignment.Center).offset(y = (-8).dp),
            color = Color.White, style = MaterialTheme.typography.titleMedium)
    }
}

/** No HTML rendering and no network. Plain text, headings, fences and common Markdown spans. */
internal data class MarkdownBlock(val kind: String, val value: String)

internal fun parseMarkdown(source: String): List<MarkdownBlock> {
    val out = ArrayList<MarkdownBlock>()
    val lines = source.replace("\r\n", "\n").split('\n')
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trimStart()
        if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
            val marker = trimmed.takeWhile { it == trimmed[0] }
            val code = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trimStart().startsWith(marker)) {
                if (code.isNotEmpty()) code.append('\n')
                code.append(lines[i]); i++
            }
            out.add(MarkdownBlock("code", code.toString()))
        } else if (trimmed.startsWith("#") && trimmed.takeWhile { it == '#' }.length in 1..6 &&
            trimmed.dropWhile { it == '#' }.startsWith(' ')) {
            out.add(MarkdownBlock("heading", trimmed.dropWhile { it == '#' }.trim()))
        } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ") ||
            Regex("^\\d+[.)] ").containsMatchIn(trimmed)) {
            out.add(MarkdownBlock("bullet", trimmed))
        } else if (line.isNotBlank()) {
            out.add(MarkdownBlock("body", line))
        } else if (out.isNotEmpty() && out.last().kind != "space") {
            out.add(MarkdownBlock("space", ""))
        }
        i++
    }
    return out
}

internal fun inlineMarkup(source: String) = buildAnnotatedString {
    val pattern = Regex("(`[^`\\n]+`|\\*\\*[^*\\n]+\\*\\*|\\*[^*\\n]+\\*)")
    var previous = 0
    pattern.findAll(source).forEach { match ->
        append(source.substring(previous, match.range.first))
        val word = match.value
        when {
            word.startsWith("**") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                append(word.drop(2).dropLast(2))
            }
            word.startsWith('`') -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace)) {
                append(word.drop(1).dropLast(1))
            }
            else -> withStyle(SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)) {
                append(word.drop(1).dropLast(1))
            }
        }
        previous = match.range.last + 1
    }
    append(source.substring(previous))
}

@Composable
fun NexusMarkdown(markdown: String) {
    val blocks = remember(markdown) { parseMarkdown(markdown) }
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            blocks.forEach { block ->
                when (block.kind) {
                    "code" -> Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.background,
                        border = BorderStroke(.7.dp, MaterialTheme.colorScheme.outline.copy(alpha = .5f))
                    ) {
                        Text(block.value, Modifier.fillMaxWidth().padding(12.dp),
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    "heading" -> Text(inlineMarkup(block.value),
                        style = MaterialTheme.typography.titleLarge)
                    "bullet" -> Text(inlineMarkup(block.value),
                        style = MaterialTheme.typography.bodyMedium)
                    "space" -> Spacer(Modifier.height(4.dp))
                    else -> Text(inlineMarkup(block.value), style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
